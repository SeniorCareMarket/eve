(ns com.seniorcaremarket.eve-sab-deftype.jvm-benchmark
  "JVM Clojure benchmark — equivalent scenarios to the CLJS wild-data-benchmark,
   plus multi-threaded contention tests using real JVM threads.

   Domains:
   1. E-commerce catalog — 2000 products with nested specs/pricing/tags
   2. User activity stream — 5000 events with metadata
   3. Configuration tree — 5-level deep nesting, mixed types
   4. Social profiles — 1000 users with friend-vecs + post-vecs
   5. Metrics dashboard — 3000 metric points with labels

   Contention tests:
   - Write-only: multiple threads swapping into shared atom
   - Read-heavy: multiple threads reading shared atom + occasional writes
   - Mixed: read-compute-write cycles under contention
   - Scaling: 1/2/4/8 threads on same workload

   Run with: cd scm-eve && clojure -M:jvm-benchmark"
  (:import [java.util Arrays]
           [java.util.concurrent CyclicBarrier CountDownLatch]))

;;=============================================================================
;; Infrastructure
;;=============================================================================

(defn bench [f & {:keys [iters warmup] :or {iters 200 warmup 50}}]
  (dotimes [_ warmup] (f))
  (let [times (double-array iters)]
    (dotimes [i iters]
      (let [start (System/nanoTime)]
        (f)
        (aset times i (/ (double (- (System/nanoTime) start)) 1000.0))))
    (Arrays/sort times)
    (let [sum (areduce times i ret 0.0 (+ ret (aget times i)))
          mean-us (/ sum (double iters))
          median-us (aget times (quot iters 2))]
      {:mean-us mean-us
       :median-us median-us
       :ops-s (if (pos? mean-us) (/ 1.0e6 mean-us) 0.0)})))

(defn fmt-us [us]
  (cond
    (< us 1) (str (Math/round (* us 1000.0)) "ns")
    (< us 1000) (format "%.2fus" (double us))
    :else (format "%.2fms" (/ (double us) 1000.0))))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (format "%.2fM" (/ (double ops) 1e6))
    (>= ops 1e3) (format "%.1fK" (/ (double ops) 1e3))
    :else (format "%.1f" (double ops))))

(defn lpad [s n]
  (let [s (str s)]
    (if (>= (count s) n) s
        (str (apply str (repeat (- n (count s)) \space)) s))))

(defn rpad [s n]
  (let [s (str s)]
    (if (>= (count s) n) s
        (str s (apply str (repeat (- n (count s)) \space))))))

(def ^:private results (atom []))

(defn record! [domain scenario n result]
  (swap! results conj {:domain domain :scenario scenario :n n :result result}))

;;=============================================================================
;; Deterministic pseudo-random
;;=============================================================================

(defn prng [seed]
  (let [s (unchecked-int seed)
        x (bit-xor s (bit-shift-left s 13))
        x (bit-xor x (unsigned-bit-shift-right x 17))
        x (bit-xor x (bit-shift-left x 5))]
    (bit-and x 0x7FFFFFFF)))

;;=============================================================================
;; Domain 1: E-Commerce Catalog (2000 products)
;;=============================================================================

(def ^:const CATALOG-SIZE 2000)
(def categories [:electronics :clothing :food :tools :books :toys :sports :home
                 :garden :automotive :health :beauty :office :music :pets])
(def brands ["Acme" "GlobalTech" "EcoGoods" "PrimeLine" "NovaCo" "ZenithCorp"
             "AlphaWare" "BetaBuild" "GammaProd" "DeltaMfg"])
(def colors [:red :blue :green :black :white :silver :gold :navy :forest :coral])

(defn gen-product [^long i]
  {:id i
   :sku (str "SKU-" (format "%06d" i))
   :name (str (nth brands (mod i (count brands))) " "
              (name (nth categories (mod i (count categories)))) " #" i)
   :category (nth categories (mod i (count categories)))
   :brand (nth brands (mod i (count brands)))
   :price (+ 0.99 (* (mod (* i 13) 500) 0.97))
   :cost (+ 0.50 (* (mod (* i 7) 300) 0.63))
   :stock (mod (* i 17) 2000)
   :active (zero? (mod i 5))
   :featured (zero? (mod i 23))
   :rating (+ 1.0 (* (mod (* i 11) 40) 0.1))
   :review-count (mod (* i 31) 500)
   :color (nth colors (mod i (count colors)))
   :weight-kg (+ 0.1 (* (mod (* i 19) 100) 0.15))
   :tags [(keyword (str "tag-" (mod i 20)))
          (keyword (str "season-" (mod i 4)))
          (keyword (str "tier-" (mod i 3)))]
   :specs {:width (+ 1 (mod (* i 3) 100))
           :height (+ 1 (mod (* i 5) 80))
           :depth (+ 1 (mod (* i 7) 60))
           :material (nth [:plastic :metal :wood :glass :fabric :ceramic] (mod i 6))}
   :pricing {:wholesale (+ 0.50 (* (mod (* i 7) 300) 0.50))
             :bulk-discount (+ 5 (mod (* i 3) 25))
             :min-order (+ 1 (mod i 50))}})

(defn build-catalog [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "p" i)) (gen-product i)) (inc i)))))

(defn bench-catalog-revenue [n]
  (print (str "    Building " n "-product catalog... "))
  (let [m (build-catalog n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k prod]
                      (if (:active prod) (+ acc (* (:price prod) (:stock prod))) acc))
                    0.0 m))
                 :iters 150 :warmup 30)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :catalog "revenue: price*stock active" n r)))

(defn bench-catalog-category-count [n]
  (print "    Category count... ")
  (let [m (build-catalog n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k prod]
                      (let [cat (:category prod)]
                        (assoc acc cat (inc (get acc cat 0)))))
                    {} m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :catalog "group-by category count" n r)))

(defn bench-catalog-margin [n]
  (print "    Margin analysis... ")
  (let [m (build-catalog n)
        r (bench (fn []
                   (let [result (reduce-kv
                                 (fn [acc _k prod]
                                   (let [margin (- (:price prod) (:cost prod))
                                         pct (/ margin (:price prod))]
                                     (if (> pct 0.3)
                                       {:sum (+ (:sum acc) pct) :cnt (inc (:cnt acc))}
                                       acc)))
                                 {:sum 0.0 :cnt 0} m)]
                     (when (pos? (:cnt result)) (/ (:sum result) (:cnt result)))))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :catalog "margin filter+avg (>30%)" n r)))

(defn bench-catalog-deep-access [n num-reads]
  (print (str "    " num-reads " deep reads... "))
  (let [keys-arr (object-array num-reads)
        _ (dotimes [i num-reads]
            (aset keys-arr i (keyword (str "p" (mod (bit-and (prng (* i 2654435761)) 0x7FFFFFFF) n)))))
        m (build-catalog n)
        r (bench (fn []
                   (dotimes [i num-reads]
                     (let [prod (get m (aget keys-arr i))]
                       (when prod
                         (get-in prod [:specs :width])
                         (get-in prod [:specs :material])
                         (get-in prod [:pricing :wholesale])
                         (get-in prod [:pricing :bulk-discount])))))
                 :iters 300 :warmup 50)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :catalog (str num-reads " deep nested reads") n r)))

(defn bench-catalog-batch-update [n num-updates]
  (print (str "    " num-updates " nested assoc updates... "))
  (let [keys-arr (object-array num-updates)
        _ (dotimes [i num-updates]
            (aset keys-arr i (keyword (str "p" (mod (bit-and (prng (* i 7919)) 0x7FFFFFFF) n)))))
        m (build-catalog n)
        r (bench (fn []
                   (loop [m m i 0]
                     (if (>= i num-updates) m
                         (let [k (aget keys-arr i)
                               prod (get m k)]
                           (recur (if prod (assoc m k (assoc prod :price (* (:price prod) 1.05))) m)
                                  (inc i))))))
                 :iters 50 :warmup 10)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :catalog (str num-updates " nested assoc updates") n r)))

;;=============================================================================
;; Domain 2: Activity Stream (5000 events)
;;=============================================================================

(def ^:const STREAM-SIZE 5000)
(def actions [:page-view :click :purchase :add-cart :remove-cart :search
              :login :logout :share :bookmark :review :signup])

(defn gen-event [^long i]
  {:event-id i
   :user-id (mod i 500)
   :action (nth actions (mod i (count actions)))
   :timestamp (+ 1700000000 (* i 60))
   :session (str "sess-" (mod i 200))
   :page (str "/page/" (mod (* i 7) 100))
   :duration-ms (+ 100 (mod (* i 37) 30000))
   :metadata {:device (nth [:mobile :desktop :tablet] (mod i 3))
              :browser (nth [:chrome :firefox :safari :edge] (mod i 4))
              :country (nth [:us :uk :de :fr :jp :br :au :ca :in :mx] (mod i 10))}
   :value (when (zero? (mod i 3)) (+ 1.0 (* (mod (* i 11) 200) 0.99)))})

(defn build-stream [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "e" i)) (gen-event i)) (inc i)))))

(defn bench-stream-purchase-revenue [n]
  (print (str "    Building " n "-event stream... "))
  (let [m (build-stream n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k evt]
                      (if (and (= :purchase (:action evt)) (:value evt))
                        (+ acc (double (:value evt))) acc))
                    0.0 m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :stream "purchase revenue sum" n r)))

(defn bench-stream-user-action-count [n]
  (print "    User action count... ")
  (let [m (build-stream n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k evt]
                      (let [uid (:user-id evt)]
                        (assoc acc uid (inc (get acc uid 0)))))
                    {} m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :stream "group-by user action count" n r)))

(defn bench-stream-device-breakdown [n]
  (print "    Device breakdown... ")
  (let [m (build-stream n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k evt]
                      (let [device (get-in evt [:metadata :device])]
                        (assoc acc device (inc (get acc device 0)))))
                    {} m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :stream "device breakdown (nested)" n r)))

(defn bench-stream-pipeline [n]
  (print "    Desktop+highDur pipeline... ")
  (let [m (build-stream n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k evt]
                      (if (and (= :desktop (get-in evt [:metadata :device]))
                               (> (:duration-ms evt) 5000)
                               (:value evt))
                        {:sum (+ (:sum acc) (double (:value evt))) :cnt (inc (:cnt acc))}
                        acc))
                    {:sum 0.0 :cnt 0} m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :stream "desktop+highDur pipeline" n r)))

;;=============================================================================
;; Domain 3: Configuration Tree
;;=============================================================================

(defn gen-config-tree []
  {:app {:name "eve-platform"
         :version "3.14.159"
         :debug false
         :features {:dark-mode true
                    :notifications {:email true :sms false :push true
                                    :frequency :daily :quiet-hours [22 7]}
                    :analytics {:enabled true :sample-rate 0.1 :provider "mixpanel"
                                :events [:page-view :click :purchase :signup]}
                    :caching {:strategy :lru :max-size 10000 :ttl-ms 300000
                              :layers {:l1 {:size 1000 :type :memory}
                                       :l2 {:size 10000 :type :disk}
                                       :l3 {:size 100000 :type :redis}}}}}
   :database {:primary {:host "db-primary.internal"
                        :port 5432 :name "eve_prod"
                        :pool {:min 5 :max 50 :idle-timeout 30000}
                        :ssl {:enabled true :ca-cert "/certs/ca.pem"}}
              :replica {:host "db-replica.internal"
                        :port 5432 :name "eve_prod"
                        :pool {:min 2 :max 20 :idle-timeout 60000}}
              :redis {:host "redis.internal" :port 6379 :db 0
                      :cluster {:enabled true :nodes 6 :replicas 2}}}
   :services (loop [m {} i 0]
               (if (>= i 20) m
                   (recur (assoc m (keyword (str "svc-" i))
                                 {:url (str "https://svc-" i ".internal")
                                  :timeout-ms (+ 1000 (* i 500))
                                  :retries (+ 1 (mod i 5))
                                  :auth {:type (nth [:jwt :api-key :oauth2] (mod i 3))
                                         :secret (str "secret-" i)}
                                  :health {:interval-ms 10000 :threshold 3 :endpoint "/health"}})
                          (inc i))))
   :deployment {:environment :production :region "us-east-1" :replicas 12
                :autoscale {:min 3 :max 50 :target-cpu 70}
                :rollout {:strategy :canary :percentage 10 :interval-ms 60000}}
   :logging {:level :info
             :outputs {:console {:enabled true :format :json}
                       :file {:enabled true :path "/var/log/eve" :max-size-mb 100
                              :rotation {:count 10 :compress true}}
                       :remote {:enabled true :host "log.internal" :port 5514
                                :protocol :tcp :buffer-size 1000}}
             :sampling {:rate 0.01 :excluded [:health-check :metrics]}}
   :users (loop [m {} i 0]
            (if (>= i 50) m
                (recur (assoc m (keyword (str "u" i))
                              {:name (str "User " i)
                               :email (str "user" i "@example.com")
                               :role (nth [:admin :editor :viewer] (mod i 3))
                               :permissions [(keyword (str "perm-" (mod i 10)))
                                             (keyword (str "perm-" (mod (* i 3) 10)))]
                               :settings {:theme (nth [:dark :light :auto] (mod i 3))
                                          :lang (nth [:en :fr :de :ja :es] (mod i 5))
                                          :timezone (str "UTC" (if (zero? (mod i 2)) "+" "-") (mod i 12))}})
                       (inc i))))})

(defn bench-config-deep-reads [num-reads]
  (print (str "    " num-reads " deep get-in reads... "))
  (let [paths [[:app :name]
               [:app :features :dark-mode]
               [:app :features :notifications :frequency]
               [:app :features :caching :strategy]
               [:app :features :caching :layers :l2 :type]
               [:database :primary :host]
               [:database :primary :pool :max]
               [:database :primary :ssl :enabled]
               [:database :redis :cluster :nodes]
               [:deployment :autoscale :target-cpu]
               [:logging :outputs :file :max-size-mb]
               [:logging :outputs :remote :protocol]
               [:logging :sampling :rate]
               [:deployment :rollout :strategy]
               [:app :features :analytics :provider]]
        path-arr (object-array num-reads)
        _ (dotimes [i num-reads] (aset path-arr i (nth paths (mod i (count paths)))))
        cfg (gen-config-tree)
        r (bench (fn []
                   (dotimes [i num-reads]
                     (get-in cfg (aget path-arr i))))
                 :iters 500 :warmup 100)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :config (str num-reads " deep get-in reads") 1 r)))

(defn bench-config-service-scan []
  (print "    Service health scan... ")
  (let [cfg (gen-config-tree)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc svc-key svc]
                      (if (> (:retries svc) 2)
                        (conj acc {:svc svc-key :timeout (:timeout-ms svc)
                                   :auth-type (get-in svc [:auth :type])})
                        acc))
                    [] (:services cfg)))
                 :iters 500 :warmup 100)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :config "service health scan (20 svcs)" 1 r)))

(defn bench-config-user-permissions []
  (print "    User permissions scan... ")
  (let [cfg (gen-config-tree)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k user]
                      (case (:role user)
                        :admin (update acc :admin-count inc)
                        :editor (update acc :editor-perms #(into % (:permissions user)))
                        acc))
                    {:admin-count 0 :editor-perms []}
                    (:users cfg)))
                 :iters 300 :warmup 50)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :config "user permissions scan (50 users)" 1 r)))

;;=============================================================================
;; Domain 4: Social Profiles (1000 users)
;;=============================================================================

(def ^:const SOCIAL-SIZE 1000)

(defn gen-social-profile [^long i ^long n]
  {:user-id i
   :username (str "user_" i)
   :display-name (str "User " i " " (nth ["Smith" "Jones" "Chen" "Garcia" "Kim"
                                           "Patel" "Brown" "Wilson" "Lee" "Taylor"] (mod i 10)))
   :bio (str "Bio for user " i ". Interests: "
             (name (nth [:coding :music :sports :travel :cooking
                         :reading :gaming :art :science :photography] (mod i 10))))
   :verified (zero? (mod i 7))
   :follower-count (* i 10)
   :following-count (+ 50 (mod (* i 13) 500))
   :joined-year (+ 2015 (mod i 10))
   :friends (let [num-friends (+ 10 (mod (* i 7) 21))]
              (loop [v [] j 0]
                (if (>= j num-friends) v
                    (recur (conj v (mod (+ i (* j 37) 7) n)) (inc j)))))
   :posts (loop [v [] j 0]
            (if (>= j 5) v
                (recur (conj v {:post-id (+ (* i 100) j)
                                :text (str "Post " j " by user " i)
                                :likes (mod (* (+ (* i 100) j) 11) 1000)
                                :timestamp (+ 1700000000 (* j 3600))
                                :tags [(keyword (str "topic-" (mod j 8)))]})
                       (inc j))))
   :settings {:privacy (nth [:public :friends :private] (mod i 3))
              :notifications true
              :theme (nth [:light :dark :auto] (mod i 3))}})

(defn build-social [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "u" i)) (gen-social-profile i n)) (inc i)))))

(defn bench-social-total-likes [n]
  (print (str "    Building " n "-user social graph... "))
  (let [m (build-social n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k profile]
                      (+ acc (long (reduce (fn [s post] (+ s (long (:likes post)))) 0 (:posts profile)))))
                    0 m))
                 :iters 80 :warmup 15)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :social "total post likes (nested reduce)" n r)))

(defn bench-social-verified-influencers [n]
  (print "    Verified influencers... ")
  (let [threshold (* n 5)
        m (build-social n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k profile]
                      (if (and (:verified profile) (> (:follower-count profile) threshold))
                        (conj acc {:name (:display-name profile) :followers (:follower-count profile)})
                        acc))
                    [] m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :social "verified influencers filter" n r)))

(defn bench-social-friend-lookup [n num-lookups]
  (print (str "    " num-lookups " friend-of-friend joins... "))
  (let [user-keys (object-array num-lookups)
        _ (dotimes [i num-lookups]
            (aset user-keys i (keyword (str "u" (mod (bit-and (prng (* i 9973)) 0x7FFFFFFF) n)))))
        m (build-social n)
        r (bench (fn []
                   (dotimes [i num-lookups]
                     (let [profile (get m (aget user-keys i))]
                       (when profile
                         (let [friends (:friends profile)]
                           (dotimes [j (min 5 (count friends))]
                             (let [friend-id (nth friends j)]
                               (when-let [fp (get m (keyword (str "u" friend-id)))]
                                 (:username fp)))))))))
                 :iters 200 :warmup 40)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :social (str num-lookups " friend-of-friend joins") n r)))

(defn bench-social-privacy-scan [n]
  (print "    Privacy scan... ")
  (let [m (build-social n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k profile]
                      (let [privacy (get-in profile [:settings :privacy])]
                        (-> acc
                            (update privacy (fnil inc 0))
                            (cond->
                              (= :public privacy)
                              (update :public-bios (fnil conj []) (:bio profile))))))
                    {} m))
                 :iters 80 :warmup 15)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :social "privacy scan (nested access)" n r)))

;;=============================================================================
;; Domain 5: Metrics Dashboard (3000 points)
;;=============================================================================

(def ^:const METRICS-SIZE 3000)
(def metric-names [:cpu-usage :memory-mb :disk-io :network-in :network-out
                   :request-count :error-rate :latency-p50 :latency-p99
                   :gc-pause :thread-count :queue-depth])
(def hosts ["web-1" "web-2" "web-3" "api-1" "api-2" "api-3"
            "worker-1" "worker-2" "db-1" "db-2" "cache-1" "cache-2"])

(defn gen-metric [^long i]
  (let [metric-name (nth metric-names (mod i (count metric-names)))
        host (nth hosts (mod (quot i (count metric-names)) (count hosts)))]
    {:metric metric-name
     :host host
     :timestamp (+ 1700000000 (* i 10))
     :value (case metric-name
              :cpu-usage (+ 10.0 (mod (* i 7) 90))
              :memory-mb (+ 500.0 (mod (* i 13) 3500))
              :disk-io (+ 0.0 (mod (* i 17) 10000))
              :network-in (+ 100.0 (mod (* i 23) 50000))
              :network-out (+ 50.0 (mod (* i 29) 30000))
              :request-count (mod (* i 37) 5000)
              :error-rate (/ (mod (* i 3) 100) 1000.0)
              :latency-p50 (+ 1.0 (mod (* i 11) 200))
              :latency-p99 (+ 10.0 (mod (* i 19) 2000))
              :gc-pause (+ 0.1 (/ (mod (* i 31) 500) 100.0))
              :thread-count (+ 10 (mod (* i 41) 200))
              :queue-depth (mod (* i 43) 1000))
     :unit (case metric-name
             :cpu-usage :percent
             :memory-mb :mb
             (:disk-io :network-in :network-out) :bytes-per-sec
             :request-count :count
             :error-rate :ratio
             (:latency-p50 :latency-p99 :gc-pause) :ms
             :thread-count :count
             :queue-depth :count)
     :tags {:env :production
            :region (nth [:us-east :us-west :eu-west :ap-east] (mod i 4))
            :tier (nth [:frontend :backend :data :infra] (mod i 4))}}))

(defn build-metrics [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "m" i)) (gen-metric i)) (inc i)))))

(defn bench-metrics-cpu-avg [n]
  (print (str "    Building " n "-point metrics... "))
  (let [m (build-metrics n)
        r (bench (fn []
                   (let [by-host (reduce-kv
                                  (fn [acc _k pt]
                                    (if (= :cpu-usage (:metric pt))
                                      (let [h (:host pt)
                                            prev (get acc h {:sum 0.0 :cnt 0})]
                                        (assoc acc h {:sum (+ (:sum prev) (double (:value pt)))
                                                      :cnt (inc (:cnt prev))}))
                                      acc))
                                  {} m)]
                     (reduce-kv (fn [acc h {:keys [sum cnt]}]
                                  (assoc acc h (/ (double sum) (double cnt))))
                                {} by-host)))
                 :iters 80 :warmup 15)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :metrics "per-host CPU avg (filter+group)" n r)))

(defn bench-metrics-error-hotspots [n]
  (print "    Error hotspots... ")
  (let [m (build-metrics n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k pt]
                      (if (and (= :error-rate (:metric pt)) (> (double (:value pt)) 0.05))
                        (conj acc {:host (:host pt) :rate (:value pt)
                                   :region (get-in pt [:tags :region])
                                   :tier (get-in pt [:tags :tier])})
                        acc))
                    [] m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :metrics "error hotspots (filter+nested)" n r)))

(defn bench-metrics-latency-summary [n]
  (print "    Latency p99 summary... ")
  (let [m (build-metrics n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k pt]
                      (if (= :latency-p99 (:metric pt))
                        (let [v (double (:value pt))]
                          {:min (min (double (:min acc)) v)
                           :max (max (double (:max acc)) v)
                           :sum (+ (double (:sum acc)) v)
                           :cnt (inc (:cnt acc))})
                        acc))
                    {:min Double/POSITIVE_INFINITY :max Double/NEGATIVE_INFINITY
                     :sum 0.0 :cnt 0}
                    m))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :metrics "latency-p99 min/max/sum" n r)))

(defn bench-metrics-region-tier [n]
  (print "    Region×tier group-by... ")
  (let [m (build-metrics n)
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k pt]
                      (let [region (get-in pt [:tags :region])
                            tier (get-in pt [:tags :tier])
                            inner (get acc region {})]
                        (assoc acc region (assoc inner tier (inc (get inner tier 0))))))
                    {} m))
                 :iters 80 :warmup 15)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :metrics "region×tier 2-level group-by" n r)))

;;=============================================================================
;; Cross-Domain: Mixed Collection Types
;;=============================================================================

(defn bench-vec-of-maps [n]
  (print (str "    Vec of " n " maps... "))
  (let [gen-item (fn [i]
                   {:id i :type (nth [:product :user :event :metric] (mod i 4))
                    :value (* i 1.5) :active (zero? (mod i 3))
                    :label (str "item-" i)
                    :tags [(keyword (str "t" (mod i 10))) (keyword (str "g" (mod i 5)))]})
        v (vec (map gen-item (range n)))
        r (bench (fn []
                   (reduce (fn [acc item]
                             (if (:active item) (+ acc (double (:value item))) acc))
                           0.0 v))
                 :iters 100 :warmup 20)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :mixed "vec-of-maps active sum" n r)))

(defn bench-map-of-sets [n]
  (print (str "    Map of " n " sets... "))
  (let [gen-set (fn [i] (set (range i (+ i 10 (mod i 11)))))
        m (loop [m {} i 0]
            (if (>= i n) m
                (recur (assoc m (keyword (str "s" i)) (gen-set i)) (inc i))))
        r (bench (fn []
                   (reduce-kv
                    (fn [acc _k s] (if (contains? s 50) (inc acc) acc))
                    0 m))
                 :iters 200 :warmup 40)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :mixed "map-of-sets membership scan" n r)))

(defn bench-atom-workflow [map-size]
  (print (str "    Atom read-compute-write (" map-size " entries)... "))
  (let [data (loop [m {} i 0]
               (if (>= i map-size) m
                   (recur (assoc m (keyword (str "k" i))
                                 {:count (mod (* i 7) 100) :total (* i 2.5) :label (str "item-" i)})
                          (inc i))))
        a (atom data)
        r (bench (fn []
                   (let [s @a
                         max-entry (reduce-kv
                                    (fn [best _k v]
                                      (if (> (:count v) (:count best)) v best))
                                    {:count -1} s)]
                     (swap! a (fn [m]
                                (reduce-kv
                                 (fn [acc k v]
                                   (if (= (:count v) (:count max-entry))
                                     (assoc acc k (update v :count inc))
                                     acc))
                                 m m)))))
                 :iters 30 :warmup 5)]
    (println (str (fmt-us (:mean-us r)) " (" (fmt-ops (:ops-s r)) "/s)"))
    (record! :mixed "atom: read-compute-write cycle" map-size r)))

;;=============================================================================
;; Multi-threaded Contention Benchmarks
;;=============================================================================

(def ^:private contention-results (atom []))

(defn bench-contention
  "Run a contention test with num-threads threads.
   setup-fn returns shared state, work-fn receives [state thread-id ops-count].
   All threads start simultaneously via CyclicBarrier."
  [desc num-threads ops-per-thread setup-fn work-fn]
  (let [state (setup-fn)
        barrier (CyclicBarrier. (inc num-threads))
        thread-times (long-array num-threads)]
    ;; Launch threads
    (let [threads (doall
                    (for [tid (range num-threads)]
                      (Thread.
                        (fn []
                          (.await barrier)
                          (let [start (System/nanoTime)]
                            (work-fn state tid ops-per-thread)
                            (aset thread-times tid (- (System/nanoTime) start)))))))]
      (doseq [^Thread t threads] (.start t))
      (.await barrier)  ;; release all threads simultaneously
      (let [wall-start (System/nanoTime)]
        (doseq [^Thread t threads] (.join t))
        (let [wall-ns (- (System/nanoTime) wall-start)
              wall-ms (/ (double wall-ns) 1e6)
              total-ops (* num-threads ops-per-thread)
              throughput (/ (* (double total-ops) 1e3) wall-ms)
              max-thread-ms (/ (double (apply max (seq (vec thread-times)))) 1e6)
              min-thread-ms (/ (double (apply min (seq (vec thread-times)))) 1e6)]
          (swap! contention-results conj
                 {:desc desc :threads num-threads :ops-per-thread ops-per-thread
                  :wall-ms wall-ms :total-ops total-ops :throughput throughput
                  :max-thread-ms max-thread-ms :min-thread-ms min-thread-ms})
          {:wall-ms wall-ms :throughput throughput
           :max-thread-ms max-thread-ms :min-thread-ms min-thread-ms})))))

;; Contention 1: Write-only — all threads assoc into shared atom
(defn bench-write-contention [num-threads ops-per-thread map-size]
  (print (str "    " num-threads " threads × " ops-per-thread " writes (map-size=" map-size ")... "))
  (let [r (bench-contention
            (str "write-only " num-threads "T")
            num-threads ops-per-thread
            (fn []
              (atom (loop [m {} i 0]
                      (if (>= i map-size) m
                          (recur (assoc m (keyword (str "k" i)) i) (inc i))))))
            (fn [state tid ops]
              (dotimes [i ops]
                (let [k (keyword (str "t" tid "k" i))]
                  (swap! state assoc k (* tid 1000 (inc i)))))))]
    (println (format "%.1fms, %s ops/s" (:wall-ms r) (fmt-ops (:throughput r))))))

;; Contention 2: Read-heavy — 90% reads, 10% writes
(defn bench-read-heavy-contention [num-threads ops-per-thread map-size]
  (print (str "    " num-threads " threads × " ops-per-thread " ops (90/10 r/w, map-size=" map-size ")... "))
  (let [read-keys (vec (map #(keyword (str "k" %)) (range map-size)))
        r (bench-contention
            (str "read-heavy " num-threads "T")
            num-threads ops-per-thread
            (fn []
              (atom (loop [m {} i 0]
                      (if (>= i map-size) m
                          (recur (assoc m (keyword (str "k" i)) {:val i :count 0}) (inc i))))))
            (fn [state tid ops]
              (dotimes [i ops]
                (if (zero? (mod i 10))
                  ;; Write: increment a count
                  (let [k (nth read-keys (mod (+ (* tid 97) i) map-size))]
                    (swap! state update-in [k :count] inc))
                  ;; Read: access value
                  (let [k (nth read-keys (mod (+ (* tid 31) i) map-size))
                        s @state]
                    (get-in s [k :val]))))))]
    (println (format "%.1fms, %s ops/s" (:wall-ms r) (fmt-ops (:throughput r))))))

;; Contention 3: Read-compute-write — deref, scan, swap
(defn bench-rcw-contention [num-threads ops-per-thread map-size]
  (print (str "    " num-threads " threads × " ops-per-thread " r-c-w cycles (map-size=" map-size ")... "))
  (let [r (bench-contention
            (str "rcw " num-threads "T")
            num-threads ops-per-thread
            (fn []
              (atom (loop [m {} i 0]
                      (if (>= i map-size) m
                          (recur (assoc m (keyword (str "k" i))
                                       {:count (mod (* i 7) 100) :total (* i 2.5)})
                                 (inc i))))))
            (fn [state _tid ops]
              (dotimes [_ ops]
                (let [s @state
                      max-entry (reduce-kv
                                  (fn [best _k v]
                                    (if (> (:count v) (:count best)) v best))
                                  {:count -1} s)]
                  (swap! state
                         (fn [m]
                           (reduce-kv
                            (fn [acc k v]
                              (if (= (:count v) (:count max-entry))
                                (assoc acc k (update v :count inc))
                                acc))
                            m m)))))))]
    (println (format "%.1fms, %s ops/s" (:wall-ms r) (fmt-ops (:throughput r))))))

;; Contention 4: Scaling curve — same total work, varying thread count
(defn bench-scaling-curve [total-ops map-size]
  (println (str "\n    Scaling curve: " total-ops " total writes, map-size=" map-size))
  (println (str "    " (rpad "Threads" 10) (rpad "Wall-ms" 12) (rpad "Throughput" 15) "Efficiency"))
  (println (str "    " (apply str (repeat 50 "-"))))
  (let [baseline (atom nil)]
    (doseq [n-threads [1 2 4 8]]
      (let [ops-per (quot total-ops n-threads)
            r (bench-contention
                (str "scale " n-threads "T")
                n-threads ops-per
                (fn []
                  (atom (loop [m {} i 0]
                          (if (>= i map-size) m
                              (recur (assoc m (keyword (str "k" i)) i) (inc i))))))
                (fn [state tid ops]
                  (dotimes [i ops]
                    (let [k (keyword (str "t" tid "k" i))]
                      (swap! state assoc k i)))))]
        (when (= n-threads 1) (reset! baseline (:throughput r)))
        (let [eff (if @baseline (/ (:throughput r) (double @baseline)) 1.0)]
          (println (str "    " (rpad n-threads 10)
                        (rpad (format "%.1f" (:wall-ms r)) 12)
                        (rpad (str (fmt-ops (:throughput r)) "/s") 15)
                        (format "%.2fx" eff))))))))

;;=============================================================================
;; Output
;;=============================================================================

(defn print-results []
  (let [results @results
        sep   "  +----------------------------------------------+------+-----------------+"
        hdr   "  | Scenario                                     |    n |       JVM       |"]
    (println sep)
    (println hdr)
    (println sep)
    (let [groups (group-by :domain results)]
      (doseq [domain [:catalog :stream :config :social :metrics :mixed]]
        (when-let [entries (get groups domain)]
          (doseq [{:keys [scenario n result]} entries]
            (let [op-str (str (name domain) ": " scenario)
                  op-str (if (> (count op-str) 44) (subs op-str 0 44) op-str)
                  r-str (str (fmt-us (:mean-us result)) " " (fmt-ops (:ops-s result)) "/s")]
              (println (str "  | " (rpad op-str 44) " | " (lpad n 4) " | " (lpad r-str 15) " |"))))
          (println sep))))))

(defn print-contention-summary []
  (let [results @contention-results]
    (println "\n  === Contention Test Results ===\n")
    (println (str "  " (rpad "Test" 25) (rpad "Threads" 10) (rpad "Wall-ms" 12)
                  (rpad "Throughput" 15) "Spread"))
    (println (str "  " (apply str (repeat 70 "-"))))
    (doseq [{:keys [desc threads wall-ms throughput max-thread-ms min-thread-ms]} results]
      (let [spread (if (pos? min-thread-ms) (format "%.1fx" (/ max-thread-ms min-thread-ms)) "N/A")]
        (println (str "  " (rpad desc 25) (rpad threads 10)
                      (rpad (format "%.1f" wall-ms) 12)
                      (rpad (str (fmt-ops throughput) "/s") 15)
                      spread))))))

;;=============================================================================
;; Main
;;=============================================================================

(defn -main [& _args]
  (reset! results [])
  (reset! contention-results [])

  (println "\n================================================================================")
  (println "  JVM Clojure Benchmark — Wild Data Scenarios + Multi-threaded Contention")
  (println (str "  JVM: " (System/getProperty "java.vm.name") " "
                (System/getProperty "java.vm.version")))
  (println (str "  Clojure: " (clojure-version)))
  (println (str "  CPUs: " (.availableProcessors (Runtime/getRuntime))))
  (println "================================================================================\n")

  ;; --- Domain 1: E-Commerce Catalog ---
  (println "  [Domain 1/5] E-Commerce Catalog (2000 products)\n")
  (bench-catalog-revenue CATALOG-SIZE)
  (bench-catalog-category-count CATALOG-SIZE)
  (bench-catalog-margin CATALOG-SIZE)
  (bench-catalog-deep-access CATALOG-SIZE 100)
  (bench-catalog-deep-access CATALOG-SIZE 300)
  (bench-catalog-batch-update CATALOG-SIZE 200)

  ;; --- Domain 2: Activity Stream ---
  (println "\n  [Domain 2/5] Activity Stream (5000 events)\n")
  (bench-stream-purchase-revenue STREAM-SIZE)
  (bench-stream-user-action-count STREAM-SIZE)
  (bench-stream-device-breakdown STREAM-SIZE)
  (bench-stream-pipeline STREAM-SIZE)

  ;; --- Domain 3: Config Tree ---
  (println "\n  [Domain 3/5] Configuration Tree (deep nesting)\n")
  (bench-config-deep-reads 200)
  (bench-config-deep-reads 500)
  (bench-config-service-scan)
  (bench-config-user-permissions)

  ;; --- Domain 4: Social Profiles ---
  (println "\n  [Domain 4/5] Social Profiles (1000 users)\n")
  (bench-social-total-likes SOCIAL-SIZE)
  (bench-social-verified-influencers SOCIAL-SIZE)
  (bench-social-friend-lookup SOCIAL-SIZE 50)
  (bench-social-friend-lookup SOCIAL-SIZE 100)
  (bench-social-privacy-scan SOCIAL-SIZE)

  ;; --- Domain 5: Metrics Dashboard ---
  (println "\n  [Domain 5/5] Metrics Dashboard (3000 points)\n")
  (bench-metrics-cpu-avg METRICS-SIZE)
  (bench-metrics-error-hotspots METRICS-SIZE)
  (bench-metrics-latency-summary METRICS-SIZE)
  (bench-metrics-region-tier METRICS-SIZE)

  ;; --- Cross-Domain: Mixed Types ---
  (println "\n  [Bonus] Mixed Collection Types\n")
  (bench-vec-of-maps 2000)
  (bench-map-of-sets 500)
  (bench-atom-workflow 500)

  ;; --- Results Table ---
  (println "\n  === Full Results ===\n")
  (print-results)

  ;; --- Contention Tests ---
  (println "\n================================================================================")
  (println "  Multi-threaded Contention Benchmarks")
  (println "================================================================================\n")

  ;; Write-only contention
  (println "  [1] Write-Only Contention (all threads assoc into shared atom)\n")
  (bench-write-contention 1 500 200)
  (bench-write-contention 2 250 200)
  (bench-write-contention 4 125 200)
  (bench-write-contention 8 62 200)

  ;; Read-heavy contention
  (println "\n  [2] Read-Heavy Contention (90% reads, 10% writes)\n")
  (bench-read-heavy-contention 1 5000 200)
  (bench-read-heavy-contention 2 2500 200)
  (bench-read-heavy-contention 4 1250 200)
  (bench-read-heavy-contention 8 625 200)

  ;; Read-compute-write cycles
  (println "\n  [3] Read-Compute-Write Contention (deref → scan → swap!)\n")
  (bench-rcw-contention 1 30 100)
  (bench-rcw-contention 2 15 100)
  (bench-rcw-contention 4 8 100)
  (bench-rcw-contention 8 4 100)

  ;; Scaling curve
  (println "\n  [4] Scaling Curve")
  (bench-scaling-curve 1000 200)

  ;; Contention summary
  (print-contention-summary)

  (println "\n  Legend: JVM Clojure persistent data structures (single-threaded domains)")
  (println "         Multi-threaded tests use Clojure atoms with CAS under real thread contention")
  (println "         Efficiency = throughput / single-thread-throughput (1.0 = linear scaling)")
  (println "\n================================================================================")

  (shutdown-agents))

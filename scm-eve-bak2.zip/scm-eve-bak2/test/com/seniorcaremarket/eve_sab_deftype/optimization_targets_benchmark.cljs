(ns com.seniorcaremarket.eve-sab-deftype.optimization-targets-benchmark
  "Targeted benchmarks for measuring optimization impact.

   Each benchmark targets a specific optimization pattern:
   1. Memory fragmentation - measures coalescing benefit
   2. Repeated field access - measures caching benefit
   3. Transient bulk ops - measures flat hashtable benefit
   4. Bit operations - measures SIMD benefit
   5. Value-only iteration - measures columnar K/V benefit

   Run with: npx shadow-cljs compile opt-targets-bench && node target/opt-targets-bench.js"
  (:require
   [cljs.test :refer [deftest is testing]]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as sab-set]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sab-vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sab-list]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Utilities
;;-----------------------------------------------------------------------------

(defn now [] (js/performance.now))

;; Note: SAB-backed structures use a fixed memory pool. Intermediate HAMT nodes
;; created during persistent operations accumulate until the atom root is swapped.
;; Larger buffers are needed for sustained churn compared to in-memory structures.
(defn fresh-env
  [& {:keys [sab-size max-blocks]
      :or {sab-size (* 64 1024 1024) max-blocks 65536}}]  ;; 64MB, 64K blocks default
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size sab-size :max-blocks max-blocks))
  (a/get-env a/*global-atom-instance*))

(def ^:dynamic *results* (atom {}))

(defn record! [category test-name metric value]
  (swap! *results* assoc-in [category test-name metric] value))

(defn format-ops [ops ms]
  (if (pos? ms)
    (str (.toFixed (/ (* ops 1000) ms) 0) " ops/s")
    "N/A"))

;;-----------------------------------------------------------------------------
;; 1. MEMORY FRAGMENTATION BENCHMARK
;;    Tests: Block coalescing effectiveness
;;    Pattern: Allocate many small blocks, free every other one, try to allocate large blocks
;;-----------------------------------------------------------------------------

(defn bench-memory-fragmentation []
  (println "\n=== MEMORY FRAGMENTATION BENCHMARK ===")
  (println "Pattern: Allocate/free cycles to measure coalescing effectiveness\n")

  ;; Test 1: Simple alloc/free cycle
  (println "  Test 1: Simple allocation cycles")
  (let [env (fresh-env :sab-size (* 8 1024 1024) :max-blocks 4096)
        n 500
        start (now)
        ;; Build map, then dissoc half the entries (should trigger frees)
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m i {:data (str "value-" i)}) (inc i))))
        ;; Dissoc every other entry
        m2 (loop [m m i 0]
             (if (>= i n) m (recur (if (even? i) (dissoc m i) m) (inc i))))
        ;; Now try to add new entries (should reuse freed space)
        m3 (loop [m m2 i n]
             (if (>= i (* 2 n)) m (recur (assoc m i {:data (str "new-" i)}) (inc i))))
        dur (- (now) start)]
    (record! :fragmentation "alloc-free-cycle" :duration-ms dur)
    (record! :fragmentation "alloc-free-cycle" :final-count (count m3))
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    Final map count: " (count m3)))
    (is (= (* 1.5 n) (count m3)) "Should have 750 entries after cycle"))

  ;; Test 2: Churn with dispose! - disposes each intermediate map
  ;; This properly frees ALL intermediate HAMT nodes
  (println "\n  Test 2: Persistent churn with dispose! (100 cycles, 20 entries)")
  (let [env (fresh-env :sab-size (* 32 1024 1024) :max-blocks 16384)
        cycles 100
        entries-per-cycle 20
        start (now)
        success (atom 0)
        failures (atom 0)
        last-error (atom nil)]
    (dotimes [cycle cycles]
      (try
        ;; Build map disposing each intermediate version
        (loop [m (sab-map/empty-sab-map) i 0]
          (if (>= i entries-per-cycle)
            (do
              ;; Verify and dispose final map
              (when (= entries-per-cycle (count m))
                (swap! success inc))
              (sab-map/dispose! m))
            (let [new-m (assoc m i {:c cycle :i i})]
              ;; Dispose old map (CRITICAL: frees intermediate nodes)
              (sab-map/dispose! m)
              (recur new-m (inc i)))))
        (catch :default e
          (reset! last-error (.-message e))
          (swap! failures inc))))
    (let [dur (- (now) start)]
      (record! :fragmentation "churn-with-dispose" :duration-ms dur)
      (record! :fragmentation "churn-with-dispose" :success @success)
      (record! :fragmentation "churn-with-dispose" :failures @failures)
      (println (str "    Duration: " (.toFixed dur 2) "ms"))
      (println (str "    Successful cycles: " @success "/" cycles))
      (println (str "    Failures (OOM): " @failures))
      (when @last-error
        (println (str "    Last error: " @last-error)))
      ;; With proper disposal of intermediates, should sustain churn
      (is (< @failures (/ cycles 10)) "Should have <10% OOM failures with dispose!"))))

;;-----------------------------------------------------------------------------
;; 2. REPEATED FIELD ACCESS BENCHMARK
;;    Tests: Cached deserialization benefit
;;    Pattern: Access same keys multiple times
;;-----------------------------------------------------------------------------

(defn bench-repeated-access []
  (println "\n=== REPEATED FIELD ACCESS BENCHMARK ===")
  (println "Pattern: Access same fields multiple times (caching target)\n")

  ;; Build a map with some values
  (let [_ (fresh-env)
        n 100
        reps 100
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n)
              m
              (recur (assoc m i {:id i
                                  :name (str "item-" i)
                                  :value (* i i)
                                  :nested {:a 1 :b 2 :c 3}})
                     (inc i))))]

    ;; Test 1: Sequential repeated access to same key
    (println "  Test 1: Repeated access to same key (100x each)")
    (let [start (now)
          _ (dotimes [key-idx 10]  ;; 10 different keys
              (dotimes [_ reps]    ;; 100 times each
                (get m key-idx)))
          dur (- (now) start)
          total-ops (* 10 reps)]
      (record! :repeated-access "same-key-100x" :duration-ms dur)
      (record! :repeated-access "same-key-100x" :ops total-ops)
      (println (str "    Duration: " (.toFixed dur 2) "ms"))
      (println (str "    " (format-ops total-ops dur))))

    ;; Test 2: Random access pattern
    (println "\n  Test 2: Random access pattern")
    (let [keys (repeatedly (* n reps) #(rand-int n))
          start (now)
          _ (doseq [k keys] (get m k))
          dur (- (now) start)
          total-ops (* n reps)]
      (record! :repeated-access "random-access" :duration-ms dur)
      (record! :repeated-access "random-access" :ops total-ops)
      (println (str "    Duration: " (.toFixed dur 2) "ms"))
      (println (str "    " (format-ops total-ops dur))))

    ;; Test 3: Hot key access (80% to 20% of keys)
    (println "\n  Test 3: Hot key pattern (80/20 distribution)")
    (let [hot-keys (range 20)  ;; 20% of keys
          cold-keys (range 20 n)
          accesses (concat (repeatedly (* n reps 0.8) #(rand-nth (vec hot-keys)))
                           (repeatedly (* n reps 0.2) #(rand-nth (vec cold-keys))))
          start (now)
          _ (doseq [k accesses] (get m k))
          dur (- (now) start)
          total-ops (count accesses)]
      (record! :repeated-access "hot-key-80-20" :duration-ms dur)
      (record! :repeated-access "hot-key-80-20" :ops total-ops)
      (println (str "    Duration: " (.toFixed dur 2) "ms"))
      (println (str "    " (format-ops total-ops dur))))))

;;-----------------------------------------------------------------------------
;; 3. TRANSIENT BULK OPERATIONS BENCHMARK
;;    Tests: Flat hashtable benefit
;;    Pattern: bulk assoc! to transient, then persistent!
;;-----------------------------------------------------------------------------

(defn bench-transient-bulk []
  (println "\n=== TRANSIENT BULK OPERATIONS BENCHMARK ===")
  (println "Pattern: Bulk assoc! to transients (flat hashtable target)\n")

  ;; Test 1: Build map via transient
  (println "  Test 1: Build map via transient (n=1000)")
  (let [_ (fresh-env)
        n 1000
        start (now)
        m (persistent!
           (loop [t (transient (sab-map/empty-sab-map)) i 0]
             (if (>= i n)
               t
               (recur (assoc! t i {:val i}) (inc i)))))
        dur (- (now) start)]
    (record! :transient-bulk "build-1000" :duration-ms dur)
    (record! :transient-bulk "build-1000" :ops n)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops n dur)))
    (is (= n (count m)) "Should have 1000 entries"))

  ;; Test 2: Compare persistent vs transient build
  (println "\n  Test 2: Persistent vs Transient comparison (n=500)")
  (let [_ (fresh-env)
        n 500
        ;; Persistent
        start-p (now)
        m-p (loop [m (sab-map/empty-sab-map) i 0]
              (if (>= i n) m (recur (assoc m i {:val i}) (inc i))))
        dur-p (- (now) start-p)

        ;; Transient
        _ (fresh-env)
        start-t (now)
        m-t (persistent!
             (loop [t (transient (sab-map/empty-sab-map)) i 0]
               (if (>= i n) t (recur (assoc! t i {:val i}) (inc i)))))
        dur-t (- (now) start-t)
        speedup (if (pos? dur-t) (/ dur-p dur-t) 0)]
    (record! :transient-bulk "persistent-500" :duration-ms dur-p)
    (record! :transient-bulk "transient-500" :duration-ms dur-t)
    (record! :transient-bulk "transient-speedup" :ratio speedup)
    (println (str "    Persistent: " (.toFixed dur-p 2) "ms (" (format-ops n dur-p) ")"))
    (println (str "    Transient:  " (.toFixed dur-t 2) "ms (" (format-ops n dur-t) ")"))
    (println (str "    Speedup:    " (.toFixed speedup 2) "x")))

  ;; Test 3: reduce conj pattern (simulates into without IWithMeta)
  (println "\n  Test 3: reduce conj pattern (1000 kv pairs)")
  (let [_ (fresh-env)
        n 1000
        pairs (mapv (fn [i] [i {:val i}]) (range n))
        start (now)
        m (reduce (fn [m [k v]] (assoc m k v)) (sab-map/empty-sab-map) pairs)
        dur (- (now) start)]
    (record! :transient-bulk "reduce-conj-1000" :duration-ms dur)
    (record! :transient-bulk "reduce-conj-1000" :ops n)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops n dur)))))

;;-----------------------------------------------------------------------------
;; 4. BIT OPERATIONS / POPCOUNT BENCHMARK
;;    Tests: SIMD popcount benefit
;;    Pattern: Operations that rely heavily on popcount (HAMT navigation)
;;-----------------------------------------------------------------------------

(defn bench-bit-operations []
  (println "\n=== BIT OPERATIONS BENCHMARK ===")
  (println "Pattern: HAMT navigation with popcount (SIMD target)\n")

  ;; Test 1: Deep HAMT traversal (many lookups)
  (println "  Test 1: Deep HAMT traversal (1M lookups)")
  (let [_ (fresh-env)
        n 1000
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m i i) (inc i))))
        reps 1000
        start (now)
        _ (dotimes [_ reps]
            (dotimes [i n]
              (get m i)))
        dur (- (now) start)
        total-ops (* reps n)]
    (record! :bit-ops "hamt-lookup-1M" :duration-ms dur)
    (record! :bit-ops "hamt-lookup-1M" :ops total-ops)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops total-ops dur))))

  ;; Test 2: Set contains (uses same HAMT)
  (println "\n  Test 2: Set contains (1M checks)")
  (let [_ (fresh-env)
        n 1000
        s (loop [s (sab-set/empty-sab-set) i 0]
            (if (>= i n) s (recur (conj s i) (inc i))))
        reps 1000
        start (now)
        _ (dotimes [_ reps]
            (dotimes [i n]
              (contains? s i)))
        dur (- (now) start)
        total-ops (* reps n)]
    (record! :bit-ops "set-contains-1M" :duration-ms dur)
    (record! :bit-ops "set-contains-1M" :ops total-ops)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops total-ops dur))))

  ;; Test 3: Mixed hits/misses
  (println "\n  Test 3: Mixed hits/misses (50% each)")
  (let [_ (fresh-env)
        n 500
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m (* i 2) i) (inc i)))) ;; Even keys only
        reps 1000
        start (now)
        hits (atom 0)
        misses (atom 0)
        _ (dotimes [_ reps]
            (dotimes [i (* n 2)]
              (if (get m i)
                (swap! hits inc)
                (swap! misses inc))))
        dur (- (now) start)
        total-ops (* reps n 2)]
    (record! :bit-ops "mixed-hits-misses" :duration-ms dur)
    (record! :bit-ops "mixed-hits-misses" :ops total-ops)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops total-ops dur)))
    (println (str "    Hits: " @hits ", Misses: " @misses))))

;;-----------------------------------------------------------------------------
;; 5. VALUE-ONLY ITERATION BENCHMARK
;;    Tests: Columnar K/V separation benefit
;;    Pattern: Reduce that only uses values
;;-----------------------------------------------------------------------------

(defn bench-value-iteration []
  (println "\n=== VALUE-ONLY ITERATION BENCHMARK ===")
  (println "Pattern: Iterate values only (columnar K/V target)\n")

  ;; Test 1: reduce-kv using only values
  (println "  Test 1: reduce-kv summing values (n=1000)")
  (let [_ (fresh-env)
        n 1000
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m i i) (inc i))))
        reps 100
        start (now)
        _ (dotimes [_ reps]
            (reduce-kv (fn [acc _k v] (+ acc v)) 0 m))
        dur (- (now) start)
        total-ops (* reps n)]
    (record! :value-iteration "reduce-kv-values" :duration-ms dur)
    (record! :value-iteration "reduce-kv-values" :ops total-ops)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops total-ops dur))))

  ;; Test 2: vals sequence
  (println "\n  Test 2: vals iteration (n=1000)")
  (let [_ (fresh-env)
        n 1000
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m i {:val i}) (inc i))))
        reps 50
        start (now)
        _ (dotimes [_ reps]
            (doseq [v (vals m)] v))
        dur (- (now) start)
        total-ops (* reps n)]
    (record! :value-iteration "vals-seq" :duration-ms dur)
    (record! :value-iteration "vals-seq" :ops total-ops)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops total-ops dur))))

  ;; Test 3: keys sequence
  (println "\n  Test 3: keys iteration (n=1000)")
  (let [_ (fresh-env)
        n 1000
        m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m i {:val i}) (inc i))))
        reps 50
        start (now)
        _ (dotimes [_ reps]
            (doseq [k (keys m)] k))
        dur (- (now) start)
        total-ops (* reps n)]
    (record! :value-iteration "keys-seq" :duration-ms dur)
    (record! :value-iteration "keys-seq" :ops total-ops)
    (println (str "    Duration: " (.toFixed dur 2) "ms"))
    (println (str "    " (format-ops total-ops dur)))))

;;-----------------------------------------------------------------------------
;; Summary Report
;;-----------------------------------------------------------------------------

(defn print-summary []
  (println "\n")
  (println (apply str (repeat 80 "=")))
  (println "  OPTIMIZATION TARGETS BENCHMARK SUMMARY")
  (println (apply str (repeat 80 "=")))

  (let [results @*results*]

    ;; Fragmentation
    (println "\n  1. MEMORY FRAGMENTATION (Coalescing Target)")
    (when-let [r (get results :fragmentation)]
      (println (str "     Alloc/free cycle: " (.toFixed (get-in r ["alloc-free-cycle" :duration-ms] 0) 2) "ms"))
      (println (str "     Churn success: " (get-in r ["churn-cycles" :success] 0) " cycles"))
      (println (str "     Churn failures: " (get-in r ["churn-cycles" :failures] 0) " (should be 0)")))

    ;; Repeated access
    (println "\n  2. REPEATED FIELD ACCESS (Caching Target)")
    (when-let [r (get results :repeated-access)]
      (println (str "     Same-key-100x: " (format-ops (get-in r ["same-key-100x" :ops] 0)
                                                        (get-in r ["same-key-100x" :duration-ms] 1))))
      (println (str "     Hot-key-80/20: " (format-ops (get-in r ["hot-key-80-20" :ops] 0)
                                                        (get-in r ["hot-key-80-20" :duration-ms] 1)))))

    ;; Transient bulk
    (println "\n  3. TRANSIENT BULK OPS (Flat Hashtable Target)")
    (when-let [r (get results :transient-bulk)]
      (println (str "     Persistent build: " (.toFixed (get-in r ["persistent-500" :duration-ms] 0) 2) "ms"))
      (println (str "     Transient build:  " (.toFixed (get-in r ["transient-500" :duration-ms] 0) 2) "ms"))
      (println (str "     Speedup:          " (.toFixed (get-in r ["transient-speedup" :ratio] 0) 2) "x")))

    ;; Bit operations
    (println "\n  4. BIT OPERATIONS (SIMD Target)")
    (when-let [r (get results :bit-ops)]
      (println (str "     HAMT lookup 1M: " (format-ops (get-in r ["hamt-lookup-1M" :ops] 0)
                                                         (get-in r ["hamt-lookup-1M" :duration-ms] 1))))
      (println (str "     Set contains 1M: " (format-ops (get-in r ["set-contains-1M" :ops] 0)
                                                          (get-in r ["set-contains-1M" :duration-ms] 1)))))

    ;; Value iteration
    (println "\n  5. VALUE-ONLY ITERATION (Columnar K/V Target)")
    (when-let [r (get results :value-iteration)]
      (println (str "     reduce-kv values: " (format-ops (get-in r ["reduce-kv-values" :ops] 0)
                                                           (get-in r ["reduce-kv-values" :duration-ms] 1))))
      (println (str "     vals seq:         " (format-ops (get-in r ["vals-seq" :ops] 0)
                                                           (get-in r ["vals-seq" :duration-ms] 1)))))

    (println "\n" (apply str (repeat 80 "=")))))

;;-----------------------------------------------------------------------------
;; Test Definitions
;;-----------------------------------------------------------------------------

(deftest test-fragmentation
  (testing "Memory fragmentation benchmark"
    (bench-memory-fragmentation)
    (is true)))

(deftest test-repeated-access
  (testing "Repeated field access benchmark"
    (bench-repeated-access)
    (is true)))

(deftest test-transient-bulk
  (testing "Transient bulk operations benchmark"
    (bench-transient-bulk)
    (is true)))

(deftest test-bit-operations
  (testing "Bit operations benchmark"
    (bench-bit-operations)
    (is true)))

(deftest test-value-iteration
  (testing "Value-only iteration benchmark"
    (bench-value-iteration)
    (is true)))

;;-----------------------------------------------------------------------------
;; Main Entry Point
;;-----------------------------------------------------------------------------

(defn run-optimization-targets-benchmark []
  (println "\n" (apply str (repeat 80 "=")))
  (println "  OPTIMIZATION TARGETS BENCHMARK")
  (println "  Baseline measurements for optimization impact tracking")
  (println (apply str (repeat 80 "=")) "\n")

  (reset! *results* {})

  (bench-memory-fragmentation)
  (bench-repeated-access)
  (bench-transient-bulk)
  (bench-bit-operations)
  (bench-value-iteration)

  (print-summary)

  (println "\n  Run after each optimization to measure improvement.")
  (println "  Save results to compare before/after."))

(run-optimization-targets-benchmark)

(ns com.seniorcaremarket.eve-sab-deftype.atom-perf-benchmark
  "Performance benchmark for fast-path serialization and atom operations.

   Measures:
   - ser/serialize-element + ser/deserialize-element (fast-path + SAB pointers)
   - Full atom swap!/deref cycles
   - Serialization sizes

   These are the exact code paths used by atom deref and atom swap."
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]))

;; 4MB SAB, 16384 blocks (matches unit tests)
(def _init-atom
  (let [large-atom (atom/private-atom {} :sab-size (* 4 1024 1024)
                                         :max-blocks 16384)]
    (set! atom/*global-atom-instance* large-atom)
    large-atom))

;;-----------------------------------------------------------------------------
;; Helpers
;;-----------------------------------------------------------------------------

(defn now-us [] (* 1000.0 (js/performance.now)))

(defn bench
  "Run f repeatedly, return {:mean-us :ops-s :bytes (optional)}."
  [f & {:keys [iters warmup] :or {iters 1000 warmup 100}}]
  (dotimes [_ warmup] (f))
  (let [start (now-us)]
    (dotimes [_ iters] (f))
    (let [elapsed (- (now-us) start)
          mean (/ elapsed iters)]
      {:mean-us mean :ops-s (/ 1e6 mean)})))

(defn fmt-us [us]
  (cond
    (< us 1) (str (.toFixed (* us 1000) 0) "ns")
    (< us 1000) (str (.toFixed us 2) "us")
    :else (str (.toFixed (/ us 1000) 2) "ms")))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (str (.toFixed (/ ops 1e6) 2) "M")
    (>= ops 1e3) (str (.toFixed (/ ops 1e3) 1) "K")
    :else (str (.toFixed ops 0))))

;;-----------------------------------------------------------------------------
;; Benchmark: Atom serialization (the hot path for atom swap!)
;;-----------------------------------------------------------------------------

(defn run-serialize-benchmark []
  (println "\n--- Benchmark 1: Atom state serialization ---")
  (println "  (The core hot path: serialize map state for atom swap)")
  (println "  Path: ser/serialize-element (fast-path + SAB pointers)\n")

  (doseq [[label test-map iters]
          [["Small map {:a 1 :b 2 :c 3}"
            {:a 1 :b 2 :c 3} 100]
           ["Medium map (7 keys, mixed types)"
            {:name "Alice" :age 30 :active true :score 98.5
             :role :admin :level 5 :ns-kw :user/name} 50]
           ["Map with nested map"
            {:config {:host "localhost" :port 5432}} 50]]]
    (let [enc (bench #(ser/serialize-element test-map) :iters iters)
          bytes (ser/serialize-element test-map)]
      (println (str "  " label))
      (println (str "    Encode: " (fmt-us (:mean-us enc))
                    " mean, " (fmt-ops (:ops-s enc)) " ops/s"
                    " [" (.-length bytes) " bytes]"))
      (println))))

;;-----------------------------------------------------------------------------
;; Benchmark: Atom deserialization (the hot path for atom deref!)
;;-----------------------------------------------------------------------------

(defn run-deserialize-benchmark []
  (println "--- Benchmark 2: Atom state deserialization ---")
  (println "  (The core hot path: deserialize map state for atom deref)")
  (println "  Path: ser/deserialize-element (fast-path + SAB pointers)\n")

  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)]
    ;; Test 1: Simple map
    (let [test-map {:a 1 :b 2 :c 3}
          fast-bytes (ser/serialize-element test-map)
          fast-dec (bench #(ser/deserialize-element s-atom-env fast-bytes) :iters 10000)]
      (println "  Simple map {:a 1 :b 2 :c 3}")
      (println (str "    Decode: " (fmt-us (:mean-us fast-dec))
                    " mean, " (fmt-ops (:ops-s fast-dec)) " ops/s"))
      (println))

    ;; Test 2: Medium map
    (let [test-map {:name "Alice" :age 30 :active true :score 98.5
                    :id (random-uuid) :role :admin :level 5}
          fast-bytes (ser/serialize-element test-map)
          fast-dec (bench #(ser/deserialize-element s-atom-env fast-bytes) :iters 10000)]
      (println "  Medium map (7 keys, mixed types)")
      (println (str "    Decode: " (fmt-us (:mean-us fast-dec))
                    " mean, " (fmt-ops (:ops-s fast-dec)) " ops/s"))
      (println))

    ;; Test 3: Map with nested map
    (let [test-map {:config {:host "localhost" :port 5432}}
          fast-bytes (ser/serialize-element test-map)
          fast-dec (bench #(ser/deserialize-element s-atom-env fast-bytes) :iters 10000)]
      (println "  Map with nested map {:config {:host ... :port ...}}")
      (println (str "    Decode: " (fmt-us (:mean-us fast-dec))
                    " mean, " (fmt-ops (:ops-s fast-dec)) " ops/s"))
      (println))))

;;-----------------------------------------------------------------------------
;; Benchmark: Full atom deref+swap cycle
;;-----------------------------------------------------------------------------

(defn run-atom-ops-benchmark []
  (println "--- Benchmark 3: Full atom operations ---")
  (println "  (End-to-end: swap! = deref + apply fn + serialize + CAS)\n")

  ;; First, set up atom with some state
  (reset! atom/*global-atom-instance* {:counter 0 :name "test"})

  ;; Benchmark swap! with a simple update
  (let [swap-result (bench #(swap! atom/*global-atom-instance* update :counter inc) :iters 500 :warmup 50)]
    (println "  swap! (update :counter inc)")
    (println (str "    " (fmt-us (:mean-us swap-result))
                  " mean, " (fmt-ops (:ops-s swap-result)) " ops/s"))
    (println))

  ;; Benchmark swap! with assoc
  (let [swap-result (bench #(swap! atom/*global-atom-instance* assoc :x (rand-int 1000)) :iters 500 :warmup 50)]
    (println "  swap! (assoc :x <random>)")
    (println (str "    " (fmt-us (:mean-us swap-result))
                  " mean, " (fmt-ops (:ops-s swap-result)) " ops/s"))
    (println))

  ;; Benchmark deref
  (let [deref-result (bench #(deref atom/*global-atom-instance*) :iters 2000 :warmup 200)]
    (println "  @atom (deref)")
    (println (str "    " (fmt-us (:mean-us deref-result))
                  " mean, " (fmt-ops (:ops-s deref-result)) " ops/s"))
    (println))

  ;; Benchmark deref + nested access
  (reset! atom/*global-atom-instance* {:config {:db {:host "localhost" :port 5432}}})
  (let [drill-result (bench #(get-in @atom/*global-atom-instance* [:config :db :host]) :iters 2000 :warmup 200)]
    (println "  @atom -> get-in [:config :db :host]")
    (println (str "    " (fmt-us (:mean-us drill-result))
                  " mean, " (fmt-ops (:ops-s drill-result)) " ops/s"))
    (println))

  ;; Clean up
  (reset! atom/*global-atom-instance* {}))

;;-----------------------------------------------------------------------------
;; Benchmark: Serialization size
;;-----------------------------------------------------------------------------

(defn run-size-benchmark []
  (println "--- Benchmark 4: Serialization sizes ---\n")
  (println "  Value                           | Bytes")
  (println "  --------------------------------|------")
  (doseq [[label value]
          [["nil" nil]
           ["true" true]
           ["42 (int32)" 42]
           ["3.14 (float64)" 3.14]
           [":keyword" :keyword]
           [":ns/keyword" :ns/keyword]
           ["\"hello\"" "hello"]
           ["UUID" (random-uuid)]
           ["{:a 1 :b 2 :c 3}" {:a 1 :b 2 :c 3}]
           ["{:cfg {:h \"x\" :p 1}}" {:cfg {:h "x" :p 1}}]]]
    (let [fast-bytes (ser/serialize-element value)
          fast-len (.-length fast-bytes)]
      (println (str "  " (.padEnd label 33) "| " fast-len "B"))))
  (println))

;;-----------------------------------------------------------------------------
;; Main
;;-----------------------------------------------------------------------------

(defn ^:export run-all-benchmarks []
  (println "================================================================================")
  (println "  ATOM SERIALIZATION PERFORMANCE REPORT")
  (println "  Fast-path serialization with SAB pointers")
  (println "================================================================================")

  (run-serialize-benchmark)
  (run-deserialize-benchmark)
  (run-atom-ops-benchmark)
  (run-size-benchmark)

  (println "================================================================================")
  (println "  SUMMARY")
  (println "  - Atom deref: O(1) SAB pointer decode for nested collections")
  (println "  - Atom swap: fast-path encode (SAB pointer) for nested collections")
  (println "  - Nested collections: 7 bytes constant (SAB pointer)")
  (println "  - Primitives: compact fast-path encoding")
  (println "================================================================================"))

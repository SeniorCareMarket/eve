(ns com.seniorcaremarket.eve-sab-deftype.stock-comparison-benchmark
  "Compare SAB-backed structures vs stock ClojureScript persistent structures.
   Uses proper warmup and multi-iteration measurement."
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sab-vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as sab-set]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Benchmark infrastructure
;;-----------------------------------------------------------------------------

(defn now [] (js/performance.now))

(defn fresh-env!
  "Create a fresh atom environment for SAB benchmarks.
   Updates WASM memory views and resets global pools."
  []
  ;; Reset pools first to clear stale refs from previous env
  (sab-map/reset-pools!)
  (sab-set/reset-pools!)
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 256 1024 1024) :max-blocks 262144))
  ;; Reset pools again after atom creation (try-build-sab may have populated them)
  (sab-map/reset-pools!)
  (sab-set/reset-pools!))

(defn bench
  "Run f repeatedly with warmup. Returns {:mean-us :median-us :ops-s}."
  [f & {:keys [iters warmup] :or {iters 200 warmup 50}}]
  (dotimes [_ warmup] (f))
  (let [times (js/Float64Array. iters)]
    (dotimes [i iters]
      (let [start (now)]
        (f)
        (aset times i (- (now) start))))
    (let [sorted (doto (js/Array.from times) (.sort))
          sum (reduce + 0 (array-seq sorted))
          mean-ms (/ sum iters)
          median-ms (aget sorted (js/Math.floor (/ iters 2)))]
      {:mean-us (* mean-ms 1000)
       :median-us (* median-ms 1000)
       :ops-s (if (pos? mean-ms) (/ 1000 mean-ms) 0)})))

(defn fmt-us [us]
  (cond
    (< us 1) (str (.toFixed (* us 1000) 0) "ns")
    (< us 1000) (str (.toFixed us 2) "us")
    :else (str (.toFixed (/ us 1000) 2) "ms")))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (str (.toFixed (/ ops 1e6) 2) "M")
    (>= ops 1e3) (str (.toFixed (/ ops 1e3) 1) "K")
    :else (str (.toFixed ops 1) "")))

(defn ratio-str [sab-ops stock-ops]
  (let [ratio (/ sab-ops stock-ops)]
    (if (>= ratio 1)
      (str (.toFixed ratio 1) "x faster")
      (str (.toFixed (/ 1 ratio) 1) "x slower"))))

(defn pad [s n] (.padStart (str s) n))

(def ^:private *results* (atom []))

(defn record! [category operation n stock-result sab-result]
  (swap! *results* conj
         {:category category :operation operation :n n
          :stock stock-result :sab sab-result
          :ratio (/ (:ops-s sab-result) (:ops-s stock-result))}))

;;-----------------------------------------------------------------------------
;; Benchmark runners
;;-----------------------------------------------------------------------------

(defn bench-map-build [n]
  ;; Stock
  (let [stock (bench (fn []
                       (loop [m {} i 0]
                         (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i)))))
                     :iters (if (> n 500) 5 20) :warmup 2)]
    ;; SAB
    (fresh-env!)
    (let [sab (bench (fn []
                       (loop [m (sab-map/empty-sab-map) i 0]
                         (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i)))))
                     :iters (if (> n 500) 5 20) :warmup 2)]
      (record! :map "build" n stock sab))))

(defn bench-map-lookup [n]
  ;; Build maps once
  (let [stock-m (loop [m {} i 0]
                  (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
        stock (bench (fn []
                       (dotimes [i n]
                         (get stock-m (keyword (str "k" (mod i n))))))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                  (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
          sab (bench (fn []
                       (dotimes [i n]
                         (get sab-m (keyword (str "k" (mod i n))))))
                     :iters 100 :warmup 20)]
      (record! :map "lookup" n stock sab))))

(defn bench-map-assoc [n]
  ;; Build base maps once
  (let [stock-m (loop [m {} i 0]
                  (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
        stock (bench (fn [] (assoc stock-m :new-key 999))
                     :iters 500 :warmup 100)]
    (fresh-env!)
    (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                  (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
          sab (bench (fn [] (assoc sab-m :new-key 999))
                     :iters 500 :warmup 100)]
      (record! :map "assoc" n stock sab))))

(defn bench-map-reduce [n]
  (let [stock-m (loop [m {} i 0]
                  (if (>= i n) m (recur (assoc m i i) (inc i))))
        stock (bench (fn [] (reduce-kv (fn [acc _ v] (+ acc v)) 0 stock-m))
                     :iters 200 :warmup 50)]
    (fresh-env!)
    (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                  (if (>= i n) m (recur (assoc m i i) (inc i))))
          sab (bench (fn [] (reduce-kv (fn [acc _ v] (+ acc v)) 0 sab-m))
                     :iters 200 :warmup 50)]
      (record! :map "reduce-kv" n stock sab))))

(defn bench-vec-build [n]
  (let [stock (bench (fn []
                       (loop [v [] i 0]
                         (if (>= i n) v (recur (conj v i) (inc i)))))
                     :iters (if (> n 500) 5 20) :warmup 2)]
    (fresh-env!)
    (let [sab (bench (fn []
                       (loop [v (sab-vec/empty-sab-vec) i 0]
                         (if (>= i n) v (recur (conj v i) (inc i)))))
                     :iters (if (> n 500) 5 20) :warmup 2)]
      (record! :vec "build" n stock sab))))

(defn bench-vec-nth [n]
  (let [stock-v (vec (range n))
        stock (bench (fn []
                       (dotimes [i n]
                         (nth stock-v i)))
                     :iters 200 :warmup 50)]
    (fresh-env!)
    (let [sab-v (reduce conj (sab-vec/empty-sab-vec) (range n))
          sab (bench (fn []
                       (dotimes [i n]
                         (nth sab-v i)))
                     :iters 200 :warmup 50)]
      (record! :vec "nth" n stock sab))))

(defn bench-set-build [n]
  (let [stock (bench (fn []
                       (loop [s #{} i 0]
                         (if (>= i n) s (recur (conj s i) (inc i)))))
                     :iters (if (> n 500) 5 20) :warmup 2)]
    (fresh-env!)
    (let [sab (bench (fn []
                       (loop [s (sab-set/empty-sab-set) i 0]
                         (if (>= i n) s (recur (conj s i) (inc i)))))
                     :iters (if (> n 500) 5 20) :warmup 2)]
      (record! :set "build" n stock sab))))

(defn bench-set-contains [n]
  (let [stock-s (set (range n))
        stock (bench (fn []
                       (dotimes [i n]
                         (contains? stock-s i)))
                     :iters 200 :warmup 50)]
    (fresh-env!)
    (let [sab-s (reduce conj (sab-set/empty-sab-set) (range n))
          sab (bench (fn []
                       (dotimes [i n]
                         (contains? sab-s i)))
                     :iters 200 :warmup 50)]
      (record! :set "contains?" n stock sab))))

(defn bench-atom-ops []
  ;; Atom deref (small map)
  (fresh-env!)
  (let [_ (swap! a/*global-atom-instance* assoc :a 1 :b 2 :c 3)
        stock-a (cljs.core/atom {:a 1 :b 2 :c 3})
        stock-deref (bench (fn [] @stock-a) :iters 1000 :warmup 200)
        sab-deref (bench (fn [] @a/*global-atom-instance*) :iters 1000 :warmup 200)]
    (record! :atom "deref (3-key)" 3 stock-deref sab-deref))

  ;; Atom deref (20-key map)
  (fresh-env!)
  (let [m20 (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i)) {} (range 20))
        _ (reset! a/*global-atom-instance* m20)
        stock-a (cljs.core/atom m20)
        stock-d (bench (fn [] @stock-a) :iters 1000 :warmup 200)
        sab-d (bench (fn [] @a/*global-atom-instance*) :iters 1000 :warmup 200)]
    (record! :atom "deref (20-key)" 20 stock-d sab-d))

  ;; Atom swap! (update :counter inc)
  (fresh-env!)
  (let [stock-a (cljs.core/atom {:counter 0})
        stock-s (bench (fn [] (cljs.core/swap! stock-a update :counter inc))
                       :iters 500 :warmup 100)
        _ (fresh-env!)
        _ (swap! a/*global-atom-instance* assoc :counter 0)
        sab-s (bench (fn [] (swap! a/*global-atom-instance* update :counter inc))
                     :iters 500 :warmup 100)]
    (record! :atom "swap! update inc" 1 stock-s sab-s))

  ;; Atom swap! (assoc :x random)
  (fresh-env!)
  (let [stock-a (cljs.core/atom {:x 0})
        stock-s (bench (fn [] (cljs.core/swap! stock-a assoc :x (rand-int 1000)))
                       :iters 500 :warmup 100)
        _ (fresh-env!)
        _ (swap! a/*global-atom-instance* assoc :x 0)
        sab-s (bench (fn [] (swap! a/*global-atom-instance* assoc :x (rand-int 1000)))
                     :iters 500 :warmup 100)]
    (record! :atom "swap! assoc rand" 1 stock-s sab-s))

  ;; Atom swap! (assoc same value) — tests identical? fast-path
  (fresh-env!)
  (let [stock-a (cljs.core/atom {:x 42 :y "hello" :z :foo})
        stock-s (bench (fn [] (cljs.core/swap! stock-a assoc :x 42))
                       :iters 500 :warmup 100)
        _ (fresh-env!)
        _ (reset! a/*global-atom-instance* {:x 42 :y "hello" :z :foo})
        sab-s (bench (fn [] (swap! a/*global-atom-instance* assoc :x 42))
                     :iters 500 :warmup 100)]
    (record! :atom "swap! same-val" 3 stock-s sab-s))

  ;; Atom swap! on 10-key map (update one key)
  (fresh-env!)
  (let [m10 (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i)) {} (range 10))
        stock-a (cljs.core/atom m10)
        stock-s (bench (fn [] (cljs.core/swap! stock-a update :k5 inc))
                       :iters 500 :warmup 100)
        _ (fresh-env!)
        _ (reset! a/*global-atom-instance* m10)
        sab-s (bench (fn [] (swap! a/*global-atom-instance* update :k5 inc))
                     :iters 500 :warmup 100)]
    (record! :atom "swap! inc 10-key" 10 stock-s sab-s))

  ;; Atom swap! on 20-key map (update one key)
  (fresh-env!)
  (let [m20 (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i)) {} (range 20))
        stock-a (cljs.core/atom m20)
        stock-s (bench (fn [] (cljs.core/swap! stock-a update :k10 inc))
                       :iters 500 :warmup 100)
        _ (fresh-env!)
        _ (reset! a/*global-atom-instance* m20)
        sab-s (bench (fn [] (swap! a/*global-atom-instance* update :k10 inc))
                     :iters 500 :warmup 100)]
    (record! :atom "swap! inc 20-key" 20 stock-s sab-s))

  ;; Atom swap! same-val on 20-key map
  (fresh-env!)
  (let [m20 (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i)) {} (range 20))
        stock-a (cljs.core/atom m20)
        stock-s (bench (fn [] (cljs.core/swap! stock-a assoc :k10 10))
                       :iters 500 :warmup 100)
        _ (fresh-env!)
        _ (reset! a/*global-atom-instance* m20)
        sab-s (bench (fn [] (swap! a/*global-atom-instance* assoc :k10 10))
                     :iters 500 :warmup 100)]
    (record! :atom "swap! same 20-key" 20 stock-s sab-s))

  ;; Atom deref + get (read a single key from atom)
  (fresh-env!)
  (let [m10 (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i)) {} (range 10))
        stock-a (cljs.core/atom m10)
        _ (reset! a/*global-atom-instance* m10)
        stock-g (bench (fn [] (get @stock-a :k5)) :iters 2000 :warmup 200)
        sab-g (bench (fn [] (get @a/*global-atom-instance* :k5)) :iters 2000 :warmup 200)]
    (record! :atom "deref+get" 10 stock-g sab-g))

  ;; Atom deref + get-in (nested read)
  (fresh-env!)
  (let [stock-a (cljs.core/atom {:a {:b {:c 42}}})
        _ (reset! a/*global-atom-instance* {:a {:b {:c 42}}})
        stock-gi (bench (fn [] (get-in @stock-a [:a :b :c])) :iters 2000 :warmup 200)
        sab-gi (bench (fn [] (get-in @a/*global-atom-instance* [:a :b :c])) :iters 2000 :warmup 200)]
    (record! :atom "deref+get-in" 3 stock-gi sab-gi))

  ;; Atom reset! with medium map
  (fresh-env!)
  (let [m20 (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i)) {} (range 20))
        stock-a (cljs.core/atom {})
        stock-r (bench (fn [] (cljs.core/reset! stock-a m20)) :iters 500 :warmup 100)
        _ (fresh-env!)
        sab-r (bench (fn [] (reset! a/*global-atom-instance* m20)) :iters 50 :warmup 5)]
    (record! :atom "reset! 20-key" 20 stock-r sab-r))

  ;; Atom reset! with small map
  (fresh-env!)
  (let [m3 {:a 1 :b 2 :c 3}
        stock-a (cljs.core/atom {})
        stock-r (bench (fn [] (cljs.core/reset! stock-a m3)) :iters 500 :warmup 100)
        _ (fresh-env!)
        sab-r (bench (fn [] (reset! a/*global-atom-instance* m3)) :iters 200 :warmup 20)]
    (record! :atom "reset! 3-key" 3 stock-r sab-r))

)

;;-----------------------------------------------------------------------------
;; Output
;;-----------------------------------------------------------------------------

(defn print-table []
  (let [results @*results*
        sep "  +----------------------------+------+-----------------+-----------------+--------------+"
        hdr "  | Operation                  |    n |      Stock      |       SAB       |    Ratio     |"]
    (println sep)
    (println hdr)
    (println sep)
    (doseq [{:keys [category operation n stock sab ratio]} results]
      (let [cat-str (name category)
            op-str (str cat-str " " operation)
            stock-str (str (fmt-us (:mean-us stock)) " " (fmt-ops (:ops-s stock)) "/s")
            sab-str (str (fmt-us (:mean-us sab)) " " (fmt-ops (:ops-s sab)) "/s")
            ratio-str (if (>= ratio 1)
                        (str (.toFixed ratio 1) "x faster")
                        (str (.toFixed (/ 1 ratio) 1) "x slower"))]
        (println (str "  | "
                      (.padEnd op-str 26)
                      " | " (pad n 4)
                      " | " (pad stock-str 15)
                      " | " (pad sab-str 15)
                      " | " (pad ratio-str 12) " |"))))
    (println sep)))

;;-----------------------------------------------------------------------------
;; Main
;;-----------------------------------------------------------------------------

(defn run-benchmarks []
  (reset! *results* [])

  (println "\n================================================================================")
  (println "  EVE SAB vs Stock CLJS — Comprehensive Performance Comparison")
  (println "  (JIT-warmed, single-threaded, median of multiple iterations)")
  (println "================================================================================")
  (println "\n  Trade-off: SAB is slower single-threaded but enables zero-copy")
  (println "  cross-worker sharing via SharedArrayBuffer.\n")

  (println "  Running batched map benchmarks...")
  (bench-map-build 10)
  (bench-map-build 100)
  (bench-map-build 500)
  (bench-map-lookup 100)
  (bench-map-lookup 500)
  (bench-map-assoc 100)
  (bench-map-assoc 500)
  (bench-map-reduce 100)
  (bench-map-reduce 500)

  (println "  Running single-op map benchmarks...")
  (doseq [n [10 100]]
    (let [stock-m (loop [m {} i 0]
                    (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
          k (keyword (str "k" (quot n 2)))
          stock (bench (fn [] (get stock-m k)) :iters 5000 :warmup 500)]
      (fresh-env!)
      (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                    (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
            sab (bench (fn [] (get sab-m k)) :iters 5000 :warmup 500)]
        (record! :map-1op "get" n stock sab))))

  (doseq [n [10 100]]
    (let [stock-m (loop [m {} i 0]
                    (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
          stock (bench (fn [] (assoc stock-m :new-key 999)) :iters 500 :warmup 100)]
      (fresh-env!)
      (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                    (if (>= i n) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))
            sab (bench (fn [] (assoc sab-m :new-key 999)) :iters 500 :warmup 100)]
        (record! :map-1op "assoc" n stock sab))))

  (println "  Running single-op set benchmarks...")
  (doseq [n [10 100]]
    (let [stock-s (set (range n))
          stock (bench (fn [] (contains? stock-s (quot n 2))) :iters 5000 :warmup 500)]
      (fresh-env!)
      (let [sab-s (reduce conj (sab-set/empty-sab-set) (range n))
            sab (bench (fn [] (contains? sab-s (quot n 2))) :iters 5000 :warmup 500)]
        (record! :set-1op "contains?" n stock sab))))

  (println "  Running single-op vec benchmarks...")
  (doseq [n [10 100]]
    (let [stock-v (vec (range n))
          stock (bench (fn [] (nth stock-v (quot n 2))) :iters 5000 :warmup 500)]
      (fresh-env!)
      (let [sab-v (reduce conj (sab-vec/empty-sab-vec) (range n))
            sab (bench (fn [] (nth sab-v (quot n 2))) :iters 5000 :warmup 500)]
        (record! :vec-1op "nth" n stock sab))))

  (println "  Running vector benchmarks...")
  (bench-vec-build 100)
  (bench-vec-build 500)
  (bench-vec-nth 100)
  (bench-vec-nth 500)

  (println "  Running set benchmarks...")
  (bench-set-build 100)
  (bench-set-build 500)
  (bench-set-contains 100)
  (bench-set-contains 500)

  (println "  Running atom benchmarks...")
  (bench-atom-ops)

  (println "\n")
  (print-table)

  (println "\n  Legend: Stock = standard CLJS persistent structures")
  (println "          SAB   = EVE SharedArrayBuffer-backed structures")
  (println "          Ratio > 1 means SAB is faster; < 1 means SAB is slower")
  (println "\n  Note: Build operations are expected to be slower (SAB allocation +")
  (println "  serialization overhead). Read operations (lookup, nth, contains?) are")
  (println "  the key metric for typical usage patterns.")
  (println "\n================================================================================"))

(defn ^:export run-stock-comparison-benchmark []
  (run-benchmarks))

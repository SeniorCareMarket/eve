(ns com.seniorcaremarket.eve-sab-deftype.sab-field-access-bug-test
  "Regression tests for field-access bugs in standalone functions.

   eve-sab-deftype fields live in SAB memory, not as JS properties.
   (.-field-name instance) returns nil outside deftype method bodies.
   These tests verify that dispose!, -sab-retire-diff!, and sab-preduce
   correctly read fields via DataView instead of JS property access."
  (:require
   [cljs.test :refer-macros [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]))

;;-----------------------------------------------------------------------------
;; Setup — fresh atom for each test ensures clean SAB state
;;-----------------------------------------------------------------------------

(defn fresh-atom! []
  (let [a (atom/private-atom {} :sab-size (* 4 1024 1024)
                                :max-blocks 16384)]
    (set! atom/*global-atom-instance* a)
    (sm/reset-pools!)
    (ss/reset-pools!)
    a))

;; Initial atom for test runner
(def _init-atom (fresh-atom!))

;;-----------------------------------------------------------------------------
;; A. SabMapRoot field access (3 bugs)
;;-----------------------------------------------------------------------------

(deftest test-sab-map-dispose
  (testing "dispose! correctly reads root-off from SAB (Bug #1)"
    (fresh-atom!)
    (let [m (-> (sm/empty-sab-map)
                (assoc :a 1 :b 2 :c 3))]
      (is (= 3 (count m)))
      ;; dispose! should not throw — it should correctly read root-off
      ;; Before fix: (.-root-off sab-map) returns nil, dispose silently skips
      (sm/dispose! m))))

(deftest test-sab-map-retire-diff
  (testing "-sab-retire-diff! reads new-value's root-off from SAB (Bug #2)"
    (fresh-atom!)
    (let [m1 (-> (sm/empty-sab-map) (assoc :a 1 :b 2))
          m2 (assoc m1 :c 3)
          s-atom-env (atom/get-env atom/*global-atom-instance*)]
      (is (= 2 (count m1)))
      (is (= 3 (count m2)))
      ;; retire-diff should not throw — needs valid root-off from new-value
      ;; Before fix: (.-root-off new-value) returns nil
      (com.seniorcaremarket.eve.data/-sab-retire-diff! m1 m2 s-atom-env :free))))

(deftest test-sab-map-preduce
  (testing "sab-preduce reads cnt and root-off from SAB (Bug #3)"
    (fresh-atom!)
    (let [m (reduce (fn [m i] (assoc m (keyword (str "k" i)) i))
                    (sm/empty-sab-map)
                    (range 20))]
      (is (= 20 (count m)))
      ;; preduce should work — needs valid cnt and root-off
      ;; Before fix: (.-cnt sab-map) and (.-root-off sab-map) return nil
      (let [result (sm/sab-preduce m
                                   (fn [] 0)
                                   (fn [acc _k v] (+ acc v))
                                   +)]
        (is (= (reduce + (range 20)) result))))))

;;-----------------------------------------------------------------------------
;; B. SabSetRoot field access (2 bugs)
;;-----------------------------------------------------------------------------

(deftest test-sab-set-retire-diff
  (testing "-sab-retire-diff! reads new-value's root-off from SAB (Bug #4)"
    (fresh-atom!)
    (let [s1 (reduce conj (ss/empty-sab-set) (range 50))
          s2 (conj s1 50)
          s-atom-env (atom/get-env atom/*global-atom-instance*)]
      (is (= 50 (count s1)))
      (is (= 51 (count s2)))
      ;; Should not throw
      (com.seniorcaremarket.eve.data/-sab-retire-diff! s1 s2 s-atom-env :free))))

(deftest test-sab-set-dispose
  (testing "dispose! reads root-off from SAB (Bug #5)"
    (fresh-atom!)
    (let [s (reduce conj (ss/empty-sab-set) (range 10))]
      (is (= 10 (count s)))
      ;; Verify we can read the root-off without error
      (let [dv (wasm/data-view)
            base-off (.-offset__ s)
            root-off (.getInt32 dv (+ base-off 8) true)]
        (is (integer? root-off) "root-off should be an integer")
        (is (> root-off -1) "root-off should be valid for non-empty set"))
      ;; dispose! should not throw
      (ss/dispose! s))))

;;-----------------------------------------------------------------------------
;; C. SabVecRoot field access (4 bugs in retire-diff, 3+ in dispose)
;;-----------------------------------------------------------------------------

(deftest test-sab-vec-retire-diff
  (testing "-sab-retire-diff! reads fields from SAB (Bugs #6-8)"
    (fresh-atom!)
    (let [v1 (reduce conj (sv/empty-sab-vec) (range 100))
          v2 (conj v1 100)
          s-atom-env (atom/get-env atom/*global-atom-instance*)]
      (is (= 100 (count v1)))
      (is (= 101 (count v2)))
      ;; Should not throw — needs valid root, shift from this and new-value
      (com.seniorcaremarket.eve.data/-sab-retire-diff! v1 v2 s-atom-env :free))))

(deftest test-sab-vec-dispose
  (testing "dispose! reads root, tail, shift from SAB (Bugs #9-10)"
    (fresh-atom!)
    (let [v (reduce conj (sv/empty-sab-vec) (range 100))]
      (is (= 100 (count v)))
      ;; Should not throw — needs valid root-off, tail-off, shift-val
      (sv/dispose! v))))

;;-----------------------------------------------------------------------------
;; D. SabList field access (5 bugs)
;;-----------------------------------------------------------------------------

(deftest test-sab-list-retire-diff
  (testing "-sab-retire-diff! reads head-off from SAB (Bugs #11-12)"
    (fresh-atom!)
    (let [l1 (reduce conj (sl/empty-sab-list) (range 10))
          l2 (conj l1 10)
          s-atom-env (atom/get-env atom/*global-atom-instance*)]
      (is (= 10 (count l1)))
      (is (= 11 (count l2)))
      ;; Should not throw
      (com.seniorcaremarket.eve.data/-sab-retire-diff! l1 l2 s-atom-env :free))))

(deftest test-sab-list-dispose
  (testing "dispose! reads head-off from SAB (Bugs #13-14)"
    (fresh-atom!)
    (let [l (reduce conj (sl/empty-sab-list) (range 10))]
      (is (= 10 (count l)))
      ;; Should not throw
      (sl/dispose! l))))

(ns com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test
  "Comprehensive multi-threaded contention tests for heterogeneous data structures
   with variable chunk sizes and progressive data sizes.

   Tests cover:
   - Heterogeneous nested data (maps with vecs, vecs with maps, etc.)
   - Variable chunk sizes: 32, 64, 128, 256, 512, 1024
   - Progressive data sizes: small (50), medium (200), large (500), huge (1000)
   - Multi-worker contention scenarios"
  (:require
   [cljs.test :refer [deftest is testing async]]
   [clojure.set :as set]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Configuration Constants
;;-----------------------------------------------------------------------------

(def ^:const CHUNK-SIZES [32 64 128 256 512 1024])

(def DATA-TIERS
  {:small  {:count 50   :workers 2 :timeout 30000}
   :medium {:count 200  :workers 3 :timeout 60000}
   :large  {:count 500  :workers 4 :timeout 120000}
   :huge   {:count 1000 :workers 4 :timeout 180000}})

(def ^:const MAX-RETRIES 3000)

;;-----------------------------------------------------------------------------
;; Environment Setup
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize the global atom with larger SAB for stress tests."
  ([] (init-env! (* 64 1024 1024) 262144))
  ([sab-size max-blocks]
   (set! a/*global-atom-instance*
         (a/private-atom {} :sab-size sab-size :max-blocks max-blocks))
   (a/get-env a/*global-atom-instance*)))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

;;-----------------------------------------------------------------------------
;; Root Slot Management
;;-----------------------------------------------------------------------------

(defn alloc-root-slot!
  "Allocate an atomic Int32 root pointer slot. Returns int32 index."
  [env]
  (let [alloc-result (a/alloc env 8)
        _ (when (:error alloc-result)
            (throw (js/Error. (str "Root slot alloc failed: " (:error alloc-result)))))
        byte-offset (:offset alloc-result)
        aligned-offset (let [rem (mod byte-offset 4)]
                         (if (zero? rem) byte-offset (+ byte-offset (- 4 rem))))
        int32-idx (unsigned-bit-shift-right aligned-offset 2)
        int32-view (js/Int32Array. (:sab env))]
    (js/Atomics.store int32-view int32-idx -1)
    int32-idx))

;;-----------------------------------------------------------------------------
;; Read Helpers for All Structure Types
;;-----------------------------------------------------------------------------

(defn read-vec [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sv/SabVecRoot. (:sab env) off))))

(defn read-vec-n [env int32-idx _node-size]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sv/SabVecN. (:sab env) off))))

(defn read-list [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sl/SabList. (:sab env) off))))

(defn read-list-n [env int32-idx _chunk-size]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sl/SabListN. (:sab env) off))))

(defn read-map [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sm/SabMapRoot. (:sab env) off))))

(defn read-set [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (ss/SabSetRoot. (:sab env) off))))

;;-----------------------------------------------------------------------------
;; Test 1: Heterogeneous Nested Data Transformations
;;-----------------------------------------------------------------------------

(defn dispatch-heterogeneous-transform-worker!
  "Worker builds nested heterogeneous structures:
   - Maps containing vectors
   - Vectors containing maps
   - Sets containing complex keys
   - Lists with mixed data"
  [worker map-idx vec-idx set-idx list-idx worker-id values-per-worker]
  (in worker [map-idx vec-idx set-idx list-idx worker-id values-per-worker]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          sab (:sab env)
          int32-view (js/Int32Array. sab)
          start-val (* worker-id values-per-worker)
          end-val (+ start-val values-per-worker)]

      (println (str "  [W" worker-id "] Heterogeneous transform " start-val "-" (dec end-val)))
      (let [start-time (js/performance.now)
            retries-total (atom 0)]

        ;; Build maps with vector values: {:key-N [N N*2 N*3]}
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view map-idx)
                  old-map (when (not= old-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off))
                  ;; Value is a CLJ vector (will be serialized)
                  val-vec [v (* v 2) (* v 3) (str "item-" v)]
                  new-map (assoc (or old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/empty-sab-map))
                                 (keyword (str "key-" v)) val-vec)
                  new-off (.-offset__ new-map)]
              (if (== old-off (js/Atomics.compareExchange int32-view map-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        ;; Build vectors with map values: [{:id N :data "..."} ...]
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view vec-idx)
                  old-vec (when (not= old-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot. sab old-off))
                  ;; Value is a CLJ map
                  val-map {:id v :worker worker-id :data (str "payload-" v)}
                  new-vec (conj (or old-vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec)) val-map)
                  new-off (.-offset__ new-vec)]
              (if (== old-off (js/Atomics.compareExchange int32-view vec-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        ;; Build sets with complex keys: #{[N :worker-W] ...}
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view set-idx)
                  old-set (when (not= old-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-set/SabSetRoot. sab old-off))
                  ;; Complex set key
                  key-val [v (keyword (str "worker-" worker-id)) {:nested true}]
                  new-set (conj (or old-set (com.seniorcaremarket.eve-sab-deftype.sab-set/empty-sab-set)) key-val)
                  new-off (.-offset__ new-set)]
              (if (== old-off (js/Atomics.compareExchange int32-view set-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        ;; Build list with mixed types
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view list-idx)
                  old-list (when (not= old-off -1)
                             (com.seniorcaremarket.eve-sab-deftype.sab-list/SabList. sab old-off))
                  ;; Alternate between different value types
                  val (case (mod v 4)
                        0 v
                        1 (str "str-" v)
                        2 {:map-val v}
                        3 [v (* v 2)])
                  new-list (conj (or old-list (com.seniorcaremarket.eve-sab-deftype.sab-list/empty-sab-list)) val)
                  new-off (.-offset__ new-list)]
              (if (== old-off (js/Atomics.compareExchange int32-view list-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [W" worker-id "] Heterogeneous done in " (.toFixed elapsed 0) "ms "
                        "(retries: " @retries-total ")")))))))

;;-----------------------------------------------------------------------------
;; Test 2: Variable Chunk Size Tests for SabVecN
;;-----------------------------------------------------------------------------

(defn dispatch-chunk-size-vec-worker!
  "Worker tests SabVecN with a specific chunk size."
  [worker vec-idx worker-id values-per-worker chunk-size]
  (in worker [vec-idx worker-id values-per-worker chunk-size]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          sab (:sab env)
          int32-view (js/Int32Array. sab)
          start-val (* worker-id values-per-worker)
          end-val (+ start-val values-per-worker)]

      (println (str "  [W" worker-id "] VecN chunk=" chunk-size " values " start-val "-" (dec end-val)))
      (let [start-time (js/performance.now)
            retries-total (atom 0)]

        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view vec-idx)
                  old-vec (when (not= old-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecN. sab old-off))
                  new-vec (conj (or old-vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec-n chunk-size))
                                {:val v :chunk chunk-size})
                  new-off (.-offset__ new-vec)]
              (if (== old-off (js/Atomics.compareExchange int32-view vec-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [W" worker-id "] VecN chunk=" chunk-size " done in " (.toFixed elapsed 0) "ms "
                        "(retries: " @retries-total ")")))))))

;;-----------------------------------------------------------------------------
;; Test 3: Variable Chunk Size Tests for SabListN
;;-----------------------------------------------------------------------------

(defn dispatch-chunk-size-list-worker!
  "Worker tests SabListN with a specific chunk size."
  [worker list-idx worker-id values-per-worker chunk-size]
  (in worker [list-idx worker-id values-per-worker chunk-size]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          sab (:sab env)
          int32-view (js/Int32Array. sab)
          start-val (* worker-id values-per-worker)
          end-val (+ start-val values-per-worker)]

      (println (str "  [W" worker-id "] ListN chunk=" chunk-size " values " start-val "-" (dec end-val)))
      (let [start-time (js/performance.now)
            retries-total (atom 0)]

        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view list-idx)
                  old-list (when (not= old-off -1)
                             (com.seniorcaremarket.eve-sab-deftype.sab-list/SabListN. sab old-off))
                  new-list (conj (or old-list (com.seniorcaremarket.eve-sab-deftype.sab-list/empty-sab-list-n chunk-size))
                                 {:val v :chunk chunk-size})
                  new-off (.-offset__ new-list)]
              (if (== old-off (js/Atomics.compareExchange int32-view list-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [W" worker-id "] ListN chunk=" chunk-size " done in " (.toFixed elapsed 0) "ms "
                        "(retries: " @retries-total ")")))))))

;;-----------------------------------------------------------------------------
;; Test 4: Cross-Structure Transformations Under Contention
;;-----------------------------------------------------------------------------

(defn dispatch-cross-transform-worker!
  "Worker performs transformations that read from one structure and write to another."
  [worker src-map-idx dest-vec-idx dest-set-idx worker-id values-per-worker]
  (in worker [src-map-idx dest-vec-idx dest-set-idx worker-id values-per-worker]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          sab (:sab env)
          int32-view (js/Int32Array. sab)
          start-val (* worker-id values-per-worker)
          end-val (+ start-val values-per-worker)]

      (println (str "  [W" worker-id "] Cross-transform " start-val "-" (dec end-val)))
      (let [start-time (js/performance.now)
            retries-total (atom 0)]

        ;; Phase 1: Write to source map
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view src-map-idx)
                  old-map (when (not= old-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off))
                  new-map (assoc (or old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/empty-sab-map))
                                 v {:squared (* v v) :cubed (* v v v)})
                  new-off (.-offset__ new-map)]
              (if (== old-off (js/Atomics.compareExchange int32-view src-map-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        ;; Phase 2: Read from map, transform, write to vec
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [map-off (js/Atomics.load int32-view src-map-idx)
                  the-map (when (not= map-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab map-off))
                  map-val (when the-map (get the-map v))
                  transformed (when map-val
                                (assoc map-val :transformed-by worker-id :original-key v))
                  vec-off (js/Atomics.load int32-view dest-vec-idx)
                  old-vec (when (not= vec-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot. sab vec-off))
                  new-vec (conj (or old-vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec))
                                (or transformed {:missing v}))
                  new-off (.-offset__ new-vec)]
              (if (== vec-off (js/Atomics.compareExchange int32-view dest-vec-idx vec-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        ;; Phase 3: Extract keys to set
        (loop [v start-val retries 0]
          (when (and (< v end-val) (< retries com.seniorcaremarket.eve-sab-deftype.heterogeneous-contention-test/MAX-RETRIES))
            (let [old-off (js/Atomics.load int32-view dest-set-idx)
                  old-set (when (not= old-off -1)
                            (com.seniorcaremarket.eve-sab-deftype.sab-set/SabSetRoot. sab old-off))
                  new-set (conj (or old-set (com.seniorcaremarket.eve-sab-deftype.sab-set/empty-sab-set))
                                [:processed v worker-id])
                  new-off (.-offset__ new-set)]
              (if (== old-off (js/Atomics.compareExchange int32-view dest-set-idx old-off new-off))
                (recur (inc v) 0)
                (do (swap! retries-total inc)
                    (recur v (inc retries)))))))

        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [W" worker-id "] Cross-transform done in " (.toFixed elapsed 0) "ms "
                        "(retries: " @retries-total ")")))))))

;;-----------------------------------------------------------------------------
;; Test Runners
;;-----------------------------------------------------------------------------

(defn run-heterogeneous-test
  "Run heterogeneous nested data test with specified tier."
  [tier-key next-fn]
  (let [{:keys [count workers timeout]} (get DATA-TIERS tier-key)
        values-per-worker (quot count workers)]
    (println (str "\n  === Heterogeneous Test (" (name tier-key) ": " count " items, " workers " workers) ==="))
    (let [env (init-env!)
          map-idx (alloc-root-slot! env)
          vec-idx (alloc-root-slot! env)
          set-idx (alloc-root-slot! env)
          list-idx (alloc-root-slot! env)
          worker-pool (vec (repeatedly workers #(w/mk-worker)))]

      (println "  Dispatching workers...")
      (doseq [i (range workers)]
        (dispatch-heterogeneous-transform-worker!
         (nth worker-pool i) map-idx vec-idx set-idx list-idx i values-per-worker))

      (js/setTimeout
       (fn []
         (println "\n  Verifying heterogeneous results...")
         (let [final-map (read-map env map-idx)
               final-vec (read-vec env vec-idx)
               final-set (read-set env set-idx)
               final-list (read-list env list-idx)

               expected-count (* workers values-per-worker)
               map-count (if final-map (cljs.core/count final-map) 0)
               vec-count (if final-vec (cljs.core/count final-vec) 0)
               set-count (if final-set (cljs.core/count final-set) 0)
               list-count (if final-list (cljs.core/count final-list) 0)]

           (println (str "  MAP:  " map-count "/" expected-count))
           (println (str "  VEC:  " vec-count "/" expected-count))
           (println (str "  SET:  " set-count "/" expected-count))
           (println (str "  LIST: " list-count "/" expected-count))

           (let [all-ok? (and (= map-count expected-count)
                              (= vec-count expected-count)
                              (= set-count expected-count)
                              (= list-count expected-count))]
             (println (str "\n  Result: " (if all-ok? "PASS" "FAIL")))
             (cleanup-workers worker-pool)
             (next-fn all-ok?))))
       timeout))))

(defn run-chunk-size-vec-test
  "Run SabVecN tests across all chunk sizes."
  [tier-key next-fn]
  (let [{:keys [count workers timeout]} (get DATA-TIERS tier-key)
        values-per-worker (quot count workers)]
    (println (str "\n  === Chunk Size VecN Test (" (name tier-key) ") ==="))
    (println (str "  Testing chunk sizes: " CHUNK-SIZES))

    (letfn [(test-chunk-size [chunk-sizes results]
              (if (empty? chunk-sizes)
                (do
                  (println "\n  Chunk Size VecN Results:")
                  (doseq [[cs ok?] results]
                    (println (str "    Chunk " cs ": " (if ok? "PASS" "FAIL"))))
                  (next-fn (every? second results)))

                (let [chunk-size (first chunk-sizes)
                      env (init-env!)
                      vec-idx (alloc-root-slot! env)
                      worker-pool (vec (repeatedly workers #(w/mk-worker)))]

                  (println (str "\n  Testing chunk size " chunk-size "..."))
                  (doseq [i (range workers)]
                    (dispatch-chunk-size-vec-worker!
                     (nth worker-pool i) vec-idx i values-per-worker chunk-size))

                  (js/setTimeout
                   (fn []
                     (let [final-vec (read-vec-n env vec-idx chunk-size)
                           expected-count (* workers values-per-worker)
                           actual-count (if final-vec (cljs.core/count final-vec) 0)
                           ok? (= actual-count expected-count)]
                       (println (str "    Count: " actual-count "/" expected-count " - " (if ok? "OK" "FAIL")))
                       (cleanup-workers worker-pool)
                       (test-chunk-size (rest chunk-sizes) (conj results [chunk-size ok?]))))
                   (quot timeout (cljs.core/count CHUNK-SIZES))))))]

      (test-chunk-size CHUNK-SIZES []))))

(defn run-chunk-size-list-test
  "Run SabListN tests across all chunk sizes."
  [tier-key next-fn]
  (let [{:keys [count workers timeout]} (get DATA-TIERS tier-key)
        values-per-worker (quot count workers)]
    (println (str "\n  === Chunk Size ListN Test (" (name tier-key) ") ==="))
    (println (str "  Testing chunk sizes: " CHUNK-SIZES))

    (letfn [(test-chunk-size [chunk-sizes results]
              (if (empty? chunk-sizes)
                (do
                  (println "\n  Chunk Size ListN Results:")
                  (doseq [[cs ok?] results]
                    (println (str "    Chunk " cs ": " (if ok? "PASS" "FAIL"))))
                  (next-fn (every? second results)))

                (let [chunk-size (first chunk-sizes)
                      env (init-env!)
                      list-idx (alloc-root-slot! env)
                      worker-pool (vec (repeatedly workers #(w/mk-worker)))]

                  (println (str "\n  Testing chunk size " chunk-size "..."))
                  (doseq [i (range workers)]
                    (dispatch-chunk-size-list-worker!
                     (nth worker-pool i) list-idx i values-per-worker chunk-size))

                  (js/setTimeout
                   (fn []
                     (let [final-list (read-list-n env list-idx chunk-size)
                           expected-count (* workers values-per-worker)
                           actual-count (if final-list (cljs.core/count final-list) 0)
                           ok? (= actual-count expected-count)]
                       (println (str "    Count: " actual-count "/" expected-count " - " (if ok? "OK" "FAIL")))
                       (cleanup-workers worker-pool)
                       (test-chunk-size (rest chunk-sizes) (conj results [chunk-size ok?]))))
                   (quot timeout (cljs.core/count CHUNK-SIZES))))))]

      (test-chunk-size CHUNK-SIZES []))))

(defn run-cross-transform-test
  "Run cross-structure transformation test."
  [tier-key next-fn]
  (let [{:keys [count workers timeout]} (get DATA-TIERS tier-key)
        values-per-worker (quot count workers)]
    (println (str "\n  === Cross-Transform Test (" (name tier-key) ": " count " items, " workers " workers) ==="))
    (let [env (init-env!)
          src-map-idx (alloc-root-slot! env)
          dest-vec-idx (alloc-root-slot! env)
          dest-set-idx (alloc-root-slot! env)
          worker-pool (vec (repeatedly workers #(w/mk-worker)))]

      (println "  Dispatching workers...")
      (doseq [i (range workers)]
        (dispatch-cross-transform-worker!
         (nth worker-pool i) src-map-idx dest-vec-idx dest-set-idx i values-per-worker))

      (js/setTimeout
       (fn []
         (println "\n  Verifying cross-transform results...")
         (let [final-map (read-map env src-map-idx)
               final-vec (read-vec env dest-vec-idx)
               final-set (read-set env dest-set-idx)

               expected-count (* workers values-per-worker)
               map-count (if final-map (cljs.core/count final-map) 0)
               vec-count (if final-vec (cljs.core/count final-vec) 0)
               set-count (if final-set (cljs.core/count final-set) 0)]

           (println (str "  Source MAP:  " map-count "/" expected-count))
           (println (str "  Dest VEC:    " vec-count "/" expected-count))
           (println (str "  Dest SET:    " set-count "/" expected-count))

           (let [all-ok? (and (= map-count expected-count)
                              (= vec-count expected-count)
                              (= set-count expected-count))]
             (println (str "\n  Result: " (if all-ok? "PASS" "FAIL")))
             (cleanup-workers worker-pool)
             (next-fn all-ok?))))
       timeout))))

;;-----------------------------------------------------------------------------
;; Progressive Scale Test Suite
;;-----------------------------------------------------------------------------

(defn run-progressive-scale-suite
  "Run all tests at progressively larger scales."
  [tier-keys done-fn]
  (println "\n========================================")
  (println "Progressive Scale Test Suite")
  (println "========================================")

  (letfn [(run-tier [tiers all-results]
            (if (empty? tiers)
              (do
                (println "\n========================================")
                (println "Final Summary:")
                (doseq [[tier test-name ok?] all-results]
                  (println (str "  " (name tier) "/" test-name ": " (if ok? "PASS" "FAIL"))))
                (let [all-passed? (every? #(nth % 2) all-results)]
                  (println (str "\nOverall: " (if all-passed? "ALL TESTS PASSED!" "SOME TESTS FAILED")))
                  (println "========================================\n")
                  (done-fn all-passed?)))

              (let [tier (first tiers)]
                (println (str "\n\n>>> TIER: " (name tier) " <<<"))

                (run-heterogeneous-test tier
                  (fn [hetero-ok?]
                    (run-cross-transform-test tier
                      (fn [cross-ok?]
                        (run-tier (rest tiers)
                                  (conj all-results
                                        [tier "heterogeneous" hetero-ok?]
                                        [tier "cross-transform" cross-ok?])))))))))]

    (run-tier tier-keys [])))

;;-----------------------------------------------------------------------------
;; cljs.test Integration
;;-----------------------------------------------------------------------------

(deftest test-heterogeneous-small
  (async done
    (run-heterogeneous-test :small
      (fn [passed?]
        (is passed? "Small heterogeneous test should pass")
        (done)))))

(deftest test-chunk-sizes-vec-small
  (async done
    (run-chunk-size-vec-test :small
      (fn [passed?]
        (is passed? "Small chunk size vec test should pass")
        (done)))))

(deftest test-chunk-sizes-list-small
  (async done
    (run-chunk-size-list-test :small
      (fn [passed?]
        (is passed? "Small chunk size list test should pass")
        (done)))))

(deftest test-cross-transform-small
  (async done
    (run-cross-transform-test :small
      (fn [passed?]
        (is passed? "Small cross-transform test should pass")
        (done)))))

(deftest test-heterogeneous-medium
  (async done
    (run-heterogeneous-test :medium
      (fn [passed?]
        (is passed? "Medium heterogeneous test should pass")
        (done)))))

(deftest test-cross-transform-medium
  (async done
    (run-cross-transform-test :medium
      (fn [passed?]
        (is passed? "Medium cross-transform test should pass")
        (done)))))

;;-----------------------------------------------------------------------------
;; Main Entry Point
;;-----------------------------------------------------------------------------

(defn run-all-heterogeneous-tests
  "Run the complete test suite."
  []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (run-progressive-scale-suite
       [:small :medium]  ;; Can add :large :huge for longer runs
       (fn [all-passed?]
         (println (str "\nTest suite completed: " (if all-passed? "SUCCESS" "FAILURE"))))))))

(defn run-chunk-benchmark
  "Run chunk size comparison benchmark."
  []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (println "\n========================================")
      (println "Chunk Size Comparison Benchmark")
      (println "========================================")

      (run-chunk-size-vec-test :medium
        (fn [vec-ok?]
          (run-chunk-size-list-test :medium
            (fn [list-ok?]
              (println (str "\nBenchmark complete: VecN=" (if vec-ok? "OK" "FAIL")
                            " ListN=" (if list-ok? "OK" "FAIL"))))))))))

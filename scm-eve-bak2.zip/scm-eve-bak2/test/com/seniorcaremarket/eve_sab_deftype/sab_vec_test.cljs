(ns com.seniorcaremarket.eve-sab-deftype.sab-vec-test
  (:require
   [cljs.test :refer-macros [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]))

;;-----------------------------------------------------------------------------
;; Setup
;;-----------------------------------------------------------------------------

;; Use larger SAB for vector tests (4MB with 16K block descriptors)
;; Must set *global-atom-instance* since alloc-node! uses it
(def _init-atom
  (let [large-atom (atom/private-atom {} :sab-size (* 4 1024 1024)
                                         :max-blocks 16384)]
    (set! atom/*global-atom-instance* large-atom)
    large-atom))

;;-----------------------------------------------------------------------------
;; Basic Operations
;;-----------------------------------------------------------------------------

(deftest empty-vec-test
  (testing "Empty vector"
    (let [v (sv/empty-sab-vec)]
      (is (= 0 (count v)))
      (is (nil? (peek v)))
      (is (nil? (get v 0)))
      (is (= :not-found (get v 0 :not-found))))))

(deftest conj-test
  (testing "Conj single element"
    (let [v (conj (sv/empty-sab-vec) 42)]
      (is (= 1 (count v)))
      (is (= 42 (nth v 0)))
      (is (= 42 (peek v)))
      (is (= 42 (get v 0)))
      (is (= 42 (v 0)))))

  (testing "Conj multiple elements"
    (let [v (-> (sv/empty-sab-vec)
                (conj 1)
                (conj 2)
                (conj 3))]
      (is (= 3 (count v)))
      (is (= 1 (nth v 0)))
      (is (= 2 (nth v 1)))
      (is (= 3 (nth v 2)))
      (is (= 3 (peek v))))))

(deftest sab-vec-constructor-test
  (testing "sab-vec from collection"
    (let [v (sv/sab-vec [10 20 30 40 50])]
      (is (= 5 (count v)))
      (is (= 10 (nth v 0)))
      (is (= 30 (nth v 2)))
      (is (= 50 (peek v))))))

;;-----------------------------------------------------------------------------
;; Indexed Access
;;-----------------------------------------------------------------------------

(deftest nth-test
  (testing "nth within bounds"
    (let [v (sv/sab-vec (range 10))]
      (dotimes [i 10]
        (is (= i (nth v i))))))

  (testing "nth with not-found"
    (let [v (sv/sab-vec [1 2 3])]
      (is (= :nope (nth v 100 :nope)))
      (is (= :nope (nth v -1 :nope))))))

;;-----------------------------------------------------------------------------
;; Assoc
;;-----------------------------------------------------------------------------

(deftest assoc-test
  (testing "Assoc existing index"
    (let [v (sv/sab-vec [10 20 30])
          v2 (assoc v 1 99)]
      ;; Original unchanged (persistent)
      (is (= 20 (nth v 1)))
      ;; New vector updated
      (is (= 99 (nth v2 1)))
      (is (= 10 (nth v2 0)))
      (is (= 30 (nth v2 2)))))

  (testing "Assoc at count (append)"
    (let [v (sv/sab-vec [1 2 3])
          v2 (assoc v 3 4)]
      (is (= 4 (count v2)))
      (is (= 4 (nth v2 3))))))

;;-----------------------------------------------------------------------------
;; Pop
;;-----------------------------------------------------------------------------

(deftest pop-test
  (testing "Pop single element"
    (let [v (sv/sab-vec [1 2 3])
          v2 (pop v)]
      (is (= 2 (count v2)))
      (is (= 1 (nth v2 0)))
      (is (= 2 (nth v2 1)))
      (is (= 2 (peek v2)))))

  (testing "Pop to empty"
    (let [v (sv/sab-vec [42])
          v2 (pop v)]
      (is (= 0 (count v2)))))

  (testing "Pop empty throws"
    (is (thrown? js/Error (pop (sv/empty-sab-vec))))))

;;-----------------------------------------------------------------------------
;; Sequence Operations
;;-----------------------------------------------------------------------------

(deftest seq-test
  (testing "seq produces lazy sequence"
    (let [v (sv/sab-vec [1 2 3 4 5])
          s (seq v)]
      (is (= [1 2 3 4 5] (vec s)))))

  (testing "Empty vec seq is nil"
    (is (nil? (seq (sv/empty-sab-vec))))))

(deftest reduce-test
  (testing "Reduce with initial value"
    (let [v (sv/sab-vec [1 2 3 4 5])]
      (is (= 15 (reduce + 0 v)))))

  (testing "Reduce without initial value"
    (let [v (sv/sab-vec [1 2 3 4 5])]
      (is (= 15 (reduce + v)))))

  (testing "Reduce on empty"
    (let [v (sv/empty-sab-vec)]
      (is (= 0 (reduce + 0 v)))
      ;; (reduce + []) returns 0 because (+) = 0
      (is (= 0 (reduce + v))))))

;;-----------------------------------------------------------------------------
;; Equality and Hashing
;;-----------------------------------------------------------------------------

(deftest equality-test
  (testing "Equal vectors"
    (let [v1 (sv/sab-vec [1 2 3])
          v2 (sv/sab-vec [1 2 3])]
      (is (= v1 v2))))

  (testing "Unequal vectors"
    (let [v1 (sv/sab-vec [1 2 3])
          v2 (sv/sab-vec [1 2 4])]
      (is (not= v1 v2))))

  (testing "Equal to regular vector"
    (let [v1 (sv/sab-vec [1 2 3])
          v2 [1 2 3]]
      (is (= v1 v2))
      (is (= v2 v1)))))

;;-----------------------------------------------------------------------------
;; Large Vector Tests (exercises trie)
;;-----------------------------------------------------------------------------

(deftest large-vector-test
  (testing "Build and access large vector"
    (let [n 100
          v (sv/sab-vec (range n))]
      (is (= n (count v)))
      ;; Check some samples
      (is (= 0 (nth v 0)))
      (is (= 50 (nth v 50)))
      (is (= 99 (nth v 99)))
      ;; Reduce
      (is (= (reduce + (range n)) (reduce + 0 v))))))

(deftest very-large-vector-test
  (testing "Build and access vector beyond tail (triggers trie)"
    (let [n 1000
          v (sv/sab-vec (range n))]
      (is (= n (count v)))
      ;; Spot check various indices
      (is (= 0 (nth v 0)))
      (is (= 31 (nth v 31)))
      (is (= 32 (nth v 32)))
      (is (= 100 (nth v 100)))
      (is (= 500 (nth v 500)))
      (is (= 999 (nth v 999)))
      ;; Assoc deep in trie
      (let [v2 (assoc v 500 -500)]
        (is (= -500 (nth v2 500)))
        (is (= 500 (nth v 500)))))))

(deftest persistence-test
  (testing "Multiple branches share structure"
    (let [v1 (sv/sab-vec (range 100))
          v2 (assoc v1 50 -50)
          v3 (assoc v1 50 -100)]
      ;; v1 unchanged
      (is (= 50 (nth v1 50)))
      ;; v2 and v3 have different values
      (is (= -50 (nth v2 50)))
      (is (= -100 (nth v3 50)))
      ;; Other elements unchanged
      (is (= 0 (nth v2 0)))
      (is (= 99 (nth v2 99))))))

;;-----------------------------------------------------------------------------
;; Pop with Trie
;;-----------------------------------------------------------------------------

(deftest pop-large-test
  (testing "Pop from large vector"
    (let [n 100
          v (sv/sab-vec (range n))
          v2 (pop v)]
      (is (= (dec n) (count v2)))
      (is (= 98 (peek v2)))))

  (testing "Pop many times"
    (let [v (sv/sab-vec (range 50))]
      (loop [v v expected 50]
        (when (pos? expected)
          (is (= expected (count v)))
          (recur (pop v) (dec expected)))))))

(ns com.seniorcaremarket.eve-sab-deftype.performance-comparison-test
  "Performance comparison: new eve-sab-deftype structures vs old sabp-* structures.

   Compares:
   - Regular CLJS structures (map, set, vector, list)
   - Old sabp-* structures (manual deftype, SAB serialization)
   - New sab-* structures (eve-sab-deftype macro, SAB serialization)

   Both SAB-backed structures support arbitrary CLJS values via fast-path serialization.
   The new structures use the eve-sab-deftype macro for cleaner code."
  (:require
   [cljs.test :refer [deftest is testing run-tests]]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   ;; Old sabp-* structures
   [com.seniorcaremarket.eve.sabp-map :as old-map]
   [com.seniorcaremarket.eve.sabp-set :as old-set]
   [com.seniorcaremarket.eve.sabp-list :as old-list]
   ;; New eve-sab-deftype structures
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as new-vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as new-list]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as new-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as new-set]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Utilities
;;-----------------------------------------------------------------------------

(defn now [] (js/performance.now))

(def ^:dynamic *results* (atom []))

(defn record! [category label ops duration-ms]
  (let [ops-sec (if (pos? duration-ms) (/ (* ops 1000) duration-ms) 0)]
    (swap! *results* conj
           {:category category :label label :ops ops
            :duration-ms duration-ms :ops-sec ops-sec})
    (println (str "  [" category "] " label ": "
                  (.toFixed duration-ms 2) "ms, "
                  (.toFixed ops-sec 0) " ops/sec"))))

(defn fresh-env
  [& {:keys [sab-size max-blocks]
      :or {sab-size (* 8 1024 1024) max-blocks 32768}}]
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size sab-size :max-blocks max-blocks))
  (a/get-env a/*global-atom-instance*))

;;-----------------------------------------------------------------------------
;; MAP Performance Comparison
;;-----------------------------------------------------------------------------

(deftest test-map-build-comparison
  (testing "Map build: CLJS vs old-SAB vs new-SAB"
    (doseq [n [50 100 200 500]]
      (println (str "\n  --- Map build (n=" n ") ---"))

      ;; Regular CLJS persistent map (with integer keys)
      (let [start (now)
            m (loop [m {} i 0]
                (if (>= i n) m (recur (assoc m i (* i i)) (inc i))))
            dur (- (now) start)]
        (record! "CLJS" (str "Map build n=" n) n dur)
        (is (= n (count m))))

      ;; Old sabp-map (fressian-based, arbitrary keys)
      (let [env (fresh-env)
            start (now)
            m (loop [m (old-map/sabp-map env) i 0]
                (if (>= i n) m (recur (assoc m i (* i i)) (inc i))))
            dur (- (now) start)]
        (record! "OLD-SAB" (str "Map build n=" n) n dur)
        (is (= n (count m))))

      ;; New sab-map (direct SAB, int32 only)
      (let [_ (fresh-env)
            start (now)
            m (loop [m (new-map/empty-sab-map) i 0]
                (if (>= i n) m (recur (assoc m i (* i i)) (inc i))))
            dur (- (now) start)]
        (record! "NEW-SAB" (str "Map build n=" n) n dur)
        (is (= n (count m)))))))

(deftest test-map-lookup-comparison
  (testing "Map lookup: CLJS vs old-SAB vs new-SAB"
    (doseq [n [50 100 200 500]]
      (println (str "\n  --- Map lookup (n=" n ", 100 reps) ---"))
      (let [reps 100
            total-ops (* reps n)]

        ;; Build maps first
        (let [cljs-map (into {} (map (fn [i] [i (* i i)]) (range n)))

              env1 (fresh-env)
              old-map (loop [m (old-map/sabp-map env1) i 0]
                        (if (>= i n) m (recur (assoc m i (* i i)) (inc i))))

              _ (fresh-env)
              new-map (loop [m (new-map/empty-sab-map) i 0]
                        (if (>= i n) m (recur (assoc m i (* i i)) (inc i))))]

          ;; CLJS lookup
          (let [start (now)]
            (dotimes [_ reps]
              (dotimes [i n] (get cljs-map i)))
            (record! "CLJS" (str "Map lookup n=" n) total-ops (- (now) start)))

          ;; Old SAB lookup
          (let [start (now)]
            (dotimes [_ reps]
              (dotimes [i n] (get old-map i)))
            (record! "OLD-SAB" (str "Map lookup n=" n) total-ops (- (now) start)))

          ;; New SAB lookup
          (let [start (now)]
            (dotimes [_ reps]
              (dotimes [i n] (get new-map i)))
            (record! "NEW-SAB" (str "Map lookup n=" n) total-ops (- (now) start))))

        (is true)))))

;;-----------------------------------------------------------------------------
;; SET Performance Comparison
;;-----------------------------------------------------------------------------

(deftest test-set-build-comparison
  (testing "Set build: CLJS vs old-SAB vs new-SAB"
    (doseq [n [50 100 200 500]]
      (println (str "\n  --- Set build (n=" n ") ---"))

      ;; Regular CLJS set
      (let [start (now)
            s (loop [s #{} i 0]
                (if (>= i n) s (recur (conj s i) (inc i))))
            dur (- (now) start)]
        (record! "CLJS" (str "Set build n=" n) n dur)
        (is (= n (count s))))

      ;; Old sabp-set
      (let [env (fresh-env)
            start (now)
            s (loop [s (old-set/sabp-set env) i 0]
                (if (>= i n) s (recur (conj s i) (inc i))))
            dur (- (now) start)]
        (record! "OLD-SAB" (str "Set build n=" n) n dur)
        (is (= n (count s))))

      ;; New sab-set
      (let [_ (fresh-env)
            start (now)
            s (loop [s (new-set/empty-sab-set) i 0]
                (if (>= i n) s (recur (conj s i) (inc i))))
            dur (- (now) start)]
        (record! "NEW-SAB" (str "Set build n=" n) n dur)
        (is (= n (count s)))))))

(deftest test-set-contains-comparison
  (testing "Set contains?: CLJS vs old-SAB vs new-SAB"
    (doseq [n [50 100 200 500]]
      (println (str "\n  --- Set contains? (n=" n ", 100 reps) ---"))
      (let [reps 100
            total-ops (* reps n)]

        ;; Build sets first
        (let [cljs-set (into #{} (range n))

              env1 (fresh-env)
              old-set (loop [s (old-set/sabp-set env1) i 0]
                        (if (>= i n) s (recur (conj s i) (inc i))))

              _ (fresh-env)
              new-set (loop [s (new-set/empty-sab-set) i 0]
                        (if (>= i n) s (recur (conj s i) (inc i))))]

          ;; CLJS contains?
          (let [start (now)]
            (dotimes [_ reps]
              (dotimes [i n] (contains? cljs-set i)))
            (record! "CLJS" (str "Set contains? n=" n) total-ops (- (now) start)))

          ;; Old SAB contains?
          (let [start (now)]
            (dotimes [_ reps]
              (dotimes [i n] (contains? old-set i)))
            (record! "OLD-SAB" (str "Set contains? n=" n) total-ops (- (now) start)))

          ;; New SAB contains?
          (let [start (now)]
            (dotimes [_ reps]
              (dotimes [i n] (contains? new-set i)))
            (record! "NEW-SAB" (str "Set contains? n=" n) total-ops (- (now) start))))

        (is true)))))

;;-----------------------------------------------------------------------------
;; LIST/VECTOR Performance Comparison
;;-----------------------------------------------------------------------------

(deftest test-list-build-comparison
  (testing "List/Vector build: CLJS vs old-SAB vs new-SAB"
    (doseq [n [100 200 500 1000]]
      (println (str "\n  --- List build (n=" n ") ---"))

      ;; Regular CLJS vector
      (let [start (now)
            v (loop [v [] i 0]
                (if (>= i n) v (recur (conj v i) (inc i))))
            dur (- (now) start)]
        (record! "CLJS-vec" (str "Vec build n=" n) n dur)
        (is (= n (count v))))

      ;; Regular CLJS list
      (let [start (now)
            l (loop [l (list) i 0]
                (if (>= i n) l (recur (conj l i) (inc i))))
            dur (- (now) start)]
        (record! "CLJS-list" (str "List build n=" n) n dur)
        (is (= n (count l))))

      ;; Old sabp-list
      (let [env (fresh-env)
            start (now)
            l (loop [l (old-list/->SabpLinkedList env d/ROOT_POINTER_NIL_SENTINEL 0 nil nil) i 0]
                (if (>= i n) l (recur (conj l i) (inc i))))
            dur (- (now) start)]
        (record! "OLD-SAB" (str "List build n=" n) n dur)
        (is (= n (count l))))

      ;; New sab-vec
      (let [_ (fresh-env)
            start (now)
            v (loop [v (new-vec/empty-sab-vec) i 0]
                (if (>= i n) v (recur (conj v i) (inc i))))
            dur (- (now) start)]
        (record! "NEW-SAB-vec" (str "Vec build n=" n) n dur)
        (is (= n (count v))))

      ;; New sab-list
      (let [_ (fresh-env)
            start (now)
            l (loop [l (new-list/empty-sab-list) i 0]
                (if (>= i n) l (recur (conj l i) (inc i))))
            dur (- (now) start)]
        (record! "NEW-SAB-list" (str "List build n=" n) n dur)
        (is (= n (count l)))))))

;;-----------------------------------------------------------------------------
;; Transient Performance Comparison (Map/Set)
;;-----------------------------------------------------------------------------

(deftest test-map-transient-comparison
  (testing "Map transient build: CLJS vs old-SAB vs new-SAB"
    (doseq [n [100 500 1000]]
      (println (str "\n  --- Map transient build (n=" n ") ---"))

      ;; CLJS transient
      (let [start (now)
            m (persistent!
               (reduce (fn [t i] (assoc! t i (* i i)))
                       (transient {}) (range n)))
            dur (- (now) start)]
        (record! "CLJS-t" (str "Map transient n=" n) n dur)
        (is (= n (count m))))

      ;; Old SAB transient
      (let [env (fresh-env)
            start (now)
            m (persistent!
               (reduce (fn [t i] (assoc! t i (* i i)))
                       (transient (old-map/sabp-map env)) (range n)))
            dur (- (now) start)]
        (record! "OLD-SAB-t" (str "Map transient n=" n) n dur)
        (is (= n (count m))))

      ;; New SAB transient
      (let [_ (fresh-env)
            start (now)
            m (persistent!
               (reduce (fn [t i] (assoc! t i (* i i)))
                       (transient (new-map/empty-sab-map)) (range n)))
            dur (- (now) start)]
        (record! "NEW-SAB-t" (str "Map transient n=" n) n dur)
        (is (= n (count m)))))))

;;-----------------------------------------------------------------------------
;; Summary Report
;;-----------------------------------------------------------------------------

(defn pad-right [s width]
  (let [s (str s)
        pad (- width (count s))]
    (if (<= pad 0) s (str s (apply str (repeat pad " "))))))

(defn print-summary []
  (println "\n" (apply str (repeat 80 "=")))
  (println "  PERFORMANCE COMPARISON: Old SAB (sabp) vs New SAB (eve-sab-deftype)")
  (println (apply str (repeat 80 "=")) "\n")

  (let [results @*results*
        cljs-results (filter #(or (= "CLJS" (:category %))
                                  (= "CLJS-vec" (:category %))
                                  (= "CLJS-list" (:category %))
                                  (= "CLJS-t" (:category %))) results)
        old-sab-results (filter #(or (= "OLD-SAB" (:category %))
                                     (= "OLD-SAB-t" (:category %))) results)
        new-sab-results (filter #(or (= "NEW-SAB" (:category %))
                                     (= "NEW-SAB-vec" (:category %))
                                     (= "NEW-SAB-list" (:category %))) results)]

    (println "  KEY FINDINGS:")
    (println (str "  " (apply str (repeat 76 "-"))))

    ;; Compare old vs new SAB for same operations
    (println "\n  OLD-SAB (fressian) vs NEW-SAB (eve-sab-deftype) - same operation type:")
    (println (str "  " (pad-right "Operation" 30) (pad-right "OLD ops/s" 15)
                  (pad-right "NEW ops/s" 15) "Speedup"))
    (println (str "  " (apply str (repeat 70 "-"))))

    (doseq [old-r old-sab-results
            :when (not (.includes (:label old-r) "transient"))
            :let [;; Extract operation type from label
                  label (:label old-r)
                  ;; Find matching new result
                  new-r (first (filter #(= label (:label %)) new-sab-results))]]
      (when new-r
        (let [speedup (if (pos? (:ops-sec old-r))
                        (/ (:ops-sec new-r) (:ops-sec old-r))
                        0)]
          (println (str "  " (pad-right label 30)
                        (pad-right (.toFixed (:ops-sec old-r) 0) 15)
                        (pad-right (.toFixed (:ops-sec new-r) 0) 15)
                        (.toFixed speedup 2) "x")))))

    (println "\n" (str "  " (apply str (repeat 76 "-"))))
    (println "  Speedup > 1.0 means NEW-SAB is faster than OLD-SAB")
    (println "  NEW-SAB: eve-sab-deftype macro, SAB serialization")
    (println "  OLD-SAB: Manual deftype, SAB serialization")
    (println "  Both support arbitrary CLJS values")
    (println (str "  " (apply str (repeat 76 "="))))))

;;-----------------------------------------------------------------------------
;; Test Runner
;;-----------------------------------------------------------------------------

(defn run-performance-comparison []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (reset! *results* [])
      (println "\n" (apply str (repeat 80 "="))
               "\n  BENCHMARK: Old SAB (sabp) vs New SAB (eve-sab-deftype)"
               "\n" (apply str (repeat 80 "=")) "\n")
      (run-tests)
      (print-summary))))

(run-performance-comparison)

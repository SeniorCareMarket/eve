(ns com.seniorcaremarket.eve-sab-deftype.sab-vec-contention-test
  "Multi-worker contention test for SAB-backed persistent vector.

   Spawns N workers that concurrently conj elements to a shared vector.
   The root offset is stored in a dedicated Int32 slot in the SAB,
   updated via Atomics.compareExchange (CAS loop pattern).

   After all workers finish, verifies:
     - Count matches expected total
     - All elements are present
     - Persistence works correctly under contention"
  (:require
   [cljs.test :refer [deftest is testing async run-tests]]
   [clojure.set :as set]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Environment setup
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize the global atom with a large SAB for contention tests."
  []
  ;; Use 16MB SAB with 64K block descriptors for high-contention scenarios
  ;; CAS retries cause lots of allocations, need plenty of headroom
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 16 1024 1024) :max-blocks 65536))
  (a/get-env a/*global-atom-instance*))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

;;-----------------------------------------------------------------------------
;; Root slot for shared vector (atomic Int32 storing offset)
;;-----------------------------------------------------------------------------

(defn alloc-root-slot!
  "Allocate 4 bytes for an atomic Int32 root pointer.
   Returns the Int32 index (byte-offset >> 2). Initialized to -1 (empty)."
  [env]
  (let [alloc-result (a/alloc env 8) ;; 8 bytes for alignment safety
        _ (when (:error alloc-result)
            (throw (js/Error. (str "Failed to alloc root slot: " (:error alloc-result)))))
        byte-offset (:offset alloc-result)
        ;; Align to 4-byte boundary
        aligned-offset (let [rem (mod byte-offset 4)]
                         (if (zero? rem) byte-offset (+ byte-offset (- 4 rem))))
        int32-idx (unsigned-bit-shift-right aligned-offset 2)
        int32-view (js/Int32Array. (:sab env))]
    (js/Atomics.store int32-view int32-idx -1)
    int32-idx))

(defn read-root-vec
  "Read the current vector from the atomic root slot."
  [env int32-idx]
  (let [root-off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= root-off -1)
      (sv/SabVecRoot. (:sab env) root-off))))

(defn cas-conj!
  "CAS-loop conj for the main thread. Adds val to the shared vector."
  [env int32-idx val]
  (let [int32-view (js/Int32Array. (:sab env))]
    (loop [retries 0]
      (when (> retries 1000)
        (throw (js/Error. "cas-conj! exceeded max retries")))
      (let [old-root-off (js/Atomics.load int32-view int32-idx)
            old-vec (if (== old-root-off -1)
                      nil
                      (sv/SabVecRoot. (:sab env) old-root-off))
            new-vec (if old-vec
                      (conj old-vec val)
                      (conj (sv/empty-sab-vec) val))
            new-root-off (.-offset__ new-vec)]
        (if (== old-root-off
                (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
          new-vec
          (recur (inc retries)))))))

;;-----------------------------------------------------------------------------
;; Worker dispatch helpers
;;-----------------------------------------------------------------------------

(defn dispatch-worker-conj-range!
  "Send a range of values to conj to a worker.
   Worker adds values [start-val, start-val+cnt) to the shared vector."
  [worker int32-idx start-val cnt]
  (in worker [int32-idx start-val cnt]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          end-val (+ start-val cnt)
          int32-view (js/Int32Array. (:sab env))]
      (println (str "  [Worker] Conj " cnt " values starting at " start-val))
      (let [start-time (js/performance.now)]
        (loop [v start-val retries 0]
          (when (< v end-val)
            (if (> retries 1000)
              (println (str "  [Worker] WARN: exceeded retries at value " v))
              (let [old-root-off (js/Atomics.load int32-view int32-idx)
                    old-vec (when (not= old-root-off -1)
                              (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot.
                               (:sab env) old-root-off))
                    new-vec (if old-vec
                              (conj old-vec v)
                              (conj (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec) v))
                    new-root-off (.-offset__ new-vec)]
                (if (== old-root-off
                        (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
                  (recur (inc v) 0)
                  (recur v (inc retries)))))))
        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [Worker] Done from " start-val " in "
                        (.toFixed elapsed 0) "ms ("
                        (.toFixed (/ (* cnt 1000) elapsed) 0) " conj/sec)")))))))

(defn dispatch-worker-read-verify!
  "Have a worker read and verify specific elements from the shared vector."
  [worker int32-idx expected-count sample-indices]
  (in worker [int32-idx expected-count sample-indices]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          int32-view (js/Int32Array. (:sab env))
          root-off (js/Atomics.load int32-view int32-idx)]
      (if (== root-off -1)
        (println "  [Worker] ERROR: Root is nil!")
        (let [vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot. (:sab env) root-off)
              cnt (count vec)]
          (println (str "  [Worker] Read vector with count=" cnt " (expected " expected-count ")"))
          (if (not= cnt expected-count)
            (println "  [Worker] ERROR: Count mismatch!")
            (do
              (doseq [idx sample-indices]
                (let [val (nth vec idx nil)]
                  (when (nil? val)
                    (println (str "  [Worker] ERROR: nil at index " idx)))))
              (println "  [Worker] Read verification complete"))))))))

;;-----------------------------------------------------------------------------
;; Test: 4 workers x 25 values = 100 total
;;-----------------------------------------------------------------------------

(defn run-test-40
  "4 workers each conj 10 values to a shared vector (smaller to avoid OOM)."
  [next-fn]
  (println "\n  == Test: sab-vec Contention (4 workers x 10 = 40) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        num-workers 4
        vals-per-worker 10
        total-vals (* num-workers vals-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    ;; Each worker conjs a disjoint range of values
    (dispatch-worker-conj-range! (nth workers 0) int32-idx 0 vals-per-worker)
    (dispatch-worker-conj-range! (nth workers 1) int32-idx 10 vals-per-worker)
    (dispatch-worker-conj-range! (nth workers 2) int32-idx 20 vals-per-worker)
    (dispatch-worker-conj-range! (nth workers 3) int32-idx 30 vals-per-worker)

    (js/setTimeout
     (fn []
       (let [vec (read-root-vec env int32-idx)]
         (if (nil? vec)
           (do
             (println "  [RESULT] ERROR: Vector is nil!")
             (is false "Vector should not be nil"))
           (let [cnt (count vec)]
             (println (str "  [RESULT] count=" cnt " expected=" total-vals))
             (is (= total-vals cnt) (str "Expected " total-vals " values, got " cnt))

             ;; Collect all values to verify they're all present
             (let [all-vals (set (seq vec))
                   expected-set (set (range total-vals))
                   missing (set/difference expected-set all-vals)
                   extra (set/difference all-vals expected-set)]
               (println (str "  [RESULT] missing=" (count missing) " extra=" (count extra)))
               (is (empty? missing) (str "Missing values: " (take 10 missing)))
               (is (empty? extra) (str "Extra values: " (take 10 extra))))))

         (println "  [RESULT] 40-value contention test complete.")
         (cleanup-workers workers)
         (next-fn)))
     20000)))

;;-----------------------------------------------------------------------------
;; Test: 4 workers x 100 values = 400 total (stress)
;;-----------------------------------------------------------------------------

(defn run-test-400
  "4 workers each conj 100 values (higher contention)."
  [next-fn]
  (println "\n  == Test: sab-vec Contention STRESS (4 workers x 100 = 400) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        num-workers 4
        vals-per-worker 100
        total-vals (* num-workers vals-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (dispatch-worker-conj-range! (nth workers 0) int32-idx 0 vals-per-worker)
    (dispatch-worker-conj-range! (nth workers 1) int32-idx 100 vals-per-worker)
    (dispatch-worker-conj-range! (nth workers 2) int32-idx 200 vals-per-worker)
    (dispatch-worker-conj-range! (nth workers 3) int32-idx 300 vals-per-worker)

    (js/setTimeout
     (fn []
       (let [vec (read-root-vec env int32-idx)]
         (if (nil? vec)
           (do
             (println "  [RESULT] ERROR: Vector is nil!")
             (is false "Vector should not be nil"))
           (let [cnt (count vec)]
             (println (str "  [RESULT] count=" cnt " expected=" total-vals))
             (is (= total-vals cnt) (str "Expected " total-vals " values, got " cnt))

             ;; Spot check some values
             (let [all-vals (set (seq vec))]
               (is (contains? all-vals 0) "Should contain 0")
               (is (contains? all-vals 199) "Should contain 199")
               (is (contains? all-vals 399) "Should contain 399")
               (is (not (contains? all-vals 400)) "Should not contain 400")

               ;; Check total coverage
               (let [expected-set (set (range total-vals))
                     missing-count (count (set/difference expected-set all-vals))]
                 (println (str "  [RESULT] missing values: " missing-count))
                 (is (zero? missing-count) "All values should be present")))))

         (println "  [RESULT] 400-value stress test complete.")
         (cleanup-workers workers)
         (next-fn)))
     60000)))

;;-----------------------------------------------------------------------------
;; Test: Main thread + 4 workers concurrent reads
;;-----------------------------------------------------------------------------

(defn run-test-concurrent-reads
  "Build a vector, then have main + workers read concurrently."
  [next-fn]
  (println "\n  == Test: sab-vec Concurrent Reads (main + 4 workers) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        vec-size 200
        workers (vec (repeatedly 4 #(w/mk-worker)))]

    ;; Main thread builds the vector
    (println "  [Main] Building vector with " vec-size " elements")
    (loop [i 0]
      (when (< i vec-size)
        (cas-conj! env int32-idx i)
        (recur (inc i))))
    (println "  [Main] Vector built")

    ;; Verify on main thread first
    (let [vec (read-root-vec env int32-idx)
          main-cnt (count vec)]
      (println (str "  [Main] Initial count: " main-cnt))
      (is (= vec-size main-cnt) "Main thread should see full vector"))

    ;; Have workers read and verify
    (dispatch-worker-read-verify! (nth workers 0) int32-idx vec-size [0 50 100 150 199])
    (dispatch-worker-read-verify! (nth workers 1) int32-idx vec-size [10 60 110 160])
    (dispatch-worker-read-verify! (nth workers 2) int32-idx vec-size [20 70 120 170])
    (dispatch-worker-read-verify! (nth workers 3) int32-idx vec-size [30 80 130 180])

    (js/setTimeout
     (fn []
       ;; Final verification from main
       (let [vec (read-root-vec env int32-idx)]
         (let [final-sum (reduce + 0 vec)
               expected-sum (reduce + (range vec-size))]
           (println (str "  [RESULT] final sum=" final-sum " expected=" expected-sum))
           (is (= expected-sum final-sum) "Sum should match")))

       (println "  [RESULT] Concurrent reads test complete.")
       (cleanup-workers workers)
       (next-fn))
     15000)))

;;-----------------------------------------------------------------------------
;; Test: Mixed - main and workers both conj
;;-----------------------------------------------------------------------------

(defn run-test-mixed
  "Main thread and workers all conj interleaved values."
  [next-fn]
  (println "\n  == Test: sab-vec Mixed Contention (main + 4 workers interleaved) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        total-vals 100
        num-agents 5 ;; main + 4 workers
        workers (vec (repeatedly 4 #(w/mk-worker)))]

    ;; Workers add their interleaved values (agents 1-4)
    ;; Agent 1 adds: 1, 6, 11, 16, ...
    ;; Agent 2 adds: 2, 7, 12, 17, ...
    ;; etc.
    (doseq [[idx worker] (map-indexed vector workers)]
      (let [agent-id (inc idx)] ;; 1-4
        (in worker [int32-idx agent-id total-vals num-agents]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                int32-view (js/Int32Array. (:sab env))]
            (println (str "  [Worker agent-" agent-id "] Starting interleaved conj"))
            (loop [v agent-id retries 0]
              (when (< v total-vals)
                (if (> retries 500)
                  (do
                    (println (str "  [Worker agent-" agent-id "] WARN: high retries at " v))
                    (recur (+ v num-agents) 0))
                  (let [old-root-off (js/Atomics.load int32-view int32-idx)
                        old-vec (when (not= old-root-off -1)
                                  (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot.
                                   (:sab env) old-root-off))
                        new-vec (if old-vec
                                  (conj old-vec v)
                                  (conj (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec) v))
                        new-root-off (.-offset__ new-vec)]
                    (if (== old-root-off
                            (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
                      (recur (+ v num-agents) 0)
                      (recur v (inc retries)))))))
            (println (str "  [Worker agent-" agent-id "] Done"))))))

    ;; Main thread adds agent-0 values: 0, 5, 10, 15, ...
    (println "  [Main agent-0] Starting interleaved conj")
    (loop [v 0]
      (when (< v total-vals)
        (cas-conj! env int32-idx v)
        (recur (+ v num-agents))))
    (println "  [Main agent-0] Done")

    (js/setTimeout
     (fn []
       (let [vec (read-root-vec env int32-idx)]
         (if (nil? vec)
           (do
             (println "  [RESULT] ERROR: Vector is nil!")
             (is false "Vector should not be nil"))
           (let [cnt (count vec)
                 all-vals (set (seq vec))
                 expected-set (set (range total-vals))]
             (println (str "  [RESULT] count=" cnt " expected=" total-vals))
             (is (= total-vals cnt) (str "Expected " total-vals " values"))

             (let [missing (set/difference expected-set all-vals)]
               (println (str "  [RESULT] missing=" (count missing)))
               (is (empty? missing) (str "Missing: " (take 10 missing)))))))

       (println "  [RESULT] Mixed contention test complete.")
       (cleanup-workers workers)
       (next-fn))
     30000)))

;;-----------------------------------------------------------------------------
;; Test entry point
;;-----------------------------------------------------------------------------

(deftest test-sab-vec-contention
  (testing "sab-vec under multi-worker contention"
    (async done
      (run-test-40
       (fn []
         (run-test-concurrent-reads
          (fn []
            (run-test-mixed
             (fn []
               (println "\n  == All sab-vec contention tests complete ==")
               (done))))))))))

;;-----------------------------------------------------------------------------
;; Runner
;;-----------------------------------------------------------------------------

(defn run-contention-tests []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (println "\n--- sab-vec Contention Tests ---\n")
      (run-tests)
      (println "\n--- sab-vec Contention Tests Complete ---\n"))))

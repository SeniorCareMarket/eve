(ns com.seniorcaremarket.eve-sab-deftype.perf-benchmark
  "Performance benchmark for EVE SAB data structures and atom operations.
   Measures throughput for map/set/vec/list operations and atom deref/swap."
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]))

;;-----------------------------------------------------------------------------
;; Benchmark infrastructure
;;-----------------------------------------------------------------------------

(defn bench
  "Run f repeatedly and return timing stats.
   Returns {:mean-us :median-us :min-us :ops-s :iters}"
  [f & {:keys [iters warmup] :or {iters 1000 warmup 100}}]
  (dotimes [_ warmup] (f))
  (let [times (js/Float64Array. iters)]
    (dotimes [i iters]
      (let [start (js/performance.now)]
        (f)
        (aset times i (- (js/performance.now) start))))
    (let [sorted (doto (js/Array.from times) (.sort))
          sum (reduce + 0 (array-seq sorted))
          mean-ms (/ sum iters)
          median-ms (aget sorted (js/Math.floor (/ iters 2)))
          min-ms (aget sorted 0)]
      {:mean-us (* mean-ms 1000)
       :median-us (* median-ms 1000)
       :min-us (* min-ms 1000)
       :ops-s (if (pos? mean-ms) (/ 1000 mean-ms) 0)
       :iters iters})))

(defn fresh-atom!
  "Create a fresh atom with plenty of room for benchmark allocations.
   Updates WASM memory views and resets global pools."
  []
  (set! atom/*global-atom-instance*
        (atom/private-atom {} :sab-size (* 32 1024 1024) :max-blocks 32768))
  (when-let [wm (:wasm-memory (atom/get-env atom/*global-atom-instance*))]
    (wasm/update-views! wm))
  (sm/reset-pools!))

(defn fmt-us [us]
  (cond
    (< us 1) (str (.toFixed (* us 1000) 0) "ns")
    (< us 1000) (str (.toFixed us 2) "us")
    :else (str (.toFixed (/ us 1000) 2) "ms")))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (str (.toFixed (/ ops 1e6) 2) "M")
    (>= ops 1e3) (str (.toFixed (/ ops 1e3) 1) "K")
    :else (str (.toFixed ops 1) "")))

(defn print-row [label result & [extra]]
  (println (str "    "
                (.padEnd label 35)
                (.padStart (fmt-us (:mean-us result)) 10) " mean, "
                (.padStart (str (fmt-ops (:ops-s result)) " ops/s") 14)
                (when extra (str "  " extra)))))

;;-----------------------------------------------------------------------------
;; SabMap benchmarks
;;-----------------------------------------------------------------------------

(defn bench-sab-map []
  (println "\n=== SabMap ===\n")

  ;; Build (allocates heavily — keep iterations low)
  (println "  Build:")
  (doseq [[n iters warmup] [[10 50 5] [100 10 2]]]
    (fresh-atom!)
    (let [kvs (mapv (fn [i] [(keyword (str "k" i)) i]) (range n))
          result (bench #(reduce (fn [m [k v]] (assoc m k v))
                                 (sm/empty-sab-map) kvs)
                        :iters iters :warmup warmup)]
      (print-row (str "build n=" n) result)))

  ;; Lookup (read-only — high iterations safe)
  (println "  Lookup:")
  (fresh-atom!)
  (let [m10 (reduce (fn [m i] (assoc m (keyword (str "k" i)) i)) (sm/empty-sab-map) (range 10))
        m100 (reduce (fn [m i] (assoc m (keyword (str "k" i)) i)) (sm/empty-sab-map) (range 100))]
    (doseq [[label m n iters] [["get n=10" m10 10 10000]
                                ["get n=100" m100 100 5000]]]
      (let [k (keyword (str "k" (quot n 2)))]
        (print-row label (bench #(get m k) :iters iters)))))

  ;; Assoc (allocates one node per iter — moderate iterations)
  (println "  Assoc:")
  (fresh-atom!)
  (let [m10 (reduce (fn [m i] (assoc m (keyword (str "k" i)) i)) (sm/empty-sab-map) (range 10))
        m100 (reduce (fn [m i] (assoc m (keyword (str "k" i)) i)) (sm/empty-sab-map) (range 100))]
    (doseq [[label m iters warmup] [["assoc n=10" m10 200 20]
                                     ["assoc n=100" m100 100 10]]]
      (print-row label (bench #(assoc m :new-key 999) :iters iters :warmup warmup))))

  ;; Reduce (read-only — high iterations safe)
  (println "  Reduce:")
  (fresh-atom!)
  (let [m10 (reduce (fn [m i] (assoc m (keyword (str "k" i)) i)) (sm/empty-sab-map) (range 10))
        m100 (reduce (fn [m i] (assoc m (keyword (str "k" i)) i)) (sm/empty-sab-map) (range 100))]
    (doseq [[label m iters] [["reduce-kv sum n=10" m10 5000]
                              ["reduce-kv sum n=100" m100 2000]]]
      (print-row label (bench #(reduce-kv (fn [acc _k v] (+ acc v)) 0 m) :iters iters)))))

;;-----------------------------------------------------------------------------
;; SabVec benchmarks
;;-----------------------------------------------------------------------------

(defn bench-sab-vec []
  (println "\n=== SabVec ===\n")

  ;; Build (allocates heavily)
  (println "  Build:")
  (doseq [[n iters warmup] [[10 50 5] [100 10 2]]]
    (fresh-atom!)
    (let [result (bench #(reduce conj (sv/empty-sab-vec) (range n))
                        :iters iters :warmup warmup)]
      (print-row (str "build n=" n) result)))

  ;; Lookup (read-only)
  (println "  Lookup:")
  (fresh-atom!)
  (let [v100 (reduce conj (sv/empty-sab-vec) (range 100))]
    (doseq [[label idx iters] [["nth n=100 mid" 50 10000]
                                ["nth n=100 tail" 99 10000]]]
      (print-row label (bench #(nth v100 idx) :iters iters))))

  ;; Conj (allocates)
  (println "  Conj:")
  (fresh-atom!)
  (let [v100 (reduce conj (sv/empty-sab-vec) (range 100))]
    (print-row "conj n=100" (bench #(conj v100 999) :iters 200 :warmup 20))))

;;-----------------------------------------------------------------------------
;; SabSet benchmarks
;;-----------------------------------------------------------------------------

(defn bench-sab-set []
  (println "\n=== SabSet ===\n")

  ;; Build (allocates heavily)
  (println "  Build:")
  (doseq [[n iters warmup] [[10 50 5] [100 10 2]]]
    (fresh-atom!)
    (let [result (bench #(reduce conj (ss/empty-sab-set) (range n))
                        :iters iters :warmup warmup)]
      (print-row (str "build n=" n) result)))

  ;; Contains (read-only)
  (println "  Contains:")
  (fresh-atom!)
  (let [s100 (reduce conj (ss/empty-sab-set) (range 100))]
    (print-row "contains? n=100" (bench #(contains? s100 50) :iters 5000))))

;;-----------------------------------------------------------------------------
;; SabList benchmarks
;;-----------------------------------------------------------------------------

(defn bench-sab-list []
  (println "\n=== SabList ===\n")

  ;; Build (allocates)
  (println "  Build:")
  (doseq [[n iters warmup] [[10 50 5] [100 10 2]]]
    (fresh-atom!)
    (let [result (bench #(reduce conj (sl/empty-sab-list) (range n))
                        :iters iters :warmup warmup)]
      (print-row (str "conj n=" n) result)))

  ;; First/Rest (read-only)
  (println "  Access:")
  (fresh-atom!)
  (let [l100 (sl/sab-list (range 100))]
    (print-row "first n=100" (bench #(first l100) :iters 10000))
    (print-row "rest n=100" (bench #(rest l100) :iters 10000))))

;;-----------------------------------------------------------------------------
;; Atom benchmarks
;;-----------------------------------------------------------------------------

(defn bench-atom-ops []
  (println "\n=== Atom Operations ===\n")
  (fresh-atom!)

  ;; Deref (read-only)
  (let [result (bench #(deref atom/*global-atom-instance*) :iters 10000)]
    (print-row "@atom (deref)" result))

  ;; Swap with simple update (allocates per swap)
  (let [_ (reset! atom/*global-atom-instance* {:counter 0})
        result (bench #(swap! atom/*global-atom-instance* update :counter inc)
                      :iters 200 :warmup 10)]
    (print-row "swap! (update :counter inc)" result))

  ;; Swap with assoc
  (let [_ (reset! atom/*global-atom-instance* {:x 0})
        result (bench #(swap! atom/*global-atom-instance* assoc :x (rand-int 1000))
                      :iters 200 :warmup 10)]
    (print-row "swap! (assoc :x random)" result))

  ;; Swap with same value (exercises identical? fast-path)
  (let [_ (reset! atom/*global-atom-instance* {:x 42 :y "hello" :z :foo})
        result (bench #(swap! atom/*global-atom-instance* assoc :x 42)
                      :iters 200 :warmup 10)]
    (print-row "swap! (assoc :x same-val)" result))

  ;; Deref + get-in (read-only)
  (let [_ (reset! atom/*global-atom-instance* {:a {:b {:c 42}}})
        result (bench #(get-in @atom/*global-atom-instance* [:a :b :c])
                      :iters 5000)]
    (print-row "@atom -> get-in [:a :b :c]" result))

  ;; Reset with medium map (allocates)
  (let [m (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i))
                  {} (range 20))
        result (bench #(reset! atom/*global-atom-instance* m)
                      :iters 50 :warmup 5)]
    (print-row "reset! (20-key map)" result)))

;;-----------------------------------------------------------------------------
;; Serialization benchmarks
;;-----------------------------------------------------------------------------

(defn bench-serialize []
  (println "\n=== Serialization (fast-path) ===\n")
  (fresh-atom!)

  (println "  Encode:")
  (doseq [[label value iters]
          [["nil" nil 10000]
           ["true" true 10000]
           ["int32 (42)" 42 10000]
           ["float64 (3.14)" 3.14 10000]
           ["keyword (:foo)" :foo 10000]
           ["ns-keyword (:a/b)" :a/b 10000]
           ["string (\"hello\")" "hello" 10000]
           ["symbol ('foo)" 'foo 10000]]]
    (print-row label (bench #(ser/serialize-element value) :iters iters)
               (str "[" (.-length (ser/serialize-element value)) "B]")))

  (println "  Decode:")
  (let [s-env {:sab (.-buffer (atom/get-env atom/*global-atom-instance*))}]
    (doseq [[label value iters]
            [["nil" nil 10000]
             ["true" true 10000]
             ["int32 (42)" 42 10000]
             ["float64 (3.14)" 3.14 10000]
             ["keyword (:foo)" :foo 10000]
             ["string (\"hello\")" "hello" 10000]]]
      (let [bytes (ser/serialize-element value)]
        (print-row label (bench #(ser/deserialize-element s-env bytes) :iters iters))))))

;;-----------------------------------------------------------------------------
;; Allocation benchmarks
;;-----------------------------------------------------------------------------

(defn bench-alloc []
  (println "\n=== Allocation ===\n")

  ;; Batch alloc — measures raw descriptor scan + claim speed
  (fresh-atom!)
  (let [env (atom/get-env atom/*global-atom-instance*)]
    (print-row "batch-alloc 8×64B"
               (bench #(atom/batch-alloc env 64 8) :iters 50 :warmup 5)))

  ;; Build map from scratch — exercises pool-miss → batch-alloc → pool-hit cycle
  (fresh-atom!)
  (let [kvs (mapv (fn [i] [(keyword (str "k" i)) i]) (range 50))]
    (print-row "alloc-heavy build n=50"
               (bench #(reduce (fn [m [k v]] (assoc m k v))
                               (sm/empty-sab-map) kvs)
                      :iters 20 :warmup 3))))

;;-----------------------------------------------------------------------------
;; GC Sweep benchmarks
;;-----------------------------------------------------------------------------

(defn bench-sweep []
  (println "\n=== GC Sweep ===\n")

  ;; Create retired blocks via repeated swaps, then measure sweep
  (fresh-atom!)
  (reset! atom/*global-atom-instance* {:x 0})
  (dotimes [_ 50]
    (swap! atom/*global-atom-instance* assoc :x (rand-int 1000)))
  (let [env (atom/get-env atom/*global-atom-instance*)]
    (print-row "sweep (after 50 swaps)"
               (bench #(atom/sweep-retired-blocks! env) :iters 50 :warmup 5))))

;;-----------------------------------------------------------------------------
;; Runner
;;-----------------------------------------------------------------------------

(defn run-all-benchmarks []
  (fresh-atom!)

  (println "")
  (println "╔══════════════════════════════════════════════════════════════╗")
  (println "║  EVE SAB Performance Benchmark                             ║")
  (println "║  Post-Fressian: fast-path serialization only               ║")
  (println "╚══════════════════════════════════════════════════════════════╝")

  (bench-sab-map)
  (bench-sab-vec)
  (bench-sab-set)
  (bench-sab-list)
  (bench-atom-ops)
  (bench-alloc)
  (bench-sweep)
  (bench-serialize)

  (println "\n--- Done ---\n"))

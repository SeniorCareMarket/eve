(ns com.seniorcaremarket.eve-sab-deftype.alloc-diag
  "Diagnostic: measure where time goes during SAB map building."
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]))

(set! d/*worker-id* 1)

(defn now [] (js/performance.now))

(defn fresh-env! []
  (sab-map/reset-pools!)
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 512 1024 1024) :max-blocks 524288))
  (sab-map/reset-pools!))

(defn ^:export run-alloc-diag []
  (println "=== Allocation Diagnostics ===\n")

  ;; Check 1: Is WASM ready after fresh-env?
  (println (str "WASM ready before fresh-env!: " @wasm/wasm-ready))
  (fresh-env!)
  (println (str "WASM ready after fresh-env!:  " @wasm/wasm-ready))
  (println)

  ;; Check 2: Build flat map at n=500 intervals, measure per-interval time
  (println "--- Flat map incremental build (keyword->int) ---")
  (println "  Each row = 500 assocs into the growing map")
  (println (str "  " (.padEnd "range" 14) (.padEnd "time(ms)" 12) (.padEnd "ms/item" 10) "total-count"))
  (let [start-total (now)]
    (loop [m (sab-map/empty-sab-map)
           i 0
           interval-start (now)]
      (if (>= i 5000)
        (println (str "\n  Total: " (.toFixed (- (now) start-total) 0) "ms for 5000 entries"))
        (let [m' (assoc m (keyword (str "k" i)) i)]
          (if (and (pos? i) (zero? (mod i 500)))
            (let [elapsed (- (now) interval-start)
                  per-item (/ elapsed 500)]
              (println (str "  " (.padEnd (str (- i 500) "-" i) 14)
                            (.padEnd (.toFixed elapsed 1) 12)
                            (.padEnd (.toFixed per-item 4) 10)
                            (count m')))
              (recur m' (inc i) (now)))
            (recur m' (inc i) interval-start))))))

  (println)

  ;; Check 3: Build nested map (product records) at n=100 intervals
  (println "--- Nested map incremental build (product records) ---")
  (println "  Each row = 100 assocs of nested records into growing map")
  (println (str "  " (.padEnd "range" 14) (.padEnd "time(ms)" 12) (.padEnd "ms/item" 10) "total-count"))
  (fresh-env!)
  (let [gen-product (fn [i]
                      {:id i :name (str "Product-" i)
                       :price (* i 1.5) :stock (mod (* i 17) 2000)
                       :active (zero? (mod i 5))
                       :tags [(keyword (str "tag-" (mod i 20)))
                              (keyword (str "season-" (mod i 4)))]
                       :specs {:width (mod (* i 3) 100)
                               :height (mod (* i 5) 80)
                               :material (nth [:plastic :metal :wood :glass] (mod i 4))}})
        start-total (now)]
    (loop [m (sab-map/empty-sab-map)
           i 0
           interval-start (now)]
      (if (>= i 1000)
        (println (str "\n  Total: " (.toFixed (- (now) start-total) 0) "ms for 1000 entries"))
        (let [m' (assoc m (keyword (str "p" i)) (gen-product i))]
          (if (and (pos? i) (zero? (mod i 100)))
            (let [elapsed (- (now) interval-start)
                  per-item (/ elapsed 100)]
              (println (str "  " (.padEnd (str (- i 100) "-" i) 14)
                            (.padEnd (.toFixed elapsed 1) 12)
                            (.padEnd (.toFixed per-item 4) 10)
                            (count m')))
              (recur m' (inc i) (now)))
            (recur m' (inc i) interval-start))))))

  (println "\nDone."))

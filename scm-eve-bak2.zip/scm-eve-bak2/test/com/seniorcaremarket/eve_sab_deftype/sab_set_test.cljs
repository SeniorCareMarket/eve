(ns com.seniorcaremarket.eve-sab-deftype.sab-set-test
  (:require
   [cljs.test :refer-macros [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]))

;;-----------------------------------------------------------------------------
;; Setup
;;-----------------------------------------------------------------------------

(def _init-atom
  (let [large-atom (atom/private-atom {} :sab-size (* 4 1024 1024)
                                         :max-blocks 16384)]
    (set! atom/*global-atom-instance* large-atom)
    large-atom))

;;-----------------------------------------------------------------------------
;; Basic Operations
;;-----------------------------------------------------------------------------

(deftest empty-set-test
  (testing "Empty set"
    (let [s (ss/empty-sab-set)]
      (is (= 0 (count s)))
      (is (nil? (get s 1)))
      (is (nil? (seq s))))))

(deftest conj-test
  (testing "Conj single element"
    (let [s (conj (ss/empty-sab-set) 42)]
      (is (= 1 (count s)))
      (is (= 42 (get s 42)))
      (is (nil? (get s 99)))))

  (testing "Conj multiple elements"
    (let [s (-> (ss/empty-sab-set)
                (conj 1)
                (conj 2)
                (conj 3))]
      (is (= 3 (count s)))
      (is (= 1 (get s 1)))
      (is (= 2 (get s 2)))
      (is (= 3 (get s 3)))))

  (testing "Conj duplicate (no-op)"
    (let [s1 (conj (ss/empty-sab-set) 42)
          s2 (conj s1 42)]
      (is (= 1 (count s2)))
      (is (identical? s1 s2)))))

(deftest sab-set-constructor-test
  (testing "sab-set from values"
    (let [s (ss/sab-set 1 2 3 4 5)]
      (is (= 5 (count s)))
      (is (= 1 (get s 1)))
      (is (= 3 (get s 3)))
      (is (= 5 (get s 5)))))

  (testing "into-sab-set from collection"
    (let [s (ss/into-sab-set [1 2 3 4 5])]
      (is (= 5 (count s)))
      (is (= 1 (get s 1)))
      (is (= 5 (get s 5))))))

;;-----------------------------------------------------------------------------
;; Lookup
;;-----------------------------------------------------------------------------

(deftest lookup-test
  (testing "Get with not-found"
    (let [s (ss/sab-set 1 2 3)]
      (is (= 1 (get s 1 :nf)))
      (is (= :nf (get s 99 :nf)))))

  (testing "IFn invoke"
    (let [s (ss/sab-set 1 2 3)]
      (is (= 1 (s 1)))
      (is (= 2 (s 2)))
      (is (nil? (s 99)))
      (is (= :nf (s 99 :nf)))))

  (testing "Contains"
    (let [s (ss/sab-set 1 2 3)]
      (is (contains? s 1))
      (is (contains? s 2))
      (is (not (contains? s 99))))))

;;-----------------------------------------------------------------------------
;; Disj
;;-----------------------------------------------------------------------------

(deftest disj-test
  (testing "Disj existing element"
    (let [s (ss/sab-set 1 2 3)
          s' (disj s 2)]
      (is (= 2 (count s')))
      (is (= 1 (get s' 1)))
      (is (nil? (get s' 2)))
      (is (= 3 (get s' 3)))))

  (testing "Disj non-existing element"
    (let [s (ss/sab-set 1 2 3)
          s' (disj s 99)]
      (is (= 3 (count s')))
      (is (identical? s s'))))

  (testing "Disj to empty"
    (let [s (ss/sab-set 42)
          s' (disj s 42)]
      (is (= 0 (count s')))))

  (testing "Disj all elements"
    (let [s (ss/sab-set 1 2 3)
          s' (-> s (disj 1) (disj 2) (disj 3))]
      (is (= 0 (count s'))))))

;;-----------------------------------------------------------------------------
;; Seq Operations
;;-----------------------------------------------------------------------------

(deftest seq-test
  (testing "Seq on non-empty set"
    (let [s (ss/sab-set 1 2 3)
          values (seq s)]
      (is (= 3 (count values)))
      ;; Order may not be preserved
      (is (= #{1 2 3} (set values)))))

  (testing "Seq on empty set"
    (let [s (ss/empty-sab-set)]
      (is (nil? (seq s))))))

;;-----------------------------------------------------------------------------
;; Reduce
;;-----------------------------------------------------------------------------

(deftest reduce-test
  (testing "Reduce with initial value"
    (let [s (ss/sab-set 1 2 3 4 5)]
      (is (= 15 (reduce + 0 s)))))

  (testing "Reduce on empty"
    (let [s (ss/empty-sab-set)]
      (is (= 0 (reduce + 0 s))))))

;;-----------------------------------------------------------------------------
;; Equality
;;-----------------------------------------------------------------------------

(deftest equality-test
  (testing "Equal sets"
    (let [s1 (ss/sab-set 1 2 3)
          s2 (ss/sab-set 1 2 3)]
      (is (= s1 s2))))

  (testing "Equal sets (different order)"
    (let [s1 (ss/sab-set 1 2 3)
          s2 (ss/sab-set 3 2 1)]
      (is (= s1 s2))))

  (testing "Unequal sets - different values"
    (let [s1 (ss/sab-set 1 2 3)
          s2 (ss/sab-set 1 2 4)]
      (is (not= s1 s2))))

  (testing "Unequal sets - different count"
    (let [s1 (ss/sab-set 1 2 3)
          s2 (ss/sab-set 1 2)]
      (is (not= s1 s2))))

  (testing "Equal to regular set"
    (let [s1 (ss/sab-set 1 2 3)
          s2 #{1 2 3}]
      (is (= s1 s2))
      (is (= s2 s1)))))

;;-----------------------------------------------------------------------------
;; Large Set
;;-----------------------------------------------------------------------------

(deftest large-set-test
  (testing "Build and query large set"
    (let [n 100
          s (ss/into-sab-set (range n))]
      (is (= n (count s)))
      (is (= 0 (get s 0)))
      (is (= 50 (get s 50)))
      (is (= 99 (get s 99)))
      (is (nil? (get s n))))))

;;-----------------------------------------------------------------------------
;; Persistence
;;-----------------------------------------------------------------------------

(deftest persistence-test
  (testing "Conj preserves original"
    (let [s1 (ss/sab-set 1 2)
          s2 (conj s1 3)]
      (is (= 2 (count s1)))
      (is (= 3 (count s2)))
      (is (nil? (get s1 3)))
      (is (= 3 (get s2 3)))))

  (testing "Disj preserves original"
    (let [s1 (ss/sab-set 1 2 3)
          s2 (disj s1 2)]
      (is (= 3 (count s1)))
      (is (= 2 (count s2)))
      (is (= 2 (get s1 2)))
      (is (nil? (get s2 2))))))

;;-----------------------------------------------------------------------------
;; Hash Collision
;;-----------------------------------------------------------------------------

(deftest collision-test
  (testing "Values with potential hash collisions"
    (let [values (range 20)
          s (ss/into-sab-set values)]
      (is (= 20 (count s)))
      (doseq [v values]
        (is (= v (get s v)))))))

(deftest no-op-transient-roundtrip-test
  (testing "persistent! on unmodified transient returns original set"
    (let [s (ss/into-sab-set [1 2 3])]
      (is (identical? s (persistent! (transient s)))
          "No-op transient round-trip returns identical set")))

  (testing "persistent! on modified transient returns new set"
    (let [s (ss/into-sab-set [1 2])]
      (is (not (identical? s (persistent! (conj! (transient s) 3))))
          "Modified transient returns different set"))))

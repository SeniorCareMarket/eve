(ns com.seniorcaremarket.eve-sab-deftype.large-scale-stress-test
  "Large-scale stress tests for SAB data structures.
   Tests sizes > 1024, heterogeneous data, and many operations."
  (:require
   [cljs.test :refer-macros [deftest testing is async use-fixtures]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]))

;;-----------------------------------------------------------------------------
;; Setup - Fresh SAB for each test (32MB with 32K blocks)
;;
;; Now that constructors use per-operation arenas, we need fewer block
;; descriptors. The arena approach allocates one large block per batch
;; operation instead of one block per node.
;;-----------------------------------------------------------------------------

(defn fresh-atom-fixture
  "Create a fresh large atom before each test to avoid memory exhaustion."
  [f]
  (let [fresh-atom (atom/private-atom {} :sab-size (* 32 1024 1024)
                                          :max-blocks 32768)]
    (set! atom/*global-atom-instance* fresh-atom)
    (f)))

(use-fixtures :each fresh-atom-fixture)

;;-----------------------------------------------------------------------------
;; Test Data Generators
;;-----------------------------------------------------------------------------

(defn generate-heterogeneous-data
  "Generate a vector of heterogeneous data of size n."
  [n]
  (vec
   (for [i (range n)]
     (case (mod i 7)
       0 i                                      ; integers
       1 (/ i 3.14159)                         ; floats
       2 (str "string-" i)                     ; strings
       3 (keyword (str "key-" i))              ; keywords
       4 nil                                    ; nil
       5 (= (mod i 2) 0)                       ; booleans
       6 {:nested i :data (str "value-" i)}))))  ; maps

(defn generate-mixed-keys
  "Generate mixed-type keys for maps/sets.
   Note: Uses only integer, string, and keyword keys for reliable hashing."
  [n]
  (vec
   (for [i (range n)]
     (case (mod i 3)
       0 i                          ; integers
       1 (str "str-key-" i)         ; strings
       2 (keyword (str "kw-" i))))) ; keywords
  )

;;-----------------------------------------------------------------------------
;; SAB-VEC Large Scale Tests
;;-----------------------------------------------------------------------------

(deftest sab-vec-2000-elements-test
  (testing "sab-vec with 2000 elements"
    (let [n 2000
          v (sv/sab-vec (range n))]
      (is (= n (count v)) "Count should be 2000")
      ;; Spot check values
      (is (= 0 (nth v 0)))
      (is (= 1024 (nth v 1024)))
      (is (= 1500 (nth v 1500)))
      (is (= 1999 (nth v 1999)))
      ;; Reduce should work
      (is (= (reduce + (range n)) (reduce + 0 v))))))

(deftest sab-vec-5000-elements-test
  (testing "sab-vec with 5000 elements"
    (let [n 5000
          v (sv/sab-vec (range n))]
      (is (= n (count v)))
      ;; Random access at various depths
      (is (= 0 (nth v 0)))
      (is (= 31 (nth v 31)))
      (is (= 32 (nth v 32)))
      (is (= 1000 (nth v 1000)))
      (is (= 2500 (nth v 2500)))
      (is (= 4000 (nth v 4000)))
      (is (= 4999 (nth v 4999))))))

(deftest sab-vec-10000-elements-test
  (testing "sab-vec with 10000 elements"
    (let [n 10000
          v (sv/sab-vec (range n))]
      (is (= n (count v)))
      ;; Test boundaries
      (is (= 0 (nth v 0)))
      (is (= 9999 (nth v 9999)))
      ;; Test middle
      (is (= 5000 (nth v 5000)))
      ;; Assoc deep in trie
      (let [v2 (assoc v 7500 :replaced)]
        (is (= :replaced (nth v2 7500)))
        (is (= 7500 (nth v 7500)))))))

(deftest sab-vec-heterogeneous-data-test
  (testing "sab-vec with heterogeneous data (2000 elements)"
    (let [n 2000
          data (generate-heterogeneous-data n)
          v (sv/sab-vec data)]
      (is (= n (count v)))
      ;; Verify each element type is stored and retrieved correctly
      (doseq [i (range n)]
        (let [expected (nth data i)
              actual (nth v i)]
          (is (= expected actual)
              (str "Mismatch at index " i ": expected " expected ", got " actual)))))))

(deftest sab-vec-many-updates-test
  (testing "sab-vec with many assoc operations"
    (let [n 2000
          v (sv/sab-vec (range n))]
      ;; Perform many updates
      (let [v2 (reduce (fn [acc i]
                         (assoc acc i (* i 100)))
                       v
                       (range 0 n 10))]  ; Update every 10th element
        (is (= n (count v2)))
        ;; Check updated elements
        (doseq [i (range 0 n 10)]
          (is (= (* i 100) (nth v2 i))))
        ;; Check non-updated elements
        (is (= 5 (nth v2 5)))
        (is (= 15 (nth v2 15)))))))

(deftest sab-vec-sequential-pop-test
  (testing "sab-vec popping from 2000 down to 0"
    (let [n 2000
          v (sv/sab-vec (range n))]
      (loop [current v
             expected-count n]
        (when (> expected-count 0)
          (is (= expected-count (count current)))
          (is (= (dec expected-count) (peek current)))
          (recur (pop current) (dec expected-count)))))))

;;-----------------------------------------------------------------------------
;; SAB-LIST Large Scale Tests
;;-----------------------------------------------------------------------------

(deftest sab-list-2000-elements-test
  (testing "sab-list with 2000 elements"
    (let [n 2000
          l (sl/sab-list (range n))]
      (is (= n (count l)))
      (is (= 0 (first l)))
      (is (= (dec n) (nth l (dec n))))
      ;; Traverse
      (is (= (vec (range n)) (vec l))))))

(deftest sab-list-5000-elements-test
  (testing "sab-list with 5000 elements"
    (let [n 5000
          l (sl/sab-list (range n))]
      (is (= n (count l)))
      (is (= 0 (first l)))
      (is (= 2500 (nth l 2500)))
      (is (= 4999 (nth l 4999))))))

(deftest sab-list-heterogeneous-data-test
  (testing "sab-list with heterogeneous data (2000 elements)"
    (let [n 2000
          data (generate-heterogeneous-data n)
          l (sl/sab-list data)]
      (is (= n (count l)))
      ;; Verify elements match
      (doseq [i (range n)]
        (is (= (nth data i) (nth l i))
            (str "Mismatch at index " i))))))

(deftest sab-list-many-conj-test
  (testing "sab-list with many conj operations (building 3000 elements)"
    (let [n 3000
          l (reduce conj (sl/empty-sab-list) (range n))]
      ;; Lists conj at front, so order is reversed
      (is (= n (count l)))
      (is (= (dec n) (first l)))
      (is (= 0 (nth l (dec n)))))))

(deftest sab-list-sequential-pop-test
  (testing "sab-list popping from 2000 down to 0"
    (let [n 2000
          l (sl/sab-list (range n))]
      (loop [current l
             expected-count n
             expected-first 0]
        (when (> expected-count 0)
          (is (= expected-count (count current)))
          (is (= expected-first (first current)))
          (recur (pop current) (dec expected-count) (inc expected-first)))))))

;;-----------------------------------------------------------------------------
;; SAB-MAP Large Scale Tests
;;-----------------------------------------------------------------------------

(deftest sab-map-2000-entries-test
  (testing "sab-map with 2000 integer key entries"
    (let [n 2000
          m (reduce (fn [m i] (assoc m i (* i 10)))
                    (sm/empty-sab-map)
                    (range n))]
      (is (= n (count m)))
      ;; Spot check
      (is (= 0 (get m 0)))
      (is (= 10000 (get m 1000)))
      (is (= 15000 (get m 1500)))
      (is (= 19990 (get m 1999))))))

(deftest sab-map-5000-entries-test
  (testing "sab-map with 5000 entries"
    (let [n 5000
          m (reduce (fn [m i] (assoc m i (str "value-" i)))
                    (sm/empty-sab-map)
                    (range n))]
      (is (= n (count m)))
      (is (= "value-0" (get m 0)))
      (is (= "value-2500" (get m 2500)))
      (is (= "value-4999" (get m 4999))))))

(deftest sab-map-7500-entries-test
  (testing "sab-map with 7500 integer entries"
    ;; Reduced from 10000 to fit in memory
    (let [n 7500
          m (reduce (fn [m i] (assoc m i (* i 10)))
                    (sm/empty-sab-map)
                    (range n))]
      (is (= n (count m)))
      (is (= 0 (get m 0)))
      (is (= 37500 (get m 3750)))
      (is (= 74990 (get m 7499))))))

(deftest sab-map-string-keys-test
  (testing "sab-map with 2000 string keys"
    ;; Test with string keys to verify serialization at scale
    (let [n 2000
          m (reduce (fn [m i]
                      (assoc m (str "key-" i) (* i 10)))
                    (sm/empty-sab-map)
                    (range n))]
      (is (= n (count m)))
      ;; Spot check lookups
      (is (= 0 (get m "key-0")))
      (is (= 10000 (get m "key-1000")))
      (is (= 19990 (get m "key-1999"))))))

(deftest sab-map-heterogeneous-values-test
  (testing "sab-map with heterogeneous values (2000 entries)"
    (let [n 2000
          values (generate-heterogeneous-data n)
          m (reduce (fn [m i]
                      (assoc m i (nth values i)))
                    (sm/empty-sab-map)
                    (range n))]
      (is (= n (count m)))
      ;; Verify values
      (doseq [i (range n)]
        (is (= (nth values i) (get m i))
            (str "Mismatch at key " i))))))

(deftest sab-map-many-dissocs-test
  (testing "sab-map with many dissoc operations"
    (let [n 2000
          m (reduce (fn [m i] (assoc m i i))
                    (sm/empty-sab-map)
                    (range n))
          ;; Remove every 3rd entry
          m2 (reduce (fn [m i] (dissoc m i))
                     m
                     (filter #(= 0 (mod % 3)) (range n)))]
      ;; Count should be 2/3 of original (roughly)
      (is (< (count m2) n))
      (is (> (count m2) 0))
      ;; Verify removed keys are gone
      (doseq [i (filter #(= 0 (mod % 3)) (range n))]
        (is (nil? (get m2 i))))
      ;; Verify kept keys still present
      (doseq [i (filter #(not= 0 (mod % 3)) (range n))]
        (is (= i (get m2 i)))))))

(deftest sab-map-update-all-test
  (testing "sab-map updating all 2000 entries"
    (let [n 2000
          m1 (reduce (fn [m i] (assoc m i i))
                     (sm/empty-sab-map)
                     (range n))
          m2 (reduce (fn [m i] (assoc m i (* i 100)))
                     m1
                     (range n))]
      (is (= n (count m2)))
      ;; All values should be updated
      (doseq [i (range n)]
        (is (= (* i 100) (get m2 i)))))))

;;-----------------------------------------------------------------------------
;; SAB-SET Large Scale Tests
;;-----------------------------------------------------------------------------

(deftest sab-set-2000-elements-test
  (testing "sab-set with 2000 integer elements"
    (let [n 2000
          s (ss/into-sab-set (range n))]
      (is (= n (count s)))
      ;; Membership checks
      (doseq [i (range n)]
        (is (contains? s i)))
      (is (not (contains? s n)))
      (is (not (contains? s -1))))))

(deftest sab-set-5000-elements-test
  (testing "sab-set with 5000 elements"
    (let [n 5000
          s (ss/into-sab-set (range n))]
      (is (= n (count s)))
      (is (contains? s 0))
      (is (contains? s 2500))
      (is (contains? s 4999))
      (is (not (contains? s 5000))))))

(deftest sab-set-string-elements-test
  (testing "sab-set with 2000 string elements"
    ;; Test with string elements to verify serialization at scale
    (let [n 2000
          data (mapv #(str "elem-" %) (range n))
          s (ss/into-sab-set data)]
      (is (= n (count s)))
      ;; Spot check elements
      (is (contains? s "elem-0"))
      (is (contains? s "elem-1000"))
      (is (contains? s "elem-1999"))
      (is (not (contains? s "elem-2000"))))))

(deftest sab-set-many-disj-test
  (testing "sab-set with many disj operations"
    (let [n 2000
          s (ss/into-sab-set (range n))
          ;; Remove all even numbers
          s2 (reduce disj s (filter even? (range n)))]
      (is (= (/ n 2) (count s2)))
      ;; Verify evens are gone
      (doseq [i (filter even? (range n))]
        (is (not (contains? s2 i))))
      ;; Verify odds remain
      (doseq [i (filter odd? (range n))]
        (is (contains? s2 i))))))

(deftest sab-set-add-remove-cycles-test
  (testing "sab-set add/remove cycles (stress test)"
    (let [base-set (ss/into-sab-set (range 1000))]
      ;; Add 500 new elements, remove 500 existing
      (let [result (-> base-set
                       ;; Add 1000-1499
                       (as-> s (reduce conj s (range 1000 1500)))
                       ;; Remove 0-499
                       (as-> s (reduce disj s (range 0 500))))]
        (is (= 1000 (count result)))
        ;; 500-999 should still be there
        (doseq [i (range 500 1000)]
          (is (contains? result i)))
        ;; 1000-1499 should be there
        (doseq [i (range 1000 1500)]
          (is (contains? result i)))
        ;; 0-499 should be gone
        (doseq [i (range 0 500)]
          (is (not (contains? result i))))))))

;;-----------------------------------------------------------------------------
;; Mixed Operations Stress Tests
;;-----------------------------------------------------------------------------

(deftest mixed-operations-vec-stress-test
  (testing "sab-vec mixed operations stress test"
    ;; Build up, modify, pop down
    (let [v1 (sv/sab-vec (range 1500))
          ;; Update every 100th element
          v2 (reduce (fn [v i] (assoc v i :updated))
                     v1
                     (range 0 1500 100))
          ;; Pop 500 elements
          v3 (loop [v v2 n 500]
               (if (zero? n)
                 v
                 (recur (pop v) (dec n))))]
      (is (= 1000 (count v3)))
      ;; Check updated elements that weren't popped
      (doseq [i (range 0 1000 100)]
        (is (= :updated (nth v3 i)))))))

(deftest mixed-operations-map-stress-test
  (testing "sab-map mixed operations stress test"
    ;; Build, update, delete cycles
    (let [;; Initial build
          m1 (reduce (fn [m i] (assoc m i {:v i}))
                     (sm/empty-sab-map)
                     (range 2000))
          ;; Update all values
          m2 (reduce (fn [m i] (assoc m i {:v (* i 2)}))
                     m1
                     (range 2000))
          ;; Delete half
          m3 (reduce dissoc m2 (range 0 2000 2))]
      (is (= 1000 (count m3)))
      ;; Verify remaining entries
      (doseq [i (range 1 2000 2)]
        (is (= {:v (* i 2)} (get m3 i)))))))

;;-----------------------------------------------------------------------------
;; Persistence Under Load Tests
;;-----------------------------------------------------------------------------

(deftest persistence-many-versions-vec-test
  (testing "sab-vec persistence with many versions"
    (let [base (sv/sab-vec (range 1000))
          ;; Create 100 different versions by modifying different indices
          versions (for [i (range 100)]
                     (assoc base (* i 10) :modified))]
      ;; Original should be unchanged
      (doseq [i (range 1000)]
        (is (= i (nth base i))))
      ;; Each version should have exactly one modification
      (doseq [[i v] (map-indexed vector versions)]
        (is (= :modified (nth v (* i 10))))))))

(deftest persistence-many-versions-map-test
  (testing "sab-map persistence with many versions"
    (let [base (reduce (fn [m i] (assoc m i i))
                       (sm/empty-sab-map)
                       (range 1000))
          ;; Create branching versions
          v1 (assoc base 500 :v1)
          v2 (assoc base 500 :v2)
          v3 (dissoc base 500)]
      ;; All should have correct counts
      (is (= 1000 (count base)))
      (is (= 1000 (count v1)))
      (is (= 1000 (count v2)))
      (is (= 999 (count v3)))
      ;; Each version independent
      (is (= 500 (get base 500)))
      (is (= :v1 (get v1 500)))
      (is (= :v2 (get v2 500)))
      (is (nil? (get v3 500))))))

;;-----------------------------------------------------------------------------
;; Reduce Performance on Large Collections
;;-----------------------------------------------------------------------------

(deftest reduce-large-vec-test
  (testing "reduce on 5000 element sab-vec"
    (let [v (sv/sab-vec (range 5000))]
      (is (= (reduce + (range 5000)) (reduce + 0 v)))
      ;; With transformation
      (is (= (reduce + (map #(* % 2) (range 5000)))
             (reduce (fn [acc x] (+ acc (* x 2))) 0 v))))))

(deftest reduce-large-map-test
  (testing "reduce on 5000 entry sab-map"
    (let [m (reduce (fn [m i] (assoc m i (* i 2)))
                    (sm/empty-sab-map)
                    (range 5000))]
      ;; Sum all values
      (is (= (reduce + (map #(* % 2) (range 5000)))
             (reduce (fn [acc [k v]] (+ acc v)) 0 m)))
      ;; Sum all keys
      (is (= (reduce + (range 5000))
             (reduce (fn [acc [k v]] (+ acc k)) 0 m))))))

(deftest reduce-large-set-test
  (testing "reduce on 5000 element sab-set"
    (let [s (ss/into-sab-set (range 5000))]
      (is (= (reduce + (range 5000)) (reduce + 0 s))))))

;;-----------------------------------------------------------------------------
;; Edge Cases at Scale
;;-----------------------------------------------------------------------------

(deftest boundary-chunk-size-vec-test
  (testing "sab-vec at chunk boundaries (32, 64, 1024, 1025, 2048)"
    (doseq [n [32 64 1024 1025 2048]]
      (let [v (sv/sab-vec (range n))]
        (is (= n (count v)) (str "Count mismatch for n=" n))
        (is (= 0 (nth v 0)))
        (is (= (dec n) (nth v (dec n))))))))

(deftest boundary-operations-map-test
  (testing "sab-map operations at boundary sizes"
    (doseq [n [31 32 33 63 64 65 1023 1024 1025]]
      (let [m (reduce (fn [m i] (assoc m i i))
                      (sm/empty-sab-map)
                      (range n))]
        (is (= n (count m)) (str "Count mismatch for n=" n))
        ;; Add one more
        (let [m2 (assoc m n n)]
          (is (= (inc n) (count m2))))))))

(ns com.seniorcaremarket.eve-sab-deftype.zerocopy-benchmark
  "Phase 6 benchmark: measures deref and swap performance.
   Run before and after zero-copy changes to compare."
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]))

(set! d/*worker-id* 1)

(defn bench
  "Run f repeatedly and return {:mean-ns :ops-sec :total-ms}."
  [f & {:keys [iters warmup] :or {iters 10000 warmup 500}}]
  (dotimes [_ warmup] (f))
  (let [start (js/performance.now)]
    (dotimes [_ iters] (f))
    (let [elapsed-ms (- (js/performance.now) start)
          mean-ns (* (/ elapsed-ms iters) 1e6)
          ops-sec (if (pos? elapsed-ms) (/ (* iters 1000) elapsed-ms) 0)]
      {:mean-ns mean-ns :ops-sec ops-sec :total-ms elapsed-ms :iters iters})))

(defn fmt [n] (.toFixed n 0))
(defn fmt2 [n] (.toFixed n 2))

(defn run-benchmark []
  (println "\n================================================================================")
  (println "  PHASE 6 ZERO-COPY BENCHMARK")
  (println "  Measures: atom deref, swap!, nested structure access")
  (println "================================================================================\n")

  ;; Setup: create atom with a simple map
  (let [atom1 (a/private-atom {:a 1 :b 2 :c 3}
                               :sab-size (* 4 1024 1024)
                               :max-blocks 4096)]
    (set! a/*global-atom-instance* atom1)

    ;; Benchmark 1: Simple deref
    (println "--- Benchmark 1: SharedAtom deref (simple map {:a 1 :b 2 :c 3}) ---")
    (let [result (bench #(deref atom1) :iters 50000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op, "
                    (fmt2 (:total-ms result)) "ms total, "
                    (:iters result) " iters)\n")))

    ;; Benchmark 2: Deref + field access
    (println "--- Benchmark 2: Deref + get field (:a @atom) ---")
    (let [result (bench #(:a @atom1) :iters 50000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n")))

    ;; Benchmark 3: swap! with simple update
    (println "--- Benchmark 3: swap! (assoc :counter (inc n)) ---")
    (let [result (bench #(swap! atom1 assoc :counter (inc (or (:counter @atom1) 0))) :iters 5000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n"))))

  ;; Setup: atom with nested data
  (let [nested-data {:users [{:name "Alice" :age 30 :tags #{:admin :active}}
                              {:name "Bob" :age 25 :tags #{:user}}]
                     :config {:debug false :max-retries 3}
                     :counts [10 20 30 40 50]}
        atom2 (a/private-atom nested-data
                              :sab-size (* 4 1024 1024)
                              :max-blocks 4096)]
    (set! a/*global-atom-instance* atom2)

    ;; Benchmark 4: Deref nested structure
    (println "--- Benchmark 4: Deref (nested map with vecs, sets, sub-maps) ---")
    (let [result (bench #(deref atom2) :iters 20000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n")))

    ;; Benchmark 5: Deref + deep access
    (println "--- Benchmark 5: Deep access (get-in @atom [:config :max-retries]) ---")
    (let [result (bench #(get-in @atom2 [:config :max-retries]) :iters 20000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n")))

    ;; Benchmark 6: swap! on nested structure
    (println "--- Benchmark 6: swap! (update-in [:counts 0] inc) on nested ---")
    (let [result (bench #(swap! atom2 update-in [:counts 0] inc) :iters 3000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n"))))

  ;; Setup: atom with larger map
  (let [big-map (into {} (for [i (range 50)] [(keyword (str "key-" i)) i]))
        atom3 (a/private-atom big-map
                              :sab-size (* 4 1024 1024)
                              :max-blocks 4096)]
    (set! a/*global-atom-instance* atom3)

    ;; Benchmark 7: Deref large map
    (println "--- Benchmark 7: Deref (50-key map) ---")
    (let [result (bench #(deref atom3) :iters 20000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n")))

    ;; Benchmark 8: swap! on large map
    (println "--- Benchmark 8: swap! (assoc :key-0 (inc n)) on 50-key map ---")
    (let [result (bench #(swap! atom3 assoc :key-0 (inc (or (:key-0 @atom3) 0))) :iters 3000)]
      (println (str "  " (fmt (:ops-sec result)) " ops/sec  ("
                    (fmt2 (:mean-ns result)) " ns/op)\n"))))

  (println "================================================================================")
  (println "  BENCHMARK COMPLETE")
  (println "================================================================================"))

(run-benchmark)

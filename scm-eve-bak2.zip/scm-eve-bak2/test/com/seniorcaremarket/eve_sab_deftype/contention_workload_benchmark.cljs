(ns com.seniorcaremarket.eve-sab-deftype.contention-workload-benchmark
  "Multi-worker contention benchmarks: EVE SAB vs Stock CLJS.

   Tests various workload patterns under high contention across multiple workers.
   Stock CLJS runs single-threaded (baseline); EVE SAB runs with real worker_threads.

   Workloads:
   1. Write-only: N workers assoc into shared SAB map via CAS
   2. Read-only: N workers read from pre-populated shared SAB map
   3. Mixed 80/20 read/write: pre-populated map, mixed operations
   4. Atom swap! cycles: N workers do swap! on same SAB atom
   5. Scaling curve: 1-4 workers, same total work

   Run with: shadow-compile contention-workload-benchmark && node out/contention-workload-benchmark.js"
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sab-vec]))

(set! d/*worker-id* 1)

;;=============================================================================
;; Infrastructure
;;=============================================================================

(defn now [] (js/performance.now))

(defn fresh-env! [& {:keys [sab-size max-blocks]
                      :or {sab-size (* 256 1024 1024) max-blocks 524288}}]
  (sab-map/reset-pools!)
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size sab-size :max-blocks max-blocks))
  (sab-map/reset-pools!)
  (a/get-env a/*global-atom-instance*))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

(defn alloc-root-slot!
  "Allocate an atomic Int32 root pointer slot. Returns int32 index."
  [env]
  (let [alloc-result (a/alloc env 8)
        byte-offset (:offset alloc-result)
        aligned-offset (let [rem (mod byte-offset 4)]
                         (if (zero? rem) byte-offset (+ byte-offset (- 4 rem))))
        int32-idx (unsigned-bit-shift-right aligned-offset 2)
        int32-view (js/Int32Array. (:sab env))]
    (js/Atomics.store int32-view int32-idx -1)
    int32-idx))

(defn alloc-timing-slots!
  "Allocate N float64 slots for workers to write their elapsed time."
  [env n]
  (let [alloc-result (a/alloc env (* n 8))
        offset (:offset alloc-result)
        aligned (let [rem (mod offset 8)]
                  (if (zero? rem) offset (+ offset (- 8 rem))))]
    aligned))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (str (.toFixed (/ ops 1e6) 2) "M")
    (>= ops 1e3) (str (.toFixed (/ ops 1e3) 1) "K")
    :else (str (.toFixed ops 1) "")))

(defn pad [s n] (.padStart (str s) n))
(defn rpad [s n] (.padEnd (str s) n))

(def ^:private all-results (atom []))

(defn record-result! [workload config stock-result sab-result]
  (swap! all-results conj
         {:workload workload :config config
          :stock stock-result :sab sab-result}))

;;=============================================================================
;; Stock CLJS Baselines (single-threaded)
;;=============================================================================

(defn bench-stock-writes [map-size num-ops]
  "Single-thread baseline: assoc num-ops entries into a stock CLJS map."
  (let [m (atom (loop [m {} i 0]
                  (if (>= i map-size) m
                      (recur (assoc m (keyword (str "k" i)) i) (inc i)))))]
    (let [start (now)]
      (dotimes [i num-ops]
        (let [k (keyword (str "w" i))]
          (swap! m assoc k (* i i))))
      (let [elapsed (- (now) start)]
        {:elapsed-ms elapsed :ops num-ops
         :throughput (if (pos? elapsed) (/ (* num-ops 1000) elapsed) 0)}))))

(defn bench-stock-reads [map-size num-ops]
  "Single-thread baseline: read num-ops entries from a stock CLJS map."
  (let [m (loop [m {} i 0]
            (if (>= i map-size) m
                (recur (assoc m (keyword (str "k" i)) {:val i :count 0}) (inc i))))
        keys-arr (let [arr (make-array num-ops)]
                   (dotimes [i num-ops]
                     (aset arr i (keyword (str "k" (mod i map-size)))))
                   arr)]
    (let [start (now)]
      (dotimes [i num-ops]
        (get m (aget keys-arr i)))
      (let [elapsed (- (now) start)]
        {:elapsed-ms elapsed :ops num-ops
         :throughput (if (pos? elapsed) (/ (* num-ops 1000) elapsed) 0)}))))

(defn bench-stock-mixed [map-size num-ops]
  "Single-thread baseline: 80% reads, 20% writes."
  (let [m (atom (loop [m {} i 0]
                  (if (>= i map-size) m
                      (recur (assoc m (keyword (str "k" i)) (* i 10)) (inc i)))))]
    (let [start (now)]
      (dotimes [i num-ops]
        (if (zero? (mod i 5))
          ;; Write (20%)
          (let [k (keyword (str "k" (mod i map-size)))]
            (swap! m assoc k (* i i)))
          ;; Read (80%)
          (let [k (keyword (str "k" (mod i map-size)))]
            (get @m k))))
      (let [elapsed (- (now) start)]
        {:elapsed-ms elapsed :ops num-ops
         :throughput (if (pos? elapsed) (/ (* num-ops 1000) elapsed) 0)}))))

(defn bench-stock-rcw [map-size num-ops]
  "Single-thread baseline: read-compute-write cycles."
  (let [m (atom (loop [m {} i 0]
                  (if (>= i map-size) m
                      (recur (assoc m (keyword (str "k" i))
                                   {:count (mod (* i 7) 100) :total (* i 2.5)})
                             (inc i)))))]
    (let [start (now)]
      (dotimes [_ num-ops]
        (let [s @m
              max-entry (reduce-kv
                          (fn [best _k v]
                            (if (> (:count v) (:count best)) v best))
                          {:count -1} s)]
          (swap! m (fn [mm]
                     (reduce-kv
                      (fn [acc k v]
                        (if (= (:count v) (:count max-entry))
                          (assoc acc k (update v :count inc))
                          acc))
                      mm mm)))))
      (let [elapsed (- (now) start)]
        {:elapsed-ms elapsed :ops num-ops
         :throughput (if (pos? elapsed) (/ (* num-ops 1000) elapsed) 0)}))))

;;=============================================================================
;; SAB Multi-Worker Tests
;;=============================================================================

;; Workload 1: Write-only contention
(defn run-sab-write-contention [num-workers ops-per-worker map-size next-fn]
  (let [env (fresh-env!)
        slot-idx (alloc-root-slot! env)
        timing-off (alloc-timing-slots! env num-workers)
        ;; Pre-populate map
        _ (let [int32-view (js/Int32Array. (:sab env))
                m (loop [m (sab-map/empty-sab-map) i 0]
                    (if (>= i map-size) m
                        (recur (assoc m (keyword (str "k" i)) i) (inc i))))]
            (js/Atomics.store int32-view slot-idx (.-offset__ m)))
        workers (vec (repeatedly num-workers #(w/mk-worker)))
        start-time (now)]

    (doseq [i (range num-workers)]
      (let [wid (inc i)]
        (in (nth workers i) [slot-idx wid ops-per-worker timing-off]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                _ (com.seniorcaremarket.eve.wasm-mem/init-views-from-sab! sab)
                int32-view (js/Int32Array. sab)
                f64-view (js/Float64Array. sab)
                max-retries 5000
                start-time (js/performance.now)]
            (dotimes [j ops-per-worker]
              (let [k (keyword (str "t" wid "k" j))
                    v (* wid 1000 (inc j))]
                (loop [retries 0]
                  (when (< retries max-retries)
                    (let [old-off (js/Atomics.load int32-view slot-idx)
                          old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off)
                          new-map (assoc old-map k v)
                          new-off (.-offset__ new-map)]
                      (when-not (== old-off (js/Atomics.compareExchange int32-view slot-idx old-off new-off))
                        (recur (inc retries))))))))
            (let [elapsed (- (js/performance.now) start-time)]
              (aset f64-view (+ (/ timing-off 8) (dec wid)) elapsed)
              (println (str "  [W" wid "] Write done: " (.toFixed elapsed 0) "ms, " ops-per-worker " ops")))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (now) start-time)
             total-ops (* num-workers ops-per-worker)
             f64-view (js/Float64Array. (:sab env))
             worker-times (vec (for [i (range num-workers)]
                                 (aget f64-view (+ (/ timing-off 8) i))))
             max-worker-ms (apply max worker-times)]
         (cleanup-workers workers)
         (next-fn {:elapsed-ms elapsed :ops total-ops :workers num-workers
                   :throughput (if (pos? max-worker-ms) (/ (* total-ops 1000) max-worker-ms) 0)
                   :worker-times worker-times})))
     (+ 5000 (* num-workers ops-per-worker 5)))))  ;; adaptive timeout

;; Workload 2: Read-only parallel
(defn run-sab-read-parallel [num-workers reads-per-worker map-size next-fn]
  (let [env (fresh-env!)
        slot-idx (alloc-root-slot! env)
        timing-off (alloc-timing-slots! env num-workers)
        ;; Pre-populate map
        _ (let [int32-view (js/Int32Array. (:sab env))
                m (loop [m (sab-map/empty-sab-map) i 0]
                    (if (>= i map-size) m
                        (recur (assoc m (keyword (str "k" i)) {:val i :count 0}) (inc i))))]
            (js/Atomics.store int32-view slot-idx (.-offset__ m)))
        workers (vec (repeatedly num-workers #(w/mk-worker)))
        start-time (now)]

    (doseq [i (range num-workers)]
      (let [wid (inc i)]
        (in (nth workers i) [slot-idx wid reads-per-worker map-size timing-off]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                _ (com.seniorcaremarket.eve.wasm-mem/init-views-from-sab! sab)
                int32-view (js/Int32Array. sab)
                f64-view (js/Float64Array. sab)
                root-off (js/Atomics.load int32-view slot-idx)
                m (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab root-off)
                start-time (js/performance.now)]
            (dotimes [j reads-per-worker]
              (let [k (keyword (str "k" (mod (+ (* wid 31) j) map-size)))]
                (get m k)))
            (let [elapsed (- (js/performance.now) start-time)]
              (aset f64-view (+ (/ timing-off 8) (dec wid)) elapsed)
              (println (str "  [W" wid "] Read done: " (.toFixed elapsed 0) "ms, " reads-per-worker " reads")))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (now) start-time)
             total-ops (* num-workers reads-per-worker)
             f64-view (js/Float64Array. (:sab env))
             worker-times (vec (for [i (range num-workers)]
                                 (aget f64-view (+ (/ timing-off 8) i))))
             max-worker-ms (apply max worker-times)]
         (cleanup-workers workers)
         (next-fn {:elapsed-ms elapsed :ops total-ops :workers num-workers
                   :throughput (if (pos? max-worker-ms) (/ (* total-ops 1000) max-worker-ms) 0)
                   :worker-times worker-times})))
     8000)))

;; Workload 3: Mixed 80/20 read-write
(defn run-sab-mixed-contention [num-workers ops-per-worker map-size next-fn]
  (let [env (fresh-env!)
        slot-idx (alloc-root-slot! env)
        timing-off (alloc-timing-slots! env num-workers)
        _ (let [int32-view (js/Int32Array. (:sab env))
                m (loop [m (sab-map/empty-sab-map) i 0]
                    (if (>= i map-size) m
                        (recur (assoc m (keyword (str "k" i)) (* i 10)) (inc i))))]
            (js/Atomics.store int32-view slot-idx (.-offset__ m)))
        workers (vec (repeatedly num-workers #(w/mk-worker)))
        start-time (now)]

    (doseq [i (range num-workers)]
      (let [wid (inc i)]
        (in (nth workers i) [slot-idx wid ops-per-worker map-size timing-off]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                _ (com.seniorcaremarket.eve.wasm-mem/init-views-from-sab! sab)
                int32-view (js/Int32Array. sab)
                f64-view (js/Float64Array. sab)
                max-retries 5000
                start-time (js/performance.now)]
            (dotimes [j ops-per-worker]
              (if (zero? (mod j 5))
                ;; Write (20%) — CAS loop
                (let [k (keyword (str "k" (mod (+ (* wid 97) j) map-size)))]
                  (loop [retries 0]
                    (when (< retries max-retries)
                      (let [old-off (js/Atomics.load int32-view slot-idx)
                            old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off)
                            new-map (assoc old-map k (+ (* wid 1000) j))
                            new-off (.-offset__ new-map)]
                        (when-not (== old-off (js/Atomics.compareExchange int32-view slot-idx old-off new-off))
                          (recur (inc retries)))))))
                ;; Read (80%) — lock-free snapshot
                (let [root-off (js/Atomics.load int32-view slot-idx)
                      m (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab root-off)
                      k (keyword (str "k" (mod (+ (* wid 31) j) map-size)))]
                  (get m k))))
            (let [elapsed (- (js/performance.now) start-time)]
              (aset f64-view (+ (/ timing-off 8) (dec wid)) elapsed)
              (println (str "  [W" wid "] Mixed done: " (.toFixed elapsed 0) "ms, " ops-per-worker " ops")))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (now) start-time)
             total-ops (* num-workers ops-per-worker)
             f64-view (js/Float64Array. (:sab env))
             worker-times (vec (for [i (range num-workers)]
                                 (aget f64-view (+ (/ timing-off 8) i))))
             max-worker-ms (apply max worker-times)]
         (cleanup-workers workers)
         (next-fn {:elapsed-ms elapsed :ops total-ops :workers num-workers
                   :throughput (if (pos? max-worker-ms) (/ (* total-ops 1000) max-worker-ms) 0)
                   :worker-times worker-times})))
     10000)))

;; Workload 4: Read-compute-write contention (simulates swap! semantics via CAS)
(defn run-sab-atom-swap-contention [num-workers swaps-per-worker map-size next-fn]
  (let [env (fresh-env!)
        slot-idx (alloc-root-slot! env)
        timing-off (alloc-timing-slots! env num-workers)
        ;; Pre-populate map with numeric values
        _ (let [int32-view (js/Int32Array. (:sab env))
                m (loop [m (sab-map/empty-sab-map) i 0]
                    (if (>= i map-size) m
                        (recur (assoc m (keyword (str "k" i)) (* i 7)) (inc i))))]
            (js/Atomics.store int32-view slot-idx (.-offset__ m)))
        workers (vec (repeatedly num-workers #(w/mk-worker)))
        start-time (now)]

    (doseq [i (range num-workers)]
      (let [wid (inc i)]
        (in (nth workers i) [slot-idx wid swaps-per-worker map-size timing-off]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                _ (com.seniorcaremarket.eve.wasm-mem/init-views-from-sab! sab)
                int32-view (js/Int32Array. sab)
                f64-view (js/Float64Array. sab)
                max-retries 5000
                start-time (js/performance.now)]
            ;; Each swap: read current map, compute new value, CAS-write
            (dotimes [j swaps-per-worker]
              (let [k (keyword (str "k" (mod (+ (* wid 13) j) map-size)))]
                (loop [retries 0]
                  (when (< retries max-retries)
                    (let [old-off (js/Atomics.load int32-view slot-idx)
                          old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off)
                          old-val (get old-map k)
                          new-val (+ (if (number? old-val) old-val 0) wid)
                          new-map (assoc old-map k new-val)
                          new-off (.-offset__ new-map)]
                      (when-not (== old-off (js/Atomics.compareExchange int32-view slot-idx old-off new-off))
                        (recur (inc retries))))))))
            (let [elapsed (- (js/performance.now) start-time)]
              (aset f64-view (+ (/ timing-off 8) (dec wid)) elapsed)
              (println (str "  [W" wid "] RCW done: " (.toFixed elapsed 0) "ms, "
                            swaps-per-worker " cycles")))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (now) start-time)
             total-ops (* num-workers swaps-per-worker)
             f64-view (js/Float64Array. (:sab env))
             worker-times (vec (for [i (range num-workers)]
                                 (aget f64-view (+ (/ timing-off 8) i))))
             max-worker-ms (apply max worker-times)]
         (cleanup-workers workers)
         (next-fn {:elapsed-ms elapsed :ops total-ops :workers num-workers
                   :throughput (if (pos? max-worker-ms) (/ (* total-ops 1000) max-worker-ms) 0)
                   :worker-times worker-times})))
     15000)))

;;=============================================================================
;; Test Orchestration
;;=============================================================================

(defn run-workload-1 [next-fn]
  (println "\n  ================================================================")
  (println "  [Workload 1] Write-Only Contention (assoc into shared SAB map)")
  (println "  ================================================================\n")

  (let [map-size 200
        ops-per-worker 50
        stock-result (bench-stock-writes map-size (* 4 ops-per-worker))]
    (println (str "  Stock CLJS baseline: " (.toFixed (:elapsed-ms stock-result) 1) "ms, "
                  (fmt-ops (:throughput stock-result)) " ops/s (single-thread, " (* 4 ops-per-worker) " ops)\n"))

    ;; 1 worker
    (run-sab-write-contention 1 (* 4 ops-per-worker) map-size
      (fn [r1]
        (println (str "\n  SAB 1 worker: " (.toFixed (:elapsed-ms r1) 1) "ms, "
                      (fmt-ops (:throughput r1)) " ops/s"))
        ;; 2 workers
        (run-sab-write-contention 2 (* 2 ops-per-worker) map-size
          (fn [r2]
            (println (str "  SAB 2 workers: " (.toFixed (:elapsed-ms r2) 1) "ms, "
                          (fmt-ops (:throughput r2)) " ops/s"))
            ;; 4 workers
            (run-sab-write-contention 4 ops-per-worker map-size
              (fn [r4]
                (println (str "  SAB 4 workers: " (.toFixed (:elapsed-ms r4) 1) "ms, "
                              (fmt-ops (:throughput r4)) " ops/s"))
                (record-result! "write-only" {:map-size map-size} stock-result
                                {:w1 r1 :w2 r2 :w4 r4})
                (next-fn)))))))))

(defn run-workload-2 [next-fn]
  (println "\n  ================================================================")
  (println "  [Workload 2] Read-Only Parallel (reads from shared SAB map)")
  (println "  ================================================================\n")

  (let [map-size 500
        reads-per-worker 2000
        stock-result (bench-stock-reads map-size (* 4 reads-per-worker))]
    (println (str "  Stock CLJS baseline: " (.toFixed (:elapsed-ms stock-result) 1) "ms, "
                  (fmt-ops (:throughput stock-result)) " ops/s (single-thread, " (* 4 reads-per-worker) " reads)\n"))

    (run-sab-read-parallel 1 (* 4 reads-per-worker) map-size
      (fn [r1]
        (println (str "\n  SAB 1 worker: " (.toFixed (:elapsed-ms r1) 1) "ms, "
                      (fmt-ops (:throughput r1)) " ops/s"))
        (run-sab-read-parallel 2 (* 2 reads-per-worker) map-size
          (fn [r2]
            (println (str "  SAB 2 workers: " (.toFixed (:elapsed-ms r2) 1) "ms, "
                          (fmt-ops (:throughput r2)) " ops/s"))
            (run-sab-read-parallel 4 reads-per-worker map-size
              (fn [r4]
                (println (str "  SAB 4 workers: " (.toFixed (:elapsed-ms r4) 1) "ms, "
                              (fmt-ops (:throughput r4)) " ops/s"))
                (record-result! "read-only" {:map-size map-size} stock-result
                                {:w1 r1 :w2 r2 :w4 r4})
                (next-fn)))))))))

(defn run-workload-3 [next-fn]
  (println "\n  ================================================================")
  (println "  [Workload 3] Mixed 80/20 Read/Write Contention")
  (println "  ================================================================\n")

  (let [map-size 200
        ops-per-worker 200
        stock-result (bench-stock-mixed map-size (* 4 ops-per-worker))]
    (println (str "  Stock CLJS baseline: " (.toFixed (:elapsed-ms stock-result) 1) "ms, "
                  (fmt-ops (:throughput stock-result)) " ops/s (single-thread, " (* 4 ops-per-worker) " ops)\n"))

    (run-sab-mixed-contention 1 (* 4 ops-per-worker) map-size
      (fn [r1]
        (println (str "\n  SAB 1 worker: " (.toFixed (:elapsed-ms r1) 1) "ms, "
                      (fmt-ops (:throughput r1)) " ops/s"))
        (run-sab-mixed-contention 2 (* 2 ops-per-worker) map-size
          (fn [r2]
            (println (str "  SAB 2 workers: " (.toFixed (:elapsed-ms r2) 1) "ms, "
                          (fmt-ops (:throughput r2)) " ops/s"))
            (run-sab-mixed-contention 4 ops-per-worker map-size
              (fn [r4]
                (println (str "  SAB 4 workers: " (.toFixed (:elapsed-ms r4) 1) "ms, "
                              (fmt-ops (:throughput r4)) " ops/s"))
                (record-result! "mixed-80/20" {:map-size map-size} stock-result
                                {:w1 r1 :w2 r2 :w4 r4})
                (next-fn)))))))))

(defn run-workload-4 [next-fn]
  (println "\n  ================================================================")
  (println "  [Workload 4] Read-Compute-Write Contention (swap! semantics via CAS)")
  (println "  ================================================================\n")

  (let [map-size 100
        swaps-per-worker 20
        stock-result (bench-stock-rcw map-size (* 4 swaps-per-worker))]
    (println (str "  Stock CLJS baseline: " (.toFixed (:elapsed-ms stock-result) 1) "ms, "
                  (fmt-ops (:throughput stock-result)) " ops/s (single-thread, " (* 4 swaps-per-worker) " rcw cycles)\n"))

    (run-sab-atom-swap-contention 1 (* 4 swaps-per-worker) map-size
      (fn [r1]
        (println (str "\n  SAB 1 worker: " (.toFixed (:elapsed-ms r1) 1) "ms, "
                      (fmt-ops (:throughput r1)) " ops/s"))
        (run-sab-atom-swap-contention 2 (* 2 swaps-per-worker) map-size
          (fn [r2]
            (println (str "  SAB 2 workers: " (.toFixed (:elapsed-ms r2) 1) "ms, "
                          (fmt-ops (:throughput r2)) " ops/s"))
            (run-sab-atom-swap-contention 4 swaps-per-worker map-size
              (fn [r4]
                (println (str "  SAB 4 workers: " (.toFixed (:elapsed-ms r4) 1) "ms, "
                              (fmt-ops (:throughput r4)) " ops/s"))
                (record-result! "rcw-swap" {:map-size map-size} stock-result
                                {:w1 r1 :w2 r2 :w4 r4})
                (next-fn)))))))))

;;=============================================================================
;; Summary Output
;;=============================================================================

(defn print-summary []
  (println "\n\n================================================================================")
  (println "  CONTENTION BENCHMARK SUMMARY")
  (println "================================================================================\n")

  (let [sep   "  +---------------------+---------------+---------------+---------------+---------------+"
        hdr   "  | Workload            |  Stock 1T     |  SAB 1W       |  SAB 2W       |  SAB 4W       |"]
    (println sep)
    (println hdr)
    (println sep)

    (doseq [{:keys [workload stock sab]} @all-results]
      (let [stock-str (str (fmt-ops (:throughput stock)) "/s")
            sab1-str (str (fmt-ops (:throughput (:w1 sab))) "/s")
            sab2-str (str (fmt-ops (:throughput (:w2 sab))) "/s")
            sab4-str (str (fmt-ops (:throughput (:w4 sab))) "/s")]
        (println (str "  | " (rpad workload 19) " | "
                      (pad stock-str 13) " | "
                      (pad sab1-str 13) " | "
                      (pad sab2-str 13) " | "
                      (pad sab4-str 13) " |"))))
    (println sep))

  ;; Scaling analysis
  (println "\n  Scaling Analysis (SAB throughput vs Stock single-thread baseline):\n")
  (doseq [{:keys [workload stock sab]} @all-results]
    (let [stock-t (:throughput stock)
          r1 (/ (:throughput (:w1 sab)) stock-t)
          r2 (/ (:throughput (:w2 sab)) stock-t)
          r4 (/ (:throughput (:w4 sab)) stock-t)]
      (println (str "  " (rpad workload 20) " — "
                    "1W: " (.toFixed r1 2) "x  "
                    "2W: " (.toFixed r2 2) "x  "
                    "4W: " (.toFixed r4 2) "x  "
                    (cond
                      (> r4 1) "(SAB wins at 4 workers)"
                      (> r2 1) "(SAB wins at 2 workers)"
                      :else "(Stock still faster)")))))

  (println "\n  Legend: Stock 1T = stock CLJS single-threaded (no shared memory)")
  (println "         SAB NW  = EVE SAB with N worker_threads (shared memory via CAS)")
  (println "         Ratio > 1.0 = SAB multi-worker beats stock single-thread")
  (println "\n================================================================================"))

;;=============================================================================
;; Main Entry Point
;;=============================================================================

(defn ^:export run-contention-workload-benchmark []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (reset! all-results [])

      (println "\n================================================================================")
      (println "  EVE SAB vs Stock CLJS — Contention Workload Benchmarks")
      (println "  Stock CLJS: single-threaded baseline (no shared memory)")
      (println "  EVE SAB: multi-worker via worker_threads (SharedArrayBuffer + CAS)")
      (println "  Same total work for each configuration")
      (println "================================================================================")

      (run-workload-1
        (fn []
          (run-workload-2
            (fn []
              (run-workload-3
                (fn []
                  (run-workload-4
                    (fn []
                      (print-summary))))))))))))

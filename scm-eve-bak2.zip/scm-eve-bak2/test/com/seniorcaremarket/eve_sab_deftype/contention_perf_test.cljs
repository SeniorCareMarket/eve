(ns com.seniorcaremarket.eve-sab-deftype.contention-perf-test
  "Multi-threaded performance comparison: OLD vs NEW SAB structures under contention.

   This is the benchmark for tracking optimization progress.
   Focus: concurrent operations across multiple workers.

   Run with: npx shadow-cljs compile contention-perf-test && node out/worker.js"
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   ;; Old structures
   [com.seniorcaremarket.eve.sabp-map :as old-map]
   ;; New structures
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as new-map]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Configuration
;;-----------------------------------------------------------------------------

(def ^:const NUM_WORKERS 4)
(def ^:const OPS_PER_WORKER 10)  ;; Per-worker operations for write tests (kept small due to CAS retry overhead)
(def ^:const READ_REPS 50)       ;; Read repetitions per worker (reads don't allocate)
(def ^:const MAP_SIZE 50)        ;; Size of pre-populated maps

;;-----------------------------------------------------------------------------
;; Environment setup
;; NOTE: SAB needs to be large because CAS retries waste memory.
;; Each failed CAS attempt allocates nodes that are never used.
;; With 4 workers contending, most attempts fail, so we need ~10x headroom.
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize with large SAB for contention tests."
  []
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 128 1024 1024) :max-blocks 262144))
  (a/get-env a/*global-atom-instance*))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

;;-----------------------------------------------------------------------------
;; Root slot allocation for storing structure offsets
;;-----------------------------------------------------------------------------

(defn alloc-root-slot!
  "Allocate a root slot and initialize to -1 (empty)."
  [env]
  (let [result (a/alloc env 8)
        offset (:offset result)
        dv (js/DataView. (:sab env))]
    (.setInt32 dv offset -1 true)      ;; cnt = -1 (marks empty)
    (.setInt32 dv (+ offset 4) -1 true) ;; root-off = -1
    offset))

;;-----------------------------------------------------------------------------
;; Results collection
;;-----------------------------------------------------------------------------

(def ^:dynamic *results* (atom []))

(defn record-result! [test-name structure-type impl duration-ms ops]
  (let [ops-sec (if (pos? duration-ms) (/ (* ops 1000) duration-ms) 0)]
    (swap! *results* conj
           {:test test-name
            :structure structure-type
            :impl impl
            :duration-ms duration-ms
            :ops ops
            :ops-sec ops-sec})))

;;-----------------------------------------------------------------------------
;; Test: Parallel Map Writes
;;-----------------------------------------------------------------------------

(defn run-parallel-map-write-old [done-atom]
  (println "\n  [OLD-MAP] Parallel writes...")
  (let [env (init-env!)
        slot-idx (alloc-root-slot! env)
        workers (vec (repeatedly NUM_WORKERS #(w/mk-worker)))
        completed (atom 0)
        start-time (js/performance.now)]

    (doseq [i (range NUM_WORKERS)]
      (let [worker-id (inc i)]
        (in (nth workers i) [slot-idx worker-id OPS_PER_WORKER completed]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                dv (js/DataView. sab)]
            (dotimes [j OPS_PER_WORKER]
              (let [k (+ (* worker-id 1000) j)
                    v (* k k)]
                (loop [retries 0]
                  (when (< retries 100)  ;; Limit retries
                    (let [cnt (.getInt32 dv slot-idx true)
                          root-off (.getInt32 dv (+ slot-idx 4) true)
                          old-map (if (== cnt -1)
                                    (com.seniorcaremarket.eve.sabp-map/sabp-map env)
                                    (com.seniorcaremarket.eve.sabp-map/->SabpMap
                                     env root-off cnt nil nil))
                          new-map (assoc old-map k v)
                          new-cnt (count new-map)
                          new-root (.-root-offset new-map)]
                      (if (== (js/Atomics.compareExchange
                               (js/Int32Array. sab) (/ slot-idx 4) cnt new-cnt)
                              cnt)
                        (.setInt32 dv (+ slot-idx 4) new-root true)
                        (recur (inc retries))))))))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (js/performance.now) start-time)
             total-ops (* NUM_WORKERS OPS_PER_WORKER)]
         (record-result! "parallel-write" "map" "OLD" elapsed total-ops)
         (println (str "    " (.toFixed elapsed 0) "ms for " total-ops " ops"))
         (cleanup-workers workers)
         (reset! done-atom true)))
     2000)))

(defn run-parallel-map-write-new [done-atom]
  (println "  [NEW-MAP] Parallel writes...")
  (let [env (init-env!)
        slot-idx (alloc-root-slot! env)
        workers (vec (repeatedly NUM_WORKERS #(w/mk-worker)))
        start-time (js/performance.now)]

    (doseq [i (range NUM_WORKERS)]
      (let [worker-id (inc i)]
        (in (nth workers i) [slot-idx worker-id OPS_PER_WORKER]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                dv (js/DataView. sab)]
            (dotimes [j OPS_PER_WORKER]
              (let [k (+ (* worker-id 1000) j)
                    v (* k k)]
                (loop [retries 0]
                  (when (< retries 100)
                    (let [cnt (.getInt32 dv slot-idx true)
                          root-off (.getInt32 dv (+ slot-idx 4) true)
                          old-map (if (== cnt -1)
                                    (com.seniorcaremarket.eve-sab-deftype.sab-map/empty-sab-map)
                                    (com.seniorcaremarket.eve-sab-deftype.sab-map/->SabMapRoot
                                     cnt root-off))
                          new-map (assoc old-map k v)
                          new-cnt (.-cnt new-map)
                          new-root (.-root-off new-map)]
                      (if (== (js/Atomics.compareExchange
                               (js/Int32Array. sab) (/ slot-idx 4) cnt new-cnt)
                              cnt)
                        (.setInt32 dv (+ slot-idx 4) new-root true)
                        (recur (inc retries))))))))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (js/performance.now) start-time)
             total-ops (* NUM_WORKERS OPS_PER_WORKER)]
         (record-result! "parallel-write" "map" "NEW" elapsed total-ops)
         (println (str "    " (.toFixed elapsed 0) "ms for " total-ops " ops"))
         (cleanup-workers workers)
         (reset! done-atom true)))
     2000)))

;;-----------------------------------------------------------------------------
;; Test: Parallel Reads
;;-----------------------------------------------------------------------------

(defn run-parallel-map-read-old [done-atom]
  (println "\n  [OLD-MAP] Parallel reads...")
  (let [env (init-env!)
        m (reduce (fn [m i] (assoc m i (* i i)))
                  (old-map/sabp-map env)
                  (range MAP_SIZE))
        root-ptr (.-root-offset m)
        cnt (count m)
        workers (vec (repeatedly NUM_WORKERS #(w/mk-worker)))
        start-time (js/performance.now)]

    (doseq [i (range NUM_WORKERS)]
      (in (nth workers i) [root-ptr cnt READ_REPS MAP_SIZE]
        (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
              m (com.seniorcaremarket.eve.sabp-map/->SabpMap env root-ptr cnt nil nil)]
          (dotimes [_ READ_REPS]
            (dotimes [k MAP_SIZE]
              (get m k))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (js/performance.now) start-time)
             total-ops (* NUM_WORKERS READ_REPS MAP_SIZE)]
         (record-result! "parallel-read" "map" "OLD" elapsed total-ops)
         (println (str "    " (.toFixed elapsed 0) "ms for " total-ops " ops"))
         (cleanup-workers workers)
         (reset! done-atom true)))
     2000)))

(defn run-parallel-map-read-new [done-atom]
  (println "  [NEW-MAP] Parallel reads...")
  (let [env (init-env!)
        m (reduce (fn [m i] (assoc m i (* i i)))
                  (new-map/empty-sab-map)
                  (range MAP_SIZE))
        root-off (.-root-off m)
        cnt (.-cnt m)
        workers (vec (repeatedly NUM_WORKERS #(w/mk-worker)))
        start-time (js/performance.now)]

    (doseq [i (range NUM_WORKERS)]
      (in (nth workers i) [root-off cnt READ_REPS MAP_SIZE]
        (let [m (com.seniorcaremarket.eve-sab-deftype.sab-map/->SabMapRoot cnt root-off)]
          (dotimes [_ READ_REPS]
            (dotimes [k MAP_SIZE]
              (get m k))))))

    (js/setTimeout
     (fn []
       (let [elapsed (- (js/performance.now) start-time)
             total-ops (* NUM_WORKERS READ_REPS MAP_SIZE)]
         (record-result! "parallel-read" "map" "NEW" elapsed total-ops)
         (println (str "    " (.toFixed elapsed 0) "ms for " total-ops " ops"))
         (cleanup-workers workers)
         (reset! done-atom true)))
     2000)))

;;-----------------------------------------------------------------------------
;; Summary
;;-----------------------------------------------------------------------------

(defn pad-right [s width]
  (let [s (str s)
        pad (- width (count s))]
    (if (<= pad 0) s (str s (apply str (repeat pad " "))))))

(defn print-summary []
  (println "\n" (apply str (repeat 70 "=")))
  (println "  CONTENTION PERFORMANCE: OLD vs NEW (higher ops/s is better)")
  (println (apply str (repeat 70 "=")) "\n")

  (println (str "  " (pad-right "Test" 20) (pad-right "Structure" 12)
                (pad-right "OLD ops/s" 15) (pad-right "NEW ops/s" 15) "Ratio"))
  (println (str "  " (apply str (repeat 65 "-"))))

  (let [results @*results*
        grouped (group-by (fn [r] [(:test r) (:structure r)]) results)]
    (doseq [[[test-name struct-type] rs] (sort-by first grouped)]
      (let [old-r (first (filter #(= "OLD" (:impl %)) rs))
            new-r (first (filter #(= "NEW" (:impl %)) rs))]
        (when (and old-r new-r)
          (let [ratio (if (pos? (:ops-sec old-r))
                        (/ (:ops-sec new-r) (:ops-sec old-r))
                        0)]
            (println (str "  " (pad-right test-name 20)
                          (pad-right struct-type 12)
                          (pad-right (.toFixed (:ops-sec old-r) 0) 15)
                          (pad-right (.toFixed (:ops-sec new-r) 0) 15)
                          (.toFixed ratio 2) "x")))))))

  (println "\n" (str "  " (apply str (repeat 65 "-"))))
  (println (str "  Workers: " NUM_WORKERS ", Ops/worker: " OPS_PER_WORKER
                ", Reads: " READ_REPS "x" MAP_SIZE))
  (println "  Ratio > 1.0 means NEW is faster under contention")
  (println (str "  " (apply str (repeat 65 "=")))))

;;-----------------------------------------------------------------------------
;; Test Runner - Sequential execution
;;-----------------------------------------------------------------------------

(defn run-all-tests []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (reset! *results* [])
      (println "\n" (apply str (repeat 70 "="))
               "\n  CONTENTION BENCHMARK: OLD vs NEW SAB Map"
               "\n  Workers:" NUM_WORKERS "  Ops/worker:" OPS_PER_WORKER
               "\n" (apply str (repeat 70 "=")) "\n")

      ;; Run tests sequentially with delays between them
      (let [done1 (atom false)
            done2 (atom false)
            done3 (atom false)
            done4 (atom false)]

        ;; Start first test
        (run-parallel-map-write-old done1)

        ;; Chain remaining tests
        (let [check-interval 100]
          (letfn [(wait-and-run [done-atom next-fn]
                    (if @done-atom
                      (js/setTimeout next-fn 500)
                      (js/setTimeout #(wait-and-run done-atom next-fn) check-interval)))]

            (wait-and-run done1 #(run-parallel-map-write-new done2))
            (wait-and-run done2 #(run-parallel-map-read-old done3))
            (wait-and-run done3 #(run-parallel-map-read-new done4))
            (wait-and-run done4 print-summary)))))))

(run-all-tests)

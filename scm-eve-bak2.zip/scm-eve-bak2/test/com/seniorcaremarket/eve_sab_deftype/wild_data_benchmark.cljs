(ns com.seniorcaremarket.eve-sab-deftype.wild-data-benchmark
  "Comprehensive real-world benchmark: heterogeneous data from 5 domains,
   large datasets, and diverse transformation patterns.

   Domains:
   1. E-commerce catalog — 2000 products with nested specs/pricing/tags
   2. User activity stream — 5000 events with metadata
   3. Configuration tree — 5-level deep nesting, mixed types
   4. Social profiles — 1000 users with friend-sets + post-vecs
   5. Metrics dashboard — 3000 metric points with labels

   Each domain tests: aggregation, filtering, multi-step pipelines,
   cross-collection joins, deep access, batch updates, and derived
   collection construction."
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sab-vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as sab-set]))

(set! d/*worker-id* 1)

;;=============================================================================
;; Infrastructure
;;=============================================================================

(defn now [] (js/performance.now))

(defn fresh-env! []
  (sab-map/reset-pools!)
  (sab-set/reset-pools!)
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 512 1024 1024) :max-blocks 524288))
  (sab-map/reset-pools!)
  (sab-set/reset-pools!))

(defn bench [f & {:keys [iters warmup] :or {iters 200 warmup 50}}]
  (dotimes [_ warmup] (f))
  (let [times (js/Float64Array. iters)]
    (dotimes [i iters]
      (let [start (now)]
        (f)
        (aset times i (- (now) start))))
    (let [sorted (doto (js/Array.from times) (.sort))
          sum (reduce + 0 (array-seq sorted))
          mean-ms (/ sum iters)
          median-ms (aget sorted (js/Math.floor (/ iters 2)))]
      {:mean-us (* mean-ms 1000)
       :median-us (* median-ms 1000)
       :ops-s (if (pos? mean-ms) (/ 1000 mean-ms) 0)})))

(defn fmt-us [us]
  (cond
    (< us 1) (str (.toFixed (* us 1000) 0) "ns")
    (< us 1000) (str (.toFixed us 2) "us")
    :else (str (.toFixed (/ us 1000) 2) "ms")))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (str (.toFixed (/ ops 1e6) 2) "M")
    (>= ops 1e3) (str (.toFixed (/ ops 1e3) 1) "K")
    :else (str (.toFixed ops 1) "")))

(defn pad [s n] (.padStart (str s) n))

(def ^:private *results* (atom []))

(defn record! [domain scenario n stock-result sab-result]
  (let [ratio (/ (:ops-s sab-result) (:ops-s stock-result))]
    (swap! *results* conj
           {:domain domain :scenario scenario :n n
            :stock stock-result :sab sab-result :ratio ratio})))

;;=============================================================================
;; Deterministic pseudo-random (avoid measuring Math.random)
;;=============================================================================

(defn prng
  "Simple xorshift32 for deterministic pseudorandom sequences."
  [seed]
  (let [x (bit-xor seed (bit-shift-left seed 13))
        x (bit-xor x (unsigned-bit-shift-right x 17))
        x (bit-xor x (bit-shift-left x 5))]
    (bit-and x 0x7FFFFFFF)))

(defn prng-seq
  "Generate n pseudorandom ints from seed."
  [seed n]
  (loop [acc [] s seed i 0]
    (if (>= i n) acc
        (let [next-s (prng s)]
          (recur (conj acc next-s) next-s (inc i))))))

;;=============================================================================
;; Domain 1: E-Commerce Product Catalog (2000 products)
;;=============================================================================

(def ^:const CATALOG-SIZE 2000)
(def categories [:electronics :clothing :food :tools :books :toys :sports :home
                 :garden :automotive :health :beauty :office :music :pets])
(def brands ["Acme" "GlobalTech" "EcoGoods" "PrimeLine" "NovaCo" "ZenithCorp"
             "AlphaWare" "BetaBuild" "GammaProd" "DeltaMfg"])
(def colors [:red :blue :green :black :white :silver :gold :navy :forest :coral])

(defn gen-product [i]
  {:id i
   :sku (str "SKU-" (.padStart (str i) 6 "0"))
   :name (str (nth brands (mod i (count brands))) " "
              (name (nth categories (mod i (count categories)))) " #" i)
   :category (nth categories (mod i (count categories)))
   :brand (nth brands (mod i (count brands)))
   :price (+ 0.99 (* (mod (* i 13) 500) 0.97))
   :cost (+ 0.50 (* (mod (* i 7) 300) 0.63))
   :stock (mod (* i 17) 2000)
   :active (zero? (mod i 5))
   :featured (zero? (mod i 23))
   :rating (+ 1.0 (* (mod (* i 11) 40) 0.1))
   :review-count (mod (* i 31) 500)
   :color (nth colors (mod i (count colors)))
   :weight-kg (+ 0.1 (* (mod (* i 19) 100) 0.15))
   :tags [(keyword (str "tag-" (mod i 20)))
          (keyword (str "season-" (mod i 4)))
          (keyword (str "tier-" (mod i 3)))]
   :specs {:width (+ 1 (mod (* i 3) 100))
           :height (+ 1 (mod (* i 5) 80))
           :depth (+ 1 (mod (* i 7) 60))
           :material (nth [:plastic :metal :wood :glass :fabric :ceramic]
                          (mod i 6))}
   :pricing {:wholesale (+ 0.50 (* (mod (* i 7) 300) 0.50))
             :bulk-discount (+ 5 (mod (* i 3) 25))
             :min-order (+ 1 (mod i 50))}})

(defn build-stock-catalog [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "p" i)) (gen-product i)) (inc i)))))

(defn build-sab-catalog [n]
  (loop [m (sab-map/empty-sab-map) i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "p" i)) (gen-product i)) (inc i)))))

;; Bench 1a: Revenue aggregation — sum(price * stock) for active products
(defn bench-catalog-revenue [n]
  (println (str "    Building " n "-product catalog..."))
  (let [stock-m (build-stock-catalog n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k prod]
                          (if (:active prod)
                            (+ acc (* (:price prod) (:stock prod)))
                            acc))
                        0.0 stock-m))
                     :iters 150 :warmup 30)]
    (fresh-env!)
    (let [sab-m (build-sab-catalog n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k prod]
                          (if (:active prod)
                            (+ acc (* (:price prod) (:stock prod)))
                            acc))
                        0.0 sab-m))
                     :iters 150 :warmup 30)]
      (record! :catalog "revenue: price*stock active" n stock sab))))

;; Bench 1b: Category breakdown — count items per category
(defn bench-catalog-category-count [n]
  (println (str "    Building " n "-product catalog for category count..."))
  (let [stock-m (build-stock-catalog n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k prod]
                          (let [cat (:category prod)]
                            (assoc acc cat (inc (get acc cat 0)))))
                        {} stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-catalog n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k prod]
                          (let [cat (:category prod)]
                            (assoc acc cat (inc (get acc cat 0)))))
                        {} sab-m))
                     :iters 100 :warmup 20)]
      (record! :catalog "group-by category count" n stock sab))))

;; Bench 1c: Margin analysis — filter high-margin products, compute avg margin%
(defn bench-catalog-margin [n]
  (println (str "    Building " n "-product catalog for margin analysis..."))
  (let [stock-m (build-stock-catalog n)
        stock (bench (fn []
                       (let [result (reduce-kv
                                     (fn [acc _k prod]
                                       (let [margin (- (:price prod) (:cost prod))
                                             pct (/ margin (:price prod))]
                                         (if (> pct 0.3)
                                           {:sum (+ (:sum acc) pct)
                                            :cnt (inc (:cnt acc))}
                                           acc)))
                                     {:sum 0.0 :cnt 0} stock-m)]
                         (when (pos? (:cnt result))
                           (/ (:sum result) (:cnt result)))))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-catalog n)
          sab (bench (fn []
                       (let [result (reduce-kv
                                     (fn [acc _k prod]
                                       (let [margin (- (:price prod) (:cost prod))
                                             pct (/ margin (:price prod))]
                                         (if (> pct 0.3)
                                           {:sum (+ (:sum acc) pct)
                                            :cnt (inc (:cnt acc))}
                                           acc)))
                                     {:sum 0.0 :cnt 0} sab-m)]
                         (when (pos? (:cnt result))
                           (/ (:sum result) (:cnt result)))))
                     :iters 100 :warmup 20)]
      (record! :catalog "margin filter+avg (>30%)" n stock sab))))

;; Bench 1d: Deep nested access — read specs.width + pricing.wholesale for 100 products
(defn bench-catalog-deep-access [n num-reads]
  (println (str "    Building " n "-product catalog for deep access..."))
  (let [keys-arr (let [arr (make-array num-reads)]
                   (dotimes [i num-reads]
                     (aset arr i (keyword (str "p" (mod (bit-and (prng (* i 2654435761)) 0x7FFFFFFF) n)))))
                   arr)
        stock-m (build-stock-catalog n)
        stock (bench (fn []
                       (dotimes [i num-reads]
                         (let [prod (get stock-m (aget keys-arr i))]
                           (when prod
                             (get-in prod [:specs :width])
                             (get-in prod [:specs :material])
                             (get-in prod [:pricing :wholesale])
                             (get-in prod [:pricing :bulk-discount])))))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-m (build-sab-catalog n)
          sab (bench (fn []
                       (dotimes [i num-reads]
                         (let [prod (get sab-m (aget keys-arr i))]
                           (when prod
                             (get-in prod [:specs :width])
                             (get-in prod [:specs :material])
                             (get-in prod [:pricing :wholesale])
                             (get-in prod [:pricing :bulk-discount])))))
                     :iters 300 :warmup 50)]
      (record! :catalog (str num-reads " deep nested reads") n stock sab))))

;; Bench 1e: Batch price update — update 200 product prices
(defn bench-catalog-batch-update [n num-updates]
  (println (str "    Building " n "-product catalog for batch update..."))
  (let [keys-arr (let [arr (make-array num-updates)]
                   (dotimes [i num-updates]
                     (aset arr i (keyword (str "p" (mod (bit-and (prng (* i 7919)) 0x7FFFFFFF) n)))))
                   arr)
        stock-m (build-stock-catalog n)
        stock (bench (fn []
                       (loop [m stock-m i 0]
                         (if (>= i num-updates) m
                             (let [k (aget keys-arr i)
                                   prod (get m k)]
                               (recur (if prod
                                        (assoc m k (assoc prod :price (* (:price prod) 1.05)))
                                        m)
                                      (inc i))))))
                     :iters 50 :warmup 10)]
    (fresh-env!)
    (let [sab-m (build-sab-catalog n)
          sab (bench (fn []
                       (loop [m sab-m i 0]
                         (if (>= i num-updates) m
                             (let [k (aget keys-arr i)
                                   prod (get m k)]
                               (recur (if prod
                                        (assoc m k (assoc prod :price (* (:price prod) 1.05)))
                                        m)
                                      (inc i))))))
                     :iters 50 :warmup 10)]
      (record! :catalog (str num-updates " nested assoc updates") n stock sab))))

;;=============================================================================
;; Domain 2: User Activity Stream (5000 events)
;;=============================================================================

(def ^:const STREAM-SIZE 5000)
(def actions [:page-view :click :purchase :add-cart :remove-cart :search
              :login :logout :share :bookmark :review :signup])

(defn gen-event [i]
  {:event-id i
   :user-id (mod i 500)
   :action (nth actions (mod i (count actions)))
   :timestamp (+ 1700000000 (* i 60))
   :session (str "sess-" (mod i 200))
   :page (str "/page/" (mod (* i 7) 100))
   :duration-ms (+ 100 (mod (* i 37) 30000))
   :metadata {:device (nth [:mobile :desktop :tablet] (mod i 3))
              :browser (nth [:chrome :firefox :safari :edge] (mod i 4))
              :country (nth [:us :uk :de :fr :jp :br :au :ca :in :mx] (mod i 10))}
   :value (when (zero? (mod i 3))
            (+ 1.0 (* (mod (* i 11) 200) 0.99)))})

(defn build-stock-stream [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "e" i)) (gen-event i)) (inc i)))))

(defn build-sab-stream [n]
  (loop [m (sab-map/empty-sab-map) i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "e" i)) (gen-event i)) (inc i)))))

;; Bench 2a: Purchase revenue — filter purchases, sum values
(defn bench-stream-purchase-revenue [n]
  (println (str "    Building " n "-event stream..."))
  (let [stock-m (build-stock-stream n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (if (and (= :purchase (:action evt))
                                   (:value evt))
                            (+ acc (:value evt))
                            acc))
                        0.0 stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-stream n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (if (and (= :purchase (:action evt))
                                   (:value evt))
                            (+ acc (:value evt))
                            acc))
                        0.0 sab-m))
                     :iters 100 :warmup 20)]
      (record! :stream "purchase revenue sum" n stock sab))))

;; Bench 2b: Per-user action count — group-by user-id, count actions
(defn bench-stream-user-action-count [n]
  (println (str "    Building " n "-event stream for user action count..."))
  (let [stock-m (build-stock-stream n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (let [uid (:user-id evt)]
                            (assoc acc uid (inc (get acc uid 0)))))
                        {} stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-stream n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (let [uid (:user-id evt)]
                            (assoc acc uid (inc (get acc uid 0)))))
                        {} sab-m))
                     :iters 100 :warmup 20)]
      (record! :stream "group-by user action count" n stock sab))))

;; Bench 2c: Device breakdown with nested metadata access
(defn bench-stream-device-breakdown [n]
  (println (str "    Building " n "-event stream for device breakdown..."))
  (let [stock-m (build-stock-stream n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (let [device (get-in evt [:metadata :device])]
                            (assoc acc device (inc (get acc device 0)))))
                        {} stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-stream n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (let [device (get-in evt [:metadata :device])]
                            (assoc acc device (inc (get acc device 0)))))
                        {} sab-m))
                     :iters 100 :warmup 20)]
      (record! :stream "device breakdown (nested)" n stock sab))))

;; Bench 2d: Multi-field pipeline — filter desktop + high-duration, sum values
(defn bench-stream-pipeline [n]
  (println (str "    Building " n "-event stream for multi-field pipeline..."))
  (let [stock-m (build-stock-stream n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (if (and (= :desktop (get-in evt [:metadata :device]))
                                   (> (:duration-ms evt) 5000)
                                   (:value evt))
                            {:sum (+ (:sum acc) (:value evt))
                             :cnt (inc (:cnt acc))}
                            acc))
                        {:sum 0.0 :cnt 0} stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-stream n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k evt]
                          (if (and (= :desktop (get-in evt [:metadata :device]))
                                   (> (:duration-ms evt) 5000)
                                   (:value evt))
                            {:sum (+ (:sum acc) (:value evt))
                             :cnt (inc (:cnt acc))}
                            acc))
                        {:sum 0.0 :cnt 0} sab-m))
                     :iters 100 :warmup 20)]
      (record! :stream "desktop+highDur pipeline" n stock sab))))

;;=============================================================================
;; Domain 3: Configuration Tree (deep nesting)
;;=============================================================================

(defn gen-config-tree
  "Generate a realistic 5-level deep config tree with ~800 leaf values."
  []
  {:app {:name "eve-platform"
         :version "3.14.159"
         :debug false
         :features {:dark-mode true
                    :notifications {:email true :sms false :push true
                                    :frequency :daily :quiet-hours [22 7]}
                    :analytics {:enabled true :sample-rate 0.1 :provider "mixpanel"
                                :events [:page-view :click :purchase :signup]}
                    :caching {:strategy :lru :max-size 10000 :ttl-ms 300000
                              :layers {:l1 {:size 1000 :type :memory}
                                       :l2 {:size 10000 :type :disk}
                                       :l3 {:size 100000 :type :redis}}}}}
   :database {:primary {:host "db-primary.internal"
                        :port 5432
                        :name "eve_prod"
                        :pool {:min 5 :max 50 :idle-timeout 30000}
                        :ssl {:enabled true :ca-cert "/certs/ca.pem"}}
              :replica {:host "db-replica.internal"
                        :port 5432
                        :name "eve_prod"
                        :pool {:min 2 :max 20 :idle-timeout 60000}}
              :redis {:host "redis.internal" :port 6379 :db 0
                      :cluster {:enabled true :nodes 6 :replicas 2}}}
   :services (loop [m {} i 0]
               (if (>= i 20) m
                   (recur (assoc m
                                 (keyword (str "svc-" i))
                                 {:url (str "https://svc-" i ".internal")
                                  :timeout-ms (+ 1000 (* i 500))
                                  :retries (+ 1 (mod i 5))
                                  :auth {:type (nth [:jwt :api-key :oauth2] (mod i 3))
                                         :secret (str "secret-" i)}
                                  :health {:interval-ms 10000
                                           :threshold 3
                                           :endpoint "/health"}})
                          (inc i))))
   :deployment {:environment :production
                :region "us-east-1"
                :replicas 12
                :autoscale {:min 3 :max 50 :target-cpu 70}
                :rollout {:strategy :canary :percentage 10 :interval-ms 60000}}
   :logging {:level :info
             :outputs {:console {:enabled true :format :json}
                       :file {:enabled true :path "/var/log/eve" :max-size-mb 100
                              :rotation {:count 10 :compress true}}
                       :remote {:enabled true :host "log.internal" :port 5514
                                :protocol :tcp :buffer-size 1000}}
             :sampling {:rate 0.01 :excluded [:health-check :metrics]}}
   :users (loop [m {} i 0]
            (if (>= i 50) m
                (recur (assoc m
                              (keyword (str "u" i))
                              {:name (str "User " i)
                               :email (str "user" i "@example.com")
                               :role (nth [:admin :editor :viewer] (mod i 3))
                               :permissions [(keyword (str "perm-" (mod i 10)))
                                             (keyword (str "perm-" (mod (* i 3) 10)))]
                               :settings {:theme (nth [:dark :light :auto] (mod i 3))
                                          :lang (nth [:en :fr :de :ja :es] (mod i 5))
                                          :timezone (str "UTC" (if (zero? (mod i 2)) "+" "-")
                                                         (mod i 12))}})
                       (inc i))))})

;; Bench 3a: Deep get-in — 200 reads at various depths
(defn bench-config-deep-reads [num-reads]
  (println (str "    Building config tree for " num-reads " deep reads..."))
  (let [;; Pre-generate access paths at various depths
        paths [[:app :name]
               [:app :features :dark-mode]
               [:app :features :notifications :frequency]
               [:app :features :caching :strategy]
               [:app :features :caching :layers :l2 :type]
               [:database :primary :host]
               [:database :primary :pool :max]
               [:database :primary :ssl :enabled]
               [:database :redis :cluster :nodes]
               [:deployment :autoscale :target-cpu]
               [:logging :outputs :file :max-size-mb]
               [:logging :outputs :remote :protocol]
               [:logging :sampling :rate]
               [:deployment :rollout :strategy]
               [:app :features :analytics :provider]]
        path-arr (let [arr (make-array num-reads)]
                   (dotimes [i num-reads]
                     (aset arr i (nth paths (mod i (count paths)))))
                   arr)
        stock-cfg (gen-config-tree)
        stock (bench (fn []
                       (dotimes [i num-reads]
                         (get-in stock-cfg (aget path-arr i))))
                     :iters 500 :warmup 100)]
    (fresh-env!)
    (reset! a/*global-atom-instance* stock-cfg)
    (let [sab-cfg @a/*global-atom-instance*
          sab (bench (fn []
                       (dotimes [i num-reads]
                         (get-in sab-cfg (aget path-arr i))))
                     :iters 500 :warmup 100)]
      (record! :config (str num-reads " deep get-in reads") 1 stock sab))))

;; Bench 3b: Service health scan — iterate all services, check retries+timeout
(defn bench-config-service-scan []
  (println "    Building config tree for service scan...")
  (let [stock-cfg (gen-config-tree)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc svc-key svc]
                          (if (> (:retries svc) 2)
                            (conj acc {:svc svc-key
                                       :timeout (:timeout-ms svc)
                                       :auth-type (get-in svc [:auth :type])})
                            acc))
                        [] (:services stock-cfg)))
                     :iters 500 :warmup 100)]
    (fresh-env!)
    (reset! a/*global-atom-instance* stock-cfg)
    (let [sab-cfg @a/*global-atom-instance*
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc svc-key svc]
                          (if (> (:retries svc) 2)
                            (conj acc {:svc svc-key
                                       :timeout (:timeout-ms svc)
                                       :auth-type (get-in svc [:auth :type])})
                            acc))
                        [] (:services sab-cfg)))
                     :iters 500 :warmup 100)]
      (record! :config "service health scan (20 svcs)" 1 stock sab))))

;; Bench 3c: User permissions scan — count admins, collect editor permissions
(defn bench-config-user-permissions []
  (println "    Building config tree for user permissions scan...")
  (let [stock-cfg (gen-config-tree)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k user]
                          (case (:role user)
                            :admin (update acc :admin-count inc)
                            :editor (update acc :editor-perms
                                            #(concat % (:permissions user)))
                            acc))
                        {:admin-count 0 :editor-perms []}
                        (:users stock-cfg)))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (reset! a/*global-atom-instance* stock-cfg)
    (let [sab-cfg @a/*global-atom-instance*
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k user]
                          (case (:role user)
                            :admin (update acc :admin-count inc)
                            :editor (update acc :editor-perms
                                            #(concat % (:permissions user)))
                            acc))
                        {:admin-count 0 :editor-perms []}
                        (:users sab-cfg)))
                     :iters 300 :warmup 50)]
      (record! :config "user permissions scan (50 users)" 1 stock sab))))

;;=============================================================================
;; Domain 4: Social Profiles (1000 users)
;;=============================================================================

(def ^:const SOCIAL-SIZE 1000)

(defn gen-social-profile [i n]
  {:user-id i
   :username (str "user_" i)
   :display-name (str "User " i " " (nth ["Smith" "Jones" "Chen" "Garcia" "Kim"
                                           "Patel" "Brown" "Wilson" "Lee" "Taylor"]
                                          (mod i 10)))
   :bio (str "Bio for user " i ". Interests: "
             (name (nth [:coding :music :sports :travel :cooking
                         :reading :gaming :art :science :photography]
                        (mod i 10))))
   :verified (zero? (mod i 7))
   :follower-count (* i 10)
   :following-count (+ 50 (mod (* i 13) 500))
   :joined-year (+ 2015 (mod i 10))
   ;; Friends as a vector of user-ids (10-30 friends each)
   :friends (let [num-friends (+ 10 (mod (* i 7) 21))]
              (loop [v [] j 0]
                (if (>= j num-friends) v
                    (recur (conj v (mod (+ i (* j 37) 7) n)) (inc j)))))
   ;; Last 5 posts as nested maps
   :posts (loop [v [] j 0]
            (if (>= j 5) v
                (recur (conj v {:post-id (+ (* i 100) j)
                                :text (str "Post " j " by user " i)
                                :likes (mod (* (+ (* i 100) j) 11) 1000)
                                :timestamp (+ 1700000000 (* j 3600))
                                :tags [(keyword (str "topic-" (mod j 8)))]})
                       (inc j))))
   :settings {:privacy (nth [:public :friends :private] (mod i 3))
              :notifications true
              :theme (nth [:light :dark :auto] (mod i 3))}})

(defn build-stock-social [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "u" i)) (gen-social-profile i n)) (inc i)))))

(defn build-sab-social [n]
  (loop [m (sab-map/empty-sab-map) i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "u" i)) (gen-social-profile i n)) (inc i)))))

;; Bench 4a: Aggregate total post likes across all users
(defn bench-social-total-likes [n]
  (println (str "    Building " n "-user social graph..."))
  (let [stock-m (build-stock-social n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k profile]
                          (+ acc (reduce (fn [s post] (+ s (:likes post)))
                                         0 (:posts profile))))
                        0 stock-m))
                     :iters 80 :warmup 15)]
    (fresh-env!)
    (let [sab-m (build-sab-social n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k profile]
                          (+ acc (reduce (fn [s post] (+ s (:likes post)))
                                         0 (:posts profile))))
                        0 sab-m))
                     :iters 80 :warmup 15)]
      (record! :social "total post likes (nested reduce)" n stock sab))))

;; Bench 4b: Find verified users with high followers — filter + extract
(defn bench-social-verified-influencers [n]
  (println (str "    Building " n "-user social graph for influencer search..."))
  (let [threshold (* n 5) ;; top ~50% by follower count
        stock-m (build-stock-social n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k profile]
                          (if (and (:verified profile)
                                   (> (:follower-count profile) threshold))
                            (conj acc {:name (:display-name profile)
                                       :followers (:follower-count profile)})
                            acc))
                        [] stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-social n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k profile]
                          (if (and (:verified profile)
                                   (> (:follower-count profile) threshold))
                            (conj acc {:name (:display-name profile)
                                       :followers (:follower-count profile)})
                            acc))
                        [] sab-m))
                     :iters 100 :warmup 20)]
      (record! :social "verified influencers filter" n stock sab))))

;; Bench 4c: Cross-collection join — for 50 random users, look up each friend's username
(defn bench-social-friend-lookup [n num-lookups]
  (println (str "    Building " n "-user social graph for friend lookup..."))
  (let [user-keys (let [arr (make-array num-lookups)]
                    (dotimes [i num-lookups]
                      (aset arr i (keyword (str "u" (mod (bit-and (prng (* i 9973)) 0x7FFFFFFF) n)))))
                    arr)
        stock-m (build-stock-social n)
        stock (bench (fn []
                       (dotimes [i num-lookups]
                         (let [profile (get stock-m (aget user-keys i))]
                           (when profile
                             ;; Look up first 5 friends' usernames
                             (let [friends (:friends profile)]
                               (dotimes [j (min 5 (count friends))]
                                 (let [friend-id (nth friends j)]
                                   (when-let [fp (get stock-m (keyword (str "u" friend-id)))]
                                     (:username fp)))))))))
                     :iters 200 :warmup 40)]
    (fresh-env!)
    (let [sab-m (build-sab-social n)
          sab (bench (fn []
                       (dotimes [i num-lookups]
                         (let [profile (get sab-m (aget user-keys i))]
                           (when profile
                             (let [friends (:friends profile)]
                               (dotimes [j (min 5 (count friends))]
                                 (let [friend-id (nth friends j)]
                                   (when-let [fp (get sab-m (keyword (str "u" friend-id)))]
                                     (:username fp)))))))))
                     :iters 200 :warmup 40)]
      (record! :social (str num-lookups " friend-of-friend joins") n stock sab))))

;; Bench 4d: Privacy scan — count users per privacy setting + collect public bios
(defn bench-social-privacy-scan [n]
  (println (str "    Building " n "-user social graph for privacy scan..."))
  (let [stock-m (build-stock-social n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k profile]
                          (let [privacy (get-in profile [:settings :privacy])]
                            (-> acc
                                (update privacy (fnil inc 0))
                                (cond->
                                  (= :public privacy)
                                  (update :public-bios (fnil conj []) (:bio profile))))))
                        {} stock-m))
                     :iters 80 :warmup 15)]
    (fresh-env!)
    (let [sab-m (build-sab-social n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k profile]
                          (let [privacy (get-in profile [:settings :privacy])]
                            (-> acc
                                (update privacy (fnil inc 0))
                                (cond->
                                  (= :public privacy)
                                  (update :public-bios (fnil conj []) (:bio profile))))))
                        {} sab-m))
                     :iters 80 :warmup 15)]
      (record! :social "privacy scan (nested access)" n stock sab))))

;;=============================================================================
;; Domain 5: Metrics Dashboard (3000 points)
;;=============================================================================

(def ^:const METRICS-SIZE 3000)
(def metric-names [:cpu-usage :memory-mb :disk-io :network-in :network-out
                   :request-count :error-rate :latency-p50 :latency-p99
                   :gc-pause :thread-count :queue-depth])
(def hosts ["web-1" "web-2" "web-3" "api-1" "api-2" "api-3"
            "worker-1" "worker-2" "db-1" "db-2" "cache-1" "cache-2"])

(defn gen-metric [i]
  (let [metric-name (nth metric-names (mod i (count metric-names)))
        host (nth hosts (mod (quot i (count metric-names)) (count hosts)))]
    {:metric metric-name
     :host host
     :timestamp (+ 1700000000 (* i 10))
     :value (case metric-name
              :cpu-usage (+ 10.0 (mod (* i 7) 90))
              :memory-mb (+ 500.0 (mod (* i 13) 3500))
              :disk-io (+ 0.0 (mod (* i 17) 10000))
              :network-in (+ 100.0 (mod (* i 23) 50000))
              :network-out (+ 50.0 (mod (* i 29) 30000))
              :request-count (mod (* i 37) 5000)
              :error-rate (/ (mod (* i 3) 100) 1000.0)
              :latency-p50 (+ 1.0 (mod (* i 11) 200))
              :latency-p99 (+ 10.0 (mod (* i 19) 2000))
              :gc-pause (+ 0.1 (/ (mod (* i 31) 500) 100.0))
              :thread-count (+ 10 (mod (* i 41) 200))
              :queue-depth (mod (* i 43) 1000))
     :unit (case metric-name
             :cpu-usage :percent
             :memory-mb :mb
             (:disk-io :network-in :network-out) :bytes-per-sec
             :request-count :count
             :error-rate :ratio
             (:latency-p50 :latency-p99 :gc-pause) :ms
             :thread-count :count
             :queue-depth :count)
     :tags {:env :production
            :region (nth [:us-east :us-west :eu-west :ap-east] (mod i 4))
            :tier (nth [:frontend :backend :data :infra] (mod i 4))}}))

(defn build-stock-metrics [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "m" i)) (gen-metric i)) (inc i)))))

(defn build-sab-metrics [n]
  (loop [m (sab-map/empty-sab-map) i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "m" i)) (gen-metric i)) (inc i)))))

;; Bench 5a: Per-host average CPU — filter cpu-usage, group by host, compute avg
(defn bench-metrics-cpu-avg [n]
  (println (str "    Building " n "-point metrics dashboard..."))
  (let [stock-m (build-stock-metrics n)
        stock (bench (fn []
                       (let [by-host (reduce-kv
                                      (fn [acc _k pt]
                                        (if (= :cpu-usage (:metric pt))
                                          (let [h (:host pt)
                                                prev (get acc h {:sum 0.0 :cnt 0})]
                                            (assoc acc h {:sum (+ (:sum prev) (:value pt))
                                                          :cnt (inc (:cnt prev))}))
                                          acc))
                                      {} stock-m)]
                         ;; Compute averages
                         (reduce-kv (fn [acc h {:keys [sum cnt]}]
                                      (assoc acc h (/ sum cnt)))
                                    {} by-host)))
                     :iters 80 :warmup 15)]
    (fresh-env!)
    (let [sab-m (build-sab-metrics n)
          sab (bench (fn []
                       (let [by-host (reduce-kv
                                      (fn [acc _k pt]
                                        (if (= :cpu-usage (:metric pt))
                                          (let [h (:host pt)
                                                prev (get acc h {:sum 0.0 :cnt 0})]
                                            (assoc acc h {:sum (+ (:sum prev) (:value pt))
                                                          :cnt (inc (:cnt prev))}))
                                          acc))
                                      {} sab-m)]
                         (reduce-kv (fn [acc h {:keys [sum cnt]}]
                                      (assoc acc h (/ sum cnt)))
                                    {} by-host)))
                     :iters 80 :warmup 15)]
      (record! :metrics "per-host CPU avg (filter+group)" n stock sab))))

;; Bench 5b: Error rate hotspots — find metrics with error_rate > 0.05, collect host+region
(defn bench-metrics-error-hotspots [n]
  (println (str "    Building " n "-point metrics for error hotspots..."))
  (let [stock-m (build-stock-metrics n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k pt]
                          (if (and (= :error-rate (:metric pt))
                                   (> (:value pt) 0.05))
                            (conj acc {:host (:host pt)
                                       :rate (:value pt)
                                       :region (get-in pt [:tags :region])
                                       :tier (get-in pt [:tags :tier])})
                            acc))
                        [] stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-metrics n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k pt]
                          (if (and (= :error-rate (:metric pt))
                                   (> (:value pt) 0.05))
                            (conj acc {:host (:host pt)
                                       :rate (:value pt)
                                       :region (get-in pt [:tags :region])
                                       :tier (get-in pt [:tags :tier])})
                            acc))
                        [] sab-m))
                     :iters 100 :warmup 20)]
      (record! :metrics "error hotspots (filter+nested)" n stock sab))))

;; Bench 5c: Multi-metric summary — compute min/max/sum for latency-p99
(defn bench-metrics-latency-summary [n]
  (println (str "    Building " n "-point metrics for latency summary..."))
  (let [stock-m (build-stock-metrics n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k pt]
                          (if (= :latency-p99 (:metric pt))
                            (let [v (:value pt)]
                              {:min (min (:min acc) v)
                               :max (max (:max acc) v)
                               :sum (+ (:sum acc) v)
                               :cnt (inc (:cnt acc))})
                            acc))
                        {:min js/Infinity :max js/Number.NEGATIVE_INFINITY
                         :sum 0.0 :cnt 0}
                        stock-m))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-m (build-sab-metrics n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k pt]
                          (if (= :latency-p99 (:metric pt))
                            (let [v (:value pt)]
                              {:min (min (:min acc) v)
                               :max (max (:max acc) v)
                               :sum (+ (:sum acc) v)
                               :cnt (inc (:cnt acc))})
                            acc))
                        {:min js/Infinity :max js/Number.NEGATIVE_INFINITY
                         :sum 0.0 :cnt 0}
                        sab-m))
                     :iters 100 :warmup 20)]
      (record! :metrics "latency-p99 min/max/sum" n stock sab))))

;; Bench 5d: Region tier matrix — 2-level group-by (region × tier), count points
(defn bench-metrics-region-tier [n]
  (println (str "    Building " n "-point metrics for region×tier matrix..."))
  (let [stock-m (build-stock-metrics n)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k pt]
                          (let [region (get-in pt [:tags :region])
                                tier (get-in pt [:tags :tier])
                                inner (get acc region {})]
                            (assoc acc region
                                   (assoc inner tier
                                          (inc (get inner tier 0))))))
                        {} stock-m))
                     :iters 80 :warmup 15)]
    (fresh-env!)
    (let [sab-m (build-sab-metrics n)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k pt]
                          (let [region (get-in pt [:tags :region])
                                tier (get-in pt [:tags :tier])
                                inner (get acc region {})]
                            (assoc acc region
                                   (assoc inner tier
                                          (inc (get inner tier 0))))))
                        {} sab-m))
                     :iters 80 :warmup 15)]
      (record! :metrics "region×tier 2-level group-by" n stock sab))))

;;=============================================================================
;; Cross-Domain: Mixed Collection Types
;;=============================================================================

;; Bench 6a: Large vector of heterogeneous maps — reduce over vec of product summaries
(defn bench-vec-of-maps [n]
  (println (str "    Building vec of " n " heterogeneous maps..."))
  (let [gen-item (fn [i]
                   {:id i
                    :type (nth [:product :user :event :metric] (mod i 4))
                    :value (* i 1.5)
                    :active (zero? (mod i 3))
                    :label (str "item-" i)
                    :tags [(keyword (str "t" (mod i 10)))
                           (keyword (str "g" (mod i 5)))]})
        stock-v (vec (map gen-item (range n)))
        stock (bench (fn []
                       (reduce (fn [acc item]
                                 (if (:active item)
                                   (+ acc (:value item))
                                   acc))
                               0.0 stock-v))
                     :iters 100 :warmup 20)]
    (fresh-env!)
    (let [sab-v (reduce conj (sab-vec/empty-sab-vec) (map gen-item (range n)))
          sab (bench (fn []
                       (reduce (fn [acc item]
                                 (if (:active item)
                                   (+ acc (:value item))
                                   acc))
                               0.0 sab-v))
                     :iters 100 :warmup 20)]
      (record! :mixed "vec-of-maps active sum" n stock sab))))

;; Bench 6b: Map with set values — membership checks across entries
(defn bench-map-of-sets [n]
  (println (str "    Building map of " n " sets..."))
  (let [;; Each entry is a set of 10-20 integers
        gen-set (fn [i] (set (range i (+ i 10 (mod i 11)))))
        stock-m (loop [m {} i 0]
                  (if (>= i n) m
                      (recur (assoc m (keyword (str "s" i)) (gen-set i)) (inc i))))
        ;; Check: how many sets contain the value 50?
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k s]
                          (if (contains? s 50)
                            (inc acc)
                            acc))
                        0 stock-m))
                     :iters 200 :warmup 40)]
    (fresh-env!)
    (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                  (if (>= i n) m
                      (recur (assoc m (keyword (str "s" i)) (gen-set i)) (inc i))))
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k s]
                          (if (contains? s 50)
                            (inc acc)
                            acc))
                        0 sab-m))
                     :iters 200 :warmup 40)]
      (record! :mixed "map-of-sets membership scan" n stock sab))))

;; Bench 6c: Atom swap workflow — multi-step transform (deref → compute → swap!)
(defn bench-atom-workflow [map-size]
  (println (str "    Setting up atom with " map-size "-entry map for workflow..."))
  (let [data (loop [m {} i 0]
               (if (>= i map-size) m
                   (recur (assoc m (keyword (str "k" i))
                                 {:count (mod (* i 7) 100)
                                  :total (* i 2.5)
                                  :label (str "item-" i)})
                          (inc i))))
        ;; Stock: deref + reduce-kv to find max + swap to increment it
        stock-a (cljs.core/atom data)
        stock (bench (fn []
                       (let [s @stock-a
                             max-entry (reduce-kv
                                        (fn [best _k v]
                                          (if (> (:count v) (:count best))
                                            v best))
                                        {:count -1} s)]
                         ;; Swap: increment the max count entry's count
                         ;; (find it again by value — realistic read-compute-write)
                         (swap! stock-a
                                (fn [m]
                                  (reduce-kv
                                   (fn [acc k v]
                                     (if (= (:count v) (:count max-entry))
                                       (assoc acc k (update v :count inc))
                                       acc))
                                   m m)))))
                     :iters 30 :warmup 5)]
    (fresh-env!)
    (reset! a/*global-atom-instance* data)
    (let [sab (bench (fn []
                       (let [s @a/*global-atom-instance*
                             max-entry (reduce-kv
                                        (fn [best _k v]
                                          (if (> (:count v) (:count best))
                                            v best))
                                        {:count -1} s)]
                         (swap! a/*global-atom-instance*
                                (fn [m]
                                  (reduce-kv
                                   (fn [acc k v]
                                     (if (= (:count v) (:count max-entry))
                                       (assoc acc k (update v :count inc))
                                       acc))
                                   m m)))))
                     :iters 30 :warmup 5)]
      (record! :mixed "atom: read-compute-write cycle" map-size stock sab))))

;;=============================================================================
;; Output
;;=============================================================================

(defn print-results []
  (let [results @*results*
        sep   "  +----------------------------------------------+------+-----------------+-----------------+--------------+"
        hdr   "  | Scenario                                     |    n |      Stock      |       SAB       |    Ratio     |"]
    (println sep)
    (println hdr)
    (println sep)
    (let [groups (group-by :domain results)]
      (doseq [domain [:catalog :stream :config :social :metrics :mixed]]
        (when-let [entries (get groups domain)]
          (doseq [{:keys [scenario n stock sab ratio]} entries]
            (let [op-str (str (name domain) ": " scenario)
                  op-str (if (> (count op-str) 44) (subs op-str 0 44) op-str)
                  stock-str (str (fmt-us (:mean-us stock)) " " (fmt-ops (:ops-s stock)) "/s")
                  sab-str (str (fmt-us (:mean-us sab)) " " (fmt-ops (:ops-s sab)) "/s")
                  ratio-str (if (>= ratio 1)
                              (str (.toFixed ratio 1) "x faster")
                              (str (.toFixed (/ 1 ratio) 1) "x slower"))]
              (println (str "  | "
                            (.padEnd op-str 44)
                            " | " (pad n 4)
                            " | " (pad stock-str 15)
                            " | " (pad sab-str 15)
                            " | " (pad ratio-str 12) " |"))))
          (println sep))))))

(defn print-summary-stats []
  (let [results @*results*
        ratios (map :ratio results)
        n (count ratios)
        sorted-ratios (sort ratios)
        faster (count (filter #(>= % 1.0) ratios))
        slower (count (filter #(< % 1.0) ratios))
        geo-mean (js/Math.exp (/ (reduce + 0 (map #(js/Math.log %) ratios)) n))
        median (nth sorted-ratios (quot n 2))
        best (last sorted-ratios)
        worst (first sorted-ratios)]
    (println "\n  === Summary Statistics ===\n")
    (println (str "  Total scenarios: " n))
    (println (str "  SAB faster: " faster " (" (.toFixed (/ (* faster 100) n) 0) "%)"))
    (println (str "  SAB slower: " slower " (" (.toFixed (/ (* slower 100) n) 0) "%)"))
    (println (str "  Geometric mean ratio: " (.toFixed geo-mean 2) "x"))
    (println (str "  Median ratio: " (.toFixed median 2) "x"))
    (println (str "  Best ratio: " (.toFixed best 1) "x faster"))
    (println (str "  Worst ratio: "
                  (if (< worst 1)
                    (str (.toFixed (/ 1 worst) 1) "x slower")
                    (str (.toFixed worst 1) "x faster"))))))

(defn print-domain-summary []
  (println "\n  === Per-Domain Summary ===\n")
  (let [results @*results*
        groups (group-by :domain results)]
    (doseq [domain [:catalog :stream :config :social :metrics :mixed]]
      (when-let [entries (get groups domain)]
        (let [ratios (map :ratio entries)
              n (count ratios)
              geo-mean (js/Math.exp (/ (reduce + 0 (map #(js/Math.log %) ratios)) n))
              faster (count (filter #(>= % 1.0) ratios))]
          (println (str "  " (.padEnd (name domain) 10)
                        " — " n " scenarios, "
                        "geo-mean: " (.toFixed geo-mean 2) "x, "
                        faster "/" n " SAB-faster")))))))

;;=============================================================================
;; Main
;;=============================================================================

(defn run-benchmarks []
  (reset! *results* [])

  (println "\n================================================================================")
  (println "  EVE SAB vs Stock CLJS — Wild Data Benchmark")
  (println "  5 domains, heterogeneous data, diverse transformations")
  (println "  (Data pre-built per scenario; only transform time measured)")
  (println "================================================================================\n")

  ;; --- Domain 1: E-Commerce Catalog ---
  (println "  [Domain 1/5] E-Commerce Catalog (2000 products)\n")
  (bench-catalog-revenue CATALOG-SIZE)
  (bench-catalog-category-count CATALOG-SIZE)
  (bench-catalog-margin CATALOG-SIZE)
  (bench-catalog-deep-access CATALOG-SIZE 100)
  (bench-catalog-deep-access CATALOG-SIZE 300)
  (bench-catalog-batch-update CATALOG-SIZE 200)

  ;; --- Domain 2: Activity Stream ---
  (println "\n  [Domain 2/5] Activity Stream (5000 events)\n")
  (bench-stream-purchase-revenue STREAM-SIZE)
  (bench-stream-user-action-count STREAM-SIZE)
  (bench-stream-device-breakdown STREAM-SIZE)
  (bench-stream-pipeline STREAM-SIZE)

  ;; --- Domain 3: Config Tree ---
  (println "\n  [Domain 3/5] Configuration Tree (deep nesting)\n")
  (bench-config-deep-reads 200)
  (bench-config-deep-reads 500)
  (bench-config-service-scan)
  (bench-config-user-permissions)

  ;; --- Domain 4: Social Profiles ---
  (println "\n  [Domain 4/5] Social Profiles (1000 users)\n")
  (bench-social-total-likes SOCIAL-SIZE)
  (bench-social-verified-influencers SOCIAL-SIZE)
  (bench-social-friend-lookup SOCIAL-SIZE 50)
  (bench-social-friend-lookup SOCIAL-SIZE 100)
  (bench-social-privacy-scan SOCIAL-SIZE)

  ;; --- Domain 5: Metrics Dashboard ---
  (println "\n  [Domain 5/5] Metrics Dashboard (3000 points)\n")
  (bench-metrics-cpu-avg METRICS-SIZE)
  (bench-metrics-error-hotspots METRICS-SIZE)
  (bench-metrics-latency-summary METRICS-SIZE)
  (bench-metrics-region-tier METRICS-SIZE)

  ;; --- Cross-Domain: Mixed Collection Types ---
  (println "\n  [Bonus] Mixed Collection Types\n")
  (bench-vec-of-maps 2000)
  (bench-map-of-sets 500)
  (bench-atom-workflow 500)

  ;; --- Output ---
  (println "\n  === Full Results ===\n")
  (print-results)
  (print-summary-stats)
  (print-domain-summary)

  (println "\n  Legend: Stock = standard CLJS persistent structures")
  (println "         SAB   = EVE SharedArrayBuffer-backed structures")
  (println "         All data pre-built before measurement (build cost excluded)")
  (println "         Ratio > 1 = SAB faster; < 1 = SAB slower")
  (println "\n================================================================================"))

(defn ^:export run-wild-data-benchmark []
  (run-benchmarks))

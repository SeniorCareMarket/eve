(ns com.seniorcaremarket.eve-sab-deftype.sab-pointer-benchmark
  "Benchmark: SAB pointer encoding for nested collections.

   Measures the performance of SAB pointer encoding where nested collections
   are encoded as 7-byte SAB pointers (O(1) decode).

   Key insight: SAB encode builds a real tree in SAB memory,
   but SAB decode is O(1) pointer read — constant time regardless of size."
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]))

;; Match unit test atom size (4MB, 16384 blocks)
(def _init-atom
  (let [large-atom (atom/private-atom {} :sab-size (* 4 1024 1024)
                                         :max-blocks 16384)]
    (set! atom/*global-atom-instance* large-atom)
    large-atom))

;;-----------------------------------------------------------------------------
;; Helpers
;;-----------------------------------------------------------------------------

(defn now-ms [] (js/performance.now))

(defn bench
  "Run f warmup times, then iters times. Returns {:mean-us :total-ms :iters :ops-sec}."
  [f & {:keys [warmup iters] :or {warmup 3 iters 100}}]
  (dotimes [_ warmup] (f))
  (let [start (now-ms)]
    (dotimes [_ iters] (f))
    (let [elapsed (- (now-ms) start)
          mean-ms (/ elapsed iters)
          mean-us (* mean-ms 1000)]
      {:mean-us mean-us :total-ms elapsed :iters iters
       :ops-sec (if (pos? mean-ms) (/ 1000 mean-ms) 0)})))

(defn fmt-us [us]
  (if (< us 1)
    (str (.toFixed (* us 1000) 0) "ns")
    (if (< us 1000)
      (str (.toFixed us 2) "us")
      (str (.toFixed (/ us 1000) 2) "ms"))))

(defn fmt-ops [ops]
  (cond
    (>= ops 1000000) (str (.toFixed (/ ops 1000000) 2) "M ops/s")
    (>= ops 1000) (str (.toFixed (/ ops 1000) 1) "K ops/s")
    :else (str (.toFixed ops 0) " ops/s")))

(defn print-row [label result & [extra]]
  (println (str "  " label ": "
                (fmt-us (:mean-us result)) " mean, "
                (fmt-ops (:ops-sec result))
                (when extra (str " " extra)))))

;;-----------------------------------------------------------------------------
;; Benchmark 1: Encode/decode performance
;;-----------------------------------------------------------------------------

(defn run-encode-decode-benchmark []
  (println "\n--- Benchmark 1: Encode/Decode {:a 1 :b 2 :c 3} ---")
  (println "  (SAB pointer: builds SabMap tree in SAB memory, O(1) decode)\n")

  (let [test-map {:a 1 :b 2 :c 3}
        s-atom-env (atom/get-env atom/*global-atom-instance*)

        ;; SAB pointer (encode = build SabMap + encode pointer)
        sab-enc (bench #(ser/serialize-val test-map) :iters 200)
        sab-bytes (ser/serialize-val test-map)
        ;; SAB decode = just read 4-byte offset, wrap in constructor
        sab-dec (bench #(ser/deserialize-element s-atom-env sab-bytes) :iters 10000)]

    (print-row "SAB ptr  encode" sab-enc (str "[" (.-length sab-bytes) " bytes]"))
    (print-row "SAB ptr  decode" sab-dec)
    (println (str "\n  Encoding size: " (.-length sab-bytes) " bytes (constant 7-byte pointer)"))))

;;-----------------------------------------------------------------------------
;; Benchmark 2: Decode-only at various sizes
;;-----------------------------------------------------------------------------

(defn run-decode-benchmark []
  (println "\n--- Benchmark 2: Decode performance at various map sizes ---")
  (println "  (SAB decode is always O(1) regardless of size)\n")

  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)]
    (println "  Size   | SAB decode       | SAB bytes")
    (println "  -------+------------------+----------")

    (doseq [n [3 5 10 20 50]]
      (let [test-map (into {} (map (fn [i] [(keyword (str "k" i)) i]) (range n)))
            sab-bytes (ser/serialize-val test-map)
            sab-dec (bench #(ser/deserialize-element s-atom-env sab-bytes) :iters 10000)]
        (println (str "  n=" (if (< n 10) (str " " n) n)
                      "   | " (fmt-us (:mean-us sab-dec))
                      (apply str (repeat (- 17 (count (fmt-us (:mean-us sab-dec)))) " "))
                      "| " (.-length sab-bytes)))))))

;;-----------------------------------------------------------------------------
;; Benchmark 3: End-to-end store/retrieve in SabMap
;;-----------------------------------------------------------------------------

(defn run-end-to-end-benchmark []
  (println "\n--- Benchmark 3: End-to-end store/retrieve nested map in SabMap ---\n")

  (let [nested {:host "localhost" :port 8080 :timeout 5000}

        ;; Store CLJS map as SabMap value
        store (bench #(assoc (sm/empty-sab-map) :config nested) :iters 100)

        ;; Pre-build parent for retrieval tests
        parent (assoc (sm/empty-sab-map) :config nested)

        ;; Retrieve: get nested SabMap
        retrieve (bench #(get parent :config) :iters 5000)

        ;; Drill: get nested -> access field
        drill (bench #(get (get parent :config) :host) :iters 5000)]

    (print-row "Store CLJS map as value" store "(builds SabMap + assoc)")
    (print-row "Retrieve nested value  " retrieve "(deserialize 7-byte pointer)")
    (print-row "Drill: config->host    " drill "(deser pointer + HAMT lookup)")))

;;-----------------------------------------------------------------------------
;; Benchmark 4: Pre-built SabMap as value (no conversion overhead)
;;-----------------------------------------------------------------------------

(defn run-prebuilt-sab-benchmark []
  (println "\n--- Benchmark 4: Pre-built SabMap stored as value (pure pointer) ---\n")

  (let [inner (sm/sab-map :x 1 :y 2 :z 3)

        store (bench #(assoc (sm/empty-sab-map) :inner inner) :iters 500)
        parent (assoc (sm/empty-sab-map) :inner inner)

        retrieve (bench #(get parent :inner) :iters 10000)
        drill (bench #(get (get parent :inner) :x) :iters 5000)]

    (print-row "Store pre-built SabMap " store "(7-byte encode + assoc)")
    (print-row "Retrieve SabMap value  " retrieve "(7-byte decode)")
    (print-row "Drill: inner->:x       " drill "(decode + HAMT lookup)")
    (println (str "\n  Encoding size: " (.-length (ser/serialize-val inner)) " bytes"))))

;;-----------------------------------------------------------------------------
;; Benchmark 5: Deep nesting (3 levels)
;;-----------------------------------------------------------------------------

(defn run-deep-nesting-benchmark []
  (println "\n--- Benchmark 5: 3-level deep nesting ---\n")

  (let [deep {:db {:host "localhost" :options {:timeout 5000 :retries 3}}
              :cache {:enabled true}}
        s-atom-env (atom/get-env atom/*global-atom-instance*)

        sab-bytes (ser/serialize-val deep)
        sab-enc (bench #(ser/serialize-val deep) :iters 50)
        sab-dec (bench #(ser/deserialize-element s-atom-env sab-bytes) :iters 10000)

        ;; End-to-end drill
        parent (assoc (sm/empty-sab-map) :cfg deep)
        drill (bench #(get (get (get (get parent :cfg) :db) :options) :timeout) :iters 2000)]

    (print-row "SAB encode (3 levels)  " sab-enc (str "[" (.-length sab-bytes) " bytes]"))
    (print-row "SAB decode             " sab-dec)
    (println)
    (print-row "Drill cfg->db->opts->timeout" drill)
    (println (str "  Value: " (get (get (get (get parent :cfg) :db) :options) :timeout)))))

;;-----------------------------------------------------------------------------
;; Benchmark 6: Other collection types
;;-----------------------------------------------------------------------------

(defn run-other-types-benchmark []
  (println "\n--- Benchmark 6: Vector and Set as nested values ---\n")

  ;; Vector
  (let [v [1 2 3 4 5]
        parent (assoc (sm/empty-sab-map) :items v)
        store (bench #(assoc (sm/empty-sab-map) :items v) :iters 100)
        retrieve (bench #(nth (get parent :items) 2) :iters 5000)]
    (print-row "Store CLJS vec [1..5]  " store)
    (print-row "Retrieve + nth(2)      " retrieve)
    (println (str "  Value: " (nth (get parent :items) 2))))

  (println)

  ;; Set
  (let [s #{:a :b :c :d :e}
        parent (assoc (sm/empty-sab-map) :tags s)
        store (bench #(assoc (sm/empty-sab-map) :tags s) :iters 100)
        retrieve (bench #(contains? (get parent :tags) :c) :iters 5000)]
    (print-row "Store CLJS set #{..}   " store)
    (print-row "Retrieve + contains? :c" retrieve)
    (println (str "  Value: " (contains? (get parent :tags) :c)))))

;;-----------------------------------------------------------------------------
;; Main
;;-----------------------------------------------------------------------------

(defn run-sab-pointer-benchmark []
  (println "\n================================================================================")
  (println "  SAB POINTER ENCODING BENCHMARK")
  (println "  SAB pointer encoding: O(1) decode for nested collections")
  (println "================================================================================")

  (run-encode-decode-benchmark)
  (run-decode-benchmark)
  (run-end-to-end-benchmark)
  (run-prebuilt-sab-benchmark)
  (run-deep-nesting-benchmark)
  (run-other-types-benchmark)

  (println "\n================================================================================")
  (println "  SUMMARY")
  (println "  - Encode: Builds real persistent data structure in SAB memory")
  (println "  - Decode: O(1) pointer read (constant time regardless of collection size)")
  (println "  - Size: 7 bytes constant (SAB pointer)")
  (println "  - Nested access: Each level = one 7-byte decode + HAMT lookup")
  (println "  - The decode speedup compounds at every nesting level")
  (println "================================================================================"))

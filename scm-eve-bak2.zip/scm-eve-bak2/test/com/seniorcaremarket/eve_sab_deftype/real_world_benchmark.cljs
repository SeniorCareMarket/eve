(ns com.seniorcaremarket.eve-sab-deftype.real-world-benchmark
  "Real-world benchmark: large, heterogeneous data with read-heavy workloads.

   Tests the hypothesis that once data is IN the SAB, subsequent read operations
   approach parity with stock CLJS. Exercises realistic access patterns:
   full scans, filtered aggregations, random reads, nested access, mixed types."
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sab-vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as sab-set]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Infrastructure
;;-----------------------------------------------------------------------------

(defn now [] (js/performance.now))

(defn fresh-env! []
  (sab-map/reset-pools!)
  (sab-set/reset-pools!)
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 512 1024 1024) :max-blocks 524288))
  (sab-map/reset-pools!)
  (sab-set/reset-pools!))

(defn bench [f & {:keys [iters warmup] :or {iters 200 warmup 50}}]
  (dotimes [_ warmup] (f))
  (let [times (js/Float64Array. iters)]
    (dotimes [i iters]
      (let [start (now)]
        (f)
        (aset times i (- (now) start))))
    (let [sorted (doto (js/Array.from times) (.sort))
          sum (reduce + 0 (array-seq sorted))
          mean-ms (/ sum iters)
          median-ms (aget sorted (js/Math.floor (/ iters 2)))]
      {:mean-us (* mean-ms 1000)
       :median-us (* median-ms 1000)
       :ops-s (if (pos? mean-ms) (/ 1000 mean-ms) 0)})))

(defn fmt-us [us]
  (cond
    (< us 1) (str (.toFixed (* us 1000) 0) "ns")
    (< us 1000) (str (.toFixed us 2) "us")
    :else (str (.toFixed (/ us 1000) 2) "ms")))

(defn fmt-ops [ops]
  (cond
    (>= ops 1e6) (str (.toFixed (/ ops 1e6) 2) "M")
    (>= ops 1e3) (str (.toFixed (/ ops 1e3) 1) "K")
    :else (str (.toFixed ops 1) "")))

(defn pad [s n] (.padStart (str s) n))

(def ^:private *results* (atom []))

(defn record! [scenario operation n stock-result sab-result]
  (let [ratio (/ (:ops-s sab-result) (:ops-s stock-result))]
    (swap! *results* conj
           {:scenario scenario :operation operation :n n
            :stock stock-result :sab sab-result :ratio ratio})))

;;-----------------------------------------------------------------------------
;; Data Generators
;;-----------------------------------------------------------------------------

(def roles [:admin :user :moderator :viewer :editor])
(def categories [:electronics :clothing :food :tools :books :toys :sports :home])
(def statuses [:active :inactive :pending :suspended])

(defn gen-user-record
  "Generate a heterogeneous user record map (stock CLJS)."
  [i]
  {:id i
   :name (str "User-" i)
   :email (str "user" i "@example.com")
   :age (+ 18 (mod (* i 7) 62))
   :active (zero? (mod i 3))
   :role (nth roles (mod i (count roles)))
   :score (* i 1.5)
   :tags [(keyword (str "tag-" (mod i 10))) (keyword (str "group-" (mod i 5)))]})

(defn gen-product-record [i]
  {:sku (str "SKU-" i)
   :name (str "Product-" i)
   :price (+ 0.99 (* (mod (* i 13) 100) 0.97))
   :category (nth categories (mod i (count categories)))
   :stock (mod (* i 17) 1000)
   :active (zero? (mod i 4))})

;;-----------------------------------------------------------------------------
;; Build helpers — build once, measure reads
;;-----------------------------------------------------------------------------

(defn build-stock-map
  "Build a stock CLJS map of n entries with keyword keys."
  [n gen-fn]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "r" i)) (gen-fn i)) (inc i)))))

(defn build-sab-map
  "Build a SAB map of n entries with keyword keys."
  [n gen-fn]
  (loop [m (sab-map/empty-sab-map) i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "r" i)) (gen-fn i)) (inc i)))))

(defn build-stock-flat-map
  "Build a stock CLJS map of n entries, keyword -> integer."
  [n]
  (loop [m {} i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "k" i)) (* i 3)) (inc i)))))

(defn build-sab-flat-map
  "Build a SAB map of n entries, keyword -> integer."
  [n]
  (loop [m (sab-map/empty-sab-map) i 0]
    (if (>= i n) m
        (recur (assoc m (keyword (str "k" i)) (* i 3)) (inc i)))))

(defn build-stock-vec [n]
  (vec (range n)))

(defn build-sab-vec [n]
  (reduce conj (sab-vec/empty-sab-vec) (range n)))

(defn build-stock-set [n]
  (set (range n)))

(defn build-sab-set [n]
  (reduce conj (sab-set/empty-sab-set) (range n)))

;;-----------------------------------------------------------------------------
;; Pre-generate random access keys (avoid measuring key generation)
;;-----------------------------------------------------------------------------

(defn random-keys
  "Generate an array of k random keyword keys from :r0..:r(n-1)."
  [n k]
  (let [arr (make-array k)]
    (dotimes [i k]
      (aset arr i (keyword (str "r" (mod (js/Math.abs (bit-xor (* i 2654435761) (bit-shift-right (* i 40503) 4))) n)))))
    arr))

(defn random-int-keys
  "Generate an array of k random keyword keys from :k0..:k(n-1)."
  [n k]
  (let [arr (make-array k)]
    (dotimes [i k]
      (aset arr i (keyword (str "k" (mod (js/Math.abs (bit-xor (* i 2654435761) (bit-shift-right (* i 40503) 4))) n)))))
    arr))

;;-----------------------------------------------------------------------------
;; Scenarios
;;-----------------------------------------------------------------------------

;; Scenario 1: Random reads from a large flat map (pre-built)
(defn bench-random-reads [n num-reads]
  (println (str "    Building n=" n " flat maps..."))
  (let [stock-m (build-stock-flat-map n)
        keys-arr (random-int-keys n num-reads)
        stock (bench (fn []
                       (dotimes [i num-reads]
                         (get stock-m (aget keys-arr i))))
                     :iters 500 :warmup 100)]
    (fresh-env!)
    (let [sab-m (build-sab-flat-map n)
          sab (bench (fn []
                       (dotimes [i num-reads]
                         (get sab-m (aget keys-arr i))))
                     :iters 500 :warmup 100)]
      (record! :random-read (str num-reads " gets from n=" n) n stock sab))))

;; Scenario 2: Full scan reduce-kv (sum all values)
(defn bench-reduce-kv-sum [n]
  (println (str "    Building n=" n " maps for reduce-kv sum..."))
  (let [stock-m (build-stock-flat-map n)
        stock (bench (fn []
                       (reduce-kv (fn [acc _k v] (+ acc v)) 0 stock-m))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-m (build-sab-flat-map n)
          sab (bench (fn []
                       (reduce-kv (fn [acc _k v] (+ acc v)) 0 sab-m))
                     :iters 300 :warmup 50)]
      (record! :full-scan "reduce-kv sum" n stock sab))))

;; Scenario 2b: WASM fast-path numeric sum (no JS deserialization)
(defn bench-wasm-sum [n]
  (println (str "    Building n=" n " maps for WASM sum..."))
  (let [stock-m (build-stock-flat-map n)
        stock (bench (fn []
                       (reduce-kv (fn [acc _k v] (+ acc v)) 0 stock-m))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-m (build-sab-flat-map n)
          sab (bench (fn []
                       (or (sab-map/sab-map-sum-values sab-m)
                           (reduce-kv (fn [acc _k v] (+ acc v)) 0 sab-m)))
                     :iters 300 :warmup 50)]
      (record! :full-scan "WASM sum" n stock sab))))

;; Scenario 3: Filtered reduce-kv (count entries > threshold)
(defn bench-reduce-kv-filter [n]
  (println (str "    Building n=" n " maps for filtered reduce-kv..."))
  (let [threshold (* n 2) ;; roughly half will be above
        stock-m (build-stock-flat-map n)
        stock (bench (fn []
                       (reduce-kv (fn [acc _k v] (if (> v threshold) (inc acc) acc))
                                  0 stock-m))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-m (build-sab-flat-map n)
          sab (bench (fn []
                       (reduce-kv (fn [acc _k v] (if (> v threshold) (inc acc) acc))
                                  0 sab-m))
                     :iters 300 :warmup 50)]
      (record! :filtered-scan "reduce-kv count>thresh" n stock sab))))

;; Scenario 4: Map of records — lookup + nested field access
(defn bench-record-field-access [n num-lookups]
  (println (str "    Building n=" n " record maps..."))
  (let [stock-m (build-stock-map n gen-user-record)
        keys-arr (random-keys n num-lookups)
        stock (bench (fn []
                       (dotimes [i num-lookups]
                         (let [record (get stock-m (aget keys-arr i))]
                           ;; Access 3 fields from the nested record
                           (when record
                             (:age record)
                             (:name record)
                             (:role record)))))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-m (build-sab-map n gen-user-record)
          sab (bench (fn []
                       (dotimes [i num-lookups]
                         (let [record (get sab-m (aget keys-arr i))]
                           (when record
                             (:age record)
                             (:name record)
                             (:role record)))))
                     :iters 300 :warmup 50)]
      (record! :record-access (str num-lookups " record lookups+fields") n stock sab))))

;; Scenario 5: Full scan over records — aggregate with predicate
(defn bench-record-scan [n]
  (println (str "    Building n=" n " record maps for scanning..."))
  (let [stock-m (build-stock-map n gen-user-record)
        stock (bench (fn []
                       (reduce-kv
                        (fn [acc _k record]
                          (if (:active record)
                            (+ acc (:score record))
                            acc))
                        0.0 stock-m))
                     :iters 200 :warmup 30)]
    (fresh-env!)
    (let [sab-m (build-sab-map n gen-user-record)
          sab (bench (fn []
                       (reduce-kv
                        (fn [acc _k record]
                          (if (:active record)
                            (+ acc (:score record))
                            acc))
                        0.0 sab-m))
                     :iters 200 :warmup 30)]
      (record! :record-scan "sum active scores" n stock sab))))

;; Scenario 6: Large vector reduce (sum)
(defn bench-vec-reduce [n]
  (println (str "    Building n=" n " vectors..."))
  (let [stock-v (build-stock-vec n)
        stock (bench (fn [] (reduce + 0 stock-v))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-v (build-sab-vec n)
          sab (bench (fn [] (reduce + 0 sab-v))
                     :iters 300 :warmup 50)]
      (record! :vec-reduce "reduce + sum" n stock sab))))

;; Scenario 7: Large vector random nth (pre-built)
(defn bench-vec-random-nth [n num-reads]
  (println (str "    Building n=" n " vectors for random nth..."))
  (let [stock-v (build-stock-vec n)
        indices (let [arr (js/Int32Array. num-reads)]
                  (dotimes [i num-reads]
                    (aset arr i (mod (js/Math.abs (bit-xor (* i 2654435761) 12345)) n)))
                  arr)
        stock (bench (fn []
                       (dotimes [i num-reads]
                         (nth stock-v (aget indices i))))
                     :iters 500 :warmup 100)]
    (fresh-env!)
    (let [sab-v (build-sab-vec n)
          sab (bench (fn []
                       (dotimes [i num-reads]
                         (nth sab-v (aget indices i))))
                     :iters 500 :warmup 100)]
      (record! :vec-random-nth (str num-reads " random nth") n stock sab))))

;; Scenario 8: Large set membership batch check
(defn bench-set-membership [n num-checks]
  (println (str "    Building n=" n " sets..."))
  (let [stock-s (build-stock-set n)
        ;; Mix of hits and misses
        check-vals (let [arr (js/Int32Array. num-checks)]
                     (dotimes [i num-checks]
                       (aset arr i (mod (js/Math.abs (bit-xor (* i 2654435761) 99999)) (* n 2))))
                     arr)
        stock (bench (fn []
                       (dotimes [i num-checks]
                         (contains? stock-s (aget check-vals i))))
                     :iters 500 :warmup 100)]
    (fresh-env!)
    (let [sab-s (build-sab-set n)
          sab (bench (fn []
                       (dotimes [i num-checks]
                         (contains? sab-s (aget check-vals i))))
                     :iters 500 :warmup 100)]
      (record! :set-membership (str num-checks " contains? (hit+miss)") n stock sab))))

;; Scenario 9: Selective update — N assocs on a pre-built large map
(defn bench-selective-update [map-size num-updates]
  (println (str "    Building n=" map-size " maps for selective update..."))
  (let [update-keys (random-int-keys map-size num-updates)
        stock-m (build-stock-flat-map map-size)
        stock (bench (fn []
                       (loop [m stock-m i 0]
                         (if (>= i num-updates) m
                             (recur (assoc m (aget update-keys i) 999) (inc i)))))
                     :iters 300 :warmup 50)]
    (fresh-env!)
    (let [sab-m (build-sab-flat-map map-size)
          sab (bench (fn []
                       (loop [m sab-m i 0]
                         (if (>= i num-updates) m
                             (recur (assoc m (aget update-keys i) 999) (inc i)))))
                     :iters 300 :warmup 50)]
      (record! :selective-update (str num-updates " assocs on n=" map-size) map-size stock sab))))

;; Scenario 10: Atom read-heavy workload (simulated render cycle)
;; deref + read 10 keys + 2 nested get-ins
(defn bench-render-cycle [map-size]
  (println (str "    Setting up atom with n=" map-size " map for render cycle..."))
  (let [flat-data (build-stock-flat-map map-size)
        stock-data (assoc flat-data
                         :config {:theme "dark" :lang "en" :debug false}
                         :user {:name "Alice" :role :admin :age 32})
        read-keys (random-int-keys map-size 10)
        stock-a (cljs.core/atom stock-data)
        stock (bench (fn []
                       (let [s @stock-a]
                         ;; 10 key reads
                         (dotimes [i 10]
                           (get s (aget read-keys i)))
                         ;; 2 nested reads
                         (get-in s [:config :theme])
                         (get-in s [:user :role])))
                     :iters 1000 :warmup 200)]
    (fresh-env!)
    (reset! a/*global-atom-instance* stock-data)
    (let [sab (bench (fn []
                       (let [s @a/*global-atom-instance*]
                         (dotimes [i 10]
                           (get s (aget read-keys i)))
                         (get-in s [:config :theme])
                         (get-in s [:user :role])))
                     :iters 1000 :warmup 200)]
      (record! :render-cycle "deref+10gets+2get-ins" map-size stock sab))))

;; Scenario 11: Seq pipeline — keys + count through filter
(defn bench-seq-pipeline [n]
  (println (str "    Building n=" n " maps for seq pipeline..."))
  (let [threshold (* n 2)
        stock-m (build-stock-flat-map n)
        stock (bench (fn []
                       (count (filter (fn [[_k v]] (> v threshold)) stock-m)))
                     :iters 200 :warmup 30)]
    (fresh-env!)
    (let [sab-m (build-sab-flat-map n)
          sab (bench (fn []
                       (count (filter (fn [[_k v]] (> v threshold)) sab-m)))
                     :iters 200 :warmup 30)]
      (record! :seq-pipeline "filter+count" n stock sab))))

;; Scenario 12: Mixed-type map — heterogeneous values, full iteration
(defn bench-mixed-type-scan [n]
  (println (str "    Building n=" n " mixed-type maps..."))
  (let [gen-val (fn [i]
                  (case (mod i 5)
                    0 i
                    1 (str "val-" i)
                    2 (keyword (str "kw-" i))
                    3 (* i 2.718)
                    4 (zero? (mod i 7))))
        stock-m (loop [m {} i 0]
                  (if (>= i n) m
                      (recur (assoc m (keyword (str "k" i)) (gen-val i)) (inc i))))
        stock (bench (fn []
                       (reduce-kv (fn [acc _k v]
                                    (if (number? v) (+ acc v) acc))
                                  0 stock-m))
                     :iters 200 :warmup 30)]
    (fresh-env!)
    (let [sab-m (loop [m (sab-map/empty-sab-map) i 0]
                  (if (>= i n) m
                      (let [val-i (gen-val i)]
                        (recur (assoc m (keyword (str "k" i)) val-i) (inc i)))))
          sab (bench (fn []
                       (reduce-kv (fn [acc _k v]
                                    (if (number? v) (+ acc v) acc))
                                  0 sab-m))
                     :iters 200 :warmup 30)]
      (record! :mixed-type "reduce-kv sum numbers" n stock sab))))

;;-----------------------------------------------------------------------------
;; Output
;;-----------------------------------------------------------------------------

(defn print-results []
  (let [results @*results*
        sep   "  +------------------------------------------+------+-----------------+-----------------+--------------+"
        hdr   "  | Scenario                                 |    n |      Stock      |       SAB       |    Ratio     |"]
    (println sep)
    (println hdr)
    (println sep)
    (doseq [{:keys [scenario operation n stock sab ratio]} results]
      (let [scene-str (name scenario)
            op-str (str scene-str ": " operation)
            ;; Truncate to 40 chars
            op-str (if (> (count op-str) 40) (subs op-str 0 40) op-str)
            stock-str (str (fmt-us (:mean-us stock)) " " (fmt-ops (:ops-s stock)) "/s")
            sab-str (str (fmt-us (:mean-us sab)) " " (fmt-ops (:ops-s sab)) "/s")
            ratio-str (if (>= ratio 1)
                        (str (.toFixed ratio 1) "x faster")
                        (str (.toFixed (/ 1 ratio) 1) "x slower"))]
        (println (str "  | "
                      (.padEnd op-str 40)
                      " | " (pad n 4)
                      " | " (pad stock-str 15)
                      " | " (pad sab-str 15)
                      " | " (pad ratio-str 12) " |"))))
    (println sep)))

(defn print-per-element-analysis []
  (println "\n  --- Per-Element Cost Analysis ---")
  (println "  (Mean latency / n = amortized per-element overhead)\n")
  (let [sep "  +------------------------------------------+------+-----------+-----------+---------+"
        hdr "  | Scenario                                 |    n |  Stock/el |   SAB/el  | Ratio   |"]
    (println sep)
    (println hdr)
    (println sep)
    (doseq [{:keys [scenario operation n stock sab]} @*results*
            :when (#{:full-scan :filtered-scan :record-scan :vec-reduce
                     :mixed-type :seq-pipeline} scenario)]
      (let [stock-per-el (/ (:mean-us stock) n)
            sab-per-el (/ (:mean-us sab) n)
            ratio (/ sab-per-el stock-per-el)
            op-str (str (name scenario) ": " operation)
            op-str (if (> (count op-str) 40) (subs op-str 0 40) op-str)]
        (println (str "  | "
                      (.padEnd op-str 40)
                      " | " (pad n 4)
                      " | " (pad (fmt-us stock-per-el) 9)
                      " | " (pad (fmt-us sab-per-el) 9)
                      " | " (pad (str (.toFixed ratio 1) "x") 7) " |"))))
    (println sep)))

;;-----------------------------------------------------------------------------
;; Main
;;-----------------------------------------------------------------------------

(defn run-benchmarks []
  (reset! *results* [])

  (println "\n================================================================================")
  (println "  EVE SAB vs Stock CLJS — Real-World Benchmark")
  (println "  Large, heterogeneous data with read-heavy workloads")
  (println "  (Data pre-built, only read/iteration time measured)")
  (println "================================================================================\n")

  ;; --- Random reads from pre-built maps ---
  (println "  [1/13] Random reads from large flat map...")
  (bench-random-reads 1000 50)
  (bench-random-reads 1000 200)
  (bench-random-reads 5000 200)

  ;; --- Full scan reduce-kv ---
  (println "  [2/13] Full-scan reduce-kv (sum all values)...")
  (bench-reduce-kv-sum 1000)
  (bench-reduce-kv-sum 5000)

  ;; --- WASM fast-path sum ---
  (println "  [3/13] WASM fast-path numeric sum...")
  (bench-wasm-sum 1000)
  (bench-wasm-sum 5000)

  ;; --- Filtered scan ---
  (println "  [4/13] Filtered reduce-kv (count > threshold)...")
  (bench-reduce-kv-filter 1000)
  (bench-reduce-kv-filter 5000)

  ;; --- Record access ---
  (println "  [5/13] Record lookup + field access (heterogeneous records)...")
  (bench-record-field-access 500 50)
  (bench-record-field-access 1000 100)

  ;; --- Record scan ---
  (println "  [6/13] Full scan over records (sum active scores)...")
  (bench-record-scan 500)
  (bench-record-scan 1000)

  ;; --- Vector reduce ---
  (println "  [7/13] Vector reduce (sum)...")
  (bench-vec-reduce 1000)
  (bench-vec-reduce 5000)

  ;; --- Vector random nth ---
  (println "  [8/13] Vector random nth (pre-built)...")
  (bench-vec-random-nth 1000 100)
  (bench-vec-random-nth 5000 200)

  ;; --- Set membership ---
  (println "  [9/13] Set membership batch (hit+miss)...")
  (bench-set-membership 1000 200)
  (bench-set-membership 5000 200)

  ;; --- Selective update ---
  (println "  [10/13] Selective update (N assocs on large map)...")
  (bench-selective-update 1000 10)
  (bench-selective-update 1000 50)

  ;; --- Render cycle ---
  (println "  [11/13] Atom render cycle (deref + multi-read)...")
  (bench-render-cycle 100)
  (bench-render-cycle 500)

  ;; --- Seq pipeline ---
  (println "  [12/13] Seq pipeline (filter + count)...")
  (bench-seq-pipeline 1000)
  (bench-seq-pipeline 5000)

  ;; --- Mixed-type scan ---
  (println "  [13/13] Mixed-type map scan (sum only numbers)...")
  (bench-mixed-type-scan 1000)
  (bench-mixed-type-scan 5000)

  ;; --- Output ---
  (println "\n  === Results ===\n")
  (print-results)
  (print-per-element-analysis)

  (println "\n  Legend: Stock = standard CLJS persistent structures")
  (println "         SAB   = EVE SharedArrayBuffer-backed structures")
  (println "         All data pre-built before measurement (build cost excluded)")
  (println "         Ratio > 1 = SAB faster; < 1 = SAB slower")
  (println "\n================================================================================"))

(defn ^:export run-real-world-benchmark []
  (run-benchmarks))

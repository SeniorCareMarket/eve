(ns com.seniorcaremarket.eve-sab-deftype.sab-map-test
  (:require
   [cljs.test :refer-macros [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]))

;;-----------------------------------------------------------------------------
;; Setup
;;-----------------------------------------------------------------------------

(def _init-atom
  (let [large-atom (atom/private-atom {} :sab-size (* 4 1024 1024)
                                         :max-blocks 16384)]
    (set! atom/*global-atom-instance* large-atom)
    large-atom))

;;-----------------------------------------------------------------------------
;; Basic Operations
;;-----------------------------------------------------------------------------

(deftest empty-map-test
  (testing "Empty map"
    (let [m (sm/empty-sab-map)]
      (is (= 0 (count m)))
      (is (nil? (get m 1)))
      (is (nil? (seq m))))))

(deftest assoc-test
  (testing "Assoc single entry"
    (let [m (assoc (sm/empty-sab-map) 1 100)]
      (is (= 1 (count m)))
      (is (= 100 (get m 1)))
      (is (nil? (get m 2)))))

  (testing "Assoc multiple entries"
    (let [m (-> (sm/empty-sab-map)
                (assoc 1 100)
                (assoc 2 200)
                (assoc 3 300))]
      (is (= 3 (count m)))
      (is (= 100 (get m 1)))
      (is (= 200 (get m 2)))
      (is (= 300 (get m 3)))))

  (testing "Assoc update existing key"
    (let [m1 (assoc (sm/empty-sab-map) 1 100)
          m2 (assoc m1 1 999)]
      (is (= 1 (count m2)))
      (is (= 999 (get m2 1))))))

(deftest sab-map-constructor-test
  (testing "sab-map from kvs"
    (let [m (sm/sab-map 1 10 2 20 3 30)]
      (is (= 3 (count m)))
      (is (= 10 (get m 1)))
      (is (= 20 (get m 2)))
      (is (= 30 (get m 3)))))

  (testing "into-sab-map from entries"
    (let [m (sm/into-sab-map [[1 10] [2 20] [3 30]])]
      (is (= 3 (count m)))
      (is (= 10 (get m 1)))
      (is (= 20 (get m 2)))
      (is (= 30 (get m 3))))))

;;-----------------------------------------------------------------------------
;; Lookup
;;-----------------------------------------------------------------------------

(deftest lookup-test
  (testing "Get with not-found"
    (let [m (sm/sab-map 1 10 2 20)]
      (is (= 10 (get m 1 :nf)))
      (is (= :nf (get m 99 :nf)))))

  (testing "IFn invoke"
    (let [m (sm/sab-map 1 10 2 20)]
      (is (= 10 (m 1)))
      (is (= 20 (m 2)))
      (is (nil? (m 99)))
      (is (= :nf (m 99 :nf)))))

  (testing "Contains key"
    (let [m (sm/sab-map 1 10 2 20)]
      (is (contains? m 1))
      (is (contains? m 2))
      (is (not (contains? m 99))))))

;;-----------------------------------------------------------------------------
;; Dissoc
;;-----------------------------------------------------------------------------

(deftest dissoc-test
  (testing "Dissoc existing key"
    (let [m (sm/sab-map 1 10 2 20 3 30)
          m' (dissoc m 2)]
      (is (= 2 (count m')))
      (is (= 10 (get m' 1)))
      (is (nil? (get m' 2)))
      (is (= 30 (get m' 3)))))

  (testing "Dissoc non-existing key"
    (let [m (sm/sab-map 1 10 2 20)
          m' (dissoc m 99)]
      (is (= 2 (count m')))
      (is (= 10 (get m' 1)))
      (is (= 20 (get m' 2)))))

  (testing "Dissoc to empty"
    (let [m (sm/sab-map 1 10)
          m' (dissoc m 1)]
      (is (= 0 (count m')))))

  (testing "Dissoc all entries"
    (let [m (sm/sab-map 1 10 2 20 3 30)
          m' (-> m (dissoc 1) (dissoc 2) (dissoc 3))]
      (is (= 0 (count m'))))))

;;-----------------------------------------------------------------------------
;; Seq Operations
;;-----------------------------------------------------------------------------

(deftest seq-test
  (testing "Seq on non-empty map"
    (let [m (sm/sab-map 1 10 2 20 3 30)
          entries (seq m)]
      (is (= 3 (count entries)))
      ;; Order may not be preserved, so check contents
      (is (= #{[1 10] [2 20] [3 30]}
             (set entries)))))

  (testing "Seq on empty map"
    (let [m (sm/empty-sab-map)]
      (is (nil? (seq m))))))

;;-----------------------------------------------------------------------------
;; Reduce
;;-----------------------------------------------------------------------------

(deftest reduce-test
  (testing "Reduce with initial value"
    (let [m (sm/sab-map 1 10 2 20 3 30)]
      (is (= 60 (reduce (fn [acc [k v]] (+ acc v)) 0 m)))))

  (testing "Reduce sum of keys"
    (let [m (sm/sab-map 1 10 2 20 3 30)]
      (is (= 6 (reduce (fn [acc [k v]] (+ acc k)) 0 m)))))

  (testing "Reduce on empty"
    (let [m (sm/empty-sab-map)]
      (is (= 0 (reduce (fn [acc [k v]] (+ acc v)) 0 m))))))

;;-----------------------------------------------------------------------------
;; Equality
;;-----------------------------------------------------------------------------

(deftest equality-test
  (testing "Equal maps"
    (let [m1 (sm/sab-map 1 10 2 20)
          m2 (sm/sab-map 1 10 2 20)]
      (is (= m1 m2))))

  (testing "Unequal maps - different values"
    (let [m1 (sm/sab-map 1 10 2 20)
          m2 (sm/sab-map 1 10 2 99)]
      (is (not= m1 m2))))

  (testing "Unequal maps - different keys"
    (let [m1 (sm/sab-map 1 10 2 20)
          m2 (sm/sab-map 1 10 3 30)]
      (is (not= m1 m2))))

  (testing "Unequal maps - different count"
    (let [m1 (sm/sab-map 1 10 2 20)
          m2 (sm/sab-map 1 10)]
      (is (not= m1 m2)))))

;;-----------------------------------------------------------------------------
;; Large Map
;;-----------------------------------------------------------------------------

(deftest large-map-test
  (testing "Build and query large map"
    (let [n 100
          m (reduce (fn [m i] (assoc m i (* i 10)))
                    (sm/empty-sab-map)
                    (range n))]
      (is (= n (count m)))
      (is (= 0 (get m 0)))
      (is (= 500 (get m 50)))
      (is (= 990 (get m 99)))))
  (testing "Build and query large maps at various sizes"
    (doseq [n [200 500]]
      (let [m (reduce (fn [m i] (assoc m i (* i i)))
                      (sm/empty-sab-map)
                      (range n))]
        (is (= n (count m)) (str "Count mismatch for n=" n))
        (doseq [i (range n)]
          (is (= (* i i) (get m i)) (str "Lookup failed for key " i " in map n=" n))))))
  (testing "Dissoc from large map"
    (let [n 200
          m (reduce (fn [m i] (assoc m i (* i i)))
                    (sm/empty-sab-map)
                    (range n))
          m2 (reduce (fn [m i] (dissoc m i)) m (range 100))]
      (is (= 100 (count m2)))
      (doseq [i (range 100 200)]
        (is (= (* i i) (get m2 i)) (str "Lookup failed after dissoc for key " i)))))
  (testing "Transient build large map"
    (doseq [n [100 200]]
      (let [m (persistent!
                (reduce (fn [m i] (assoc! m i (* i i)))
                        (transient (sm/empty-sab-map))
                        (range n)))]
        (is (= n (count m)) (str "Transient count mismatch for n=" n))))))

;;-----------------------------------------------------------------------------
;; Persistence
;;-----------------------------------------------------------------------------

(deftest persistence-test
  (testing "Assoc preserves original"
    (let [m1 (sm/sab-map 1 10 2 20)
          m2 (assoc m1 3 30)]
      (is (= 2 (count m1)))
      (is (= 3 (count m2)))
      (is (nil? (get m1 3)))
      (is (= 30 (get m2 3)))))

  (testing "Dissoc preserves original"
    (let [m1 (sm/sab-map 1 10 2 20 3 30)
          m2 (dissoc m1 2)]
      (is (= 3 (count m1)))
      (is (= 2 (count m2)))
      (is (= 20 (get m1 2)))
      (is (nil? (get m2 2)))))

  (testing "Update preserves original"
    (let [m1 (sm/sab-map 1 10)
          m2 (assoc m1 1 999)]
      (is (= 10 (get m1 1)))
      (is (= 999 (get m2 1))))))

;;-----------------------------------------------------------------------------
;; Hash Collision (same hash, different keys)
;;-----------------------------------------------------------------------------

(deftest collision-test
  (testing "Keys with potential hash collisions"
    ;; These keys might have collisions depending on hash function
    (let [keys-vals (for [i (range 20)] [i (* i 10)])
          m (reduce (fn [m [k v]] (assoc m k v))
                    (sm/empty-sab-map)
                    keys-vals)]
      (is (= 20 (count m)))
      (doseq [[k v] keys-vals]
        (is (= v (get m k)))))))

;;-----------------------------------------------------------------------------
;; SAB Pointer Encoding — Nested SAB Types as Values
;;-----------------------------------------------------------------------------

(deftest nested-sab-map-value-test
  (testing "Store a SabMap as value in another SabMap"
    (let [inner (sm/sab-map :x 1 :y 2)
          outer (assoc (sm/empty-sab-map) :child inner)]
      (is (= 1 (count outer)))
      (let [retrieved (get outer :child)]
        (is (some? retrieved))
        (is (= 2 (count retrieved)))
        (is (= 1 (get retrieved :x)))
        (is (= 2 (get retrieved :y)))))))

(deftest nested-sab-vec-value-test
  (testing "Store a SabVec as value in a SabMap"
    (let [v (sv/sab-vec [10 20 30])
          m (assoc (sm/empty-sab-map) :items v)]
      (is (= 1 (count m)))
      (let [retrieved (get m :items)]
        (is (some? retrieved))
        (is (= 3 (count retrieved)))
        (is (= 10 (nth retrieved 0)))
        (is (= 20 (nth retrieved 1)))
        (is (= 30 (nth retrieved 2)))))))

(deftest nested-sab-set-value-test
  (testing "Store a SabSet as value in a SabMap"
    (let [s (ss/sab-set 1 2 3)
          m (assoc (sm/empty-sab-map) :tags s)]
      (is (= 1 (count m)))
      (let [retrieved (get m :tags)]
        (is (some? retrieved))
        (is (= 3 (count retrieved)))
        (is (contains? retrieved 1))
        (is (contains? retrieved 2))
        (is (contains? retrieved 3))))))

(deftest nested-sab-list-value-test
  (testing "Store a SabList as value in a SabMap"
    (let [l (sl/sab-list [10 20 30])
          m (assoc (sm/empty-sab-map) :history l)]
      (is (= 1 (count m)))
      (let [retrieved (get m :history)]
        (is (some? retrieved))
        (is (= 3 (count retrieved)))
        (is (= 10 (first retrieved)))))))

;;-----------------------------------------------------------------------------
;; CLJS Collection Auto-Conversion
;;-----------------------------------------------------------------------------

(deftest cljs-map-auto-conversion-test
  (testing "CLJS map auto-converts to SabMap when stored as value"
    (let [m (assoc (sm/empty-sab-map) :config {:host "localhost" :port 8080})]
      (is (= 1 (count m)))
      (let [config (get m :config)]
        (is (some? config))
        (is (satisfies? d/IDirectSerialize config))
        (is (= 2 (count config)))
        (is (= "localhost" (get config :host)))
        (is (= 8080 (get config :port)))))))

(deftest cljs-vector-auto-conversion-test
  (testing "CLJS vector auto-converts to SabVec when stored as value"
    (let [m (assoc (sm/empty-sab-map) :items [1 2 3])]
      (is (= 1 (count m)))
      (let [items (get m :items)]
        (is (some? items))
        (is (satisfies? d/IDirectSerialize items))
        (is (= 3 (count items)))
        (is (= 1 (nth items 0)))
        (is (= 2 (nth items 1)))
        (is (= 3 (nth items 2)))))))

(deftest cljs-set-auto-conversion-test
  (testing "CLJS set auto-converts to SabSet when stored as value"
    (let [m (assoc (sm/empty-sab-map) :tags #{:a :b :c})]
      (is (= 1 (count m)))
      (let [tags (get m :tags)]
        (is (some? tags))
        (is (satisfies? d/IDirectSerialize tags))
        (is (= 3 (count tags)))
        (is (contains? tags :a))
        (is (contains? tags :b))
        (is (contains? tags :c))))))

(deftest deeply-nested-auto-conversion-test
  (testing "Deeply nested CLJS maps auto-convert recursively"
    (let [m (assoc (sm/empty-sab-map) :db {:host "localhost"
                                            :options {:timeout 5000}})]
      (is (= 1 (count m)))
      (let [db (get m :db)]
        (is (some? db))
        (is (= "localhost" (get db :host)))
        (let [opts (get db :options)]
          (is (some? opts))
          (is (= 5000 (get opts :timeout))))))))

(deftest sab-pointer-roundtrip-test
  (testing "SAB pointer encoding/decoding roundtrip"
    (let [inner (sm/sab-map :a 1)
          bytes (ser/serialize-val inner)
          s-atom-env (atom/get-env atom/*global-atom-instance*)
          decoded (ser/deserialize-element s-atom-env bytes)]
      (is (= 7 (.-length bytes)))
      (is (some? decoded))
      (is (= 1 (count decoded)))
      (is (= 1 (get decoded :a))))))

;;-----------------------------------------------------------------------------
;; Phase 3: Atom path with SAB pointer encoding
;;-----------------------------------------------------------------------------

(deftest atom-deref-returns-sab-map-test
  (testing "Atom deref returns a value that satisfies map?"
    (swap! atom/*global-atom-instance* assoc :test-key 42)
    (let [state @atom/*global-atom-instance*]
      (is (map? state))
      (is (= 42 (get state :test-key))))
    ;; Clean up
    (swap! atom/*global-atom-instance* dissoc :test-key)))

(deftest atom-swap-with-sab-map-test
  (testing "Atom swap works with SAB-encoded state"
    (swap! atom/*global-atom-instance* assoc :a 1 :b 2 :c 3)
    (let [state @atom/*global-atom-instance*]
      (is (= 1 (get state :a)))
      (is (= 2 (get state :b)))
      (is (= 3 (get state :c))))
    ;; Modify
    (swap! atom/*global-atom-instance* assoc :a 10)
    (is (= 10 (get @atom/*global-atom-instance* :a)))
    ;; Dissoc
    (swap! atom/*global-atom-instance* dissoc :b)
    (is (nil? (get @atom/*global-atom-instance* :b)))
    (is (= 10 (get @atom/*global-atom-instance* :a)))
    ;; Clean up
    (reset! atom/*global-atom-instance* {})))

(deftest atom-nested-collection-roundtrip-test
  (testing "Atom stores and retrieves nested collections via SAB pointers"
    (swap! atom/*global-atom-instance* assoc :config {:host "localhost" :port 5432})
    (let [state @atom/*global-atom-instance*
          config (get state :config)]
      (is (some? config))
      (is (= "localhost" (get config :host)))
      (is (= 5432 (get config :port))))
    ;; Clean up
    (reset! atom/*global-atom-instance* {})))

(deftest atom-reset-test
  (testing "Atom reset! works with fast-path encoding"
    (reset! atom/*global-atom-instance* {:x 1 :y 2})
    (let [state @atom/*global-atom-instance*]
      (is (= 1 (get state :x)))
      (is (= 2 (get state :y))))
    (reset! atom/*global-atom-instance* {})
    (is (= {} @atom/*global-atom-instance*))))

(deftest atom-sab-pointer-size-test
  (testing "Atom serializes maps as compact SAB pointers (7 bytes)"
    (let [ser-fn (fn [v] (ser/serialize-element v))
          ;; SabMap → 7-byte pointer
          sab-m (sm/sab-map :a 1)
          sab-bytes (ser-fn sab-m)
          ;; CLJS map → auto-converted to SabMap → 7-byte pointer
          cljs-m {:a 1}
          cljs-bytes (ser-fn cljs-m)]
      (is (= 7 (.-length sab-bytes)) "SabMap encodes as 7-byte pointer")
      (is (= 7 (.-length cljs-bytes)) "CLJS map auto-converts to 7-byte SAB pointer"))))

(deftest atom-isab-storable-protocol-test
  (testing "ISabStorable protocol is implemented on all SAB types"
    (let [m (sm/sab-map :a 1)
          s (ss/into-sab-set #{:a :b})
          v (sv/sab-vec [1 2 3])
          l (sl/sab-list '(1 2 3))]
      (is (satisfies? d/ISabStorable m) "SabMapRoot satisfies ISabStorable")
      (is (satisfies? d/ISabStorable s) "SabSetRoot satisfies ISabStorable")
      (is (satisfies? d/ISabStorable v) "SabVecRoot satisfies ISabStorable")
      (is (satisfies? d/ISabStorable l) "SabList satisfies ISabStorable")
      ;; Tags
      (is (= :sab-map (d/-sab-tag m)))
      (is (= :sab-set (d/-sab-tag s)))
      (is (= :sab-vec (d/-sab-tag v)))
      (is (= :sab-list (d/-sab-tag l)))
      ;; Encode returns 7 bytes
      (is (= 7 (.-length (d/-sab-encode m nil))))
      (is (= 7 (.-length (d/-sab-encode s nil))))
      (is (= 7 (.-length (d/-sab-encode v nil))))
      (is (= 7 (.-length (d/-sab-encode l nil)))))))

;;-----------------------------------------------------------------------------
;; Phase 2: Records as Tagged Maps
;;-----------------------------------------------------------------------------

(defrecord TestPerson [name age active])

(defrecord TestConfig [host port])

;; Register record types for roundtrip (3-arity: ctor, tag-str, map-fn)
(ser/register-record-type!
 TestPerson
 "com.seniorcaremarket.eve-sab-deftype.sab-map-test/TestPerson"
 map->TestPerson)

(ser/register-record-type!
 TestConfig
 "com.seniorcaremarket.eve-sab-deftype.sab-map-test/TestConfig"
 map->TestConfig)

(deftest record-registration-test
  (testing "Record type registration works with constructor identity"
    (let [r (->TestPerson "Alice" 30 true)]
      (is (record? r) "TestPerson is a record")
      (is (identical? TestPerson (type r)) "type returns the constructor"))))

(deftest record-serialize-roundtrip-test
  (testing "Record serializes as 7-byte FAST_TAG_RECORD pointer"
    (let [r (->TestPerson "Alice" 30 true)
          bytes (ser/serialize-element r)]
      (is (= 7 (.-length bytes)) "Record encodes as 7-byte pointer")
      (is (= 0xEE (aget bytes 0)) "Magic byte 0")
      (is (= 0xDB (aget bytes 1)) "Magic byte 1")
      (is (= 0x1A (aget bytes 2)) "FAST_TAG_RECORD tag")))

  (testing "Record roundtrip preserves type and fields"
    (let [r (->TestPerson "Alice" 30 true)
          bytes (ser/serialize-element r)
          s-atom-env (atom/get-env atom/*global-atom-instance*)
          decoded (ser/deserialize-element s-atom-env bytes)]
      (is (instance? TestPerson decoded) "Decoded value is a TestPerson record")
      (is (= "Alice" (:name decoded)))
      (is (= 30 (:age decoded)))
      (is (= true (:active decoded)))))

  (testing "Different record types roundtrip correctly"
    (let [cfg (->TestConfig "localhost" 5432)
          bytes (ser/serialize-element cfg)
          s-atom-env (atom/get-env atom/*global-atom-instance*)
          decoded (ser/deserialize-element s-atom-env bytes)]
      (is (instance? TestConfig decoded) "Decoded value is a TestConfig record")
      (is (= "localhost" (:host decoded)))
      (is (= 5432 (:port decoded))))))

(deftest record-as-map-value-test
  (testing "Record stored as value in SabMap is retrievable"
    (let [r (->TestPerson "Bob" 25 false)
          m (assoc (sm/empty-sab-map) :user r)]
      (is (= 1 (count m)))
      ;; The SabMap deserializes values on get. Since the record is stored as a
      ;; FAST_TAG_RECORD pointer, get returns a reconstructed record (if registered)
      ;; or a SabMap (graceful degradation).
      (let [retrieved (get m :user)]
        (is (some? retrieved))
        ;; The retrieved value should be a reconstructed TestPerson record
        (is (instance? TestPerson retrieved) "Record reconstructed from SabMap value")
        (is (= "Bob" (:name retrieved)))
        (is (= 25 (:age retrieved)))
        (is (= false (:active retrieved)))))))

(deftest record-graceful-degradation-test
  (testing "Unregistered record degrades to SabMap"
    ;; Create a record type without registering it
    (let [;; Encode a map that looks like a record with a bogus tag
          fake-tag "com.fake.ns/UnknownRecord"
          tagged-map (sm/into-sab-map [[:name "Test"] [:eve/record-tag fake-tag]])
          ;; Get the direct-serialize bytes and change tag to RECORD
          bytes (d/-direct-serialize tagged-map)]
      (aset bytes 2 0x1A)  ;; FAST_TAG_RECORD
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            decoded (ser/deserialize-element s-atom-env bytes)]
        ;; Should degrade to a SabMap since "com.fake.ns/UnknownRecord" is not registered
        (is (some? decoded) "Decoded value is not nil")
        (is (not (instance? TestPerson decoded)) "Not a TestPerson")
        (is (= "Test" (get decoded :name)) "Field values preserved")
        (is (= fake-tag (get decoded :eve/record-tag)) "Tag key preserved in degraded map")))))

(deftest no-op-transient-roundtrip-test
  (testing "persistent! on unmodified transient returns original map"
    (let [m (sm/into-sab-map [[:a 1] [:b 2] [:c 3]])]
      (is (identical? m (persistent! (transient m)))
          "No-op transient round-trip returns identical map")))

  (testing "persistent! on modified transient returns new map"
    (let [m (sm/into-sab-map [[:a 1] [:b 2]])]
      (is (not (identical? m (persistent! (assoc! (transient m) :c 3))))
          "Modified transient returns different map")))

  (testing "identical? enables fast-path in atom swap"
    (let [m (sm/into-sab-map [[:a 1] [:b 2]])
          ;; Simulate swap where function returns transient round-trip
          result (-> m transient persistent!)]
      (is (identical? m result)
          "Atom swap can detect no-op via identical?"))))

(deftest wasm-sum-values-test
  (testing "WASM sum on integer-valued map"
    (let [m (sm/sab-map 1 10 2 20 3 30)]
      (is (= 60 (sm/sab-map-sum-values m)))))

  (testing "WASM sum on larger map"
    (let [m (reduce (fn [acc i] (assoc acc (keyword (str "k" i)) i))
                    (sm/empty-sab-map)
                    (range 200))
          expected (reduce + (range 200))]
      (is (= expected (sm/sab-map-sum-values m)))))

  (testing "WASM sum on float-valued map"
    (let [m (sm/sab-map :a 1.5 :b 2.5 :c 3.0)]
      (is (= 7.0 (sm/sab-map-sum-values m)))))

  (testing "WASM sum returns nil for non-numeric values"
    (let [m (sm/sab-map :a "hello" :b 10)]
      (is (nil? (sm/sab-map-sum-values m)))))

  (testing "WASM sum on empty map returns nil"
    (is (nil? (sm/sab-map-sum-values (sm/empty-sab-map))))))

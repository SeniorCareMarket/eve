(ns com.seniorcaremarket.eve-sab-deftype.sab-list-test
  (:require
   [cljs.test :refer-macros [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]))

;;-----------------------------------------------------------------------------
;; Setup
;;-----------------------------------------------------------------------------

(def _init-atom
  (let [large-atom (atom/private-atom {} :sab-size (* 4 1024 1024)
                                         :max-blocks 16384)]
    (set! atom/*global-atom-instance* large-atom)
    large-atom))

;;-----------------------------------------------------------------------------
;; Basic Operations
;;-----------------------------------------------------------------------------

(deftest empty-list-test
  (testing "Empty list"
    (let [l (sl/empty-sab-list)]
      (is (= 0 (count l)))
      (is (nil? (first l)))
      (is (nil? (seq l)))
      (is (nil? (peek l))))))

(deftest conj-test
  (testing "Conj single element"
    (let [l (conj (sl/empty-sab-list) 42)]
      (is (= 1 (count l)))
      (is (= 42 (first l)))
      (is (= 42 (peek l)))))

  (testing "Conj multiple elements (builds in reverse)"
    (let [l (-> (sl/empty-sab-list)
                (conj 1)
                (conj 2)
                (conj 3))]
      (is (= 3 (count l)))
      ;; Last conj'd is first (stack behavior)
      (is (= 3 (first l)))
      (is (= 2 (first (rest l))))
      (is (= 1 (first (rest (rest l))))))))

(deftest sab-list-constructor-test
  (testing "sab-list from collection preserves order"
    (let [l (sl/sab-list [1 2 3 4 5])]
      (is (= 5 (count l)))
      (is (= 1 (first l)))
      (is (= 2 (first (rest l))))
      (is (= [1 2 3 4 5] (vec l)))))

  (testing "into-sab-list reverses order"
    (let [l (sl/into-sab-list [1 2 3])]
      (is (= 3 (count l)))
      (is (= 3 (first l)))
      (is (= [3 2 1] (vec l))))))

;;-----------------------------------------------------------------------------
;; Sequence Operations
;;-----------------------------------------------------------------------------

(deftest first-rest-test
  (testing "first on non-empty"
    (let [l (sl/sab-list [10 20 30])]
      (is (= 10 (first l)))))

  (testing "rest returns tail"
    (let [l (sl/sab-list [10 20 30])
          r (rest l)]
      (is (= 2 (count r)))
      (is (= 20 (first r)))))

  (testing "rest on single element"
    (let [l (sl/sab-list [42])
          r (rest l)]
      (is (= 0 (count r)))
      (is (nil? (seq r)))))

  (testing "next on list"
    (let [l (sl/sab-list [1 2 3])]
      (is (= 2 (first (next l))))
      (is (nil? (next (sl/sab-list [1])))))))

;;-----------------------------------------------------------------------------
;; Stack Operations
;;-----------------------------------------------------------------------------

(deftest peek-pop-test
  (testing "peek returns first"
    (let [l (sl/sab-list [1 2 3])]
      (is (= 1 (peek l)))))

  (testing "pop removes first"
    (let [l (sl/sab-list [1 2 3])
          p (pop l)]
      (is (= 2 (count p)))
      (is (= 2 (first p)))))

  (testing "pop to empty"
    (let [l (sl/sab-list [42])
          p (pop l)]
      (is (= 0 (count p)))))

  (testing "pop empty throws"
    (is (thrown? js/Error (pop (sl/empty-sab-list))))))

;;-----------------------------------------------------------------------------
;; Indexed Access
;;-----------------------------------------------------------------------------

(deftest nth-test
  (testing "nth within bounds"
    (let [l (sl/sab-list (range 10))]
      (is (= 0 (nth l 0)))
      (is (= 5 (nth l 5)))
      (is (= 9 (nth l 9)))))

  (testing "nth with not-found"
    (let [l (sl/sab-list [1 2 3])]
      (is (= :nope (nth l 100 :nope)))
      (is (= :nope (nth l -1 :nope)))))

  (testing "nth as function call"
    (let [l (sl/sab-list [10 20 30])]
      (is (= 10 (l 0)))
      (is (= 30 (l 2))))))

;;-----------------------------------------------------------------------------
;; Reduce
;;-----------------------------------------------------------------------------

(deftest reduce-test
  (testing "Reduce with initial value"
    (let [l (sl/sab-list [1 2 3 4 5])]
      (is (= 15 (reduce + 0 l)))))

  (testing "Reduce without initial value"
    (let [l (sl/sab-list [1 2 3 4 5])]
      (is (= 15 (reduce + l)))))

  (testing "Reduce on empty"
    (let [l (sl/empty-sab-list)]
      (is (= 0 (reduce + 0 l)))
      (is (= 0 (reduce + l))))))

;;-----------------------------------------------------------------------------
;; Equality
;;-----------------------------------------------------------------------------

(deftest equality-test
  (testing "Equal lists"
    (let [l1 (sl/sab-list [1 2 3])
          l2 (sl/sab-list [1 2 3])]
      (is (= l1 l2))))

  (testing "Unequal lists"
    (let [l1 (sl/sab-list [1 2 3])
          l2 (sl/sab-list [1 2 4])]
      (is (not= l1 l2))))

  (testing "Equal to regular list"
    (let [l1 (sl/sab-list [1 2 3])
          l2 '(1 2 3)]
      (is (= l1 l2))
      (is (= l2 l1))))

  (testing "Equal to vector (both sequential)"
    (let [l (sl/sab-list [1 2 3])
          v [1 2 3]]
      (is (= l v))
      (is (= v l)))))

;;-----------------------------------------------------------------------------
;; Large List
;;-----------------------------------------------------------------------------

(deftest large-list-test
  (testing "Build and traverse large list"
    (let [n 100
          l (sl/sab-list (range n))]
      (is (= n (count l)))
      (is (= 0 (first l)))
      (is (= (dec n) (nth l (dec n))))
      (is (= (reduce + (range n)) (reduce + 0 l))))))

(deftest persistence-test
  (testing "Conj preserves original"
    (let [l1 (sl/sab-list [1 2 3])
          l2 (conj l1 0)]
      (is (= 3 (count l1)))
      (is (= 4 (count l2)))
      (is (= 1 (first l1)))
      (is (= 0 (first l2)))))

  (testing "Pop preserves original"
    (let [l1 (sl/sab-list [1 2 3])
          l2 (pop l1)]
      (is (= 3 (count l1)))
      (is (= 2 (count l2)))
      (is (= 1 (first l1)))
      (is (= 2 (first l2))))))

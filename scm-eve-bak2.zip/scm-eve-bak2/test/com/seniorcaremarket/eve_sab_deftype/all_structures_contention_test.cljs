(ns com.seniorcaremarket.eve-sab-deftype.all-structures-contention-test
  "Comprehensive multi-worker contention test for all SAB-backed data structures.

   Tests sab-vec, sab-list, sab-map, and sab-set under heavy concurrent access.
   Multiple workers perform CAS-loop operations on shared root slots simultaneously."
  (:require
   [cljs.test :refer [deftest is testing async run-tests]]
   [clojure.set :as set]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as sv]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as sl]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as ss]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Environment setup
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize the global atom with SAB for contention tests."
  []
  ;; Use 32MB SAB with 128K block descriptors - HAMT structures with CAS retries
  ;; allocate a lot of memory due to wasted allocations on failed CAS
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 32 1024 1024) :max-blocks 131072))
  (a/get-env a/*global-atom-instance*))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

;;-----------------------------------------------------------------------------
;; Root slot allocation
;;-----------------------------------------------------------------------------

(defn alloc-root-slot!
  "Allocate an atomic Int32 root pointer slot. Returns int32 index."
  [env]
  (let [alloc-result (a/alloc env 8)
        _ (when (:error alloc-result)
            (throw (js/Error. (str "Root slot alloc failed: " (:error alloc-result)))))
        byte-offset (:offset alloc-result)
        aligned-offset (let [rem (mod byte-offset 4)]
                         (if (zero? rem) byte-offset (+ byte-offset (- 4 rem))))
        int32-idx (unsigned-bit-shift-right aligned-offset 2)
        int32-view (js/Int32Array. (:sab env))]
    (js/Atomics.store int32-view int32-idx -1)
    int32-idx))

;;-----------------------------------------------------------------------------
;; Read helpers
;;-----------------------------------------------------------------------------

(defn read-vec [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sv/SabVecRoot. (:sab env) off))))

(defn read-list [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sl/SabList. (:sab env) off))))

(defn read-map [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (sm/SabMapRoot. (:sab env) off))))

(defn read-set [env int32-idx]
  (let [off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= off -1) (ss/SabSetRoot. (:sab env) off))))

;;-----------------------------------------------------------------------------
;; Worker dispatch - operates on all 4 data structures
;;-----------------------------------------------------------------------------

(defn dispatch-worker-all-structures!
  "Dispatch work to a worker that will operate on all 4 data structures."
  [worker vec-idx list-idx map-idx set-idx worker-id values-per-worker]
  (in worker [vec-idx list-idx map-idx set-idx worker-id values-per-worker]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          sab (:sab env)
          int32-view (js/Int32Array. sab)
          start-val (* worker-id values-per-worker)
          end-val (+ start-val values-per-worker)
          max-retries 2000]

      (println (str "  [W" worker-id "] Operating on all structures, values " start-val "-" (dec end-val)))
      (let [start-time (js/performance.now)]

        ;; Vector operations
        (loop [v start-val retries 0]
          (when (< v end-val)
            (if (> retries max-retries)
              (println (str "  [W" worker-id "] VEC: exceeded retries at " v))
              (let [old-off (js/Atomics.load int32-view vec-idx)
                    old-vec (when (not= old-off -1)
                              (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot. sab old-off))
                    new-vec (conj (or old-vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec)) v)
                    new-off (.-offset__ new-vec)]
                (if (== old-off (js/Atomics.compareExchange int32-view vec-idx old-off new-off))
                  (recur (inc v) 0)
                  (recur v (inc retries)))))))

        ;; List operations
        (loop [v start-val retries 0]
          (when (< v end-val)
            (if (> retries max-retries)
              (println (str "  [W" worker-id "] LIST: exceeded retries at " v))
              (let [old-off (js/Atomics.load int32-view list-idx)
                    old-list (when (not= old-off -1)
                               (com.seniorcaremarket.eve-sab-deftype.sab-list/SabList. sab old-off))
                    new-list (conj (or old-list (com.seniorcaremarket.eve-sab-deftype.sab-list/empty-sab-list)) v)
                    new-off (.-offset__ new-list)]
                (if (== old-off (js/Atomics.compareExchange int32-view list-idx old-off new-off))
                  (recur (inc v) 0)
                  (recur v (inc retries)))))))

        ;; Map operations (key = value, val = value * 10)
        (loop [v start-val retries 0]
          (when (< v end-val)
            (if (> retries max-retries)
              (println (str "  [W" worker-id "] MAP: exceeded retries at " v))
              (let [old-off (js/Atomics.load int32-view map-idx)
                    old-map (when (not= old-off -1)
                              (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off))
                    new-map (assoc (or old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/empty-sab-map)) v (* v 10))
                    new-off (.-offset__ new-map)]
                (if (== old-off (js/Atomics.compareExchange int32-view map-idx old-off new-off))
                  (recur (inc v) 0)
                  (recur v (inc retries)))))))

        ;; Set operations
        (loop [v start-val retries 0]
          (when (< v end-val)
            (if (> retries max-retries)
              (println (str "  [W" worker-id "] SET: exceeded retries at " v))
              (let [old-off (js/Atomics.load int32-view set-idx)
                    old-set (when (not= old-off -1)
                              (com.seniorcaremarket.eve-sab-deftype.sab-set/SabSetRoot. sab old-off))
                    new-set (conj (or old-set (com.seniorcaremarket.eve-sab-deftype.sab-set/empty-sab-set)) v)
                    new-off (.-offset__ new-set)]
                (if (== old-off (js/Atomics.compareExchange int32-view set-idx old-off new-off))
                  (recur (inc v) 0)
                  (recur v (inc retries)))))))

        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [W" worker-id "] Completed all ops in " (.toFixed elapsed 0) "ms")))))))

;;-----------------------------------------------------------------------------
;; Test 1: Parallel Write to All Structures
;;-----------------------------------------------------------------------------

(defn run-parallel-write-test
  "2 workers x 15 values = 30 values per structure"
  [next-fn]
  (println "\n  === Test 1: Parallel Write to All Structures ===")
  (println "  2 workers x 15 values = 30 values per structure")
  (let [env (init-env!)
        vec-idx (alloc-root-slot! env)
        list-idx (alloc-root-slot! env)
        map-idx (alloc-root-slot! env)
        set-idx (alloc-root-slot! env)
        num-workers 2
        values-per-worker 15
        total-values (* num-workers values-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (println "  Dispatching workers...")
    ;; Dispatch work to each worker with their ID (1, 2)
    (dispatch-worker-all-structures! (nth workers 0) vec-idx list-idx map-idx set-idx 1 values-per-worker)
    (dispatch-worker-all-structures! (nth workers 1) vec-idx list-idx map-idx set-idx 2 values-per-worker)

    ;; Wait for workers to complete
    (js/setTimeout
     (fn []
       (println "\n  Verifying results...")
       (let [final-vec (read-vec env vec-idx)
             final-list (read-list env list-idx)
             final-map (read-map env map-idx)
             final-set (read-set env set-idx)

             ;; Workers add values: 1*15..2*15-1, 2*15..3*15-1
             expected-values (set (range 15 45))  ;; 15-44 (workers 1-2 each add 15 values)

             vec-values (when final-vec (set (seq final-vec)))
             list-values (when final-list (set (seq final-list)))
             map-keys (when final-map (set (map first (seq final-map))))
             set-values (when final-set (set (seq final-set)))]

         (println (str "  VEC count:  " (if final-vec (count final-vec) "nil")
                       " (expected " total-values ")"))
         (println (str "  LIST count: " (if final-list (count final-list) "nil")
                       " (expected " total-values ")"))
         (println (str "  MAP count:  " (if final-map (count final-map) "nil")
                       " (expected " total-values ")"))
         (println (str "  SET count:  " (if final-set (count final-set) "nil")
                       " (expected " total-values ")"))

         ;; Check counts
         (let [vec-ok? (and final-vec (= (count final-vec) total-values) (= expected-values vec-values))
               list-ok? (and final-list (= (count final-list) total-values) (= expected-values list-values))
               map-ok? (and final-map (= (count final-map) total-values) (= expected-values map-keys))
               set-ok? (and final-set (= (count final-set) total-values) (= expected-values set-values))
               all-ok? (and vec-ok? list-ok? map-ok? set-ok?)]

           (println (str "\n  Results: VEC=" (if vec-ok? "PASS" "FAIL")
                         " LIST=" (if list-ok? "PASS" "FAIL")
                         " MAP=" (if map-ok? "PASS" "FAIL")
                         " SET=" (if set-ok? "PASS" "FAIL")))

           (when-not vec-ok?
             (println (str "    VEC missing: " (take 5 (set/difference expected-values (or vec-values #{}))))))
           (when-not list-ok?
             (println (str "    LIST missing: " (take 5 (set/difference expected-values (or list-values #{}))))))
           (when-not map-ok?
             (println (str "    MAP missing: " (take 5 (set/difference expected-values (or map-keys #{}))))))
           (when-not set-ok?
             (println (str "    SET missing: " (take 5 (set/difference expected-values (or set-values #{}))))))

           (cleanup-workers workers)
           (next-fn all-ok?))))
     20000)))  ;; 20 seconds for workers

;;-----------------------------------------------------------------------------
;; Test 2: Interleaved Operations (Maximum Contention)
;;-----------------------------------------------------------------------------

(defn dispatch-worker-interleaved!
  "Worker performs interleaved operations - touches all 4 structures per value."
  [worker vec-idx list-idx map-idx set-idx worker-id values-per-worker]
  (in worker [vec-idx list-idx map-idx set-idx worker-id values-per-worker]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          sab (:sab env)
          int32-view (js/Int32Array. sab)
          start-val (* worker-id values-per-worker)
          end-val (+ start-val values-per-worker)
          max-retries 2000]

      (println (str "  [W" worker-id "] INTERLEAVED ops, values " start-val "-" (dec end-val)))
      (let [start-time (js/performance.now)
            retries-total (atom 0)]

        (loop [v start-val]
          (when (< v end-val)
            ;; VEC
            (loop [retries 0]
              (when (< retries max-retries)
                (let [old-off (js/Atomics.load int32-view vec-idx)
                      old-vec (when (not= old-off -1)
                                (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot. sab old-off))
                      new-vec (conj (or old-vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec)) v)
                      new-off (.-offset__ new-vec)]
                  (when-not (== old-off (js/Atomics.compareExchange int32-view vec-idx old-off new-off))
                    (swap! retries-total inc)
                    (recur (inc retries))))))

            ;; LIST
            (loop [retries 0]
              (when (< retries max-retries)
                (let [old-off (js/Atomics.load int32-view list-idx)
                      old-list (when (not= old-off -1)
                                 (com.seniorcaremarket.eve-sab-deftype.sab-list/SabList. sab old-off))
                      new-list (conj (or old-list (com.seniorcaremarket.eve-sab-deftype.sab-list/empty-sab-list)) v)
                      new-off (.-offset__ new-list)]
                  (when-not (== old-off (js/Atomics.compareExchange int32-view list-idx old-off new-off))
                    (swap! retries-total inc)
                    (recur (inc retries))))))

            ;; MAP
            (loop [retries 0]
              (when (< retries max-retries)
                (let [old-off (js/Atomics.load int32-view map-idx)
                      old-map (when (not= old-off -1)
                                (com.seniorcaremarket.eve-sab-deftype.sab-map/SabMapRoot. sab old-off))
                      new-map (assoc (or old-map (com.seniorcaremarket.eve-sab-deftype.sab-map/empty-sab-map)) v (* v 10))
                      new-off (.-offset__ new-map)]
                  (when-not (== old-off (js/Atomics.compareExchange int32-view map-idx old-off new-off))
                    (swap! retries-total inc)
                    (recur (inc retries))))))

            ;; SET
            (loop [retries 0]
              (when (< retries max-retries)
                (let [old-off (js/Atomics.load int32-view set-idx)
                      old-set (when (not= old-off -1)
                                (com.seniorcaremarket.eve-sab-deftype.sab-set/SabSetRoot. sab old-off))
                      new-set (conj (or old-set (com.seniorcaremarket.eve-sab-deftype.sab-set/empty-sab-set)) v)
                      new-off (.-offset__ new-set)]
                  (when-not (== old-off (js/Atomics.compareExchange int32-view set-idx old-off new-off))
                    (swap! retries-total inc)
                    (recur (inc retries))))))

            (recur (inc v))))

        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [W" worker-id "] INTERLEAVED done in " (.toFixed elapsed 0) "ms "
                        "(total retries: " @retries-total ")")))))))

(defn run-interleaved-test
  "2 workers x 12 values, interleaved across structures"
  [next-fn]
  (println "\n  === Test 2: Interleaved Operations (Max Contention) ===")
  (println "  2 workers x 12 values, touching all structures each iteration")
  (let [env (init-env!)
        vec-idx (alloc-root-slot! env)
        list-idx (alloc-root-slot! env)
        map-idx (alloc-root-slot! env)
        set-idx (alloc-root-slot! env)
        num-workers 2
        values-per-worker 12
        total-values (* num-workers values-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (println "  Dispatching workers...")
    (dispatch-worker-interleaved! (nth workers 0) vec-idx list-idx map-idx set-idx 1 values-per-worker)
    (dispatch-worker-interleaved! (nth workers 1) vec-idx list-idx map-idx set-idx 2 values-per-worker)

    (js/setTimeout
     (fn []
       (println "\n  Verifying results...")
       (let [final-vec (read-vec env vec-idx)
             final-list (read-list env list-idx)
             final-map (read-map env map-idx)
             final-set (read-set env set-idx)

             expected-values (set (range 12 36))  ;; workers 1-2 each add 12 values

             vec-values (when final-vec (set (seq final-vec)))
             list-values (when final-list (set (seq final-list)))
             map-keys (when final-map (set (map first (seq final-map))))
             set-values (when final-set (set (seq final-set)))]

         (println (str "  VEC count:  " (if final-vec (count final-vec) "nil")))
         (println (str "  LIST count: " (if final-list (count final-list) "nil")))
         (println (str "  MAP count:  " (if final-map (count final-map) "nil")))
         (println (str "  SET count:  " (if final-set (count final-set) "nil")))

         (let [vec-ok? (and final-vec (= expected-values vec-values))
               list-ok? (and final-list (= expected-values list-values))
               map-ok? (and final-map (= expected-values map-keys))
               set-ok? (and final-set (= expected-values set-values))
               all-ok? (and vec-ok? list-ok? map-ok? set-ok?)]

           (println (str "\n  Results: VEC=" (if vec-ok? "PASS" "FAIL")
                         " LIST=" (if list-ok? "PASS" "FAIL")
                         " MAP=" (if map-ok? "PASS" "FAIL")
                         " SET=" (if set-ok? "PASS" "FAIL")))

           (cleanup-workers workers)
           (next-fn all-ok?))))
     20000)))

;;-----------------------------------------------------------------------------
;; Test 3: Stress test with more workers
;;-----------------------------------------------------------------------------

(defn run-stress-test
  "3 workers x 15 values for vec and set - high contention"
  [next-fn]
  (println "\n  === Test 3: Stress Test (3 workers x 15 values) ===")
  (let [env (init-env!)
        vec-idx (alloc-root-slot! env)
        set-idx (alloc-root-slot! env)
        num-workers 3
        values-per-worker 15
        total-values (* num-workers values-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (println "  Dispatching workers...")
    (doseq [i (range num-workers)]
      (let [worker-id (inc i)]
        (in (nth workers i) [vec-idx set-idx worker-id values-per-worker]
          (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                sab (:sab env)
                int32-view (js/Int32Array. sab)
                start-val (* worker-id values-per-worker)
                end-val (+ start-val values-per-worker)
                max-retries 2000]

            (println (str "  [W" worker-id "] Stress test " start-val "-" (dec end-val)))
            (let [start-time (js/performance.now)]

              ;; VEC ops
              (loop [v start-val retries 0]
                (when (< v end-val)
                  (if (> retries max-retries)
                    (println (str "  [W" worker-id "] VEC exceeded retries"))
                    (let [old-off (js/Atomics.load int32-view vec-idx)
                          old-vec (when (not= old-off -1)
                                    (com.seniorcaremarket.eve-sab-deftype.sab-vec/SabVecRoot. sab old-off))
                          new-vec (conj (or old-vec (com.seniorcaremarket.eve-sab-deftype.sab-vec/empty-sab-vec)) v)
                          new-off (.-offset__ new-vec)]
                      (if (== old-off (js/Atomics.compareExchange int32-view vec-idx old-off new-off))
                        (recur (inc v) 0)
                        (recur v (inc retries)))))))

              ;; SET ops
              (loop [v start-val retries 0]
                (when (< v end-val)
                  (if (> retries max-retries)
                    (println (str "  [W" worker-id "] SET exceeded retries"))
                    (let [old-off (js/Atomics.load int32-view set-idx)
                          old-set (when (not= old-off -1)
                                    (com.seniorcaremarket.eve-sab-deftype.sab-set/SabSetRoot. sab old-off))
                          new-set (conj (or old-set (com.seniorcaremarket.eve-sab-deftype.sab-set/empty-sab-set)) v)
                          new-off (.-offset__ new-set)]
                      (if (== old-off (js/Atomics.compareExchange int32-view set-idx old-off new-off))
                        (recur (inc v) 0)
                        (recur v (inc retries)))))))

              (let [elapsed (- (js/performance.now) start-time)]
                (println (str "  [W" worker-id "] done in " (.toFixed elapsed 0) "ms"))))))))

    (js/setTimeout
     (fn []
       (println "\n  Verifying results...")
       (let [final-vec (read-vec env vec-idx)
             final-set (read-set env set-idx)

             expected-values (set (range 15 60))  ;; workers 1-3 each add 15 values

             vec-count (if final-vec (count final-vec) 0)
             set-count (if final-set (count final-set) 0)

             vec-values (when final-vec (set (seq final-vec)))
             set-values (when final-set (set (seq final-set)))

             vec-ok? (= expected-values vec-values)
             set-ok? (= expected-values set-values)]

         (println (str "  VEC count:  " vec-count " (expected " total-values ")"))
         (println (str "  SET count:  " set-count " (expected " total-values ")"))

         (let [all-ok? (and vec-ok? set-ok?)]
           (println (str "\n  Results: VEC=" (if vec-ok? "PASS" "FAIL")
                         " SET=" (if set-ok? "PASS" "FAIL")))
           (cleanup-workers workers)
           (next-fn all-ok?))))
     20000)))

;;-----------------------------------------------------------------------------
;; cljs.test integration
;;-----------------------------------------------------------------------------

(deftest test-all-structures-parallel-write
  (async done
    (run-parallel-write-test
     (fn [passed?]
       (is passed? "Parallel write test should pass")
       (done)))))

(deftest test-all-structures-interleaved
  (async done
    (run-interleaved-test
     (fn [passed?]
       (is passed? "Interleaved test should pass")
       (done)))))

(deftest test-all-structures-stress
  (async done
    (run-stress-test
     (fn [passed?]
       (is passed? "Stress test should pass")
       (done)))))

;;-----------------------------------------------------------------------------
;; Main entry point
;;-----------------------------------------------------------------------------

(defn run-all-contention-tests
  "Run all contention tests sequentially."
  []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (println "\n========================================")
      (println "All Structures Contention Tests")
      (println "========================================")

      (run-parallel-write-test
       (fn [test1-passed?]
         (println (str "\n>> Test 1: " (if test1-passed? "PASSED" "FAILED")))

         (run-interleaved-test
          (fn [test2-passed?]
            (println (str "\n>> Test 2: " (if test2-passed? "PASSED" "FAILED")))

            (run-stress-test
             (fn [test3-passed?]
               (println (str "\n>> Test 3: " (if test3-passed? "PASSED" "FAILED")))

               (println "\n========================================")
               (println "Final Summary:")
               (println (str "  Test 1 (Parallel Write):    " (if test1-passed? "PASS" "FAIL")))
               (println (str "  Test 2 (Interleaved):       " (if test2-passed? "PASS" "FAIL")))
               (println (str "  Test 3 (Stress):            " (if test3-passed? "PASS" "FAIL")))
               (let [all-passed? (and test1-passed? test2-passed? test3-passed?)]
                 (println (str "\nOverall: " (if all-passed? "ALL TESTS PASSED!" "SOME TESTS FAILED")))
                 (println "========================================\n")))))))))))

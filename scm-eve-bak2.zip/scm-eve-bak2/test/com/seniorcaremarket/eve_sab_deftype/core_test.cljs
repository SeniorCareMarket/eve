(ns com.seniorcaremarket.eve-sab-deftype.core-test
  (:require
   [cljs.test :refer-macros [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom])
  (:require-macros
   [com.seniorcaremarket.eve-sab-deftype.core :refer [eve-sab-deftype eve-sab-extend-type]]))

;;-----------------------------------------------------------------------------
;; Setup
;;-----------------------------------------------------------------------------

;; Use 4MB SAB (shared across all sab-deftype tests)
(def _init-atom
  (when-not atom/*global-atom-instance*
    (atom/private-atom {} :sab-size (* 4 1024 1024)
                          :max-blocks 16384)))

;;-----------------------------------------------------------------------------
;; Simple Counter type
;;-----------------------------------------------------------------------------

(eve-sab-deftype Counter
  [^:mutable ^:int32 count
   ^:int32 initial]

  Object
  (toString [this] (str "#Counter{count=" count ", initial=" initial "}"))

  ICounted
  (-count [this] count))

(deftest counter-basic-test
  (testing "Create counter"
    (let [c (->Counter 10 10)]
      (is (= 10 (count c)))
      (is (= "#Counter{count=10, initial=10}" (.toString c))))))

(deftest counter-mutation-test
  (testing "Mutate counter via protocol"
    (let [c (->Counter 0 0)]
      (is (= 0 (count c))))))

;;-----------------------------------------------------------------------------
;; TreeNode with volatile fields for CAS
;;-----------------------------------------------------------------------------

(eve-sab-deftype TreeNode
  [^:int32 key
   ^:volatile-mutable ^:int32 left-offset
   ^:volatile-mutable ^:int32 right-offset]

  ILookup
  (-lookup [this k]
    (case k
      :key key
      :left left-offset
      :right right-offset
      nil))
  (-lookup [this k not-found]
    (case k
      :key key
      :left left-offset
      :right right-offset
      not-found)))

(deftest tree-node-creation-test
  (testing "Create tree node"
    (let [node (->TreeNode 42 -1 -1)]
      (is (= 42 (:key node)))
      (is (= -1 (:left node)))
      (is (= -1 (:right node))))))

(deftest tree-node-linking-test
  (testing "Link tree nodes via offsets"
    (let [child1 (->TreeNode 10 -1 -1)
          child2 (->TreeNode 20 -1 -1)
          parent (->TreeNode 15 (TreeNode-offset child1) (TreeNode-offset child2))]
      (is (= 15 (:key parent)))
      (is (= (TreeNode-offset child1) (:left parent)))
      (is (= (TreeNode-offset child2) (:right parent))))))

;;-----------------------------------------------------------------------------
;; Type with CAS operations
;;-----------------------------------------------------------------------------

(defprotocol ICASNode
  (-cas-left! [this expected new-offset])
  (-get-left [this])
  (-set-left! [this offset]))

(eve-sab-deftype CASNode
  [^:int32 value
   ^:volatile-mutable ^:int32 left]

  ICASNode
  (-cas-left! [this expected new-offset]
    (cas! left expected new-offset))
  (-get-left [this]
    left)
  (-set-left! [this offset]
    (set! left offset)
    offset))

(deftest cas-node-test
  (testing "CAS operations on volatile field"
    (let [node (->CASNode 100 -1)]
      ;; Initial value
      (is (= -1 (-get-left node)))
      ;; Set via set!
      (-set-left! node 42)
      (is (= 42 (-get-left node)))
      ;; CAS success
      (is (true? (-cas-left! node 42 99)))
      (is (= 99 (-get-left node)))
      ;; CAS failure
      (is (false? (-cas-left! node 42 100)))
      (is (= 99 (-get-left node))))))

;;-----------------------------------------------------------------------------
;; Multiple instances sharing SAB
;;-----------------------------------------------------------------------------

(deftest multiple-instances-test
  (testing "Multiple instances use same SAB"
    (let [n1 (->TreeNode 1 -1 -1)
          n2 (->TreeNode 2 -1 -1)
          n3 (->TreeNode 3 -1 -1)]
      ;; Same SAB
      (is (identical? (TreeNode-sab n1) (TreeNode-sab n2)))
      (is (identical? (TreeNode-sab n2) (TreeNode-sab n3)))
      ;; Different offsets
      (is (not= (TreeNode-offset n1) (TreeNode-offset n2)))
      (is (not= (TreeNode-offset n2) (TreeNode-offset n3)))
      ;; Values preserved
      (is (= 1 (:key n1)))
      (is (= 2 (:key n2)))
      (is (= 3 (:key n3))))))

;;-----------------------------------------------------------------------------
;; Equality and hashing
;;-----------------------------------------------------------------------------

(deftest equality-test
  (testing "Same offset = equal"
    (let [n1 (->TreeNode 42 -1 -1)
          ;; Create "alias" pointing to same offset
          n2 (TreeNode. (TreeNode-sab n1) (TreeNode-offset n1))]
      (is (= n1 n2))
      (is (= (hash n1) (hash n2)))))

  (testing "Different offsets = not equal"
    (let [n1 (->TreeNode 42 -1 -1)
          n2 (->TreeNode 42 -1 -1)]
      (is (not= n1 n2)))))

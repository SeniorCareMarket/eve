(ns com.seniorcaremarket.eve-sab-deftype.chunk-size-benchmark
  "Benchmark to test different vector/list chunk sizes: 32, 64, 128, 256, 512, 1024.

   This helps determine optimal chunk size for:
   - Different collection sizes (100, 1000, 10000)
   - Different operations (conj, nth, reduce, pop)
   - SIMD-friendly layouts

   Run with: npx shadow-cljs compile chunk-size-benchmark && node out/chunk-size-benchmark.js"
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as lst]))

;;-----------------------------------------------------------------------------
;; Configuration
;;-----------------------------------------------------------------------------

(def ^:const CHUNK_SIZES [32 64 128 256 512 1024])
;; Need 2000+ to test 1024-element chunks properly (at least 2 chunks)
;; Keeping sizes smaller to complete benchmark - investigate allocator issue separately
(def ^:const COLLECTION_SIZES [500 1500])
(def ^:const WARMUP_REPS 1)
(def ^:const BENCH_REPS 2)

;;-----------------------------------------------------------------------------
;; Environment setup
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize with large SAB for benchmark.
   Using smaller max-blocks to reduce initialization overhead."
  []
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 64 1024 1024) :max-blocks 8192))
  (a/get-env a/*global-atom-instance*))

;;-----------------------------------------------------------------------------
;; Benchmarking helpers
;;-----------------------------------------------------------------------------

(defn measure-time
  "Measure execution time in ms for a thunk."
  [thunk]
  (let [start (js/performance.now)]
    (thunk)
    (- (js/performance.now) start)))

(defn run-bench
  "Run benchmark with warmup and multiple reps."
  [name thunk]
  (dotimes [_ WARMUP_REPS]
    (thunk))
  (let [times (repeatedly BENCH_REPS #(measure-time thunk))
        avg (/ (reduce + times) (count times))
        min-t (apply min times)
        max-t (apply max times)]
    {:name name :avg avg :min min-t :max max-t}))

(defn run-bench-with-reset
  "Run benchmark with env reset between reps (for allocation-heavy tests)."
  [name setup-fn thunk]
  (println "      [DEBUG] Starting:" name)
  ;; Warmup with fresh env each time
  (dotimes [w WARMUP_REPS]
    (println "      [DEBUG] Warmup" w ": init-env!")
    (init-env!)
    (let [env (a/get-env a/*global-atom-instance*)]
      (println "      [DEBUG] SAB size:" (.-byteLength (:sab env))))
    (println "      [DEBUG] Warmup" w ": calling setup-fn")
    (setup-fn)
    (println "      [DEBUG] Warmup" w ": calling thunk")
    (thunk)
    (println "      [DEBUG] Warmup" w ": complete"))
  ;; Bench reps - use loop to ensure sequential execution
  (let [times (loop [i 0
                     results []]
                (if (>= i BENCH_REPS)
                  results
                  (do
                    (init-env!)
                    (setup-fn)
                    (let [t (measure-time thunk)]
                      (recur (inc i) (conj results t))))))
        avg (/ (reduce + times) (count times))
        min-t (apply min times)
        max-t (apply max times)]
    {:name name :avg avg :min min-t :max max-t}))

;;-----------------------------------------------------------------------------
;; Benchmarks
;;-----------------------------------------------------------------------------

(defn bench-conj
  "Benchmark conj performance for different chunk sizes."
  [n chunk-size]
  (run-bench-with-reset
   (str "conj n=" n " chunk=" chunk-size)
   (fn [])  ;; no setup needed
   (fn []
     (let [v (vec/empty-sab-vec-n chunk-size)]
       (reduce (fn [acc i] (conj acc i)) v (range n))))))

(defn bench-nth
  "Benchmark random nth access."
  [n chunk-size]
  (let [v-atom (atom nil)
        indices (doall (repeatedly n #(rand-int n)))]
    (run-bench-with-reset
     (str "nth n=" n " chunk=" chunk-size)
     (fn [] (reset! v-atom (reduce conj (vec/empty-sab-vec-n chunk-size) (range n))))
     (fn []
       (let [v @v-atom]
         (doseq [i indices]
           (nth v i)))))))

(defn- read-sab-vec-fields
  "Read SabVecN fields directly from SAB for debugging."
  [v]
  (let [sab (vec/SabVecN-sab v)
        off (vec/SabVecN-offset v)
        dv (js/DataView. sab)]
    {:sab-size (.-byteLength sab)
     :instance-offset off
     :cnt (.getInt32 dv (+ off 4) true)
     :shift (.getInt32 dv (+ off 8) true)
     :root (.getInt32 dv (+ off 12) true)
     :tail (.getInt32 dv (+ off 16) true)
     :tail-len (.getInt32 dv (+ off 20) true)
     :node-size (.getInt32 dv (+ off 24) true)}))

(defn bench-nth-sequential
  "Benchmark sequential nth access (more cache-friendly)."
  [n chunk-size]
  (let [v-atom (atom nil)
        creation-sab-atom (atom nil)]
    (run-bench-with-reset
     (str "nth-seq n=" n " chunk=" chunk-size)
     (fn []
       (println "        [DEBUG] setup-fn: Creating vec n=" n "chunk=" chunk-size)
       (let [v (reduce conj (vec/empty-sab-vec-n chunk-size) (range n))
             fields (read-sab-vec-fields v)]
         (reset! creation-sab-atom (:sab (a/get-env a/*global-atom-instance*)))
         (println "        [DEBUG] setup-fn: Fields=" (pr-str fields))
         (println "        [DEBUG] setup-fn: root valid?" (< (:root fields) (:sab-size fields))
                  "tail valid?" (< (:tail fields) (:sab-size fields)))
         (reset! v-atom v)))
     (fn []
       (let [v @v-atom
             fields (read-sab-vec-fields v)
             current-sab (:sab (a/get-env a/*global-atom-instance*))]
         (println "        [DEBUG] thunk: SAB same?" (= current-sab @creation-sab-atom))
         (println "        [DEBUG] thunk: Fields=" (pr-str fields))
         ;; Debug: find failing element
         (println "        [DEBUG] thunk: Finding failing element...")
        (let [failed-at (atom nil)]
          (doseq [i (range n)
                  :while (nil? @failed-at)]
            (try
              (let [elem (nth v i)]
                (when (= 0 (mod i 100))
                  (println "          elem[" i "] =" elem)))
              (catch :default e
                (println "        [DEBUG] thunk: FAILED at element" i)
                (reset! failed-at i))))
          (when @failed-at
            (throw (js/Error. (str "Failed at element " @failed-at))))))))))

(defn bench-reduce
  "Benchmark reduce over entire vector."
  [n chunk-size]
  (let [v-atom (atom nil)]
    (run-bench-with-reset
     (str "reduce n=" n " chunk=" chunk-size)
     (fn [] (reset! v-atom (reduce conj (vec/empty-sab-vec-n chunk-size) (range n))))
     (fn []
       (reduce + 0 @v-atom)))))

(defn bench-pop
  "Benchmark pop performance."
  [n chunk-size]
  (let [v-atom (atom nil)]
    (run-bench-with-reset
     (str "pop n=" n " chunk=" chunk-size)
     (fn [] (reset! v-atom (reduce conj (vec/empty-sab-vec-n chunk-size) (range n))))
     (fn []
       (loop [v @v-atom]
         (when (pos? (count v))
           (recur (pop v))))))))

(defn bench-assoc
  "Benchmark assoc (update) performance."
  [n chunk-size]
  (let [v-atom (atom nil)]
    (run-bench-with-reset
     (str "assoc n=" n " chunk=" chunk-size)
     (fn [] (reset! v-atom (reduce conj (vec/empty-sab-vec-n chunk-size) (range n))))
     (fn []
       (reduce (fn [acc i] (assoc acc i (* i 2))) @v-atom (range n))))))

;;-----------------------------------------------------------------------------
;; List Benchmarks
;;-----------------------------------------------------------------------------

(defn bench-list-conj
  "Benchmark list conj performance for different chunk sizes."
  [n chunk-size]
  (run-bench-with-reset
   (str "list-conj n=" n " chunk=" chunk-size)
   (fn [])  ;; no setup needed
   (fn []
     (let [l (lst/empty-sab-list-n chunk-size)]
       (reduce (fn [acc i] (conj acc i)) l (range n))))))

(defn bench-list-first-rest
  "Benchmark list first/rest traversal."
  [n chunk-size]
  (let [l-atom (atom nil)]
    (run-bench-with-reset
     (str "list-first/rest n=" n " chunk=" chunk-size)
     (fn [] (reset! l-atom (reduce conj (lst/empty-sab-list-n chunk-size) (range n))))
     (fn []
       (loop [lst @l-atom
              sum 0]
         (if (seq lst)
           (recur (rest lst) (+ sum (first lst)))
           sum))))))

(defn bench-list-reduce
  "Benchmark list reduce."
  [n chunk-size]
  (let [l-atom (atom nil)]
    (run-bench-with-reset
     (str "list-reduce n=" n " chunk=" chunk-size)
     (fn [] (reset! l-atom (reduce conj (lst/empty-sab-list-n chunk-size) (range n))))
     (fn []
       (reduce + 0 @l-atom)))))

;;-----------------------------------------------------------------------------
;; Results formatting
;;-----------------------------------------------------------------------------

(defn pad-right [s width]
  (let [s (str s)
        pad (- width (count s))]
    (if (<= pad 0) s (str s (apply str (repeat pad " "))))))

(defn pad-left [s width]
  (let [s (str s)
        pad (- width (count s))]
    (if (<= pad 0) s (str (apply str (repeat pad " ")) s))))

(defn print-results-table
  "Print results grouped by operation and collection size."
  [results]
  (println "\n" (apply str (repeat 80 "=")))
  (println "  CHUNK SIZE BENCHMARK RESULTS")
  (println (apply str (repeat 80 "=")) "\n")

  ;; Group by operation and n
  (doseq [[op-name op-results] (group-by :op results)]
    (println (str "\n  === " op-name " ===\n"))
    (println (str "  " (pad-right "n" 8)
                  (apply str (map #(pad-left (str "chunk=" %) 14) CHUNK_SIZES))
                  (pad-left "Best" 10)))
    (println (str "  " (apply str (repeat 78 "-"))))

    (doseq [[n n-results] (sort-by first (group-by :n op-results))]
      (let [by-chunk (into {} (map (juxt :chunk-size identity) n-results))
            times (map #(get-in by-chunk [% :avg]) CHUNK_SIZES)
            best-chunk (first (apply min-key second (map vector CHUNK_SIZES times)))]
        (println (str "  " (pad-right n 8)
                      (apply str (map #(pad-left (if % (.toFixed % 2) "N/A") 14) times))
                      (pad-left (str best-chunk) 10))))))

  (println "\n" (apply str (repeat 80 "=")) "\n")
  (println "  Times in milliseconds. Lower is better.")
  (println "  'Best' shows the chunk size with lowest avg time for that n.\n"))

;;-----------------------------------------------------------------------------
;; Main runner
;;-----------------------------------------------------------------------------

(defn run-all-benchmarks []
  (println "\n" (apply str (repeat 80 "="))
           "\n  CHUNK SIZE BENCHMARK"
           "\n  Testing: " (pr-str CHUNK_SIZES)
           "\n  Collection sizes: " (pr-str COLLECTION_SIZES)
           "\n" (apply str (repeat 80 "=")) "\n")

  ;; Debug: Test basic SAB operations
  (println "\n  === DEBUG: Testing SAB operations ===")
  (println "  Test 1: Create 500-element vec, access immediately")
  (init-env!)
  (let [env1 (a/get-env a/*global-atom-instance*)
        _ (println "    SAB size:" (.-byteLength (:sab env1)))
        v1 (reduce conj (vec/empty-sab-vec-n 32) (range 500))]
    (println "    Created vec, count:" (count v1))
    (println "    Accessing element 0:" (nth v1 0))
    (println "    Accessing element 499:" (nth v1 499))
    (println "  Test 1 PASSED"))

  (println "\n  Test 2: Reset env, create 1500-element vec")
  (init-env!)
  (let [env2 (a/get-env a/*global-atom-instance*)
        _ (println "    SAB size:" (.-byteLength (:sab env2)))
        v2 (reduce conj (vec/empty-sab-vec-n 32) (range 1500))]
    (println "    Created vec, count:" (count v2))
    (println "    Accessing element 0:" (nth v2 0))
    (println "    Accessing element 1499:" (nth v2 1499))
    (println "  Test 2 PASSED"))

  (println "\n  === DEBUG complete, running benchmarks ===\n")

  (let [results (atom [])]

    ;; Vector benchmarks
    (println "\n  === VECTOR BENCHMARKS ===")

    ;; Run conj benchmarks
    (println "\n  Running vec conj benchmarks...")
    (doseq [n COLLECTION_SIZES
            chunk CHUNK_SIZES]
      (let [result (bench-conj n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "vec-conj" :n n :chunk-size chunk}))))

    ;; Run nth sequential benchmarks
    (println "\n  Running vec nth-sequential benchmarks...")
    (doseq [n COLLECTION_SIZES
            chunk CHUNK_SIZES]
      (let [result (bench-nth-sequential n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "vec-nth-seq" :n n :chunk-size chunk}))))

    ;; Run reduce benchmarks
    (println "\n  Running vec reduce benchmarks...")
    (doseq [n COLLECTION_SIZES
            chunk CHUNK_SIZES]
      (let [result (bench-reduce n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "vec-reduce" :n n :chunk-size chunk}))))

    ;; Run pop benchmarks (smaller n due to O(n) total work)
    (println "\n  Running vec pop benchmarks...")
    (doseq [n (filter #(<= % 1000) COLLECTION_SIZES)
            chunk CHUNK_SIZES]
      (let [result (bench-pop n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "vec-pop" :n n :chunk-size chunk}))))

    ;; Run assoc benchmarks (smaller n due to O(n) total work)
    (println "\n  Running vec assoc benchmarks...")
    (doseq [n (filter #(<= % 1000) COLLECTION_SIZES)
            chunk CHUNK_SIZES]
      (let [result (bench-assoc n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "vec-assoc" :n n :chunk-size chunk}))))

    ;; List benchmarks
    (println "\n  === LIST BENCHMARKS ===")

    ;; Run list conj benchmarks
    (println "\n  Running list conj benchmarks...")
    (doseq [n COLLECTION_SIZES
            chunk CHUNK_SIZES]
      (let [result (bench-list-conj n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "list-conj" :n n :chunk-size chunk}))))

    ;; Run list first/rest benchmarks
    (println "\n  Running list first/rest benchmarks...")
    (doseq [n (filter #(<= % 1000) COLLECTION_SIZES)
            chunk CHUNK_SIZES]
      (let [result (bench-list-first-rest n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "list-first/rest" :n n :chunk-size chunk}))))

    ;; Run list reduce benchmarks
    (println "\n  Running list reduce benchmarks...")
    (doseq [n COLLECTION_SIZES
            chunk CHUNK_SIZES]
      (let [result (bench-list-reduce n chunk)]
        (println (str "    " (:name result) ": " (.toFixed (:avg result) 2) "ms"))
        (swap! results conj (merge result {:op "list-reduce" :n n :chunk-size chunk}))))

    ;; Print summary table
    (print-results-table @results)))

;; Run on load
(run-all-benchmarks)

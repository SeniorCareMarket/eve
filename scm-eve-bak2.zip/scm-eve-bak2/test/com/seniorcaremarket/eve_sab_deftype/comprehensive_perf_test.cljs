(ns com.seniorcaremarket.eve-sab-deftype.comprehensive-perf-test
  "Comprehensive performance comparison: OLD vs NEW SAB implementations
   across variable chunk sizes, progressive data sizes, and operations.

   Tests:
   1. Single-threaded performance: build, lookup, iterate, transform
   2. Chunk size comparison: 32, 64, 128, 256, 512, 1024
   3. Progressive data sizes: 100, 500, 1000, 2500, 5000
   4. Operation types: build, lookup, iterate, reduce, update, transform

   Compares:
   - OLD: sabp-* (manual deftype, fressian)
   - NEW: sab-* (eve-sab-deftype macro)
   - NEW-N: sab-*-n (variable chunk sizes)"
  (:require
   [cljs.test :refer [deftest is testing run-tests]]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   ;; Old fressian-based structures
   [com.seniorcaremarket.eve.sabp-map :as old-map]
   [com.seniorcaremarket.eve.sabp-set :as old-set]
   [com.seniorcaremarket.eve.sabp-list :as old-list]
   ;; New eve-sab-deftype structures
   [com.seniorcaremarket.eve-sab-deftype.sab-vec :as new-vec]
   [com.seniorcaremarket.eve-sab-deftype.sab-list :as new-list]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as new-map]
   [com.seniorcaremarket.eve-sab-deftype.sab-set :as new-set]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Configuration
;;-----------------------------------------------------------------------------

(def ^:const CHUNK-SIZES [32 64 128 256 512 1024])
(def ^:const DATA-SIZES [100 500 1000 2500])
(def ^:const LOOKUP-REPS 50)
(def ^:const ITERATE-REPS 10)

;;-----------------------------------------------------------------------------
;; Results Storage
;;-----------------------------------------------------------------------------

(def ^:dynamic *results* (atom []))

(defn record! [category structure operation size chunk-size ops duration-ms]
  (let [ops-sec (if (pos? duration-ms) (/ (* ops 1000) duration-ms) 0)]
    (swap! *results* conj
           {:category category
            :structure structure
            :operation operation
            :size size
            :chunk-size chunk-size
            :ops ops
            :duration-ms duration-ms
            :ops-sec ops-sec})))

;;-----------------------------------------------------------------------------
;; Environment Setup
;;-----------------------------------------------------------------------------

(defn now [] (js/performance.now))

(defn fresh-env
  [& {:keys [sab-size max-blocks]
      :or {sab-size (* 32 1024 1024) max-blocks 65536}}]
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size sab-size :max-blocks max-blocks))
  (a/get-env a/*global-atom-instance*))

;;-----------------------------------------------------------------------------
;; 1. MAP Performance Tests
;;-----------------------------------------------------------------------------

(defn bench-map-build [n]
  (println (str "\n  === Map Build (n=" n ") ==="))

  ;; CLJS baseline
  (let [start (now)
        m (loop [m {} i 0]
            (if (>= i n) m (recur (assoc m i {:val i :squared (* i i)}) (inc i))))
        dur (- (now) start)]
    (record! "CLJS" "map" "build" n nil n dur)
    (println (str "    CLJS:    " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; OLD sabp-map
  (let [env (fresh-env)
        start (now)
        m (loop [m (old-map/sabp-map env) i 0]
            (if (>= i n) m (recur (assoc m i {:val i :squared (* i i)}) (inc i))))
        dur (- (now) start)]
    (record! "OLD" "map" "build" n nil n dur)
    (println (str "    OLD-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; NEW sab-map
  (let [_ (fresh-env)
        start (now)
        m (loop [m (new-map/empty-sab-map) i 0]
            (if (>= i n) m (recur (assoc m i {:val i :squared (* i i)}) (inc i))))
        dur (- (now) start)]
    (record! "NEW" "map" "build" n nil n dur)
    (println (str "    NEW-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)"))))

(defn bench-map-lookup [n]
  (println (str "\n  === Map Lookup (n=" n ", " LOOKUP-REPS " reps) ==="))
  (let [total-ops (* LOOKUP-REPS n)]

    ;; Build maps
    (let [cljs-map (into {} (map (fn [i] [i {:val i}]) (range n)))
          env (fresh-env)
          old-m (loop [m (old-map/sabp-map env) i 0]
                  (if (>= i n) m (recur (assoc m i {:val i}) (inc i))))
          _ (fresh-env)
          new-m (loop [m (new-map/empty-sab-map) i 0]
                  (if (>= i n) m (recur (assoc m i {:val i}) (inc i))))]

      ;; CLJS
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (get cljs-map i)))
        (let [dur (- (now) start)]
          (record! "CLJS" "map" "lookup" n nil total-ops dur)
          (println (str "    CLJS:    " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)"))))

      ;; OLD
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (get old-m i)))
        (let [dur (- (now) start)]
          (record! "OLD" "map" "lookup" n nil total-ops dur)
          (println (str "    OLD-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)"))))

      ;; NEW
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (get new-m i)))
        (let [dur (- (now) start)]
          (record! "NEW" "map" "lookup" n nil total-ops dur)
          (println (str "    NEW-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)")))))))

;;-----------------------------------------------------------------------------
;; 2. SET Performance Tests
;;-----------------------------------------------------------------------------

(defn bench-set-build [n]
  (println (str "\n  === Set Build (n=" n ") ==="))

  ;; CLJS
  (let [start (now)
        s (loop [s #{} i 0]
            (if (>= i n) s (recur (conj s i) (inc i))))
        dur (- (now) start)]
    (record! "CLJS" "set" "build" n nil n dur)
    (println (str "    CLJS:    " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; OLD
  (let [env (fresh-env)
        start (now)
        s (loop [s (old-set/sabp-set env) i 0]
            (if (>= i n) s (recur (conj s i) (inc i))))
        dur (- (now) start)]
    (record! "OLD" "set" "build" n nil n dur)
    (println (str "    OLD-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; NEW
  (let [_ (fresh-env)
        start (now)
        s (loop [s (new-set/empty-sab-set) i 0]
            (if (>= i n) s (recur (conj s i) (inc i))))
        dur (- (now) start)]
    (record! "NEW" "set" "build" n nil n dur)
    (println (str "    NEW-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)"))))

(defn bench-set-contains [n]
  (println (str "\n  === Set Contains (n=" n ", " LOOKUP-REPS " reps) ==="))
  (let [total-ops (* LOOKUP-REPS n)]

    ;; Build sets
    (let [cljs-set (into #{} (range n))
          env (fresh-env)
          old-s (loop [s (old-set/sabp-set env) i 0]
                  (if (>= i n) s (recur (conj s i) (inc i))))
          _ (fresh-env)
          new-s (loop [s (new-set/empty-sab-set) i 0]
                  (if (>= i n) s (recur (conj s i) (inc i))))]

      ;; CLJS
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (contains? cljs-set i)))
        (let [dur (- (now) start)]
          (record! "CLJS" "set" "contains" n nil total-ops dur)
          (println (str "    CLJS:    " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)"))))

      ;; OLD
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (contains? old-s i)))
        (let [dur (- (now) start)]
          (record! "OLD" "set" "contains" n nil total-ops dur)
          (println (str "    OLD-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)"))))

      ;; NEW
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (contains? new-s i)))
        (let [dur (- (now) start)]
          (record! "NEW" "set" "contains" n nil total-ops dur)
          (println (str "    NEW-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)")))))))

;;-----------------------------------------------------------------------------
;; 3. VECTOR Performance Tests (with chunk sizes)
;;-----------------------------------------------------------------------------

(defn bench-vec-build [n]
  (println (str "\n  === Vector Build (n=" n ") ==="))

  ;; CLJS vector
  (let [start (now)
        v (loop [v [] i 0]
            (if (>= i n) v (recur (conj v {:idx i :data (str "item-" i)}) (inc i))))
        dur (- (now) start)]
    (record! "CLJS" "vec" "build" n nil n dur)
    (println (str "    CLJS:      " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; NEW SabVec (fixed chunk size 32)
  (let [_ (fresh-env)
        start (now)
        v (loop [v (new-vec/empty-sab-vec) i 0]
            (if (>= i n) v (recur (conj v {:idx i :data (str "item-" i)}) (inc i))))
        dur (- (now) start)]
    (record! "NEW" "vec" "build" n 32 n dur)
    (println (str "    NEW(32):   " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; NEW SabVecN with different chunk sizes
  (doseq [chunk-size CHUNK-SIZES]
    (let [_ (fresh-env)
          start (now)
          v (loop [v (new-vec/empty-sab-vec-n chunk-size) i 0]
              (if (>= i n) v (recur (conj v {:idx i :data (str "item-" i)}) (inc i))))
          dur (- (now) start)]
      (record! "NEW-N" "vec" "build" n chunk-size n dur)
      (println (str "    VecN(" chunk-size "): " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))))

(defn bench-vec-nth [n]
  (println (str "\n  === Vector nth (n=" n ", " LOOKUP-REPS " reps) ==="))
  (let [total-ops (* LOOKUP-REPS n)]

    ;; Build vectors
    (let [cljs-vec (into [] (map (fn [i] {:idx i}) (range n)))
          _ (fresh-env)
          new-v (loop [v (new-vec/empty-sab-vec) i 0]
                  (if (>= i n) v (recur (conj v {:idx i}) (inc i))))]

      ;; CLJS
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (nth cljs-vec i)))
        (let [dur (- (now) start)]
          (record! "CLJS" "vec" "nth" n nil total-ops dur)
          (println (str "    CLJS:    " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)"))))

      ;; NEW
      (let [start (now)]
        (dotimes [_ LOOKUP-REPS]
          (dotimes [i n] (nth new-v i)))
        (let [dur (- (now) start)]
          (record! "NEW" "vec" "nth" n 32 total-ops dur)
          (println (str "    NEW-SAB: " (.toFixed dur 2) "ms (" (.toFixed (/ (* total-ops 1000) dur) 0) " ops/s)")))))))

(defn bench-vec-chunk-comparison [n]
  (println (str "\n  === Vector Chunk Size Comparison (n=" n ") ==="))
  (println "    Building and accessing with different chunk sizes...")

  (doseq [chunk-size CHUNK-SIZES]
    (let [_ (fresh-env :sab-size (* 64 1024 1024))
          ;; Build
          build-start (now)
          v (loop [v (new-vec/empty-sab-vec-n chunk-size) i 0]
              (if (>= i n) v (recur (conj v i) (inc i))))
          build-dur (- (now) build-start)

          ;; Sequential access (nth 0 to n-1)
          nth-start (now)
          _ (dotimes [r ITERATE-REPS]
              (dotimes [i n] (nth v i)))
          nth-dur (- (now) nth-start)
          nth-ops (* ITERATE-REPS n)

          ;; Reduce (sum all values)
          reduce-start (now)
          _ (dotimes [_ ITERATE-REPS]
              (reduce + 0 v))
          reduce-dur (- (now) reduce-start)]

      (record! "NEW-N" "vec" "build" n chunk-size n build-dur)
      (record! "NEW-N" "vec" "nth-seq" n chunk-size nth-ops nth-dur)
      (record! "NEW-N" "vec" "reduce" n chunk-size (* ITERATE-REPS n) reduce-dur)

      (println (str "    Chunk " chunk-size ": build=" (.toFixed build-dur 0) "ms, "
                    "nth=" (.toFixed (/ (* nth-ops 1000) nth-dur) 0) " ops/s, "
                    "reduce=" (.toFixed reduce-dur 0) "ms")))))

;;-----------------------------------------------------------------------------
;; 4. LIST Performance Tests (with chunk sizes)
;;-----------------------------------------------------------------------------

(defn bench-list-build [n]
  (println (str "\n  === List Build (n=" n ") ==="))

  ;; CLJS list
  (let [start (now)
        l (loop [l (list) i 0]
            (if (>= i n) l (recur (conj l {:idx i}) (inc i))))
        dur (- (now) start)]
    (record! "CLJS" "list" "build" n nil n dur)
    (println (str "    CLJS:      " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; OLD sabp-list
  (let [env (fresh-env)
        start (now)
        l (loop [l (old-list/->SabpLinkedList env d/ROOT_POINTER_NIL_SENTINEL 0 nil nil) i 0]
            (if (>= i n) l (recur (conj l {:idx i}) (inc i))))
        dur (- (now) start)]
    (record! "OLD" "list" "build" n nil n dur)
    (println (str "    OLD-SAB:   " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; NEW SabList (linked list)
  (let [_ (fresh-env)
        start (now)
        l (loop [l (new-list/empty-sab-list) i 0]
            (if (>= i n) l (recur (conj l {:idx i}) (inc i))))
        dur (- (now) start)]
    (record! "NEW" "list" "build" n nil n dur)
    (println (str "    NEW-SAB:   " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))

  ;; NEW SabListN with different chunk sizes
  (doseq [chunk-size CHUNK-SIZES]
    (let [_ (fresh-env :sab-size (* 64 1024 1024))
          start (now)
          l (loop [l (new-list/empty-sab-list-n chunk-size) i 0]
              (if (>= i n) l (recur (conj l {:idx i}) (inc i))))
          dur (- (now) start)]
      (record! "NEW-N" "list" "build" n chunk-size n dur)
      (println (str "    ListN(" chunk-size "): " (.toFixed dur 2) "ms (" (.toFixed (/ (* n 1000) dur) 0) " ops/s)")))))

(defn bench-list-first-rest [n]
  (println (str "\n  === List first/rest iteration (n=" n ", " ITERATE-REPS " reps) ==="))

  ;; Build lists
  (let [cljs-list (into (list) (range n))
        env (fresh-env)
        old-l (loop [l (old-list/->SabpLinkedList env d/ROOT_POINTER_NIL_SENTINEL 0 nil nil) i 0]
                (if (>= i n) l (recur (conj l i) (inc i))))
        _ (fresh-env)
        new-l (loop [l (new-list/empty-sab-list) i 0]
                (if (>= i n) l (recur (conj l i) (inc i))))]

    ;; CLJS
    (let [start (now)]
      (dotimes [_ ITERATE-REPS]
        (loop [l cljs-list]
          (when (seq l)
            (first l)
            (recur (rest l)))))
      (let [dur (- (now) start)]
        (record! "CLJS" "list" "first-rest" n nil (* ITERATE-REPS n) dur)
        (println (str "    CLJS:    " (.toFixed dur 2) "ms"))))

    ;; OLD
    (let [start (now)]
      (dotimes [_ ITERATE-REPS]
        (loop [l old-l]
          (when (seq l)
            (first l)
            (recur (rest l)))))
      (let [dur (- (now) start)]
        (record! "OLD" "list" "first-rest" n nil (* ITERATE-REPS n) dur)
        (println (str "    OLD-SAB: " (.toFixed dur 2) "ms"))))

    ;; NEW
    (let [start (now)]
      (dotimes [_ ITERATE-REPS]
        (loop [l new-l]
          (when (seq l)
            (first l)
            (recur (rest l)))))
      (let [dur (- (now) start)]
        (record! "NEW" "list" "first-rest" n nil (* ITERATE-REPS n) dur)
        (println (str "    NEW-SAB: " (.toFixed dur 2) "ms"))))))

(defn bench-list-chunk-comparison [n]
  (println (str "\n  === List Chunk Size Comparison (n=" n ") ==="))

  (doseq [chunk-size CHUNK-SIZES]
    (let [_ (fresh-env :sab-size (* 64 1024 1024))
          ;; Build
          build-start (now)
          l (loop [l (new-list/empty-sab-list-n chunk-size) i 0]
              (if (>= i n) l (recur (conj l i) (inc i))))
          build-dur (- (now) build-start)

          ;; first/rest iteration
          iter-start (now)
          _ (dotimes [_ ITERATE-REPS]
              (loop [lst l]
                (when (seq lst)
                  (first lst)
                  (recur (rest lst)))))
          iter-dur (- (now) iter-start)

          ;; reduce
          reduce-start (now)
          _ (dotimes [_ ITERATE-REPS]
              (reduce + 0 l))
          reduce-dur (- (now) reduce-start)]

      (record! "NEW-N" "list" "build" n chunk-size n build-dur)
      (record! "NEW-N" "list" "iterate" n chunk-size (* ITERATE-REPS n) iter-dur)
      (record! "NEW-N" "list" "reduce" n chunk-size (* ITERATE-REPS n) reduce-dur)

      (println (str "    Chunk " chunk-size ": build=" (.toFixed build-dur 0) "ms, "
                    "iter=" (.toFixed iter-dur 0) "ms, "
                    "reduce=" (.toFixed reduce-dur 0) "ms")))))

;;-----------------------------------------------------------------------------
;; 5. Heterogeneous Data Tests
;;-----------------------------------------------------------------------------

(defn bench-heterogeneous-transform [n]
  (println (str "\n  === Heterogeneous Transform (n=" n ") ==="))
  (println "    Testing nested structures: maps with vecs, vecs with maps...")

  ;; Build map with vector values
  (let [_ (fresh-env :sab-size (* 64 1024 1024))
        start (now)
        m (loop [m (new-map/empty-sab-map) i 0]
            (if (>= i n)
              m
              (recur (assoc m (keyword (str "key-" i))
                           {:values [i (* i 2) (* i 3)]
                            :meta {:created-at i :type :nested}})
                     (inc i))))
        build-dur (- (now) start)]
    (record! "NEW" "hetero-map" "build" n nil n build-dur)
    (println (str "    Map build: " (.toFixed build-dur 2) "ms")))

  ;; Build vec with map values
  (let [_ (fresh-env :sab-size (* 64 1024 1024))
        start (now)
        v (loop [v (new-vec/empty-sab-vec) i 0]
            (if (>= i n)
              v
              (recur (conj v {:id i
                              :name (str "item-" i)
                              :tags #{:a :b :c}
                              :children [i (inc i) (+ i 2)]})
                     (inc i))))
        build-dur (- (now) start)]
    (record! "NEW" "hetero-vec" "build" n nil n build-dur)
    (println (str "    Vec build: " (.toFixed build-dur 2) "ms")))

  ;; Transform: read from map, modify, write to vec
  (let [_ (fresh-env :sab-size (* 64 1024 1024))
        src-map (loop [m (new-map/empty-sab-map) i 0]
                  (if (>= i n) m (recur (assoc m i {:val i}) (inc i))))
        start (now)
        result-vec (loop [v (new-vec/empty-sab-vec) i 0]
                     (if (>= i n)
                       v
                       (let [map-val (get src-map i)
                             transformed (assoc map-val :transformed true :doubled (* (:val map-val) 2))]
                         (recur (conj v transformed) (inc i)))))
        transform-dur (- (now) start)]
    (record! "NEW" "transform" "map->vec" n nil n transform-dur)
    (println (str "    Transform: " (.toFixed transform-dur 2) "ms"))))

;;-----------------------------------------------------------------------------
;; Summary Report
;;-----------------------------------------------------------------------------

(defn pad-right [s width]
  (let [s (str s)
        pad (- width (count s))]
    (if (<= pad 0) s (str s (apply str (repeat pad " "))))))

(defn print-summary []
  (println "\n")
  (println (apply str (repeat 90 "=")))
  (println "  COMPREHENSIVE PERFORMANCE SUMMARY")
  (println (apply str (repeat 90 "=")))

  (let [results @*results*]

    ;; Group by structure and operation
    (println "\n  OLD vs NEW Comparison (speedup > 1.0 means NEW is faster):")
    (println (str "  " (apply str (repeat 86 "-"))))
    (println (str "  " (pad-right "Structure" 12) (pad-right "Operation" 15)
                  (pad-right "Size" 8) (pad-right "OLD ops/s" 15)
                  (pad-right "NEW ops/s" 15) "Speedup"))
    (println (str "  " (apply str (repeat 86 "-"))))

    (doseq [[struct ops] [["map" ["build" "lookup"]]
                          ["set" ["build" "contains"]]
                          ["list" ["build"]]]]
      (doseq [op ops]
        (doseq [size DATA-SIZES]
          (let [old-r (first (filter #(and (= "OLD" (:category %))
                                           (= struct (:structure %))
                                           (= op (:operation %))
                                           (= size (:size %)))
                                     results))
                new-r (first (filter #(and (= "NEW" (:category %))
                                           (= struct (:structure %))
                                           (= op (:operation %))
                                           (= size (:size %)))
                                     results))]
            (when (and old-r new-r (pos? (:ops-sec old-r)))
              (let [speedup (/ (:ops-sec new-r) (:ops-sec old-r))]
                (println (str "  " (pad-right struct 12) (pad-right op 15)
                              (pad-right size 8)
                              (pad-right (.toFixed (:ops-sec old-r) 0) 15)
                              (pad-right (.toFixed (:ops-sec new-r) 0) 15)
                              (.toFixed speedup 2) "x"))))))))

    ;; Chunk size comparison for vec
    (println "\n\n  Vector Chunk Size Comparison (build ops/s):")
    (println (str "  " (apply str (repeat 86 "-"))))
    (let [vec-n-results (filter #(and (= "NEW-N" (:category %))
                                      (= "vec" (:structure %))
                                      (= "build" (:operation %)))
                                results)]
      (when (seq vec-n-results)
        (println (str "  " (pad-right "Size" 8)
                      (clojure.string/join "" (map #(pad-right (str "CS=" %) 12) CHUNK-SIZES))))
        (println (str "  " (apply str (repeat 86 "-"))))
        (doseq [size (distinct (map :size vec-n-results))]
          (let [size-results (filter #(= size (:size %)) vec-n-results)]
            (println (str "  " (pad-right size 8)
                          (clojure.string/join ""
                            (map (fn [cs]
                                   (let [r (first (filter #(= cs (:chunk-size %)) size-results))]
                                     (pad-right (if r (.toFixed (:ops-sec r) 0) "-") 12)))
                                 CHUNK-SIZES))))))))

    ;; List chunk size comparison
    (println "\n\n  List Chunk Size Comparison (build ops/s):")
    (println (str "  " (apply str (repeat 86 "-"))))
    (let [list-n-results (filter #(and (= "NEW-N" (:category %))
                                       (= "list" (:structure %))
                                       (= "build" (:operation %)))
                                 results)]
      (when (seq list-n-results)
        (println (str "  " (pad-right "Size" 8)
                      (clojure.string/join "" (map #(pad-right (str "CS=" %) 12) CHUNK-SIZES))))
        (println (str "  " (apply str (repeat 86 "-"))))
        (doseq [size (distinct (map :size list-n-results))]
          (let [size-results (filter #(= size (:size %)) list-n-results)]
            (println (str "  " (pad-right size 8)
                          (clojure.string/join ""
                            (map (fn [cs]
                                   (let [r (first (filter #(= cs (:chunk-size %)) size-results))]
                                     (pad-right (if r (.toFixed (:ops-sec r) 0) "-") 12)))
                                 CHUNK-SIZES))))))))

    (println "\n" (apply str (repeat 90 "=")))))

;;-----------------------------------------------------------------------------
;; Test Definitions
;;-----------------------------------------------------------------------------

(deftest test-map-performance
  (testing "Map build and lookup performance"
    (doseq [n DATA-SIZES]
      (bench-map-build n)
      (bench-map-lookup n))
    (is true)))

(deftest test-set-performance
  (testing "Set build and contains performance"
    (doseq [n DATA-SIZES]
      (bench-set-build n)
      (bench-set-contains n))
    (is true)))

(deftest test-vec-performance
  (testing "Vector build, nth, and chunk comparison"
    (doseq [n DATA-SIZES]
      (bench-vec-build n)
      (bench-vec-nth n))
    ;; Chunk comparison at larger size
    (bench-vec-chunk-comparison 1000)
    (is true)))

(deftest test-list-performance
  (testing "List build, iteration, and chunk comparison"
    (doseq [n DATA-SIZES]
      (bench-list-build n)
      (bench-list-first-rest n))
    ;; Chunk comparison at larger size
    (bench-list-chunk-comparison 1000)
    (is true)))

(deftest test-heterogeneous-performance
  (testing "Heterogeneous data transformation"
    (doseq [n [100 500 1000]]
      (bench-heterogeneous-transform n))
    (is true)))

;;-----------------------------------------------------------------------------
;; Main Entry Point
;;-----------------------------------------------------------------------------

(defn run-comprehensive-perf-test []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (reset! *results* [])
      (println "\n" (apply str (repeat 90 "=")))
      (println "  COMPREHENSIVE PERFORMANCE BENCHMARK")
      (println "  OLD-SAB (sabp-*) vs NEW-SAB (sab-*) vs NEW-N (variable chunk)")
      (println (apply str (repeat 90 "=")) "\n")

      (run-tests)
      (print-summary))))

(run-comprehensive-perf-test)

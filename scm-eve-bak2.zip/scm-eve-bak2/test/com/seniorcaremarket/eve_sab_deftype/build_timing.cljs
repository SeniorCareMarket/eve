(ns com.seniorcaremarket.eve-sab-deftype.build-timing
  "Benchmark: measure time to build SAB maps with deeply nested structures
   at various scales. Tests both persistent and transient paths, plus
   flat map construction for contrast."
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sab-map]))

(set! d/*worker-id* 1)

;;=============================================================================
;; Infrastructure
;;=============================================================================

(defn now [] (js/performance.now))

(defn fresh-env! []
  (sab-map/reset-pools!)
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 512 1024 1024) :max-blocks 524288))
  (sab-map/reset-pools!))

;;=============================================================================
;; Data generators
;;=============================================================================

(def ^:private categories [:electronics :clothing :food :tools :books])
(def ^:private materials [:plastic :metal :wood :glass])

(defn gen-product [i]
  {:id i
   :sku (str "SKU-" i)
   :name (str "Product-" i)
   :category (nth categories (mod i 5))
   :price (+ 0.99 (* (mod (* i 13) 500) 0.97))
   :cost (+ 0.50 (* (mod (* i 7) 300) 0.63))
   :stock (mod (* i 17) 2000)
   :active (zero? (mod i 5))
   :rating (+ 1.0 (* (mod (* i 11) 40) 0.1))
   :tags [(keyword (str "tag-" (mod i 20)))
          (keyword (str "season-" (mod i 4)))]
   :specs {:width (+ 1 (mod (* i 3) 100))
           :height (+ 1 (mod (* i 5) 80))
           :material (nth materials (mod i 4))}
   :pricing {:wholesale (+ 0.50 (* (mod (* i 7) 300) 0.50))
             :bulk-discount (+ 5 (mod (* i 3) 25))}})

;;=============================================================================
;; Benchmark runners
;;=============================================================================

(defn time-nested-persistent [n]
  (fresh-env!)
  (let [start (now)
        result (loop [m (sab-map/empty-sab-map)
                      i 0]
                 (if (>= i n)
                   m
                   (recur (assoc m (keyword (str "p" i)) (gen-product i))
                          (inc i))))
        elapsed (- (now) start)]
    {:n n
     :time-ms elapsed
     :ms-per-item (/ elapsed n)
     :count (count result)}))

(defn time-nested-transient [n]
  (fresh-env!)
  (let [start (now)
        result (persistent!
                (reduce (fn [tm i]
                          (assoc! tm (keyword (str "p" i)) (gen-product i)))
                        (transient (sab-map/empty-sab-map))
                        (range n)))
        elapsed (- (now) start)]
    {:n n
     :time-ms elapsed
     :ms-per-item (/ elapsed n)
     :count (count result)}))

(defn time-flat-persistent [n]
  (fresh-env!)
  (let [start (now)
        result (loop [m (sab-map/empty-sab-map)
                      i 0]
                 (if (>= i n)
                   m
                   (recur (assoc m (keyword (str "k" i)) i)
                          (inc i))))
        elapsed (- (now) start)]
    {:n n
     :time-ms elapsed
     :ms-per-item (/ elapsed n)
     :count (count result)}))

(defn time-flat-transient [n]
  (fresh-env!)
  (let [start (now)
        result (persistent!
                (reduce (fn [tm i]
                          (assoc! tm (keyword (str "k" i)) i))
                        (transient (sab-map/empty-sab-map))
                        (range n)))
        elapsed (- (now) start)]
    {:n n
     :time-ms elapsed
     :ms-per-item (/ elapsed n)
     :count (count result)}))

;;=============================================================================
;; Output formatting
;;=============================================================================

(defn print-header [title]
  (println)
  (println (str "=== " title " ==="))
  (println (str "  " (.padEnd "n" 8)
                (.padEnd "time(ms)" 14)
                (.padEnd "ms/item" 12)
                "count")))

(defn print-row [{:keys [n time-ms ms-per-item count]}]
  (println (str "  " (.padEnd (str n) 8)
                (.padEnd (.toFixed time-ms 2) 14)
                (.padEnd (.toFixed ms-per-item 4) 12)
                count)))

;;=============================================================================
;; Main
;;=============================================================================

(defn run-build-timing []
  (println "SAB Map Build Timing Benchmark")
  (println "==============================")
  (println (str "SAB size: 512MB, max-blocks: 524288"))
  (println)

  ;; --- Nested structures: persistent ---
  (print-header "Nested product maps (persistent assoc)")
  (doseq [n [50 100 200 500 1000 2000]]
    (let [result (time-nested-persistent n)]
      (print-row result)))

  ;; --- Nested structures: transient ---
  (print-header "Nested product maps (transient assoc!)")
  (doseq [n [50 100 200 500 1000 2000]]
    (let [result (time-nested-transient n)]
      (print-row result)))

  ;; --- Flat maps: persistent ---
  (print-header "Flat keyword->int maps (persistent assoc)")
  (doseq [n [1000 5000 10000]]
    (let [result (time-flat-persistent n)]
      (print-row result)))

  ;; --- Flat maps: transient ---
  (print-header "Flat keyword->int maps (transient assoc!)")
  (doseq [n [1000 5000 10000]]
    (let [result (time-flat-transient n)]
      (print-row result)))

  (println)
  (println "Done."))

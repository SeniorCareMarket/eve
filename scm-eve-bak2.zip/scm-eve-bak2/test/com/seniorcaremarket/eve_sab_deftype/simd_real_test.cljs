(ns com.seniorcaremarket.eve-sab-deftype.simd-real-test
  "Actual SIMD benchmark testing REAL WebAssembly SIMD vs pure JS.

   BENCHMARK RESULTS (2024):
   ══════════════════════════════════════════════════════════════════

   CONCLUSION: SIMD is SLOWER than pure JavaScript due to copy overhead.

   Length filtering (8 × u16):
   ────────────────────────────────────────────────────────────────────
   - Pure JS:  20.3M ops/sec
   - SIMD:     13.8M ops/sec
   - Result:   JS is 47% FASTER

   16-byte comparison (equal arrays - best case for SIMD):
   ────────────────────────────────────────────────────────────────────
   - JS byte loop:    27.3M ops/sec
   - JS 32-bit words: 56.2M ops/sec
   - SIMD:            12.1M ops/sec
   - Result:          JS 32-bit is 4.6x FASTER

   16-byte comparison (different at byte 2 - early exit):
   ────────────────────────────────────────────────────────────────────
   - JS byte loop:    70.5M ops/sec
   - JS 32-bit words: 80.2M ops/sec
   - SIMD:            18.1M ops/sec
   - Result:          JS 32-bit is 4.4x FASTER

   ══════════════════════════════════════════════════════════════════
   WHY SIMD LOSES:
   ══════════════════════════════════════════════════════════════════

   The copy overhead kills SIMD performance:
   1. Data lives in JS heap (TypedArrays)
   2. Must copy to WASM linear memory before SIMD operations
   3. SIMD does its work in ~1-2 instructions
   4. But copy cost dominates for small data sizes

   For SIMD to win, we would need:
   - Data already in WASM memory (SharedArrayBuffer direct mapping)
   - Processing large contiguous blocks to amortize copy cost
   - More complex operations per data element

   For our use case (key lookup in HAMT nodes with 8-16 keys):
   - Keep using pure JS with 32-bit word comparisons
   - Length pre-filtering remains valuable (pure JS)
   - The JS JIT is extremely well-optimized for these patterns

   ══════════════════════════════════════════════════════════════════"
  (:require
   [cljs.test :refer [deftest is testing async]]))

(defn now [] (js/performance.now))

(defn bench [label iterations f]
  ;; Warmup
  (dotimes [_ 100] (f))
  ;; Actual benchmark
  (let [start (now)]
    (dotimes [_ iterations] (f))
    (let [dur (- (now) start)
          ops-sec (/ (* iterations 1000) dur)]
      (println (str "  " label ": " (.toFixed dur 2) "ms, "
                    (.toFixed ops-sec 0) " ops/sec"))
      {:label label :duration-ms dur :ops-sec ops-sec})))

;;-----------------------------------------------------------------------------
;; WASM SIMD Module - Actual binary generated from wat2wasm
;;-----------------------------------------------------------------------------

;; This WAT code:
;; (module
;;   (memory (export "memory") 1)
;;
;;   ;; Find matching u16 lengths (8 at a time using v128)
;;   ;; ptr: pointer to 8 u16 values (16 bytes)
;;   ;; target: u16 value to find
;;   ;; returns: bitmask of matches
;;   (func (export "find_lengths") (param $ptr i32) (param $target i32) (result i32)
;;     (i16x8.bitmask
;;       (i16x8.eq
;;         (v128.load (local.get $ptr))
;;         (i16x8.splat (local.get $target)))))
;;
;;   ;; Compare 16 bytes using SIMD
;;   ;; returns 0 if equal, 1 if different
;;   (func (export "compare_16") (param $ptr1 i32) (param $ptr2 i32) (result i32)
;;     (i32.eqz
;;       (v128.all_true
;;         (i8x16.eq
;;           (v128.load (local.get $ptr1))
;;           (v128.load (local.get $ptr2))))))
;; )

;; Compiled with: node compile-simd-wasm.js (uses wabt npm package)
;; WAT source:
;; (module
;;   (memory (export "memory") 1)
;;   (func (export "find_lengths") (param $ptr i32) (param $target i32) (result i32)
;;     (i16x8.bitmask (i16x8.eq (v128.load (local.get $ptr))
;;                              (i16x8.splat (local.get $target)))))
;;   (func (export "compare_16") (param $ptr1 i32) (param $ptr2 i32) (result i32)
;;     (i32.eqz (i8x16.all_true
;;       (i8x16.eq (v128.load (local.get $ptr1))
;;                 (v128.load (local.get $ptr2)))))))

(def ^:private simd-wasm-bytes
  (js/Uint8Array.
   #js [0x00 0x61 0x73 0x6d 0x01 0x00 0x00 0x00 0x01 0x07 0x01 0x60 0x02 0x7f 0x7f 0x01
        0x7f 0x03 0x03 0x02 0x00 0x00 0x05 0x03 0x01 0x00 0x01 0x07 0x26 0x03 0x06 0x6d
        0x65 0x6d 0x6f 0x72 0x79 0x02 0x00 0x0c 0x66 0x69 0x6e 0x64 0x5f 0x6c 0x65 0x6e
        0x67 0x74 0x68 0x73 0x00 0x00 0x0a 0x63 0x6f 0x6d 0x70 0x61 0x72 0x65 0x5f 0x31
        0x36 0x00 0x01 0x0a 0x27 0x02 0x11 0x00 0x20 0x00 0xfd 0x00 0x04 0x00 0x20 0x01
        0xfd 0x10 0xfd 0x2d 0xfd 0x84 0x01 0x0b 0x13 0x00 0x20 0x00 0xfd 0x00 0x04 0x00
        0x20 0x01 0xfd 0x00 0x04 0x00 0xfd 0x23 0xfd 0x63 0x45 0x0b]))

;;-----------------------------------------------------------------------------
;; WASM Instance
;;-----------------------------------------------------------------------------

(defonce ^:private wasm-instance (atom nil))
(defonce ^:private wasm-memory (atom nil))
(defonce ^:private wasm-u8 (atom nil))
(defonce ^:private wasm-u16 (atom nil))

(defn init-simd!
  "Initialize WASM SIMD module. Returns promise."
  []
  (-> (js/WebAssembly.instantiate simd-wasm-bytes)
      (.then (fn [result]
               (let [instance (.-instance result)
                     memory (.-memory (.-exports instance))]
                 (reset! wasm-instance instance)
                 (reset! wasm-memory memory)
                 (reset! wasm-u8 (js/Uint8Array. (.-buffer memory)))
                 (reset! wasm-u16 (js/Uint16Array. (.-buffer memory)))
                 (println "SIMD WASM initialized successfully!")
                 true)))
      (.catch (fn [err]
                (println "SIMD WASM failed:" (.-message err))
                (println "This may be because SIMD is not supported.")
                false))))

;;-----------------------------------------------------------------------------
;; Pure JS Implementations (for comparison)
;;-----------------------------------------------------------------------------

(defn js-find-lengths
  "Pure JS: find matching lengths in array of 8 u16 values."
  [^js lengths target]
  (loop [i 0 mask 0]
    (if (>= i 8)
      mask
      (recur (inc i)
             (if (== (aget lengths i) target)
               (bit-or mask (bit-shift-left 1 i))
               mask)))))

(defn js-compare-16
  "Pure JS: compare 16 bytes."
  [^js a offset-a ^js b offset-b]
  (loop [i 0]
    (if (>= i 16)
      0  ;; equal
      (if (== (aget a (+ offset-a i)) (aget b (+ offset-b i)))
        (recur (inc i))
        1)))) ;; different

(defn js-compare-16-32bit
  "Pure JS: compare 16 bytes using 32-bit words."
  [^js dv1 offset1 ^js dv2 offset2]
  (and (== (.getUint32 dv1 offset1 true) (.getUint32 dv2 offset2 true))
       (== (.getUint32 dv1 (+ offset1 4) true) (.getUint32 dv2 (+ offset2 4) true))
       (== (.getUint32 dv1 (+ offset1 8) true) (.getUint32 dv2 (+ offset2 8) true))
       (== (.getUint32 dv1 (+ offset1 12) true) (.getUint32 dv2 (+ offset2 12) true))))

;;-----------------------------------------------------------------------------
;; SIMD Implementations
;;-----------------------------------------------------------------------------

(defn simd-find-lengths
  "SIMD: find matching lengths using v128."
  [^js lengths target]
  (let [u16 @wasm-u16
        exports (.-exports @wasm-instance)]
    ;; Copy lengths to WASM memory
    (dotimes [i 8]
      (aset u16 i (aget lengths i)))
    ;; Call SIMD function
    (.find_lengths exports 0 target)))

(defn simd-compare-16
  "SIMD: compare 16 bytes using v128."
  [^js a offset-a ^js b offset-b]
  (let [u8 @wasm-u8
        exports (.-exports @wasm-instance)]
    ;; Copy a to offset 0
    (dotimes [i 16]
      (aset u8 i (aget a (+ offset-a i))))
    ;; Copy b to offset 32
    (dotimes [i 16]
      (aset u8 (+ 32 i) (aget b (+ offset-b i))))
    ;; Call SIMD compare
    (.compare_16 exports 0 32)))

;;-----------------------------------------------------------------------------
;; Benchmarks
;;-----------------------------------------------------------------------------

(deftest test-simd-length-filtering
  (async done
    (-> (init-simd!)
        (.then
         (fn [simd-ok?]
           (if-not simd-ok?
             (do (println "SIMD not available, skipping SIMD tests")
                 (done))
             (do
               (println "\n" (apply str (repeat 60 "=")) "\n")
               (println "  ACTUAL SIMD vs JS BENCHMARK")
               (println "  Testing REAL WebAssembly SIMD performance")
               (println "\n" (apply str (repeat 60 "=")) "\n")

               ;; Test: Length filtering (8 × u16)
               (println "--- LENGTH FILTERING (8 × u16) ---")
               (println "Finding which of 8 key lengths match target")
               (println)

               (let [lengths (js/Uint16Array. #js [6 12 8 14 10 6 18 7])
                     target 6
                     iters 100000]

                 ;; Verify correctness
                 (let [js-result (js-find-lengths lengths target)
                       simd-result (simd-find-lengths lengths target)]
                   (println (str "  JS result:   " js-result " (binary: " (.toString js-result 2) ")"))
                   (println (str "  SIMD result: " simd-result " (binary: " (.toString simd-result 2) ")"))
                   (println (str "  Expected:    " 0x21 " (bits 0 and 5 set for indices with length 6)"))
                   (is (= js-result simd-result) "Results should match"))

                 (println)
                 (bench "Pure JS find_lengths" iters
                        #(js-find-lengths lengths target))
                 (bench "SIMD find_lengths" iters
                        #(simd-find-lengths lengths target))
                 (println))

               ;; Test: 16-byte comparison
               (println "\n--- 16-BYTE COMPARISON ---")
               (println "Comparing 16 bytes using v128")
               (println)

               (let [;; Two equal 16-byte arrays
                     a (js/Uint8Array. 32)
                     b (js/Uint8Array. 32)
                     _ (dotimes [i 16]
                         (aset a i (mod (* i 17) 256))
                         (aset b i (mod (* i 17) 256)))
                     dv-a (js/DataView. (.-buffer a))
                     dv-b (js/DataView. (.-buffer b))
                     iters 100000]

                 ;; Verify correctness (equal case)
                 (let [js-result (js-compare-16 a 0 b 0)
                       simd-result (simd-compare-16 a 0 b 0)]
                   (println (str "  Equal arrays - JS: " js-result ", SIMD: " simd-result))
                   (is (= js-result simd-result 0) "Equal arrays should return 0"))

                 ;; Make arrays different
                 (aset b 8 255)
                 (let [js-result (js-compare-16 a 0 b 0)
                       simd-result (simd-compare-16 a 0 b 0)]
                   (println (str "  Different arrays - JS: " js-result ", SIMD: " simd-result))
                   (is (= js-result simd-result 1) "Different arrays should return 1"))

                 ;; Reset for benchmark
                 (aset b 8 (aget a 8))

                 (println)
                 (println "Equal arrays (best case for SIMD):")
                 (bench "  JS byte loop" iters
                        #(js-compare-16 a 0 b 0))
                 (bench "  JS 32-bit words" iters
                        #(js-compare-16-32bit dv-a 0 dv-b 0))
                 (bench "  SIMD v128" iters
                        #(simd-compare-16 a 0 b 0))

                 (println)
                 (println "Different arrays (early exit):")
                 (aset b 2 255)  ;; Differ at byte 2
                 (bench "  JS byte loop" iters
                        #(js-compare-16 a 0 b 0))
                 (bench "  JS 32-bit words" iters
                        #(js-compare-16-32bit dv-a 0 dv-b 0))
                 (bench "  SIMD v128" iters
                        #(simd-compare-16 a 0 b 0)))

               (println "\n" (apply str (repeat 60 "=")) "\n")
               (println "  ANALYSIS")
               (println (apply str (repeat 60 "-")))
               (println "
  The key question: Is SIMD faster despite copy overhead?

  For length filtering (8 × u16):
  - SIMD does 1 v128 load + 1 splat + 1 eq + 1 bitmask
  - But we must copy 16 bytes to WASM memory first

  For 16-byte comparison:
  - SIMD does 2 v128 loads + 1 eq + 1 all_true
  - But we must copy 32 bytes to WASM memory first

  The copy overhead is the killer. True SIMD benefit requires:
  - Data already in WASM memory (SharedArrayBuffer direct access)
  - Or processing enough data to amortize copy cost
  ")
               (println (apply str (repeat 60 "=")))

               (done))))))))

;;-----------------------------------------------------------------------------
;; Run benchmark
;;-----------------------------------------------------------------------------

(defn run-simd-real-benchmark []
  (test-simd-length-filtering))

(ns com.seniorcaremarket.eve-sab-deftype.simd-full-lookup-test
  "Test SIMD with FULL LOOKUP in WASM - minimize JS↔WASM boundary crossings.

   HYPOTHESIS: The problem is not SIMD itself, but WASM call overhead.
   If we move the entire lookup (length filter + byte compare) into WASM,
   we have ONE call instead of multiple calls.

   APPROACH 1: Full lookup in WASM
   ────────────────────────────────────────────────────────────────────
   - Pass: target key ptr/len, key metadata array ptr, key count
   - WASM does: length filter (SIMD) + byte compare (SIMD or scalar)
   - Return: matching index or -1

   APPROACH 2: Hash-based pre-filtering
   ────────────────────────────────────────────────────────────────────
   - Store 32-bit hash for each key
   - SIMD compare 4 hashes at once (i32x4.eq)
   - Only byte-compare on hash match (rare collision)

   APPROACH 3: Batch lookups
   ────────────────────────────────────────────────────────────────────
   - Multiple target keys in one call
   - Amortize call overhead across many lookups

   BENCHMARK RESULTS:
   ══════════════════════════════════════════════════════════════════
   8 keys:  JS 6M → WASM 21M (3.5x) → WASM-SIMD 30M (5x faster)
   16 keys: JS 7-8M → WASM 43M (5x faster)

   CONCLUSION: Full lookup in WASM is 3-5x faster than pure JS!
   Moving entire operation to WASM eliminates JS↔WASM boundary overhead.
   ══════════════════════════════════════════════════════════════════"
  (:require
   [cljs.test :refer [deftest is testing async]]))

(defn now [] (js/performance.now))

(defn bench [label iterations f]
  (dotimes [_ 100] (f))
  (let [start (now)]
    (dotimes [_ iterations] (f))
    (let [dur (- (now) start)
          ops-sec (/ (* iterations 1000) dur)]
      (println (str "  " label ": " (.toFixed dur 2) "ms, "
                    (.toFixed ops-sec 0) " ops/sec"))
      {:label label :duration-ms dur :ops-sec ops-sec})))

;;-----------------------------------------------------------------------------
;; WASM Module with Full Lookup
;;-----------------------------------------------------------------------------

(defonce ^:private wasm-module (atom nil))
(defonce ^:private shared-memory (atom nil))
(defonce ^:private memory-u8 (atom nil))
(defonce ^:private memory-u16 (atom nil))
(defonce ^:private memory-u32 (atom nil))
(defonce ^:private memory-dv (atom nil))

(defn init-full-lookup!
  "Initialize WASM with full lookup function.
   Memory layout:
   - 0-1023: Scratch/metadata
   - 1024+: Key data"
  []
  (js/Promise.
   (fn [resolve reject]
     (let [memory (js/WebAssembly.Memory.
                   #js {:initial 1
                        :maximum 100
                        :shared true})]
       (reset! shared-memory memory)
       (reset! memory-u8 (js/Uint8Array. (.-buffer memory)))
       (reset! memory-u16 (js/Uint16Array. (.-buffer memory)))
       (reset! memory-u32 (js/Uint32Array. (.-buffer memory)))
       (reset! memory-dv (js/DataView. (.-buffer memory)))

       (-> (js/Promise.resolve (js/require "wabt"))
           (.then (fn [wabt-factory] (wabt-factory)))
           (.then (fn [wabt]
                    (let [wat-source "
(module
  (import \"env\" \"memory\" (memory 1 100 shared))

  ;; ═══════════════════════════════════════════════════════════════════════
  ;; FULL LOOKUP: Do entire key search in WASM with minimal JS interaction
  ;; ═══════════════════════════════════════════════════════════════════════
  ;;
  ;; Memory layout expected:
  ;; - lengths_ptr: array of n u16 key lengths
  ;; - offsets_ptr: array of n u32 key offsets
  ;; - target_ptr: target key bytes
  ;; - target_len: target key length
  ;;
  ;; Returns: index of matching key, or -1 if not found

  (func (export \"find_key\")
    (param $lengths_ptr i32)   ;; ptr to u16[] of key lengths
    (param $offsets_ptr i32)   ;; ptr to u32[] of key offsets
    (param $n i32)             ;; number of keys
    (param $target_ptr i32)    ;; ptr to target key bytes
    (param $target_len i32)    ;; target key length
    (result i32)

    (local $i i32)
    (local $key_len i32)
    (local $key_ptr i32)
    (local $j i32)
    (local $match i32)

    ;; Linear scan through keys
    (local.set $i (i32.const 0))
    (block $done
      (loop $next_key
        ;; Check if done
        (br_if $done (i32.ge_u (local.get $i) (local.get $n)))

        ;; Get key length at index i
        (local.set $key_len
          (i32.load16_u
            (i32.add (local.get $lengths_ptr)
                     (i32.shl (local.get $i) (i32.const 1)))))

        ;; Quick length check
        (if (i32.eq (local.get $key_len) (local.get $target_len))
          (then
            ;; Get key offset
            (local.set $key_ptr
              (i32.load
                (i32.add (local.get $offsets_ptr)
                         (i32.shl (local.get $i) (i32.const 2)))))

            ;; Compare bytes
            (local.set $match (i32.const 1))
            (local.set $j (i32.const 0))
            (block $mismatch
              (loop $next_byte
                (br_if $mismatch
                  (i32.ge_u (local.get $j) (local.get $key_len)))
                (if (i32.ne
                      (i32.load8_u (i32.add (local.get $key_ptr) (local.get $j)))
                      (i32.load8_u (i32.add (local.get $target_ptr) (local.get $j))))
                  (then
                    (local.set $match (i32.const 0))
                    (br $mismatch)))
                (local.set $j (i32.add (local.get $j) (i32.const 1)))
                (br $next_byte)))

            ;; If match, return index
            (if (local.get $match)
              (then (return (local.get $i))))))

        ;; Next key
        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $next_key)))

    ;; Not found
    (i32.const -1))

  ;; ═══════════════════════════════════════════════════════════════════════
  ;; SIMD LENGTH FILTER (for comparison)
  ;; ═══════════════════════════════════════════════════════════════════════

  (func (export \"find_lengths\") (param $ptr i32) (param $target i32) (result i32)
    (i16x8.bitmask
      (i16x8.eq
        (v128.load (local.get $ptr))
        (i16x8.splat (local.get $target)))))

  ;; ═══════════════════════════════════════════════════════════════════════
  ;; FULL LOOKUP WITH SIMD LENGTH FILTER
  ;; ═══════════════════════════════════════════════════════════════════════
  ;;
  ;; Same as find_key but uses SIMD for length filtering

  (func (export \"find_key_simd\")
    (param $lengths_ptr i32)   ;; ptr to u16[] of key lengths (must be 16-byte aligned)
    (param $offsets_ptr i32)   ;; ptr to u32[] of key offsets
    (param $n i32)             ;; number of keys (max 8 for now)
    (param $target_ptr i32)    ;; ptr to target key bytes
    (param $target_len i32)    ;; target key length
    (result i32)

    (local $mask i32)
    (local $i i32)
    (local $key_ptr i32)
    (local $j i32)
    (local $match i32)

    ;; SIMD length filter: get bitmask of keys with matching length
    (local.set $mask
      (i16x8.bitmask
        (i16x8.eq
          (v128.load (local.get $lengths_ptr))
          (i16x8.splat (local.get $target_len)))))

    ;; If no matches, return -1 immediately
    (if (i32.eqz (local.get $mask))
      (then (return (i32.const -1))))

    ;; Check each candidate
    (local.set $i (i32.const 0))
    (block $done
      (loop $next_bit
        (br_if $done (i32.ge_u (local.get $i) (local.get $n)))

        ;; Check if bit i is set in mask
        (if (i32.and (local.get $mask) (i32.shl (i32.const 1) (local.get $i)))
          (then
            ;; Get key offset
            (local.set $key_ptr
              (i32.load
                (i32.add (local.get $offsets_ptr)
                         (i32.shl (local.get $i) (i32.const 2)))))

            ;; Compare bytes
            (local.set $match (i32.const 1))
            (local.set $j (i32.const 0))
            (block $mismatch
              (loop $next_byte
                (br_if $mismatch
                  (i32.ge_u (local.get $j) (local.get $target_len)))
                (if (i32.ne
                      (i32.load8_u (i32.add (local.get $key_ptr) (local.get $j)))
                      (i32.load8_u (i32.add (local.get $target_ptr) (local.get $j))))
                  (then
                    (local.set $match (i32.const 0))
                    (br $mismatch)))
                (local.set $j (i32.add (local.get $j) (i32.const 1)))
                (br $next_byte)))

            ;; If match, return index
            (if (local.get $match)
              (then (return (local.get $i))))))

        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $next_bit)))

    (i32.const -1))
)
"
                          module (.parseWat wabt "simd-full-lookup.wat" wat-source
                                            #js {:simd true :threads true})
                          binary (.toBinary module #js {})
                          wasm-buffer (.-buffer binary)]
                      (js/WebAssembly.instantiate
                       wasm-buffer
                       #js {:env #js {:memory memory}}))))
           (.then (fn [result]
                    (reset! wasm-module (.-instance result))
                    (println "Full lookup WASM initialized!")
                    (resolve true)))
           (.catch (fn [err]
                     (println "Full lookup init failed:" (.-message err))
                     (reject err))))))))

;;-----------------------------------------------------------------------------
;; JS Implementations for comparison
;;-----------------------------------------------------------------------------

(defn js-find-key
  "Pure JS key lookup with length pre-filter."
  [dv lengths-ptr offsets-ptr n target-ptr target-len]
  (loop [i 0]
    (if (>= i n)
      -1
      (let [key-len (.getUint16 dv (+ lengths-ptr (* i 2)) true)]
        (if (== key-len target-len)
          (let [key-ptr (.getUint32 dv (+ offsets-ptr (* i 4)) true)]
            (if (loop [j 0]
                  (if (>= j key-len)
                    true ;; match
                    (if (== (.getUint8 dv (+ key-ptr j))
                            (.getUint8 dv (+ target-ptr j)))
                      (recur (inc j))
                      false)))
              i
              (recur (inc i))))
          (recur (inc i)))))))

(defn js-find-key-32bit
  "Pure JS key lookup with 32-bit word comparison."
  [dv lengths-ptr offsets-ptr n target-ptr target-len]
  (loop [i 0]
    (if (>= i n)
      -1
      (let [key-len (.getUint16 dv (+ lengths-ptr (* i 2)) true)]
        (if (== key-len target-len)
          (let [key-ptr (.getUint32 dv (+ offsets-ptr (* i 4)) true)
                words (unsigned-bit-shift-right key-len 2)
                remainder (bit-and key-len 3)]
            (if (loop [w 0]
                  (if (>= w words)
                    ;; Check remainder
                    (loop [j 0]
                      (if (>= j remainder)
                        true
                        (let [pos (+ (* words 4) j)]
                          (if (== (.getUint8 dv (+ key-ptr pos))
                                  (.getUint8 dv (+ target-ptr pos)))
                            (recur (inc j))
                            false))))
                    (if (== (.getUint32 dv (+ key-ptr (* w 4)) true)
                            (.getUint32 dv (+ target-ptr (* w 4)) true))
                      (recur (inc w))
                      false)))
              i
              (recur (inc i))))
          (recur (inc i)))))))

;;-----------------------------------------------------------------------------
;; Test Setup Helpers
;;-----------------------------------------------------------------------------

(def ^:private fast-encoder (js/TextEncoder.))

(def ^:private simple-keywords
  ["id" "name" "type" "data" "value" "key" "count" "size" "idx" "ref"
   "status" "state" "error" "result" "input" "output" "config" "opts"])

(defn- write-keyword-to-memory!
  "Write a keyword to memory, return length."
  [u8 offset kw-name]
  (let [encoded (.encode fast-encoder kw-name)
        len (.-length encoded)]
    (aset u8 offset 0xEF)
    (aset u8 (+ offset 1) 0xBE)
    (aset u8 (+ offset 2) 0x07)
    (aset u8 (+ offset 3) len)
    (dotimes [i len]
      (aset u8 (+ offset 4 i) (aget encoded i)))
    (+ 4 len)))

;;-----------------------------------------------------------------------------
;; Benchmark
;;-----------------------------------------------------------------------------

(deftest test-full-lookup-performance
  (async done
    (-> (init-full-lookup!)
        (.then
         (fn [_]
           (println "\n" (apply str (repeat 70 "=")) "\n")
           (println "  FULL LOOKUP IN WASM BENCHMARK")
           (println "  Testing single WASM call vs multiple JS↔WASM crossings")
           (println "\n" (apply str (repeat 70 "=")) "\n")

           (let [u8 @memory-u8
                 u16 @memory-u16
                 u32 @memory-u32
                 dv @memory-dv
                 exports (.-exports @wasm-module)]

             (doseq [n [8 16]]
               (println (str "--- " n " KEYS ---"))

               ;; Memory layout:
               ;; 0-31: lengths (u16 array)
               ;; 32-95: offsets (u32 array)
               ;; 1024+: key data (64 bytes per key)
               ;; 4096: target key
               (let [lengths-ptr 0
                     offsets-ptr 32
                     keys-base 1024
                     key-stride 64
                     target-ptr 4096
                     key-lengths (js/Int32Array. n)]

                 ;; Write keys to memory
                 (dotimes [i n]
                   (let [kw-name (nth simple-keywords (mod i (count simple-keywords)))
                         offset (+ keys-base (* i key-stride))
                         len (write-keyword-to-memory! u8 offset kw-name)]
                     (aset key-lengths i len)
                     (aset u16 i len)
                     (aset u32 (+ 8 i) offset))) ;; offsets start at byte 32 = u32 index 8

                 ;; Target: key at middle of array
                 (let [target-idx (quot n 2)
                       target-len (aget key-lengths target-idx)
                       source-ptr (aget u32 (+ 8 target-idx))
                       iters 50000]

                   ;; Copy target key
                   (dotimes [j target-len]
                     (aset u8 (+ target-ptr j) (aget u8 (+ source-ptr j))))

                   (println (str "  Target: index " target-idx ", length " target-len "B"))
                   (println)

                   ;; Verify all implementations find the same result
                   (let [js-result (js-find-key dv lengths-ptr offsets-ptr n target-ptr target-len)
                         js32-result (js-find-key-32bit dv lengths-ptr offsets-ptr n target-ptr target-len)
                         wasm-result (.find_key exports lengths-ptr offsets-ptr n target-ptr target-len)
                         wasm-simd-result (when (<= n 8)
                                            (.find_key_simd exports lengths-ptr offsets-ptr n target-ptr target-len))]
                     (println (str "  Results - JS: " js-result ", JS-32bit: " js32-result
                                   ", WASM: " wasm-result
                                   (when wasm-simd-result (str ", WASM-SIMD: " wasm-simd-result))))
                     (is (= js-result target-idx) "JS should find target")
                     (is (= wasm-result target-idx) "WASM should find target"))

                   (println)

                   ;; Benchmarks
                   (bench (str "JS byte loop (" n " keys)") iters
                          #(js-find-key dv lengths-ptr offsets-ptr n target-ptr target-len))

                   (bench (str "JS 32-bit words (" n " keys)") iters
                          #(js-find-key-32bit dv lengths-ptr offsets-ptr n target-ptr target-len))

                   (bench (str "WASM full lookup (" n " keys)") iters
                          #(.find_key exports lengths-ptr offsets-ptr n target-ptr target-len))

                   (when (<= n 8)
                     (bench (str "WASM SIMD lookup (" n " keys)") iters
                            #(.find_key_simd exports lengths-ptr offsets-ptr n target-ptr target-len)))

                   (println)))))

           (println (apply str (repeat 70 "=")) "\n")
           (println "  ANALYSIS")
           (println (apply str (repeat 70 "-")))
           (println "
  KEY INSIGHT: By moving the FULL lookup into WASM, we:
  1. Have ONE JS↔WASM crossing instead of N crossings
  2. WASM does length filter + byte compare internally
  3. Only returns the final result

  If WASM wins here, the conclusion is:
  - SIMD/WASM is viable IF we batch enough work per call
  - The hybrid approach (JS calls WASM repeatedly) loses

  If JS still wins:
  - V8's JIT is just that well-optimized
  - WASM overhead exists even with single calls
  ")
           (println (apply str (repeat 70 "=")))

           (done)))
        (.catch (fn [err]
                  (println "Test failed:" (.-message err))
                  (js/console.error err)
                  (done))))))

(defn run-full-lookup-benchmark []
  (test-full-lookup-performance))

(ns com.seniorcaremarket.eve-sab-deftype.simd-hash-test
  "Test SIMD with hash-based pre-filtering.

   APPROACH: Store 32-bit hash per key, compare 4 hashes at once using i32x4.eq

   Why hash pre-filtering could win:
   ────────────────────────────────────────────────────────────────────
   1. Compare 4 × 32-bit hashes in one v128 operation
   2. Hash match is rare (good hash → few collisions)
   3. Only byte-compare on hash collision (O(1) expected lookups)
   4. Amortizes setup cost over typical map access patterns

   Memory Layout:
   ────────────────────────────────────────────────────────────────────
   [hashes:i32[N]][lengths:u16[N]][offsets:u32[N]][key_data...]

   WASM Functions:
   - find_by_hash_scalar: Linear hash scan, byte compare on match
   - find_by_hash_simd: SIMD 4-wide hash comparison, then verify

   BENCHMARK RESULTS:
   ══════════════════════════════════════════════════════════════════
   8 keys:  JS 5.6M → WASM 32M (5.7x) → SIMD 39M (7.0x faster)
   16 keys: JS 14M → WASM 46M (3.2x) → SIMD 44M (3.1x faster)
   32 keys: JS 27M → WASM 64M (2.4x) → SIMD 83M (3.1x faster)

   CONCLUSION: Hash-based WASM lookup is 2-7x faster than pure JS!
   ══════════════════════════════════════════════════════════════════"
  (:require
   [cljs.test :refer [deftest is testing async]]))

(defn now [] (js/performance.now))

(defn bench [label iterations f]
  (dotimes [_ 100] (f))
  (let [start (now)]
    (dotimes [_ iterations] (f))
    (let [dur (- (now) start)
          ops-sec (/ (* iterations 1000) dur)]
      (println (str "  " label ": " (.toFixed dur 2) "ms, "
                    (.toFixed ops-sec 0) " ops/sec"))
      {:label label :duration-ms dur :ops-sec ops-sec})))

;;-----------------------------------------------------------------------------
;; WASM Module with Hash-Based Lookup
;;-----------------------------------------------------------------------------

(defonce ^:private wasm-module (atom nil))
(defonce ^:private shared-memory (atom nil))
(defonce ^:private memory-u8 (atom nil))
(defonce ^:private memory-u16 (atom nil))
(defonce ^:private memory-u32 (atom nil))
(defonce ^:private memory-i32 (atom nil))
(defonce ^:private memory-dv (atom nil))

(defn init-hash-lookup!
  "Initialize WASM with hash-based lookup functions."
  []
  (js/Promise.
   (fn [resolve reject]
     (let [memory (js/WebAssembly.Memory.
                   #js {:initial 1
                        :maximum 100
                        :shared true})]
       (reset! shared-memory memory)
       (reset! memory-u8 (js/Uint8Array. (.-buffer memory)))
       (reset! memory-u16 (js/Uint16Array. (.-buffer memory)))
       (reset! memory-u32 (js/Uint32Array. (.-buffer memory)))
       (reset! memory-i32 (js/Int32Array. (.-buffer memory)))
       (reset! memory-dv (js/DataView. (.-buffer memory)))

       (-> (js/Promise.resolve (js/require "wabt"))
           (.then (fn [wabt-factory] (wabt-factory)))
           (.then (fn [wabt]
                    (let [wat-source "
(module
  (import \"env\" \"memory\" (memory 1 100 shared))

  ;; Helper: verify key at index matches target
  ;; Returns 1 if match, 0 if no match
  (func $verify_key
    (param $lengths_ptr i32)
    (param $offsets_ptr i32)
    (param $target_ptr i32)
    (param $target_len i32)
    (param $idx i32)
    (result i32)

    (local $key_len i32)
    (local $key_ptr i32)
    (local $j i32)

    ;; Check length
    (local.set $key_len
      (i32.load16_u
        (i32.add (local.get $lengths_ptr)
                 (i32.shl (local.get $idx) (i32.const 1)))))

    ;; Early exit if lengths don't match
    (if (i32.ne (local.get $key_len) (local.get $target_len))
      (then (return (i32.const 0))))

    ;; Length matches - compare bytes
    (local.set $key_ptr
      (i32.load
        (i32.add (local.get $offsets_ptr)
                 (i32.shl (local.get $idx) (i32.const 2)))))

    ;; Compare each byte
    (local.set $j (i32.const 0))
    (block $done
      (loop $next_byte
        ;; If we've compared all bytes, we matched!
        (br_if $done (i32.ge_u (local.get $j) (local.get $key_len)))
        ;; If bytes differ, return 0
        (if (i32.ne
              (i32.load8_u (i32.add (local.get $key_ptr) (local.get $j)))
              (i32.load8_u (i32.add (local.get $target_ptr) (local.get $j))))
          (then (return (i32.const 0))))
        (local.set $j (i32.add (local.get $j) (i32.const 1)))
        (br $next_byte)))
    ;; All bytes matched
    (i32.const 1))

  ;; HASH-BASED LOOKUP - SCALAR VERSION
  (func (export \"find_by_hash_scalar\")
    (param $hashes_ptr i32)
    (param $lengths_ptr i32)
    (param $offsets_ptr i32)
    (param $n i32)
    (param $target_ptr i32)
    (param $target_len i32)
    (param $target_hash i32)
    (result i32)

    (local $i i32)
    (local $key_hash i32)

    (local.set $i (i32.const 0))
    (block $done (result i32)
      (loop $next_key
        (br_if $done (i32.const -1) (i32.ge_u (local.get $i) (local.get $n)))

        ;; Get hash at index i
        (local.set $key_hash
          (i32.load
            (i32.add (local.get $hashes_ptr)
                     (i32.shl (local.get $i) (i32.const 2)))))

        ;; Quick hash check
        (if (i32.eq (local.get $key_hash) (local.get $target_hash))
          (then
            ;; Verify key bytes
            (if (call $verify_key
                      (local.get $lengths_ptr)
                      (local.get $offsets_ptr)
                      (local.get $target_ptr)
                      (local.get $target_len)
                      (local.get $i))
              (then (br $done (local.get $i))))))

        (local.set $i (i32.add (local.get $i) (i32.const 1)))
        (br $next_key))
      (i32.const -1)))

  ;; HASH-BASED LOOKUP - SIMD VERSION (4 hashes at once)
  (func (export \"find_by_hash_simd\")
    (param $hashes_ptr i32)
    (param $lengths_ptr i32)
    (param $offsets_ptr i32)
    (param $n i32)
    (param $target_ptr i32)
    (param $target_len i32)
    (param $target_hash i32)
    (result i32)

    (local $i i32)
    (local $mask i32)
    (local $target_vec v128)
    (local $idx i32)

    ;; Splat target hash into v128 (4 copies)
    (local.set $target_vec (i32x4.splat (local.get $target_hash)))

    ;; Process 4 hashes at a time
    (local.set $i (i32.const 0))
    (block $done (result i32)
      (loop $next_batch
        (br_if $done (i32.const -1) (i32.ge_u (local.get $i) (local.get $n)))

        ;; Compare 4 hashes with SIMD
        (local.set $mask
          (i32x4.bitmask
            (i32x4.eq
              (v128.load
                (i32.add (local.get $hashes_ptr)
                         (i32.shl (local.get $i) (i32.const 2))))
              (local.get $target_vec))))

        ;; Check bit 0
        (if (i32.and (local.get $mask) (i32.const 1))
          (then
            (local.set $idx (local.get $i))
            (if (i32.and (i32.lt_u (local.get $idx) (local.get $n))
                         (call $verify_key
                               (local.get $lengths_ptr) (local.get $offsets_ptr)
                               (local.get $target_ptr) (local.get $target_len)
                               (local.get $idx)))
              (then (br $done (local.get $idx))))))

        ;; Check bit 1
        (if (i32.and (local.get $mask) (i32.const 2))
          (then
            (local.set $idx (i32.add (local.get $i) (i32.const 1)))
            (if (i32.and (i32.lt_u (local.get $idx) (local.get $n))
                         (call $verify_key
                               (local.get $lengths_ptr) (local.get $offsets_ptr)
                               (local.get $target_ptr) (local.get $target_len)
                               (local.get $idx)))
              (then (br $done (local.get $idx))))))

        ;; Check bit 2
        (if (i32.and (local.get $mask) (i32.const 4))
          (then
            (local.set $idx (i32.add (local.get $i) (i32.const 2)))
            (if (i32.and (i32.lt_u (local.get $idx) (local.get $n))
                         (call $verify_key
                               (local.get $lengths_ptr) (local.get $offsets_ptr)
                               (local.get $target_ptr) (local.get $target_len)
                               (local.get $idx)))
              (then (br $done (local.get $idx))))))

        ;; Check bit 3
        (if (i32.and (local.get $mask) (i32.const 8))
          (then
            (local.set $idx (i32.add (local.get $i) (i32.const 3)))
            (if (i32.and (i32.lt_u (local.get $idx) (local.get $n))
                         (call $verify_key
                               (local.get $lengths_ptr) (local.get $offsets_ptr)
                               (local.get $target_ptr) (local.get $target_len)
                               (local.get $idx)))
              (then (br $done (local.get $idx))))))

        ;; Next batch of 4
        (local.set $i (i32.add (local.get $i) (i32.const 4)))
        (br $next_batch))
      (i32.const -1)))
)
"
                          module (.parseWat wabt "simd-hash.wat" wat-source
                                            #js {:simd true :threads true})
                          binary (.toBinary module #js {})
                          wasm-buffer (.-buffer binary)]
                      (js/WebAssembly.instantiate
                       wasm-buffer
                       #js {:env #js {:memory memory}}))))
           (.then (fn [result]
                    (reset! wasm-module (.-instance result))
                    (println "Hash-based lookup WASM initialized!")
                    (resolve true)))
           (.catch (fn [err]
                     (println "Hash init failed:" (.-message err))
                     (reject err))))))))

;;-----------------------------------------------------------------------------
;; FNV-1a Hash (simple, fast)
;;-----------------------------------------------------------------------------

(defn fnv1a-hash
  "FNV-1a 32-bit hash for key bytes."
  [^js bytes]
  (let [len (.-length bytes)]
    (loop [i 0 h (bit-and 0x811c9dc5 0xFFFFFFFF)]
      (if (>= i len)
        h
        (recur (inc i)
               (let [h' (bit-xor h (aget bytes i))]
                 (bit-and (imul h' 0x01000193) 0xFFFFFFFF)))))))

;;-----------------------------------------------------------------------------
;; JS Implementations for comparison
;;-----------------------------------------------------------------------------

(defn js-find-by-hash
  "Pure JS hash-based lookup."
  [dv hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash]
  (loop [i 0]
    (if (>= i n)
      -1
      (let [key-hash (.getInt32 dv (+ hashes-ptr (* i 4)) true)]
        (if (== key-hash target-hash)
          (let [key-len (.getUint16 dv (+ lengths-ptr (* i 2)) true)]
            (if (== key-len target-len)
              (let [key-ptr (.getUint32 dv (+ offsets-ptr (* i 4)) true)]
                (if (loop [j 0]
                      (if (>= j key-len)
                        true
                        (if (== (.getUint8 dv (+ key-ptr j))
                                (.getUint8 dv (+ target-ptr j)))
                          (recur (inc j))
                          false)))
                  i
                  (recur (inc i))))
              (recur (inc i))))
          (recur (inc i)))))))

;;-----------------------------------------------------------------------------
;; Test Data Setup
;;-----------------------------------------------------------------------------

(def ^:private fast-encoder (js/TextEncoder.))

(def ^:private realistic-keys
  "Mix of realistic Clojure key types."
  [":id" ":name" ":type" ":status" ":user/id" ":user/email" ":db/type"
   "config-key" "api-endpoint" "session-token" ":order/total" ":product/sku"
   ":created-at" ":updated-at" "cache-entry" ":app/version"])

(defn- write-keyword-to-memory!
  "Write a keyword-like string to memory, return length."
  [u8 offset kw-str]
  (let [encoded (.encode fast-encoder kw-str)
        len (.-length encoded)]
    (dotimes [i len]
      (aset u8 (+ offset i) (aget encoded i)))
    len))

;;-----------------------------------------------------------------------------
;; Benchmark
;;-----------------------------------------------------------------------------

(deftest test-hash-based-lookup
  (async done
    (-> (init-hash-lookup!)
        (.then
         (fn [_]
           (println "\n" (apply str (repeat 70 "=")) "\n")
           (println "  HASH-BASED PRE-FILTERING BENCHMARK")
           (println "  Compare 4 hashes at once using i32x4.eq")
           (println "\n" (apply str (repeat 70 "=")) "\n")

           (let [u8 @memory-u8
                 i32 @memory-i32
                 u16 @memory-u16
                 u32 @memory-u32
                 dv @memory-dv
                 exports (.-exports @wasm-module)]

             (doseq [n [8 16 32]]
               (println (str "--- " n " KEYS ---"))

               ;; Memory layout:
               ;; 0-127: hashes (i32 array, 4 bytes each)
               ;; 128-191: lengths (u16 array, 2 bytes each)
               ;; 192-319: offsets (u32 array, 4 bytes each)
               ;; 1024+: key data (64 bytes per key)
               ;; 8192: target key
               (let [hashes-ptr 0
                     lengths-ptr 128
                     offsets-ptr 192
                     keys-base 1024
                     key-stride 64
                     target-ptr 8192
                     key-bytes-array (make-array n)]

                 ;; Write keys to memory
                 (dotimes [i n]
                   (let [kw-str (nth realistic-keys (mod i (count realistic-keys)))
                         offset (+ keys-base (* i key-stride))
                         len (write-keyword-to-memory! u8 offset kw-str)
                         key-slice (js/Uint8Array. (.-buffer @shared-memory) offset len)
                         h (fnv1a-hash key-slice)]
                     (aset key-bytes-array i key-slice)
                     ;; Store hash
                     (aset i32 (unsigned-bit-shift-right (+ hashes-ptr (* i 4)) 2) h)
                     ;; Store length
                     (aset u16 (unsigned-bit-shift-right (+ lengths-ptr (* i 2)) 1) len)
                     ;; Store offset
                     (aset u32 (unsigned-bit-shift-right (+ offsets-ptr (* i 4)) 2) offset)))

                 ;; Target: key at middle of array
                 (let [target-idx (quot n 2)
                       target-key-bytes (aget key-bytes-array target-idx)
                       target-len (.-length target-key-bytes)
                       ;; Read hash directly from stored array to ensure match
                       target-hash (aget i32 (unsigned-bit-shift-right (+ hashes-ptr (* target-idx 4)) 2))
                       source-ptr (aget u32 (unsigned-bit-shift-right (+ offsets-ptr (* target-idx 4)) 2))
                       iters 100000]

                   ;; Copy target key to target location
                   (dotimes [j target-len]
                     (aset u8 (+ target-ptr j) (aget u8 (+ source-ptr j))))

                   (println (str "  Target: index " target-idx ", length " target-len "B"))
                   (println)

                   ;; Verify all implementations find the same result
                   (let [js-result (js-find-by-hash dv hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash)
                         wasm-scalar (.find_by_hash_scalar exports hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash)
                         wasm-simd (.find_by_hash_simd exports hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash)]
                     (println (str "  Results - JS: " js-result ", WASM-scalar: " wasm-scalar ", WASM-SIMD: " wasm-simd))
                     (is (= js-result target-idx) "JS should find target")
                     (is (= wasm-scalar target-idx) "WASM scalar should find target")
                     (is (= wasm-simd target-idx) "WASM SIMD should find target"))

                   (println)

                   ;; Benchmarks
                   (bench (str "JS hash lookup (" n " keys)") iters
                          #(js-find-by-hash dv hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash))

                   (bench (str "WASM hash scalar (" n " keys)") iters
                          #(.find_by_hash_scalar exports hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash))

                   (bench (str "WASM hash SIMD (" n " keys)") iters
                          #(.find_by_hash_simd exports hashes-ptr lengths-ptr offsets-ptr n target-ptr target-len target-hash))

                   (println)))))

           (println (apply str (repeat 70 "=")) "\n")
           (println "  ANALYSIS")
           (println (apply str (repeat 70 "-")))
           (println "
  HASH-BASED PRE-FILTERING:
  1. Compare 4 hashes at once using i32x4.eq
  2. Only byte-compare on hash match (rare for good hash)
  3. Reduces byte comparisons dramatically

  vs FULL LENGTH-FIRST LOOKUP:
  - Hash comparison: 4 bytes fixed vs variable key length
  - Hash is computed once at insert, not on every lookup
  - Collision rate: ~1/2^32 for good 32-bit hash

  EXPECTED OUTCOME:
  - If keys have similar lengths: hash wins (skip byte compare)
  - If keys have distinct lengths: length filter may win
  - Hash always O(1) filtering cost; length is O(n/8) with SIMD
  ")
           (println (apply str (repeat 70 "=")))

           (done)))
        (.catch (fn [err]
                  (println "Test failed:" (.-message err))
                  (js/console.error err)
                  (done))))))

(defn run-hash-benchmark []
  (test-hash-based-lookup))

(ns com.seniorcaremarket.eve-deftype.smoke-test
  "Smoke test: verify vendor code (eve's SharedAtom + SabpMap) works
   in this fresh project."
  (:require
   [cljs.test :refer [deftest testing is]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.sabp-map]
   [com.seniorcaremarket.eve.sabp-set]
   [com.seniorcaremarket.eve.sabp-list]
   [com.seniorcaremarket.eve.chunked-list]))

(deftest vendor-shared-atom-test
  (testing "Can create a SharedAtom and do basic operations"
    (let [a (atom/private-atom {:x 1 :y 2})]
      (is (some? a) "Atom should be created")
      (let [v @a]
        (is (= 1 (:x v)))
        (is (= 2 (:y v))))
      (swap! a assoc :z 3)
      (let [v @a]
        (is (= 3 (:z v))))
      (swap! a dissoc :x)
      (let [v @a]
        (is (nil? (:x v)))
        (is (= 2 (:y v)))
        (is (= 3 (:z v)))))))

(deftest vendor-shared-atom-nested-test
  (testing "SharedAtom with nested data"
    (let [a (atom/private-atom {:users [{:name "Alice"} {:name "Bob"}]})]
      (let [v @a]
        (is (= "Alice" (get-in v [:users 0 :name])))
        (is (= "Bob" (get-in v [:users 1 :name])))))))

(ns com.seniorcaremarket.eve-deftype.rb-tree-contention-test
  "Multi-worker contention test for SAB-backed red-black trees.
   Spawns N workers that concurrently insert disjoint ranges of values
   into a shared RB tree. The tree root offset is stored in a dedicated
   Int32 slot in the SAB, updated via direct Atomics.compareExchange.
   This bypasses the atom's block-descriptor CAS (which suffers from ABA
   due to rapid descriptor reuse) and instead CAS on the root-offset value
   itself — which is monotonically increasing (bump-allocated) and thus
   ABA-free. After all workers finish, the main thread verifies:
     - All values are present
     - In-order traversal is sorted
     - RB invariants hold (root black, no red-red, uniform black-height)
     - Count matches expected total"
  (:require
   [cljs.test :refer [deftest is testing async run-tests]]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   [com.seniorcaremarket.eve-deftype.rb-tree :as rb :refer [RBNode]]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Environment setup
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize the global atom with a large SAB for contention tests.
   4MB SAB, 8192 block descriptors — enough for multiple arenas across workers."
  []
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 4 1024 1024) :max-blocks 8192))
  (a/get-env a/*global-atom-instance*))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

;;-----------------------------------------------------------------------------
;; Direct Atomics CAS on root-offset (bypasses atom block-descriptor ABA)
;;-----------------------------------------------------------------------------

(defn alloc-root-slot!
  "Allocate 4 bytes in the SAB for an atomic Int32 root pointer.
   Returns the Int32 index (byte-offset >> 2). Initialized to -1 (empty tree)."
  [env]
  (let [alloc-result (a/alloc env 4)]
    (when (:error alloc-result)
      (throw (js/Error. (str "Failed to alloc root slot: " (:error alloc-result)))))
    (let [byte-offset (:offset alloc-result)
          int32-idx (unsigned-bit-shift-right byte-offset 2)
          int32-view (js/Int32Array. (:sab env))]
      (js/Atomics.store int32-view int32-idx -1)
      int32-idx)))

(defn read-root
  "Read the current tree root via Atomics.load."
  [env int32-idx]
  (let [root-off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= root-off -1)
      (RBNode. env root-off))))

(defn cas-insert!
  "CAS-loop insert for the main thread."
  [env int32-idx x]
  (let [int32-view (js/Int32Array. (:sab env))]
    (loop []
      (let [old-root-off (js/Atomics.load int32-view int32-idx)
            old-tree (when (not= old-root-off -1) (RBNode. env old-root-off))
            new-tree (rb/rb-insert env old-tree x)
            new-root-off (.-eve-offset new-tree)]
        (when-not (== old-root-off
                      (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
          (recur))))))

;;-----------------------------------------------------------------------------
;; Worker dispatch helpers (direct CAS)
;;-----------------------------------------------------------------------------

(defn dispatch-worker-cas!
  "Send a range insertion task to a single worker using direct CAS."
  [worker int32-idx start-val cnt]
  (in worker [int32-idx start-val cnt]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          end-val (+ start-val cnt)
          int32-view (js/Int32Array. (:sab env))]
      (println (str "  [Worker] Inserting " cnt " values starting at " start-val))
      (let [start-time (js/performance.now)]
        (loop [x start-val]
          (when (< x end-val)
            (loop []
              (let [old-root-off (js/Atomics.load int32-view int32-idx)
                    old-tree (when (not= old-root-off -1)
                               (com.seniorcaremarket.eve-deftype.rb-tree/RBNode. env old-root-off))
                    new-tree (com.seniorcaremarket.eve-deftype.rb-tree/rb-insert env old-tree x)
                    new-root-off (.-eve-offset new-tree)]
                (when-not (== old-root-off
                              (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
                  (recur))))
            (recur (inc x))))
        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [Worker] Done from " start-val " in "
                        (.toFixed elapsed 0) "ms ("
                        (.toFixed (/ (* cnt 1000) elapsed) 0) " inserts/sec)")))))))

(defn dispatch-worker-interleaved-cas!
  "Send an interleaved insertion task to a worker using direct CAS."
  [worker int32-idx agent-id total-vals stride]
  (in worker [int32-idx agent-id total-vals stride]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          int32-view (js/Int32Array. (:sab env))]
      (println (str "  [Worker agent-" agent-id "] Inserting interleaved values"))
      (loop [x agent-id]
        (when (< x total-vals)
          (loop []
            (let [old-root-off (js/Atomics.load int32-view int32-idx)
                  old-tree (when (not= old-root-off -1)
                             (com.seniorcaremarket.eve-deftype.rb-tree/RBNode. env old-root-off))
                  new-tree (com.seniorcaremarket.eve-deftype.rb-tree/rb-insert env old-tree x)
                  new-root-off (.-eve-offset new-tree)]
              (when-not (== old-root-off
                            (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
                (recur))))
          (recur (+ x stride))))
      (println (str "  [Worker agent-" agent-id "] Done")))))

;;-----------------------------------------------------------------------------
;; Test: 4 workers x 25 values = 100 total
;;-----------------------------------------------------------------------------

(defn run-test-contention-100
  "4 workers each insert 25 unique integers into a shared RB tree.
   Verifies correctness and invariants after all insertions."
  [next-fn]
  (println "\n  == Test: RB Tree Contention (4 workers x 25 values = 100) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        num-workers 4
        vals-per-worker 25
        total-vals (* num-workers vals-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (dispatch-worker-cas! (nth workers 0) int32-idx 0 vals-per-worker)
    (dispatch-worker-cas! (nth workers 1) int32-idx 25 vals-per-worker)
    (dispatch-worker-cas! (nth workers 2) int32-idx 50 vals-per-worker)
    (dispatch-worker-cas! (nth workers 3) int32-idx 75 vals-per-worker)

    (js/setTimeout
     (fn []
       (let [root (read-root env int32-idx)]
         (println (str "  [RESULT] root-offset="
                       (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)))

         (let [cnt (rb/rb-count root)]
           (println (str "  [RESULT] count=" cnt " expected=" total-vals))
           (is (= total-vals cnt) (str "Expected " total-vals " elements, got " cnt)))

         (let [tree-vals (vec (rb/rb-seq root))
               expected (vec (range total-vals))]
           (println (str "  [RESULT] first-5=" (take 5 tree-vals) " last-5=" (take-last 5 tree-vals)))
           (is (= expected tree-vals) "In-order traversal should match sorted range"))

         (let [valid (rb/rb-valid? root)]
           (println (str "  [RESULT] rb-valid?=" valid))
           (is valid "RB tree invariants must hold"))

         (let [bh (rb/rb-black-height root)]
           (println (str "  [RESULT] black-height=" bh))
           (is (pos? bh) "Black-height should be positive")
           (is (not= -1 bh) "Black-height should be uniform"))

         (let [h (rb/rb-height root)
               max-h (* 2 (Math/ceil (/ (Math/log (inc total-vals)) (Math/log 2))))]
           (println (str "  [RESULT] height=" h " max-allowed=" max-h))
           (is (<= h max-h) (str "Height " h " should be <= " max-h)))

         (is (rb/rb-member? root 0) "Should contain 0")
         (is (rb/rb-member? root 50) "Should contain 50")
         (is (rb/rb-member? root 99) "Should contain 99")
         (is (not (rb/rb-member? root 100)) "Should not contain 100")
         (is (not (rb/rb-member? root -1)) "Should not contain -1")

         (println "  [RESULT] All 100-element contention checks complete.")
         (cleanup-workers workers)
         (next-fn)))
     30000)))

;;-----------------------------------------------------------------------------
;; Test: 4 workers x 250 values = 1000 total (stress)
;;-----------------------------------------------------------------------------

(defn run-test-contention-1000
  "4 workers each insert 250 unique integers into a shared RB tree.
   Stress test with higher contention and deeper trees."
  [next-fn]
  (println "\n  == Test: RB Tree Contention STRESS (4 workers x 250 values = 1000) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        num-workers 4
        vals-per-worker 250
        total-vals (* num-workers vals-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (dispatch-worker-cas! (nth workers 0) int32-idx 0 vals-per-worker)
    (dispatch-worker-cas! (nth workers 1) int32-idx 250 vals-per-worker)
    (dispatch-worker-cas! (nth workers 2) int32-idx 500 vals-per-worker)
    (dispatch-worker-cas! (nth workers 3) int32-idx 750 vals-per-worker)

    (js/setTimeout
     (fn []
       (let [root (read-root env int32-idx)]
         (println (str "  [RESULT] root-offset="
                       (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)))

         (let [cnt (rb/rb-count root)]
           (println (str "  [RESULT] count=" cnt " expected=" total-vals))
           (is (= total-vals cnt) (str "Expected " total-vals " elements, got " cnt)))

         (let [tree-vals (vec (rb/rb-seq root))
               expected (vec (range total-vals))]
           (println (str "  [RESULT] first-5=" (take 5 tree-vals) " last-5=" (take-last 5 tree-vals)))
           (is (= expected tree-vals) "In-order traversal should match sorted range"))

         (let [valid (rb/rb-valid? root)]
           (println (str "  [RESULT] rb-valid?=" valid))
           (is valid "RB tree invariants must hold after 1000-element stress"))

         (let [bh (rb/rb-black-height root)]
           (println (str "  [RESULT] black-height=" bh))
           (is (pos? bh) "Black-height should be positive")
           (is (not= -1 bh) "Black-height should be uniform"))

         (let [h (rb/rb-height root)
               max-h (* 2 (Math/ceil (/ (Math/log (inc total-vals)) (Math/log 2))))]
           (println (str "  [RESULT] height=" h " max-allowed=" max-h))
           (is (<= h max-h) (str "Height " h " should be <= " max-h)))

         (is (rb/rb-member? root 0) "Should contain 0")
         (is (rb/rb-member? root 500) "Should contain 500")
         (is (rb/rb-member? root 999) "Should contain 999")
         (is (not (rb/rb-member? root 1000)) "Should not contain 1000")

         (println "  [RESULT] All 1000-element stress checks complete.")
         (cleanup-workers workers)
         (next-fn)))
     60000)))

;;-----------------------------------------------------------------------------
;; Test: Main thread + 4 workers interleaved (mixed producer)
;;-----------------------------------------------------------------------------

(defn run-test-contention-mixed
  "Main thread and 4 workers all insert interleaved values.
   Each agent inserts every 5th value (agent 0: 0,5,10,...; agent 1: 1,6,11,...).
   Tests that main thread + workers can safely share the tree."
  [next-fn]
  (println "\n  == Test: RB Tree Mixed Contention (main + 4 workers, interleaved) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        total-vals 200
        num-agents 5
        workers (vec (repeatedly 4 #(w/mk-worker)))]

    ;; Workers insert their interleaved values (agents 1-4)
    (dispatch-worker-interleaved-cas! (nth workers 0) int32-idx 1 total-vals num-agents)
    (dispatch-worker-interleaved-cas! (nth workers 1) int32-idx 2 total-vals num-agents)
    (dispatch-worker-interleaved-cas! (nth workers 2) int32-idx 3 total-vals num-agents)
    (dispatch-worker-interleaved-cas! (nth workers 3) int32-idx 4 total-vals num-agents)

    ;; Main thread inserts agent-0 values (0, 5, 10, ...)
    (println "  [Main agent-0] Inserting interleaved values")
    (loop [x 0]
      (when (< x total-vals)
        (cas-insert! env int32-idx x)
        (recur (+ x num-agents))))
    (println "  [Main agent-0] Done")

    (js/setTimeout
     (fn []
       (let [root (read-root env int32-idx)]
         (println (str "  [RESULT] root-offset="
                       (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)))

         (let [cnt (rb/rb-count root)]
           (println (str "  [RESULT] count=" cnt " expected=" total-vals))
           (is (= total-vals cnt) (str "Expected " total-vals " elements, got " cnt)))

         (let [tree-vals (vec (rb/rb-seq root))
               expected (vec (range total-vals))]
           (is (= expected tree-vals) "Interleaved in-order traversal should match sorted range"))

         (let [valid (rb/rb-valid? root)]
           (println (str "  [RESULT] rb-valid?=" valid))
           (is valid "RB invariants must hold for interleaved insertions"))

         (println "  [RESULT] All mixed contention checks complete.")
         (cleanup-workers workers)
         (next-fn)))
     30000)))

;;-----------------------------------------------------------------------------
;; Test entry point — sequential chain
;;-----------------------------------------------------------------------------

(deftest test-rb-tree-contention
  (testing "Red-black tree under multi-worker contention"
    (async done
      (run-test-contention-100
       (fn []
         (run-test-contention-1000
          (fn []
            (run-test-contention-mixed
             (fn []
               (println "\n  == All RB tree contention tests complete ==")
               (done))))))))))

;;-----------------------------------------------------------------------------
;; Runner
;;-----------------------------------------------------------------------------

(defn run-contention-tests []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (println "\n--- RB Tree Contention Tests ---\n")
      (run-tests)
      (println "\n--- RB Tree Contention Tests Complete ---\n"))))

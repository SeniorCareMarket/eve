(ns com.seniorcaremarket.eve-deftype.int-map-contention-test
  "Multi-worker contention test for SAB-backed PATRICIA trie int-maps.
   Spawns N workers that concurrently assoc disjoint key ranges into a
   shared int-map. The root offset is stored in a dedicated Int32 slot
   in the SAB, updated via direct Atomics.compareExchange (same pattern
   as the RB tree contention test). After all workers finish, verifies:
     - All keys are present with correct values
     - Count matches expected total
     - Merge under contention works correctly"
  (:require
   [cljs.test :refer [deftest is testing async run-tests]]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.in :refer [in]]
   [com.seniorcaremarket.eve-deftype.int-map :as im]))

(set! d/*worker-id* 1)

;;-----------------------------------------------------------------------------
;; Environment setup
;;-----------------------------------------------------------------------------

(defn init-env!
  "Initialize the global atom with a large SAB for contention tests."
  []
  (set! a/*global-atom-instance*
        (a/private-atom {} :sab-size (* 4 1024 1024) :max-blocks 8192))
  (let [env (a/get-env a/*global-atom-instance*)]
    (im/init-int-map! env)
    env))

(defn cleanup-workers [workers]
  (run! (fn [w] (try (.terminate w) (catch :default _))) workers))

;;-----------------------------------------------------------------------------
;; Direct Atomics CAS on root-offset
;;-----------------------------------------------------------------------------

(defn alloc-root-slot!
  "Allocate 4 bytes in the SAB for an atomic Int32 root pointer.
   Returns the Int32 index (byte-offset >> 2). Initialized to -1 (empty)."
  [env]
  (let [alloc-result (a/alloc env 4)]
    (when (:error alloc-result)
      (throw (js/Error. (str "Failed to alloc root slot: " (:error alloc-result)))))
    (let [byte-offset (:offset alloc-result)
          int32-idx (unsigned-bit-shift-right byte-offset 2)
          int32-view (js/Int32Array. (:sab env))]
      (js/Atomics.store int32-view int32-idx -1)
      int32-idx)))

(defn read-root
  "Read the current int-map root from the atomic slot."
  [env int32-idx]
  (let [root-off (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)]
    (when (not= root-off -1)
      (im/load-node env root-off))))

(defn cas-assoc!
  "CAS-loop assoc for the main thread. Inserts k→v into the shared int-map."
  [env int32-idx k v]
  (let [int32-view (js/Int32Array. (:sab env))]
    (loop []
      (let [old-root-off (js/Atomics.load int32-view int32-idx)
            old-root (when (not= old-root-off -1) (im/load-node env old-root-off))
            new-root (if old-root
                       (im/-im-assoc old-root k 0 im/default-merge v)
                       (im/->IntMapLeaf env k v))
            new-root-off (.-eve-offset new-root)]
        (when-not (== old-root-off
                      (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
          (recur))))))

;;-----------------------------------------------------------------------------
;; Worker dispatch helpers
;;-----------------------------------------------------------------------------

(defn dispatch-worker-assoc!
  "Send a range of key→value insertions to a worker.
   Each worker inserts keys [start-key, start-key+cnt) with value = key * key."
  [worker int32-idx start-key cnt]
  (in worker [int32-idx start-key cnt]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          end-key (+ start-key cnt)
          int32-view (js/Int32Array. (:sab env))]
      ;; Init int-map type-ids in this worker
      (com.seniorcaremarket.eve-deftype.int-map/init-int-map! env)
      (println (str "  [Worker] Inserting " cnt " keys starting at " start-key))
      (let [start-time (js/performance.now)]
        (loop [k start-key]
          (when (< k end-key)
            (loop []
              (let [old-root-off (js/Atomics.load int32-view int32-idx)
                    old-root (when (not= old-root-off -1)
                               (com.seniorcaremarket.eve-deftype.int-map/load-node env old-root-off))
                    new-root (if old-root
                               (com.seniorcaremarket.eve-deftype.int-map/-im-assoc
                                old-root k 0
                                com.seniorcaremarket.eve-deftype.int-map/default-merge
                                (* k k))
                               (com.seniorcaremarket.eve-deftype.int-map/->IntMapLeaf env k (* k k)))
                    new-root-off (.-eve-offset new-root)]
                (when-not (== old-root-off
                              (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
                  (recur))))
            (recur (inc k))))
        (let [elapsed (- (js/performance.now) start-time)]
          (println (str "  [Worker] Done from " start-key " in "
                        (.toFixed elapsed 0) "ms ("
                        (.toFixed (/ (* cnt 1000) elapsed) 0) " assocs/sec)")))))))

(defn dispatch-worker-interleaved!
  "Send an interleaved insertion task to a worker.
   Agent inserts keys agent-id, agent-id+stride, agent-id+2*stride, etc."
  [worker int32-idx agent-id total-keys stride]
  (in worker [int32-idx agent-id total-keys stride]
    (let [env (.-s-atom-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
          int32-view (js/Int32Array. (:sab env))]
      (com.seniorcaremarket.eve-deftype.int-map/init-int-map! env)
      (println (str "  [Worker agent-" agent-id "] Inserting interleaved keys"))
      (loop [k agent-id]
        (when (< k total-keys)
          (loop []
            (let [old-root-off (js/Atomics.load int32-view int32-idx)
                  old-root (when (not= old-root-off -1)
                             (com.seniorcaremarket.eve-deftype.int-map/load-node env old-root-off))
                  new-root (if old-root
                             (com.seniorcaremarket.eve-deftype.int-map/-im-assoc
                              old-root k 0
                              com.seniorcaremarket.eve-deftype.int-map/default-merge
                              (* k k))
                             (com.seniorcaremarket.eve-deftype.int-map/->IntMapLeaf env k (* k k)))
                  new-root-off (.-eve-offset new-root)]
              (when-not (== old-root-off
                            (js/Atomics.compareExchange int32-view int32-idx old-root-off new-root-off))
                (recur))))
          (recur (+ k stride))))
      (println (str "  [Worker agent-" agent-id "] Done")))))

;;-----------------------------------------------------------------------------
;; Test: 4 workers x 25 keys = 100 total
;;-----------------------------------------------------------------------------

(defn run-test-100
  "4 workers each insert 25 unique key→value pairs."
  [next-fn]
  (println "\n  == Test: Int-Map Contention (4 workers x 25 keys = 100) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        num-workers 4
        keys-per-worker 25
        total-keys (* num-workers keys-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (dispatch-worker-assoc! (nth workers 0) int32-idx 0 keys-per-worker)
    (dispatch-worker-assoc! (nth workers 1) int32-idx 25 keys-per-worker)
    (dispatch-worker-assoc! (nth workers 2) int32-idx 50 keys-per-worker)
    (dispatch-worker-assoc! (nth workers 3) int32-idx 75 keys-per-worker)

    (js/setTimeout
     (fn []
       (let [root (read-root env int32-idx)
             m (im/PersistentIntMap. env
                 (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)
                 0 nil)]
         (let [cnt (count m)]
           (println (str "  [RESULT] count=" cnt " expected=" total-keys))
           (is (= total-keys cnt) (str "Expected " total-keys " keys, got " cnt)))

         ;; Verify all keys present with correct values
         (doseq [k (cljs.core/range total-keys)]
           (is (= (* k k) (get m k))
               (str "Key " k " should map to " (* k k))))

         (println "  [RESULT] All 100-key contention checks complete.")
         (cleanup-workers workers)
         (next-fn)))
     30000)))

;;-----------------------------------------------------------------------------
;; Test: 4 workers x 250 keys = 1000 total (stress)
;;-----------------------------------------------------------------------------

(defn run-test-1000
  "4 workers each insert 250 unique key→value pairs."
  [next-fn]
  (println "\n  == Test: Int-Map Contention STRESS (4 workers x 250 keys = 1000) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        num-workers 4
        keys-per-worker 250
        total-keys (* num-workers keys-per-worker)
        workers (vec (repeatedly num-workers #(w/mk-worker)))]

    (dispatch-worker-assoc! (nth workers 0) int32-idx 0 keys-per-worker)
    (dispatch-worker-assoc! (nth workers 1) int32-idx 250 keys-per-worker)
    (dispatch-worker-assoc! (nth workers 2) int32-idx 500 keys-per-worker)
    (dispatch-worker-assoc! (nth workers 3) int32-idx 750 keys-per-worker)

    (js/setTimeout
     (fn []
       (let [m (im/PersistentIntMap. env
                 (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)
                 0 nil)]
         (let [cnt (count m)]
           (println (str "  [RESULT] count=" cnt " expected=" total-keys))
           (is (= total-keys cnt) (str "Expected " total-keys " keys, got " cnt)))

         ;; Spot-check some keys
         (is (= 0 (get m 0)) "Key 0 → 0")
         (is (= (* 500 500) (get m 500)) "Key 500 → 250000")
         (is (= (* 999 999) (get m 999)) "Key 999 → 998001")
         (is (nil? (get m 1000)) "Key 1000 should not exist")

         ;; Verify all values
         (let [missing (volatile! 0)]
           (doseq [k (cljs.core/range total-keys)]
             (when (not= (* k k) (get m k))
               (vswap! missing inc)))
           (println (str "  [RESULT] missing/wrong values: " @missing))
           (is (zero? @missing) "All values should be correct"))

         (println "  [RESULT] All 1000-key stress checks complete.")
         (cleanup-workers workers)
         (next-fn)))
     60000)))

;;-----------------------------------------------------------------------------
;; Test: Main thread + 4 workers interleaved
;;-----------------------------------------------------------------------------

(defn run-test-mixed
  "Main thread and 4 workers all insert interleaved key→value pairs."
  [next-fn]
  (println "\n  == Test: Int-Map Mixed Contention (main + 4 workers, interleaved) ==")
  (let [env (init-env!)
        int32-idx (alloc-root-slot! env)
        total-keys 200
        num-agents 5
        workers (vec (repeatedly 4 #(w/mk-worker)))]

    ;; Workers insert their interleaved keys (agents 1-4)
    (dispatch-worker-interleaved! (nth workers 0) int32-idx 1 total-keys num-agents)
    (dispatch-worker-interleaved! (nth workers 1) int32-idx 2 total-keys num-agents)
    (dispatch-worker-interleaved! (nth workers 2) int32-idx 3 total-keys num-agents)
    (dispatch-worker-interleaved! (nth workers 3) int32-idx 4 total-keys num-agents)

    ;; Main thread inserts agent-0 keys (0, 5, 10, ...)
    (println "  [Main agent-0] Inserting interleaved keys")
    (loop [k 0]
      (when (< k total-keys)
        (cas-assoc! env int32-idx k (* k k))
        (recur (+ k num-agents))))
    (println "  [Main agent-0] Done")

    (js/setTimeout
     (fn []
       (let [m (im/PersistentIntMap. env
                 (js/Atomics.load (js/Int32Array. (:sab env)) int32-idx)
                 0 nil)]
         (let [cnt (count m)]
           (println (str "  [RESULT] count=" cnt " expected=" total-keys))
           (is (= total-keys cnt) (str "Expected " total-keys " keys, got " cnt)))

         ;; Verify all keys and values
         (let [missing (volatile! 0)]
           (doseq [k (cljs.core/range total-keys)]
             (when (not= (* k k) (get m k))
               (vswap! missing inc)))
           (println (str "  [RESULT] missing/wrong values: " @missing))
           (is (zero? @missing) "All values should be correct"))

         (println "  [RESULT] All mixed contention checks complete.")
         (cleanup-workers workers)
         (next-fn)))
     30000)))

;;-----------------------------------------------------------------------------
;; Test entry point — sequential chain
;;-----------------------------------------------------------------------------

(deftest test-int-map-contention
  (testing "Int-map under multi-worker contention"
    (async done
      (run-test-100
       (fn []
         (run-test-1000
          (fn []
            (run-test-mixed
             (fn []
               (println "\n  == All int-map contention tests complete ==")
               (done))))))))))

;;-----------------------------------------------------------------------------
;; Runner
;;-----------------------------------------------------------------------------

(defn run-contention-tests []
  (let [wt (js/require "worker_threads")]
    (when (.-isMainThread wt)
      (println "\n--- Int-Map Contention Tests ---\n")
      (run-tests)
      (println "\n--- Int-Map Contention Tests Complete ---\n"))))

(ns com.seniorcaremarket.eve.array-test
  (:require
   [cljs.test :refer-macros [deftest testing is are use-fixtures]]
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.array :as arr]))

;;-----------------------------------------------------------------------------
;; Test setup — initialize global atom once
;;-----------------------------------------------------------------------------

(defonce _init-atom (atom/private-atom {}))

;;-----------------------------------------------------------------------------
;; Basic construction
;;-----------------------------------------------------------------------------

(deftest empty-array-test
  (testing "Empty int32-array (length 0)"
    (let [a (arr/int32-array 0)]
      (is (= 0 (count a)))
      (is (nil? (seq a))))))

(deftest single-element-test
  (testing "Single element int32-array"
    (let [a (arr/int32-array 1)]
      (is (= 1 (count a)))
      (is (= 0 (arr/aget a 0)))
      ;; Write and read back
      (arr/aset! a 0 42)
      (is (= 42 (arr/aget a 0))))))

(deftest initialized-array-test
  (testing "Int32-array initialized with value"
    (let [a (arr/int32-array 5 99)]
      (is (= 5 (count a)))
      (doseq [i (range 5)]
        (is (= 99 (arr/aget a i)) (str "index " i))))))

(deftest array-from-test
  (testing "Int32-array from collection"
    (let [a (arr/int32-array-from [10 20 30 40 50])]
      (is (= 5 (count a)))
      (is (= 10 (arr/aget a 0)))
      (is (= 20 (arr/aget a 1)))
      (is (= 30 (arr/aget a 2)))
      (is (= 40 (arr/aget a 3)))
      (is (= 50 (arr/aget a 4))))))

;;-----------------------------------------------------------------------------
;; Index protocols
;;-----------------------------------------------------------------------------

(deftest indexed-access-test
  (testing "IIndexed protocol"
    (let [a (arr/int32-array-from [100 200 300])]
      (is (= 100 (nth a 0)))
      (is (= 200 (nth a 1)))
      (is (= 300 (nth a 2)))
      (is (= :not-found (nth a 99 :not-found))))))

(deftest ifn-test
  (testing "IFn protocol - array as function"
    (let [a (arr/int32-array-from [5 10 15])]
      (is (= 5 (a 0)))
      (is (= 10 (a 1)))
      (is (= 15 (a 2)))
      (is (= :default (a 99 :default))))))

(deftest ilookup-test
  (testing "ILookup protocol"
    (let [a (arr/int32-array-from [1 2 3])]
      (is (= 1 (get a 0)))
      (is (= 2 (get a 1)))
      (is (= 3 (get a 2)))
      (is (= :nope (get a 99 :nope))))))

;;-----------------------------------------------------------------------------
;; Atomic operations
;;-----------------------------------------------------------------------------

(deftest cas-test
  (testing "Compare-and-swap"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 10)
      ;; Successful CAS
      (is (true? (arr/cas! a 0 10 20)))
      (is (= 20 (arr/aget a 0)))
      ;; Failed CAS (expected doesn't match)
      (is (false? (arr/cas! a 0 10 30)))
      (is (= 20 (arr/aget a 0))))))

(deftest exchange-test
  (testing "Atomic exchange"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 100)
      (let [old-val (arr/exchange! a 0 200)]
        (is (= 100 old-val))
        (is (= 200 (arr/aget a 0)))))))

(deftest add-test
  (testing "Atomic add"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 10)
      (let [old-val (arr/add! a 0 5)]
        (is (= 10 old-val))
        (is (= 15 (arr/aget a 0)))))))

(deftest sub-test
  (testing "Atomic sub"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 20)
      (let [old-val (arr/sub! a 0 7)]
        (is (= 20 old-val))
        (is (= 13 (arr/aget a 0)))))))

(deftest bitwise-and-test
  (testing "Atomic bitwise AND"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 0xFF)  ;; 11111111
      (let [old-val (arr/band! a 0 0x0F)]  ;; AND with 00001111
        (is (= 0xFF old-val))
        (is (= 0x0F (arr/aget a 0)))))))

(deftest bitwise-or-test
  (testing "Atomic bitwise OR"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 0xF0)  ;; 11110000
      (let [old-val (arr/bor! a 0 0x0F)]  ;; OR with 00001111
        (is (= 0xF0 old-val))
        (is (= 0xFF (arr/aget a 0)))))))

(deftest bitwise-xor-test
  (testing "Atomic bitwise XOR"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 0xFF)
      (let [old-val (arr/bxor! a 0 0x0F)]
        (is (= 0xFF old-val))
        (is (= 0xF0 (arr/aget a 0)))))))

;;-----------------------------------------------------------------------------
;; Functional operations
;;-----------------------------------------------------------------------------

(deftest reduce-test
  (testing "IReduce - reduce without init"
    (let [a (arr/int32-array-from [1 2 3 4 5])
          sum (reduce + a)]
      (is (= 15 sum))))

  (testing "IReduce - reduce with init"
    (let [a (arr/int32-array-from [1 2 3 4 5])
          sum (reduce + 100 a)]
      (is (= 115 sum)))))

(deftest areduce-test
  (testing "areduce with index"
    (let [a (arr/int32-array-from [10 20 30])
          ;; Sum of (idx * val)
          result (arr/areduce a 0
                              (fn [acc idx val]
                                (+ acc (* idx val))))]
      ;; 0*10 + 1*20 + 2*30 = 0 + 20 + 60 = 80
      (is (= 80 result)))))

(deftest amap-test
  (testing "amap creates new array"
    (let [a (arr/int32-array-from [1 2 3 4 5])
          b (arr/amap a (fn [idx val] (* val val)))]
      ;; Original unchanged
      (is (= 1 (arr/aget a 0)))
      (is (= 2 (arr/aget a 1)))
      ;; New array has squared values
      (is (= 1 (arr/aget b 0)))
      (is (= 4 (arr/aget b 1)))
      (is (= 9 (arr/aget b 2)))
      (is (= 16 (arr/aget b 3)))
      (is (= 25 (arr/aget b 4))))))

(deftest amap!-test
  (testing "amap! modifies in place"
    (let [a (arr/int32-array-from [1 2 3 4 5])]
      (arr/amap! a (fn [idx val] (* val 10)))
      (is (= 10 (arr/aget a 0)))
      (is (= 20 (arr/aget a 1)))
      (is (= 30 (arr/aget a 2)))
      (is (= 40 (arr/aget a 3)))
      (is (= 50 (arr/aget a 4))))))

(deftest afill-test
  (testing "afill! fills entire array"
    (let [a (arr/int32-array 5)]
      (arr/afill! a 42)
      (doseq [i (range 5)]
        (is (= 42 (arr/aget a i))))))

  (testing "afill! with range"
    (let [a (arr/int32-array-from [0 0 0 0 0])]
      (arr/afill! a 99 1 4)
      (is (= 0 (arr/aget a 0)))
      (is (= 99 (arr/aget a 1)))
      (is (= 99 (arr/aget a 2)))
      (is (= 99 (arr/aget a 3)))
      (is (= 0 (arr/aget a 4))))))

(deftest acopy-test
  (testing "acopy! copies elements"
    (let [src (arr/int32-array-from [1 2 3 4 5])
          dest (arr/int32-array 5)]
      (arr/acopy! dest src)
      (is (= 1 (arr/aget dest 0)))
      (is (= 2 (arr/aget dest 1)))
      (is (= 3 (arr/aget dest 2)))
      (is (= 4 (arr/aget dest 3)))
      (is (= 5 (arr/aget dest 4)))))

  (testing "acopy! with offsets"
    (let [src (arr/int32-array-from [10 20 30 40 50])
          dest (arr/int32-array-from [0 0 0 0 0])]
      (arr/acopy! dest 1 src 2 2)  ;; copy 2 elements from src[2] to dest[1]
      (is (= 0 (arr/aget dest 0)))
      (is (= 30 (arr/aget dest 1)))
      (is (= 40 (arr/aget dest 2)))
      (is (= 0 (arr/aget dest 3)))
      (is (= 0 (arr/aget dest 4))))))

;;-----------------------------------------------------------------------------
;; Seq
;;-----------------------------------------------------------------------------

(deftest seq-test
  (testing "seq over array"
    (let [a (arr/int32-array-from [5 10 15 20])
          s (seq a)]
      (is (= [5 10 15 20] (vec s))))))

;;-----------------------------------------------------------------------------
;; Equality and hashing
;;-----------------------------------------------------------------------------

(deftest equality-test
  (testing "Equal arrays"
    (let [a (arr/int32-array-from [1 2 3])
          b (arr/int32-array-from [1 2 3])]
      (is (= a b))))

  (testing "Unequal arrays - different values"
    (let [a (arr/int32-array-from [1 2 3])
          b (arr/int32-array-from [1 2 4])]
      (is (not= a b))))

  (testing "Unequal arrays - different lengths"
    (let [a (arr/int32-array-from [1 2 3])
          b (arr/int32-array-from [1 2])]
      (is (not= a b)))))

(deftest hash-test
  (testing "Equal arrays have equal hashes"
    (let [a (arr/int32-array-from [1 2 3])
          b (arr/int32-array-from [1 2 3])]
      (is (= (hash a) (hash b))))))

;;-----------------------------------------------------------------------------
;; Meta
;;-----------------------------------------------------------------------------

(deftest meta-test
  (testing "with-meta / meta"
    (let [a (arr/int32-array-from [1 2 3])
          a-meta (with-meta a {:doc "test array"})]
      (is (= {:doc "test array"} (meta a-meta)))
      (is (nil? (meta a)))
      ;; Values preserved
      (is (= 1 (arr/aget a-meta 0)))
      (is (= 2 (arr/aget a-meta 1)))
      (is (= 3 (arr/aget a-meta 2))))))

;;-----------------------------------------------------------------------------
;; Negative numbers
;;-----------------------------------------------------------------------------

(deftest negative-numbers-test
  (testing "Negative int32 values"
    (let [a (arr/int32-array-from [-100 -50 0 50 100])]
      (is (= -100 (arr/aget a 0)))
      (is (= -50 (arr/aget a 1)))
      (is (= 0 (arr/aget a 2)))
      (is (= 50 (arr/aget a 3)))
      (is (= 100 (arr/aget a 4)))))

  (testing "Negative numbers via atomic ops"
    (let [a (arr/int32-array 1)]
      (arr/aset! a 0 -42)
      (is (= -42 (arr/aget a 0)))
      (arr/add! a 0 -8)
      (is (= -50 (arr/aget a 0))))))

;;-----------------------------------------------------------------------------
;; Bounds checking
;;-----------------------------------------------------------------------------

(deftest bounds-check-test
  (testing "aget throws on out-of-bounds"
    (let [a (arr/int32-array 3)]
      (is (thrown? js/Error (arr/aget a -1)))
      (is (thrown? js/Error (arr/aget a 3)))
      (is (thrown? js/Error (arr/aget a 100)))))

  (testing "aset! throws on out-of-bounds"
    (let [a (arr/int32-array 3)]
      (is (thrown? js/Error (arr/aset! a -1 0)))
      (is (thrown? js/Error (arr/aset! a 3 0))))))

;;-----------------------------------------------------------------------------
;; Large arrays
;;-----------------------------------------------------------------------------

(deftest large-array-test
  (testing "1000 element array"
    (let [a (arr/int32-array 1000)]
      (is (= 1000 (count a)))
      ;; Write and verify
      (dotimes [i 1000]
        (arr/aset! a i (* i 2)))
      (dotimes [i 1000]
        (is (= (* i 2) (arr/aget a i)) (str "index " i))))))

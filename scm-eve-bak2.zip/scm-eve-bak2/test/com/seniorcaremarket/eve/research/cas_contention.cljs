(ns com.seniorcaremarket.eve.research.cas-contention
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.worker :as w]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve-sab-deftype.sab-map :as sm]))

(defn run-test []
  (println "=== CAS Contention Research Test ===")
  (let [sab-size (* 8 1024 1024)
        max-blocks 1024
        shared-atom (a/private-atom {} :sab-size sab-size :max-blocks max-blocks)
        metrics-sab (js/SharedArrayBuffer. 8)
        metrics (js/Int32Array. metrics-sab)
        num-workers 4
        ops-per-worker 1000
        target-key :contention-key]

    (println "Workers:" num-workers " Ops/Worker:" ops-per-worker)
    (println "Total expected successes:" (* num-workers ops-per-worker))

    ;; Spawn workers
    (let [workers (doall (repeatedly num-workers w/mk-worker))]
      (println "Spawned" (count workers) "workers.")

      (let [finish-count (atom 0)
            resolver (atom nil)
            all-done (js/Promise. (fn [resolve] (reset! resolver resolve)))
            timeout-id (js/setTimeout (fn []
                                        (println "\n!!! TEST TIMEOUT REACHED (30s) !!!")
                                        (run! #(.terminate %) workers)
                                        (js/process.exit 1))
                                      30000)]

        (doseq [worker workers]
          (.on worker "message"
               (fn [msg-js]
                 (let [msg (js->clj msg-js :keywordize-keys true)]
                   (when (= (:type msg) "done")
                     (swap! finish-count inc)
                     (when (== @finish-count num-workers)
                       (js/clearTimeout timeout-id)
                       (@resolver)))))))

        ;; Send work to workers
        (doseq [worker workers]
          (.postMessage worker
                        (clj->js {:type "task"
                                  :task "cas-contention"
                                  :conveyer [(a/conveyable-> shared-atom) metrics target-key ops-per-worker]})))

        (-> all-done
            (.then (fn []
                     (let [attempts (js/Atomics.load metrics a/METRIC_CAS_ATTEMPTS)
                           successes (js/Atomics.load metrics a/METRIC_CAS_SUCCESSES)
                           ratio (if (zero? successes) 0 (/ attempts successes))
                           final-val (get @shared-atom target-key)]
                       (println "\n--- Results ---")
                       (println "Total Attempts:" attempts)
                       (println "Total Successes:" successes)
                       (println "Retry Ratio (Attempts/Success):" (.toFixed ratio 2))
                       (println "Final Value in Atom:" final-val)
                       (if (== final-val (* num-workers ops-per-worker))
                         (println "SUCCESS: Final value matches expected count.")
                         (println "FAILURE: Final value does NOT match expected count!"))
                       (run! #(.terminate %) workers)
                       (js/process.exit 0)))))))))

#!/bin/bash
# Setup script for EVE development environment
# Downloads Maven dependencies using curl (which properly handles proxy auth)
# and creates the classpath.edn for shadow-cljs

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
M2_REPO="/root/.m2/repository"
SHADOW_CLJS_VERSION="3.3.5"
CENTRAL="https://repo1.maven.org/maven2"
CLOJARS="https://repo.clojars.org"

echo "=== EVE Development Environment Setup ==="
echo "Project dir: $PROJECT_DIR"

# ─────────────────────────────────────────────────────────────
# Proxy setup for Java
# ─────────────────────────────────────────────────────────────
setup_java_proxy() {
    if [ -n "$http_proxy" ]; then
        # Extract proxy host and port from env
        PROXY_URL="$http_proxy"
        PROXY_HOST=$(echo "$PROXY_URL" | sed -E 's|.*@([^:]+):([0-9]+)$|\1|')
        PROXY_PORT=$(echo "$PROXY_URL" | sed -E 's|.*@([^:]+):([0-9]+)$|\2|')

        export JAVA_TOOL_OPTIONS="-Dhttp.proxyHost=$PROXY_HOST -Dhttp.proxyPort=$PROXY_PORT -Dhttps.proxyHost=$PROXY_HOST -Dhttps.proxyPort=$PROXY_PORT -Djdk.http.auth.tunneling.disabledSchemes= -Djdk.http.auth.proxying.disabledSchemes="

        echo "Java proxy configured: $PROXY_HOST:$PROXY_PORT"
    else
        echo "No proxy detected"
    fi
}

# ─────────────────────────────────────────────────────────────
# Download a Maven artifact using curl
# ─────────────────────────────────────────────────────────────
download_artifact() {
    local group=$1
    local artifact=$2
    local version=$3
    local classifier=$4  # optional: "aot", etc.
    local repo=$5        # "central" or "clojars"

    local group_path=$(echo "$group" | tr '.' '/')
    local jar_name="${artifact}-${version}"
    if [ -n "$classifier" ]; then
        jar_name="${jar_name}-${classifier}"
    fi

    local target_dir="$M2_REPO/$group_path/$artifact/$version"
    local target_jar="$target_dir/${jar_name}.jar"
    local target_pom="$target_dir/${artifact}-${version}.pom"

    if [ -f "$target_jar" ]; then
        echo "  [cached] $group:$artifact:$version${classifier:+:$classifier}"
        return 0
    fi

    local base_url
    if [ "$repo" = "clojars" ]; then
        base_url="$CLOJARS"
    else
        base_url="$CENTRAL"
    fi

    mkdir -p "$target_dir"

    echo "  [download] $group:$artifact:$version${classifier:+:$classifier} from $repo"

    # Download JAR
    local jar_url="$base_url/$group_path/$artifact/$version/${jar_name}.jar"
    if ! curl -sf -o "$target_jar" "$jar_url" 2>/dev/null; then
        echo "    WARN: Failed to download JAR from $jar_url"
        rm -f "$target_jar"
        return 1
    fi

    # Download POM (best effort)
    local pom_url="$base_url/$group_path/$artifact/$version/${artifact}-${version}.pom"
    curl -sf -o "$target_pom" "$pom_url" 2>/dev/null || true

    return 0
}

# ─────────────────────────────────────────────────────────────
# Download all required dependencies
# ─────────────────────────────────────────────────────────────
download_all_deps() {
    echo ""
    echo "Downloading Maven dependencies..."

    # shadow-cljs AOT jar (from Clojars)
    download_artifact "thheller" "shadow-cljs" "$SHADOW_CLJS_VERSION" "aot" "clojars"

    # Core Clojure dependencies (from Maven Central)
    download_artifact "org.clojure" "clojure" "1.12.0" "" "central"
    download_artifact "org.clojure" "spec.alpha" "0.5.238" "" "central"
    download_artifact "org.clojure" "core.specs.alpha" "0.4.74" "" "central"
    download_artifact "org.clojure" "clojurescript" "1.12.134" "" "central"
    download_artifact "org.clojure" "data.json" "2.5.1" "" "central"
    download_artifact "org.clojure" "tools.cli" "1.1.230" "" "central"
    download_artifact "org.clojure" "tools.reader" "1.5.2" "" "central"
    download_artifact "org.clojure" "core.async" "1.8.741" "" "central"
    download_artifact "org.clojure" "tools.analyzer" "1.2.0" "" "central"
    download_artifact "org.clojure" "tools.analyzer.jvm" "1.3.1" "" "central"
    download_artifact "org.clojure" "core.memoize" "1.1.266" "" "central"
    download_artifact "org.clojure" "core.cache" "1.1.234" "" "central"
    download_artifact "org.clojure" "data.priority-map" "1.2.0" "" "central"
    download_artifact "org.clojure" "core.rrb-vector" "0.2.0" "" "central"
    download_artifact "org.clojure" "google-closure-library" "0.0-20250515-f04e4c0e" "" "central"
    download_artifact "org.clojure" "google-closure-library-third-party" "0.0-20250515-f04e4c0e" "" "central"
    download_artifact "org.clojure" "test.check" "1.1.1" "" "central"

    # Google Closure Compiler
    download_artifact "com.google.javascript" "closure-compiler" "v20250407" "" "central"

    # Transit
    download_artifact "com.cognitect" "transit-clj" "1.0.333" "" "central"
    download_artifact "com.cognitect" "transit-cljs" "0.8.280" "" "central"
    download_artifact "com.cognitect" "transit-java" "1.0.371" "" "central"

    # nREPL
    download_artifact "nrepl" "nrepl" "1.3.1" "" "clojars"
    download_artifact "nrepl" "bencode" "1.2.0" "" "clojars"

    # Other thheller deps
    download_artifact "thheller" "shadow-util" "0.7.0" "" "clojars"
    download_artifact "thheller" "shadow-client" "1.4.0" "" "clojars"
    download_artifact "thheller" "shadow-undertow" "0.3.4" "" "clojars"
    download_artifact "thheller" "shadow-cljsjs" "0.0.22" "" "clojars"

    # Piggieback
    download_artifact "cider" "piggieback" "0.6.0" "" "clojars"

    # Web server dependencies
    download_artifact "ring" "ring-core" "1.14.1" "" "clojars"
    download_artifact "ring" "ring-codec" "1.2.0" "" "clojars"
    download_artifact "commons-fileupload" "commons-fileupload" "1.5" "" "central"
    download_artifact "commons-io" "commons-io" "2.18.0" "" "central"
    download_artifact "commons-codec" "commons-codec" "1.18.0" "" "central"
    download_artifact "crypto-equality" "crypto-equality" "1.0.1" "" "clojars"
    download_artifact "crypto-random" "crypto-random" "1.2.1" "" "clojars"

    # Undertow (web server)
    download_artifact "io.undertow" "undertow-core" "2.3.18.Final" "" "central"
    download_artifact "org.jboss.logging" "jboss-logging" "3.6.1.Final" "" "central"
    download_artifact "org.jboss.xnio" "xnio-api" "3.8.16.Final" "" "central"
    download_artifact "org.jboss.xnio" "xnio-nio" "3.8.16.Final" "" "central"
    download_artifact "org.wildfly.common" "wildfly-common" "2.0.3.Final" "" "central"
    download_artifact "org.wildfly.client" "wildfly-client-config" "2.0.1.Final" "" "central"
    download_artifact "org.jboss.threads" "jboss-threads" "3.8.0.Final" "" "central"

    # Directory watcher
    download_artifact "io.methvin" "directory-watcher" "0.19.0" "" "central"

    # Misc
    download_artifact "hiccup" "hiccup" "1.0.5" "" "clojars"
    download_artifact "expound" "expound" "0.9.0" "" "clojars"
    download_artifact "fipp" "fipp" "0.6.27" "" "clojars"
    download_artifact "com.bhauman" "cljs-test-display" "0.1.1" "" "clojars"

    # Jackson (for transit)
    download_artifact "com.fasterxml.jackson.core" "jackson-core" "2.18.2" "" "central"

    # Msgpack
    download_artifact "org.msgpack" "msgpack" "0.6.12" "" "central"
    download_artifact "org.javassist" "javassist" "3.18.1-GA" "" "central"
    download_artifact "com.googlecode.json-simple" "json-simple" "1.1.1" "" "central"

    # ASM for tools.analyzer
    download_artifact "org.ow2.asm" "asm" "9.7.1" "" "central"

    # Google Guava (for closure compiler)
    download_artifact "com.google.guava" "guava" "33.4.5-jre" "" "central"
    download_artifact "com.google.guava" "failureaccess" "1.0.2" "" "central"
    download_artifact "com.google.code.findbugs" "jsr305" "3.0.2" "" "central"
    download_artifact "com.google.errorprone" "error_prone_annotations" "2.36.0" "" "central"
    download_artifact "com.google.code.gson" "gson" "2.12.1" "" "central"
    download_artifact "com.google.protobuf" "protobuf-java" "4.29.3" "" "central"
    download_artifact "com.google.re2j" "re2j" "1.7" "" "central"
    download_artifact "args4j" "args4j" "2.33" "" "central"

    # Transit JS
    download_artifact "com.cognitect" "transit-js" "0.8.874" "" "central"

    # javax.xml.bind (for older java compat)
    download_artifact "javax.xml.bind" "jaxb-api" "2.4.0-b180830.0359" "" "central"

    echo ""
    echo "Dependencies downloaded."
}

# ─────────────────────────────────────────────────────────────
# Generate classpath.edn
# ─────────────────────────────────────────────────────────────
generate_classpath() {
    echo "Generating classpath.edn..."

    local cp_dir="$PROJECT_DIR/.shadow-cljs"
    mkdir -p "$cp_dir"

    # Collect all downloaded jars
    local jars=""
    while IFS= read -r jar; do
        if [ -n "$jars" ]; then
            jars="$jars"$'\n'"         \"$jar\""
        else
            jars="\"$jar\""
        fi
    done < <(find "$M2_REPO" -name "*.jar" -type f | sort)

    cat > "$cp_dir/classpath.edn" << CPEOF
{:dependencies [[thheller/shadow-cljs "$SHADOW_CLJS_VERSION"]],
 :version "$SHADOW_CLJS_VERSION",
 :files [$jars]}
CPEOF

    echo "classpath.edn written to $cp_dir/classpath.edn"
}

# ─────────────────────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────────────────────
main() {
    cd "$PROJECT_DIR"

    # Install npm deps if needed
    if [ ! -d "node_modules/shadow-cljs" ]; then
        echo "Installing npm dependencies..."
        npm install shadow-cljs 2>/dev/null
    fi

    setup_java_proxy
    download_all_deps
    generate_classpath

    echo ""
    echo "=== Setup Complete ==="
    echo "You can now run: npx shadow-cljs compile sab-unit-test"
}

main "$@"

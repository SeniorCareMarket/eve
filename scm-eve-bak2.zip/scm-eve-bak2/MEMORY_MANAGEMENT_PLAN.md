# Single-Root-in-Atom Memory Management Plan

> **STATUS: COMPLETE** — All phases implemented. memset! removed from alloc hot path, retire-replaced-path! on all data structures, retire-tree-diff! for full tree diff, ISabRetirable protocol wired into atom swap, demand-driven sweep in alloc/batch-alloc fallback, O(1) offset→desc lookup. Result: atom swap 29-38% faster, no regressions. See commit history for details.

## The Core Insight

EVE uses **persistent data structures rooted in a single atom**. This constraint affords memory management tricks not available in general-purpose allocators:

1. **Reachability = root pointer.** The atom holds one root pointer. After a CAS swap, the old root is unreachable. No external code can traverse old nodes unless it was already reading when the swap happened.

2. **No zeroing needed.** The allocator already doesn't zero data on free — only descriptor STATUS changes. Old bytes stay in memory until a future allocation overwrites them. This is correct because no one will read old data via new pointers.

3. **Reader safety is already handled.** Epoch tracking + per-descriptor reader map counters prevent premature reuse. A freed block won't be reclaimed until all readers from that epoch have finished.

4. **Structural sharing is safe to free around.** When walking old-tree vs new-tree after a swap, shared subtrees have `old-off == new-off` — skip them. Only the replaced path (typically O(log n) nodes) needs freeing.

5. **Nested collections are just more tree nodes.** A SabMap containing a nested SabMap is a tree containing a pointer to another tree. Freeing walks both. No special lifecycle management needed.

---

## Current Allocator Behavior (Confirmed)

| Operation | Zeros data bytes? | What it does |
|-----------|-------------------|-------------|
| `atom/free` | **No** | Flips descriptor STATUS → FREE, clears metadata fields |
| `try-claim-descriptor!` | **No** | CAS-locks, marks ALLOCATED, splits remainder |
| `retire-block!` | **No** | CAS STATUS_ALLOCATED → STATUS_RETIRED, stamps epoch |
| `try-free-retired!` | **No** | STATUS_RETIRED → STATUS_FREE when epoch safe |
| `end-read!` (orphan) | **No** | STATUS_ORPHANED → STATUS_FREE when reader count == 0 |

Only `sab_map/alloc-bytes!` zeros via `memset!` when returning blocks from the pool — and this is unnecessary given the single-root model (see Phase 2 below).

---

## Architecture

```
┌─────────────────────────────────────────────────────┐
│                   Atom (CAS root pointer)            │
│                                                      │
│    root-desc-idx ──→ [9-byte typed pointer]          │
│                       │                              │
│                       ▼                              │
│              ┌─── SabMap root ───┐                   │
│              │  HAMT tree nodes  │ ◄── structural    │
│              │  ├── bitmap node  │     sharing with   │
│              │  ├── bitmap node  │     previous      │
│              │  │   └── nested   │     versions      │
│              │  │       SabVec ──│──→ (own tree)     │
│              │  └── collision    │                    │
│              └──────────────────┘                    │
│                                                      │
│  After CAS swap:                                     │
│    old root ──→ [DEAD TREE]  ← logically freed       │
│    new root ──→ [LIVE TREE]  ← shares most nodes     │
│                                                      │
│  Only the "replaced path" (O(log n) nodes) differs.  │
│  Shared subtrees are untouched.                      │
└─────────────────────────────────────────────────────┘
```

---

## Phase 1: Simplify Freeing to Descriptor-Status Flips

**Status**: Partially implemented (`retire-replaced-path!` in sab_map.cljs)

### Current State

- `retire-replaced-path!` walks old/new HAMT trees following hash bits after atom swap
- Retires each node where `old-off != new-off` (replaced path)
- Shared subtrees skipped (common case)
- Supports `:retire` mode (epoch-based, multi-worker) and `:free` mode (immediate)

### What Changes

**Simplification**: Since freeing = descriptor status flip, the entire operation is:

```
For each replaced node:
  1. Look up descriptor-idx via offset→desc map (O(1))
  2. Call atom/retire-block! (single CAS: ALLOCATED → RETIRED)

That's it. No zeroing, no recursive disposal, no complex lifecycle.
```

**Extend to all data structures**: Currently only sab_map has `retire-replaced-path!`. Need to add equivalent for:
- **sab_set**: Same HAMT structure, same walk logic
- **sab_vec**: Trie walk — compare old/new trie nodes following index bits
- **sab_list**: Linked list walk — compare old/new chains

### Implementation

```clojure
;; Generic tree-diff-retire for HAMT (works for both map and set)
(defn retire-replaced-hamt-path!
  [s-atom-env old-root new-root hash-bits mode]
  ;; Walk both trees following hash-bits
  ;; At each level: if old-node != new-node → retire old-node
  ;; If old-node == new-node → shared subtree, stop
  ...)

;; For vector trie
(defn retire-replaced-trie-path!
  [s-atom-env old-root new-root index mode]
  ;; Walk trie following index bits
  ;; Retire replaced internal nodes
  ...)
```

### Files to Modify
- `sab_set.cljs`: Add `retire-replaced-path!` (port from sab_map)
- `sab_vec.cljs`: Add `retire-replaced-trie-path!`
- `sab_list.cljs`: Add `retire-replaced-chain!`

---

## Phase 2: Remove Unnecessary Zeroing

**Status**: Not started

### What to Remove

1. **`memset!` in `sab_map/alloc-bytes!`** — Currently zeros blocks returned from pool. Unnecessary because:
   - New nodes are fully populated before being linked into the tree
   - The tree is only visible after the CAS swap
   - No reader will see partially-written data

2. **`memset!` in `sab_set/alloc-bytes!`** — Same reasoning

3. **Any zeroing in `dispose!`** — The entire tree is unreachable after freeing the root. Old bytes don't matter.

### Safety Guarantee

The invariant that makes this safe:

> **A node is fully written before it becomes reachable.** The root pointer CAS is the publication barrier. All writes to new nodes happen-before the CAS. All reads of the new tree happen-after the CAS.

This is guaranteed by `Atomics.compareExchange` which provides sequential consistency.

### Performance Impact

Removing `memset!` from the allocation hot path saves:
- One WASM function call per allocation (or JS `Uint8Array.fill` fallback)
- O(block_size) bytes of write bandwidth per allocation
- Estimated 10-20% improvement in allocation throughput

---

## Phase 3: Integrate with Atom Swap

**Status**: Infrastructure exists but not wired into atom swap

### Current Atom Swap Flow

```
do-private-atom-swap!:
  1. Read current root descriptor index
  2. Deserialize old value (Fressian — EXPENSIVE)
  3. Apply user function → new value
  4. Serialize new value (Fressian — EXPENSIVE)
  5. Allocate new descriptor for serialized bytes
  6. CAS swap root descriptor index
  7. On success: free OLD descriptor (just the atom's data block)
```

Step 7 only frees the atom's data block (the Fressian blob). It does NOT free the HAMT tree that the blob referenced. This is the current memory leak.

### New Atom Swap Flow (Post-Fressian-Removal)

```
do-private-atom-swap!:
  1. Read root pointer → construct SabMap wrapper (O(1))
  2. Apply user function → returns new SabMap
  3. Write new pointer (9 bytes) to new descriptor
  4. CAS swap root descriptor index
  5. On success:
     a. Free old atom data block (9-byte pointer)
     b. retire-replaced-path!(old-sab-map-root, new-sab-map-root, key-hash)
        → walks old/new trees, retires replaced path nodes
  6. Periodic: sweep-retired-blocks! reclaims RETIRED → FREE
```

Step 5b is the new part — it uses the infrastructure from Phase 1 to retire the old path nodes that were replaced by the user's operation.

### Key Requirement: Knowing What Changed

`retire-replaced-path!` needs the hash of the key that was modified. This must be threaded through from the user's operation:

```clojure
;; User does: (swap! atom assoc :foo 42)
;; Internally: assoc knows the key hash
;; After CAS: retire-replaced-path!(old-root, new-root, (hash :foo))
```

For operations that modify multiple keys (e.g., `merge`), we need to retire paths for each modified key or fall back to full tree diff.

### Files to Modify
- `atom.cljs`: Update `do-private-atom-swap!` to call `retire-replaced-path!`
- `sab_map.cljs`: Expose `retire-replaced-path!` as public API
- May need to extend swap protocol to pass key-hash through

---

## Phase 4: Full Tree Diff for Multi-Key Operations

**Status**: Not started

### The Problem

`retire-replaced-path!` follows a single hash path. For multi-key operations like `merge`, `select-keys`, `dissoc` of multiple keys, we need to handle multiple paths.

### Approaches

**Option A: Multiple single-path retires**
```clojure
(defn retire-replaced-paths!
  [s-atom-env old-root new-root key-hashes mode]
  (doseq [kh key-hashes]
    (retire-replaced-path! s-atom-env old-root new-root kh mode)))
```
Cost: O(k × log n) where k = number of modified keys. Good for small k.

**Option B: Full tree diff**
```clojure
(defn retire-tree-diff!
  [s-atom-env old-root new-root mode]
  ;; Walk both trees in parallel
  ;; At each node: if old == new → skip (shared)
  ;; If old != new → retire old, recurse into children
  ...)
```
Cost: O(changed nodes). Better for large k. Simple because shared subtrees are immediately skipped.

**Recommendation**: Option B is cleaner and handles all cases. The walk is efficient because structural sharing means most subtrees are identical — the comparison `old-off == new-off` is a single integer compare.

---

## Phase 5: Sweep Integration

**Status**: Infrastructure exists in atom.cljs

### Current Sweep

`sweep-retired-blocks!` in atom.cljs already:
1. Marks stale workers (`ACTIVE → STALE`)
2. Scans all descriptors for `STATUS_RETIRED`
3. Calls `try-free-retired!` on each — frees when `min_active_epoch > retired_epoch`

### What's Needed

Wire sweep into a periodic schedule. Options:
- **On atom swap**: Sweep opportunistically after every N swaps
- **On allocation pressure**: Sweep when allocator can't find free blocks
- **Worker-side timer**: Dedicated sweep interval (e.g., every 100ms)

### Recommendation

Integrate sweep into allocation fallback:
```clojure
(defn alloc-bytes! [s-atom-env n]
  ;; 1. Try pool
  ;; 2. Try batch-alloc from descriptor table
  ;; 3. If both fail: sweep-retired-blocks!, then retry
  ;; 4. If still fails: OOM error
  ...)
```

This makes sweep demand-driven — only runs when actually needed.

---

## Phase 6: offset→desc Cleanup and Worker Safety

**Status**: offset→desc implemented for sab_map and sab_set

### Current Tracking

`offset→desc` is a JS `Map` per worker, populated on allocation:
```clojure
(.set offset->desc off desc-idx)
```

Cleaned up on free:
```clojure
(.delete offset->desc node-off)
```

### Cross-Worker Consideration

Each worker maintains its own `offset→desc` map. A worker can only track allocations it made. For nodes allocated by other workers (e.g., shared via atom), the fallback is:
```clojure
(u/find-descriptor-for-data-offset s-atom-env node-off)  ;; O(n) linear scan
```

### Future Optimization

The linear scan fallback is expensive. Options:
- **Shared offset→desc index in SAB**: A hash table in shared memory mapping offset → desc-idx. Updated atomically on allocation.
- **WASM binary search**: If descriptors are sorted by offset (they're not currently), binary search would be O(log n).
- **Reverse map in descriptor**: Add a `DATA_OFFSET_TO_DESC_IDX` field to the descriptor table itself — but this doubles lookup from O(1) to O(1) with larger descriptors.

For now, the JS Map + linear fallback is sufficient for single-worker use cases. Multi-worker offset→desc will be addressed when cross-worker retire becomes a priority.

---

## Summary: What Changes vs What Stays

### What Stays (Already Correct)
- Descriptor-based coalescing allocator
- CAS locking on descriptors
- Reader map with atomic counters
- Epoch-based retirement (`retire-block!`, `try-free-retired!`, `sweep-retired-blocks!`)
- Block coalescing on free
- Proactive writer cleanup with retry

### What Changes
| Current | New |
|---------|-----|
| `dispose!` does recursive tree walk + free each node | Replaced-path retire: only O(log n) nodes per swap |
| `memset!` zeros blocks from pool | Removed — writer fully populates before CAS |
| Atom swap frees only its data block | Atom swap also retires replaced HAMT path |
| No integration between atom swap and HAMT freeing | `retire-replaced-path!` called after every successful CAS |
| Memory leak: old HAMT nodes accumulate | Retired on swap, swept periodically |

### What Gets Removed
- `memset!` in `alloc-bytes!` (both sab_map and sab_set)
- Complex recursive `dispose!` (replaced by simpler tree-diff retire)
- Any "deep clone" or "deep free" logic for nested collections

---

## Implementation Order

```
Phase 1: retire-replaced-path! for all data structures    [sab_set, sab_vec, sab_list]
    ↓
Phase 2: Remove memset! from allocation hot path           [sab_map, sab_set]
    ↓
Phase 3: Wire retire into atom swap                        [atom.cljs]
    ↓ (depends on Fressian removal — atom needs SAB pointers, not Fressian blobs)
Phase 4: Full tree diff for multi-key operations           [sab_map, sab_set]
    ↓
Phase 5: Demand-driven sweep                               [atom.cljs, sab_map/alloc-bytes!]
    ↓
Phase 6: Cross-worker offset→desc (future)                 [atom.cljs, wasm_mem]
```

**Dependency**: Phase 3 depends on the Fressian removal plan (Phase 3 of `FRESSIAN_REMOVAL_PLAN.md`). The atom currently stores Fressian blobs — it needs to store SAB pointers first so that the old/new roots are SabMap instances whose trees can be diffed.

---

## Relationship to Other Plans

| Plan | Relationship |
|------|-------------|
| `FRESSIAN_REMOVAL_PLAN.md` | Phase 3 (atom path) enables Phase 3 here (wire retire into atom swap) |
| `OPTIMIZATION_PLAN.md` | Phases 10-11 (fast-path expansion, node pooling) are superseded by Fressian removal |
| `MISSING_OPTIMIZATIONS_PLAN.md` | "Known Issues: Recursive HAMT Tree Freeing" is resolved by this plan |

---

## Expected Impact

| Metric | Current | After |
|--------|---------|-------|
| Memory leak rate | O(n) nodes per swap | 0 (all replaced nodes retired) |
| Allocation throughput | Bottlenecked by memset | 10-20% faster (no zeroing) |
| Atom swap overhead | O(n) Fressian + no freeing | O(log n) retire + O(1) pointer write |
| Long-running stability | OOM after thousands of swaps | Stable (sweep reclaims retired blocks) |

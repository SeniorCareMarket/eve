# Fressian Removal Sub-Implementation Plan

> **STATUS: COMPLETE** — All 6 phases implemented. SAB pointer encoding, zero-copy deser, ISabStorable protocol, raw.cljs deleted. See commit history for details.

## Overview

Remove Fressian serialization from the entire `eve-deftype` subproject. Replace with a direct binary encoding system where:

- **Primitive values** use the existing fast-path encoding (0xEE 0xDB prefix) — already covers 14 types
- **Nested collections** become SAB pointers (`[TAG][root-offset:i32][count:i32]`) to actual SAB data structures in shared memory
- **Extensibility** is protocol-based (`ISabStorable`) instead of Fressian handler registration (`raw/reg!`)
- **Records** are stored as tagged maps with metadata
- **No wire format** — drop wire-friendliness for now; can re-add later as a separate concern
- **Data agnosticism** deferred — will clean up after lower-level system is solid

**Key insight**: With persistent data structures rooted in a single atom, memory management is dramatically simpler. "Freeing" = flipping descriptor status. No data zeroing needed. Epoch/reader tracking already prevents use-after-free. Nested collection lifecycle is just recursive tree-walking.

---

## Current Fressian Dependency Map

| File | raw.cljs refs | What it uses Fressian for |
|------|---------------|---------------------------|
| `atom.cljs` | 25+ | Atom value ser/deser (default-fressian-serializer/deserializer) |
| `sabp_map.cljs` | 2 | Legacy SAB-persistent map value encoding |
| `sabp_list.cljs` | 11 | Legacy SAB-persistent list element encoding |
| `sabp_set.cljs` | 2 | Legacy SAB-persistent set element encoding |
| `chunked_list.cljs` | 7 | Chunked list element encoding |
| `ab_list.cljs` | 13 | ArrayBuffer list encoding + custom handlers |
| `raw.cljs` | N/A | **Core module — 403 lines — TO BE REMOVED** |
| `serialize.cljs` | 1 (fallback) | Fressian fallback for non-fast-path types |
| `util.cljs` | 0 (debug) | `fressian-code-symbols` debugging map |

**Not affected** (no Fressian deps):
- `sab_map.cljs`, `sab_set.cljs`, `sab_vec.cljs`, `sab_list.cljs` — use `serialize.cljs` not `raw.cljs` directly
- `obj.cljs`, `array.cljs` — typed field access, no serialization
- `wasm_mem.cljs`, `data.cljs`, `conveyance.cljs`
- All SIMD files (`simd.cljs`, `simd_hamt.cljs`, `simd_wasm.cljs`)

---

## Phase 0: Extend Fast-Path Encoding (No Breaking Changes)

**Goal**: Cover ALL leaf value types in the fast-path encoder so nothing falls through to Fressian.

**File**: `serialize.cljs`

### 0.1 Add SAB Pointer Tags

New tags for nested collections stored as SAB pointers:

```
FAST_TAG_SAB_MAP      (0x10)  →  [0xEE][0xDB][0x10][root-off:i32][count:i32]  = 11 bytes
FAST_TAG_SAB_SET      (0x11)  →  [0xEE][0xDB][0x11][root-off:i32][count:i32]  = 11 bytes
FAST_TAG_SAB_VEC      (0x12)  →  [0xEE][0xDB][0x12][root-off:i32][count:i32]  = 11 bytes
FAST_TAG_SAB_LIST     (0x13)  →  [0xEE][0xDB][0x13][root-off:i32][count:i32]  = 11 bytes
FAST_TAG_SAB_SORTED   (0x14)  →  [0xEE][0xDB][0x14][root-off:i32][count:i32]  = 11 bytes  (future)
```

These encode a reference to another SAB data structure's root offset + count. The actual data lives in shared memory — zero copy.

### 0.2 Add Remaining Primitive Tags

Cover types currently falling through to Fressian:

```
FAST_TAG_NIL          existing (0x01 is FALSE, need dedicated NIL)
FAST_TAG_BIGINT       (0x15)  →  [magic][tag][sign:u8][len:u16][digits...]
FAST_TAG_REGEX        (0x16)  →  [magic][tag][flags:u8][pattern-len:u16][pattern-utf8...]
FAST_TAG_ARRAY_I32    (0x17)  →  [magic][tag][count:u32][i32 × count]
FAST_TAG_ARRAY_F64    (0x18)  →  [magic][tag][count:u32][f64 × count]
FAST_TAG_JS_ARRAY     (0x19)  →  [magic][tag][count:u32][element...]  (recursive encoding)
FAST_TAG_RECORD       (0x1A)  →  [magic][tag][tag-kw-bytes...][map-pointer:i32][count:i32]
FAST_TAG_TAGGED       (0x1B)  →  [magic][tag][tag-kw-bytes...][value-bytes...]  (generic tagged value)
```

### 0.3 Add CLJS Collection → SAB Conversion on Store

When `serialize-val` encounters a CLJS PersistentHashMap, PersistentVector, etc., instead of falling through to Fressian:

1. Build a SabMap/SabVec/SabSet/SabList from the CLJS collection
2. Encode as SAB pointer tag (`FAST_TAG_SAB_MAP`, etc.)
3. The nested SAB structure lives in shared memory alongside its parent

This is the critical change — nested values become first-class SAB data structures.

**Estimated work**: ~200 lines in serialize.cljs

---

## Phase 1: Protocol-Based Extensibility

**Goal**: Replace `raw/reg!` handler system with ClojureScript protocols.

### 1.1 Define `ISabStorable` Protocol

**New file or addition to serialize.cljs**:

```clojure
(defprotocol ISabStorable
  "Protocol for types that can be stored in SAB data structures."
  (-sab-tag [this]
    "Return a keyword tag identifying this type for deserialization.")
  (-sab-encode [this s-atom-env]
    "Encode this value into a Uint8Array for storage in SAB.
     May allocate SAB blocks for nested structures.
     Returns bytes using the fast-path format.")
  (-sab-dispose [this s-atom-env]
    "Free any SAB resources owned by this value.
     Called during tree-walk freeing. Optional — default is no-op."))
```

### 1.2 Extend Protocol to Built-in Types

```clojure
(extend-protocol ISabStorable
  cljs.core/Keyword
  (-sab-tag [_] :keyword)
  (-sab-encode [this _env] (serialize-key this))  ;; already fast-path
  (-sab-dispose [_ _] nil)

  SabMapRoot
  (-sab-tag [_] :sab-map)
  (-sab-encode [this _env]
    ;; Encode as SAB pointer: [magic][tag][root-off:i32][count:i32]
    ...)
  (-sab-dispose [this env] (dispose! env this))

  ;; ... etc for all types
  )
```

### 1.3 Tag Registry for Deserialization

```clojure
(defonce ^:private tag-registry (atom {}))

(defn register-sab-type!
  "Register a tag → constructor-fn for deserialization.
   constructor-fn: (fn [s-atom-env bytes] → value)"
  [tag-kw constructor-fn]
  (swap! tag-registry assoc tag-kw constructor-fn))
```

This replaces `raw/reg!` with a simpler, protocol-driven system.

**Estimated work**: ~150 lines

---

## Phase 2: Records as Tagged Maps

**Goal**: Store CLJS records as `{:tag :my.ns/MyRecord, :data {field-map}}` in SAB.

### 2.1 Record Serialization

When `serialize-val` encounters an `IRecord`:

1. Extract the record's fields as a CLJS map
2. Build a SabMap from `{:tag <record-tag-keyword>, :data <field-map-as-sab-map>}`
3. Encode as `FAST_TAG_RECORD` pointer

### 2.2 Record Deserialization

When `deserialize-element` encounters `FAST_TAG_RECORD`:

1. Read the tag keyword and map pointer
2. Look up constructor in `tag-registry`
3. If found: call constructor with the field map → returns record instance
4. If not found: return the tagged map as-is (graceful degradation)

### 2.3 Record Registration

```clojure
(register-sab-type! :my.ns/MyRecord
  (fn [_env field-map]
    (map->MyRecord field-map)))
```

**Estimated work**: ~100 lines

---

## Phase 3: Update Atom Path

**Goal**: Atom stores a typed SAB pointer instead of Fressian blob.

### 3.1 New Atom Root Format

Currently: atom root descriptor → Fressian-encoded bytes of entire state

After: atom root descriptor → `[type-tag:u8][root-off:i32][count:i32]`

- For SabMap state: `[TAG_SAB_MAP][root-off][count]` — 9 bytes
- For SabVec state: `[TAG_SAB_VEC][root-off][count]` — 9 bytes
- For primitive state: `[fast-path encoded bytes]` — same as today

### 3.2 Replace `default-fressian-serializer`

```clojure
(defn default-serializer [value]
  (cond
    (instance? SabMapRoot value)
    ;; Already in SAB — encode as pointer, no data copy
    (encode-sab-pointer TAG_SAB_MAP (.-root-offset value) (.-count value))

    (map? value)
    ;; CLJS map — build SabMap first, then encode pointer
    (let [sab-map (sab-map/from-cljs s-atom-env value)]
      (encode-sab-pointer TAG_SAB_MAP (.-root-offset sab-map) (count sab-map)))

    :else
    ;; Primitive — use fast-path encoding
    (ser/serialize-val value)))
```

### 3.3 Replace `default-fressian-deserializer`

```clojure
(defn default-deserializer [byte-array-view]
  (ser/deserialize-element s-atom-env byte-array-view))
;; deserialize-element already handles all fast-path tags
;; SAB pointer tags return SabMap/SabVec/etc. instances — zero copy
```

### 3.4 Update `do-private-atom-swap!`

The swap function needs to:
1. Deserialize old state → returns SabMap (zero copy, just reads pointer)
2. Apply user function → returns new SabMap
3. Serialize new state → writes pointer (9 bytes, no Fressian)
4. CAS on root descriptor
5. On success: retire old tree's replaced path nodes

**Key win**: Atom deref becomes O(1) — just read 9 bytes and construct a SabMap wrapper around the root offset. No Fressian deserialization at all.

**Estimated work**: ~300 lines across atom.cljs

---

## Phase 4: Update Legacy Data Structures

**Goal**: Remove Fressian from `sabp_*`, `ab_list`, `chunked_list`.

### 4.1 Triage: Keep or Remove?

| Structure | Status | Action |
|-----------|--------|--------|
| `sabp_map.cljs` | Legacy (pre-epoch) | Remove or mark deprecated — `sab_map` is the replacement |
| `sabp_set.cljs` | Legacy (pre-epoch) | Remove or mark deprecated — `sab_set` is the replacement |
| `sabp_list.cljs` | Legacy (pre-epoch) | Remove or mark deprecated — `sab_list` is the replacement |
| `ab_list.cljs` | ArrayBuffer-based list | Update to use fast-path encoding |
| `chunked_list.cljs` | Chunked list impl | Update to use fast-path encoding |

The `sabp_*` files are the old pre-epoch implementations. If they're still needed for backward compat, update them to use the new encoding. Otherwise, deprecate and remove.

### 4.2 Update `ab_list.cljs`

- Replace `raw/object->bytes` → `ser/serialize-val`
- Replace `raw/bytes->object` → `ser/deserialize-element`
- Remove Fressian handler registration (`raw/reg!` calls)
- Remove `write-ab-list-fressian` / `read-ab-list-fressian`

### 4.3 Update `chunked_list.cljs`

Same pattern as ab_list — replace raw/ calls with serialize.cljs fast-path.

**Estimated work**: ~200 lines total across legacy files

---

## Phase 5: Remove Fressian

**Goal**: Delete `raw.cljs` and the `fress` dependency.

### 5.1 Remove `raw.cljs`

Delete `/home/user/eve/scm-eve/src/com/seniorcaremarket/eve/raw.cljs` (403 lines).

### 5.2 Remove Fressian Dependency

Update `deps.edn` to remove:
```clojure
com.github.pkpkpk/fress {:mvn/version "..."}
```

### 5.3 Clean Up References

- `atom.cljs`: Remove `raw` require, `raw/convert-sab-value-to-ab-value`, `raw/get-sabp-value-cleanup-fn`
- `util.cljs`: Remove `fressian-code-symbols`, `print-fressian-legend`
- All `sabp_*` files: Remove `raw` requires
- `serialize.cljs`: Remove Fressian fallback path in `serialize-val` and `deserialize-element`

### 5.4 Update `shadow-cljs.edn`

Remove any Fressian-related build config.

**Estimated work**: ~100 lines of deletions, ~50 lines of cleanup

---

## Phase 6: Optimize Atom for Zero-Copy SAB Operations

**Goal**: Now that atoms store SAB pointers, optimize the hot paths.

### 6.1 Zero-Copy Atom Deref

```clojure
(defn deref-atom [s-atom-env]
  ;; Read 9-byte pointer from root descriptor: [tag][offset:i32][count:i32]
  ;; Construct SabMap wrapper around root-offset — NO DATA COPY
  (let [root-desc-idx (read-private-atom-root-data-block-desc-idx ...)
        data-offset (read-descriptor-data-offset root-desc-idx)
        tag (.getUint8 dv data-offset)
        root-off (.getInt32 dv (+ data-offset 1) true)
        cnt (.getInt32 dv (+ data-offset 5) true)]
    (case tag
      TAG_SAB_MAP (SabMapRoot. s-atom-env root-off cnt ...)
      TAG_SAB_VEC (SabVecRoot. s-atom-env root-off cnt ...)
      ;; ...
      )))
```

**Performance**: Atom deref goes from O(n) Fressian decode to O(1) pointer read.

### 6.2 Zero-Copy Atom Swap

```clojure
(defn swap-atom [s-atom-env f]
  ;; 1. Read root pointer (O(1))
  ;; 2. Construct SabMap wrapper (O(1))
  ;; 3. Apply f → new SabMap (user's O(?) operation)
  ;; 4. Write new pointer (9 bytes)
  ;; 5. CAS on root descriptor
  ;; 6. Retire old tree's replaced path
  )
```

**Performance**: Only the user's function determines swap cost. No ser/deser overhead.

### 6.3 Lazy Nested Value Materialization

With SAB pointer encoding, nested values are already lazy:

- `(get sab-map :config)` → returns SabMap (reads 11-byte pointer, constructs wrapper)
- `(get-in sab-map [:config :db :host])` → three pointer reads, never materializes intermediate maps
- `@atom` → returns SabMap wrapping the root, no traversal at all

Only when you actually need a CLJS value (e.g., `(into {} sab-map)`) does full materialization happen.

**Estimated work**: ~200 lines in atom.cljs

---

## Memory Management (Single-Root-in-Atom Model)

### Why It's Simpler Than It Looks

With persistent data structures and a single root in an atom:

1. **Reachability = root pointer.** Once CAS swaps the root, old unreachable nodes are logically dead.
2. **No zeroing needed.** The allocator already doesn't zero on free (confirmed). Old bytes stay until overwritten by a future allocation.
3. **Reader safety is already handled.** Epoch tracking + reader map counters prevent premature reuse.
4. **Structural sharing is safe.** Tree-walk freeing only touches nodes where `old-off != new-off`. Shared subtrees (the common case) are untouched.
5. **Nested collections are just more tree nodes.** A SabMap containing a nested SabMap is just a tree containing a pointer to another tree. Freeing walks both.

### Freeing Lifecycle

```
Writer:
  1. alloc new nodes for modified path
  2. CAS swap root pointer (old → new)
  3. retire-replaced-path!(old-root, new-root, key-hash)
     → walks old/new trees following hash bits
     → retires each node where old != new
     → shared subtrees: skip

Reader:
  1. start-read!(root-desc) → reader count++
  2. traverse tree via pointers (reads old data — still valid bytes)
  3. end-read!(root-desc) → reader count--
     → if any ORPHANED blocks with count==0: finalize free

Sweep (periodic):
  1. sweep-retired-blocks!()
     → for each RETIRED descriptor: if min_active_epoch > retired_epoch → FREE
```

### What We Can Remove

- **`memset!` in `alloc-bytes!`** — new allocations write complete data before becoming visible
- **Recursive deep-dispose of nested collections** — replaced by tree-walk descriptor-status flips
- **"Hard question" about nested lifecycle** — dissolved by single-root reachability model

---

## Implementation Order & Dependencies

```
Phase 0: Extend Fast-Path Encoding          [serialize.cljs]
    ↓
Phase 1: Protocol-Based Extensibility        [serialize.cljs]
    ↓
Phase 2: Records as Tagged Maps              [serialize.cljs]
    ↓
Phase 3: Update Atom Path                   [atom.cljs, sab_map.cljs]
    ↓ (atoms now store SAB pointers, not Fressian)
Phase 4: Update Legacy Data Structures       [sabp_*.cljs, ab_list.cljs, chunked_list.cljs]
    ↓ (nothing uses Fressian anymore)
Phase 5: Remove Fressian                     [raw.cljs deletion, deps.edn cleanup]
    ↓
Phase 6: Optimize Zero-Copy Atom Ops         [atom.cljs]
```

Phases 0-2 can be developed in parallel with existing Fressian fallback still in place (non-breaking). Phase 3 is the breaking change. Phases 4-5 are cleanup. Phase 6 is optimization.

---

## Expected Performance Impact

| Operation | Before (Fressian) | After (SAB Pointers) | Speedup |
|-----------|-------------------|----------------------|---------|
| Atom deref | O(n) Fressian decode | O(1) pointer read | **100-1000x** |
| Atom swap | O(n) encode + O(n) decode | O(1) pointer write + O(1) CAS | **100-1000x** |
| Map get (nested value) | O(k) key match + O(v) Fressian decode | O(k) key match + O(1) pointer read | **10-100x** for collection values |
| Map get (primitive value) | O(k) key match + fast-path decode | O(k) key match + fast-path decode | **1x** (no change) |
| Map assoc (any value) | O(log n) HAMT + O(v) Fressian encode | O(log n) HAMT + O(1) pointer write | **10-100x** for collection values |
| Nested get-in | O(depth × (k + Fressian)) | O(depth × (k + pointer)) | **10-100x** |

---

## Risk Assessment

| Risk | Mitigation |
|------|------------|
| Nested SAB structures increase descriptor count | Batch-alloc already handles descriptor pressure; pool normalization helps |
| Circular references in nested structures | Not possible with persistent data structures — all DAGs |
| Record constructor not registered at deser time | Graceful degradation — return tagged map instead |
| Legacy `sabp_*` code still needed | Phase 4 updates them; can keep Fressian fallback temporarily |
| Memory fragmentation from many small SAB structures | Pool size classes already handle this; tree-walk freeing reclaims |

---

## Files Modified Per Phase

| Phase | Files | Est. Lines Changed |
|-------|-------|-------------------|
| 0 | `serialize.cljs` | +200 |
| 1 | `serialize.cljs` | +150 |
| 2 | `serialize.cljs` | +100 |
| 3 | `atom.cljs`, `sab_map.cljs`, `sab_set.cljs`, `sab_vec.cljs`, `sab_list.cljs` | +300, -200 |
| 4 | `sabp_map.cljs`, `sabp_set.cljs`, `sabp_list.cljs`, `ab_list.cljs`, `chunked_list.cljs` | +100, -200 |
| 5 | `raw.cljs` (delete), `deps.edn`, `shadow-cljs.edn`, `util.cljs` | -450 |
| 6 | `atom.cljs` | +200, -100 |
| **Total** | | **+1050, -950** (net +100) |

# SAB Performance Targets vs Clojure JVM

## Benchmark Data Sources

Data compiled from:
- [Red Planet Labs - Clojure Faster](https://blog.redplanetlabs.com/2020/09/02/clojure-faster/)
- [Clojure Goes Fast - Criterium](https://clojure-goes-fast.com/blog/benchmarking-tool-criterium/)
- [Cuddly Octo Palm Tree - Optimizing Clojure](https://cuddly-octo-palm-tree.com/posts/2022-02-13-opt-clj-5/)
- Standard Java HashMap benchmarks (~10ns per lookup)

## Clojure JVM Benchmark Numbers

### Map Operations (PersistentHashMap)

| Operation | Clojure JVM | Derived ops/sec |
|-----------|-------------|-----------------|
| `get` (lookup) | ~100-170 ns | **6-10M ops/s** |
| `assoc` (single) | ~200-400 ns | **2.5-5M ops/s** |
| `assoc` (transient bulk) | ~12 ns/op amortized | **~80M ops/s** |
| `reduce-kv` (1000 entries) | ~15-30 µs | **33-66k maps/s** |

### Vector Operations (PersistentVector)

| Operation | Clojure JVM | Derived ops/sec |
|-----------|-------------|-----------------|
| `nth` | 4-6 ns | **160-250M ops/s** |
| `conj` | ~50-100 ns | **10-20M ops/s** |
| `peek` | ~9 ns | **~110M ops/s** |
| `assoc` | ~100-200 ns | **5-10M ops/s** |

### Set Operations (PersistentHashSet)

| Operation | Clojure JVM | Derived ops/sec |
|-----------|-------------|-----------------|
| `contains?` | ~100-150 ns | **6-10M ops/s** |
| `conj` | ~200-400 ns | **2.5-5M ops/s** |

## Current SAB Performance (Single-Threaded)

| Operation | SAB CLJS | ops/sec |
|-----------|----------|---------|
| Map `get` (random) | 52-90k ops/s | **100-200x slower** |
| Map `get` (cached) | 720k-1.5M ops/s | **~7x slower** |
| Map `assoc` | 2-15k ops/s | **300-500x slower** |
| Map `reduce-kv` | 300-900k entries/s | **similar** |
| Vector `nth` | 420-670k ops/s | **250-400x slower** |
| Set `contains?` | 390-680k ops/s | **10-25x slower** |

## Performance Gap Analysis

### Biggest Gaps (Focus Areas)

1. **Map/Set build (assoc/conj)**: 300-500x slower
   - Root cause: Fressian serialization + block allocation
   - Target: 10x improvement → 30-50x slower (acceptable for sharing benefit)

2. **Map lookup (uncached)**: 100-200x slower
   - Root cause: Fressian deserialization on every access
   - Target: With caching, already ~7x slower (good!)

3. **Vector nth**: 250-400x slower
   - Root cause: HAMT traversal + deserialization
   - Target: 10x improvement → 25-40x slower

### Acceptable Gaps

1. **Map lookup (cached)**: ~7x slower - ACCEPTABLE
   - Caching brings us close to usable single-threaded perf

2. **reduce-kv**: ~similar - GOOD
   - Streaming reduces deserialization overhead

## Optimization Roadmap

### Phase 1: Reduce Serialization Overhead (Target: 5-10x improvement)

1. **Primitive fast-path expansion**
   - Currently: nil, bool, int32, float64, string, keyword
   - Add: int64, UUID, date, small vectors, small maps
   - Estimated gain: 2-3x for mixed workloads

2. **Lazy deserialization for values**
   - Don't deserialize until actually accessed
   - Estimated gain: 2-3x for iteration patterns

3. **Binary key comparison**
   - Compare serialized bytes instead of deserializing
   - Estimated gain: 2x for lookups

### Phase 2: Reduce Allocation Overhead (Target: 2-5x improvement)

1. **Node pooling**
   - Reuse freed HAMT nodes instead of allocating new
   - Estimated gain: 2x for build operations

2. **Compact node layout**
   - Store small inline KV pairs more efficiently
   - Estimated gain: 1.5x for small maps

3. **Batch allocation**
   - Allocate multiple nodes in single block
   - Estimated gain: 2x for bulk operations

### Phase 3: SIMD/WASM Optimization (Target: 2x improvement)

1. **WASM popcount/memcmp**
   - Use SIMD for bit operations
   - Estimated gain: 1.5-2x for HAMT traversal

2. **Vectorized serialization**
   - SIMD for bulk byte operations
   - Estimated gain: 1.5x for large values

## Target Performance (After Optimization)

| Operation | Current | Target | vs JVM |
|-----------|---------|--------|--------|
| Map `get` (cached) | 1M ops/s | 3M ops/s | 3x slower |
| Map `get` (uncached) | 70k ops/s | 500k ops/s | 15x slower |
| Map `assoc` | 5k ops/s | 100k ops/s | 30x slower |
| Vector `nth` | 500k ops/s | 5M ops/s | 40x slower |
| Set `contains?` | 500k ops/s | 2M ops/s | 5x slower |

## The Value Proposition

Even at 10-50x slower than JVM Clojure:

1. **Zero-copy cross-worker sharing** - JVM can't do this in JS
2. **No serialization for transfer** - Stock CLJS requires full copy
3. **Browser/edge deployment** - No JVM available
4. **Consistent semantics** - Same persistent data structure API

The trade-off: Pay single-threaded overhead, gain multi-threaded sharing.

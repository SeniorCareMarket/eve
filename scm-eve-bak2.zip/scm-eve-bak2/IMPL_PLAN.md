# EVE SAB Performance Optimization — Implementation Plan

## How to Read This Document

You are picking up a shared-memory persistent data structure system written in ClojureScript + WebAssembly. This plan guides you through fixing known bugs and then systematically improving performance to approach stock CLJS speed. **Each phase starts with a test** that reproduces the problem, then fixes it.

Your goal: **close the performance gap with stock CLJS persistent structures**, especially on the write path (assoc, swap!, reset!). Read operations are already near parity.

### Build & Test Commands

```bash
# One-time setup (run at start of every session)
source scripts/ccweb-setup.sh

# Run unit tests (must pass — 67 tests, 1262 assertions)
shadow-compile sab-unit-test && node out/sab-unit-test.js

# Run performance comparison (your progress tracker)
shadow-compile stock-comparison && node out/stock-comparison.js
```

Run the stock-comparison benchmark after each phase to measure progress. Record the numbers.

---

## Part 0: Orientation — What This System Is

### The Big Picture

EVE stores ClojureScript persistent data structures (maps, vectors, sets, lists) inside a `SharedArrayBuffer` (SAB). This lets multiple Web Workers share the same data without copying — each worker gets a zero-copy view of the same memory. The trade-off: operations are slower than stock CLJS because every read/write goes through SAB memory via DataView instead of accessing native JS object properties.

### Key Files (Read These First)

| File | Purpose |
|------|---------|
| `src/com/seniorcaremarket/eve_sab_deftype/core.clj` | **The macro** — generates SAB-backed deftypes |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_map.cljs` | HAMT persistent map (~2100 lines) |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_vec.cljs` | Persistent vector with 32-wide trie |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_set.cljs` | Set (wraps HAMT) |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_list.cljs` | Singly-linked list |
| `src/com/seniorcaremarket/eve_sab_deftype/serialize.cljs` | Serialize/deserialize values to SAB bytes |
| `src/com/seniorcaremarket/eve/data.cljs` | Protocols (ISabStorable, ISabRetirable, IDirectSerialize) |
| `src/com/seniorcaremarket/eve/wasm_mem.cljs` | WASM module (7702 bytes, 41 exports) |
| `src/com/seniorcaremarket/eve/atom.cljs` | Atom implementation (CAS-based swap!) |
| `test/com/seniorcaremarket/eve_sab_deftype/stock_comparison_benchmark.cljs` | **The scoreboard** |

### How eve-sab-deftype Works

The `eve-sab-deftype` macro in `core.clj` generates deftypes that store their fields in SAB memory, not as JavaScript object properties. Each instance is just two JS fields: `[sab__ offset__]` — a reference to the SharedArrayBuffer and the byte offset where the instance's data lives.

```clojure
;; User writes:
(eve-sab-deftype SabMapRoot [^:int32 hash-id ^:int32 cnt ^:int32 root-off]
  ICollection
  (-conj [this entry] ...))

;; Macro generates a deftype with [sab__ offset__] JS fields.
;; Inside protocol methods, the macro auto-generates let-bindings:
;;   (let [hash-id (.getInt32 dv (+ offset__ 1) true)
;;         cnt     (.getInt32 dv (+ offset__ 5) true)
;;         root-off (.getInt32 dv (+ offset__ 9) true)]
;;     <your method body here>)
```

**Critical gotcha**: `(.-root-off some-map)` returns `nil` — fields are in SAB, not JS properties. The macro only binds fields inside method bodies. Outside those methods, you must read fields manually via DataView.

### Memory Layout

```
SAB (SharedArrayBuffer):
┌─────────────┬──────────────────┬────────────────────────────────────┐
│ Header 24B  │ Worker Registry  │ Block Descriptors + Data Region    │
│ sizes/epoch │ 256 slots × 24B  │ desc: [status|offset|len|cap|...] │
└─────────────┴──────────────────┴────────────────────────────────────┘

Each eve-sab-deftype instance:
┌──────────┬────────┬────────┬───────────┐
│ type_id  │ field1 │ field2 │ field3... │  (at some offset in data region)
│ 1 byte   │ 4B     │ 4B    │ ...       │
└──────────┴────────┴────────┴───────────┘

HAMT Bitmap Node:
┌──────┬───────┬─────┬─────────┬─────────┬───────────┬──────────┬─────────┐
│type  │flags  │pad  │data_bm  │node_bm  │children   │hashes    │kv_data  │
│1B    │1B     │2B   │4B       │4B       │C×4B       │M×4B      │variable │
└──────┴───────┴─────┴─────────┴─────────┴───────────┴──────────┴─────────┘
NODE_HEADER_SIZE = 12 bytes
```

### Current Performance Baseline

These are the numbers from the stock-comparison benchmark as of the start of this plan:

| Operation | Stock CLJS | SAB | Gap |
|-----------|-----------|-----|-----|
| **Read-path (near parity)** | | | |
| map get (n=100) | 4.69M/s | 2.98M/s | 1.6x slower |
| set contains? (n=100) | 2.37M/s | 1.13M/s | 2.1x slower |
| vec nth (n=100) | 2.52M/s | 2.69M/s | **1.1x faster** |
| map reduce-kv (n=500) | 88.3K/s | 40.6K/s | 2.2x slower |
| **Write-path (big gap)** | | | |
| map assoc (n=100) | 2.54M/s | 64.6K/s | 39x slower |
| atom swap! inc | 2.05M/s | 27.1K/s | 75x slower |
| atom reset! (20-key) | 7.25M/s | 6.4K/s | 1125x slower |
| map build (n=100) | 3.1K/s | 289/s | 11x slower |

The write path is the primary optimization target. Atom swap! involves: deref (deserialize) → apply fn → serialize → CAS. Each step has overhead.

---

## Phase 1: Fix Broken Field-Access Bugs (14 bugs across 4 files)

### Background

There are 14 places in the codebase where standalone functions (outside deftype method bodies) try to read eve-sab-deftype fields using `(.-field-name instance)`. This always returns `nil` because fields live in SAB memory, not as JS properties. The macro only creates let-bindings inside method bodies — external code must use DataView reads.

These bugs cause:
- **Memory leaks**: `dispose!` functions silently skip cleanup
- **Incorrect tree diffs**: `ISabRetirable/-sab-retire-diff!` passes `nil` to tree diffing
- **Broken parallel reduce**: `sab-preduce` operates on `nil` data

### Step 1.1: Write Regression Tests

Create a test file that exposes all 14 bugs. The tests should **fail** before the fix and **pass** after.

**File**: `test/com/seniorcaremarket/eve_sab_deftype/field_access_bug_test.cljs`

Add it to the `sab-unit-test` build target in `shadow-cljs.edn`.

The test should cover:

#### A. SabMapRoot field access (3 bugs)

```clojure
(deftest test-sab-map-root-field-access-outside-methods
  ;; Bug: (.-root-off some-map) returns nil outside deftype methods
  ;; This breaks dispose!, -sab-retire-diff!, and sab-preduce
  (fresh-atom!)
  (let [m (-> (sab-map/empty-sab-map)
              (assoc :a 1 :b 2 :c 3))]
    ;; The map should have a valid root-off (positive integer)
    ;; Verify that -count works (uses correct internal binding)
    (is (= 3 (count m)))
    ;; Test dispose! actually frees memory (doesn't silently skip)
    ;; Before fix: dispose! checks (when-let [root-off (.-root-off m)] ...)
    ;; which gets nil, so it never frees anything
    ;; After fix: dispose! correctly reads root-off from SAB
    ))
```

#### B. SabMapRoot retire-diff (reading new-value's fields)

```clojure
(deftest test-sab-map-retire-diff-reads-new-value
  ;; Bug: -sab-retire-diff! uses (.-root-off new-value) which returns nil
  ;; This means tree diff gets nil, fails to retire old nodes
  (fresh-atom!)
  (let [m1 (-> (sab-map/empty-sab-map) (assoc :a 1 :b 2))
        m2 (assoc m1 :c 3)]
    ;; m1 and m2 share subtree structure
    ;; retire-diff should only retire nodes unique to m1
    ;; Before fix: passes nil as new-root, entire diff is wrong
    ))
```

#### C. SabVecRoot field access in retire-diff (4 bugs)

```clojure
(deftest test-sab-vec-retire-diff
  ;; Bug: -sab-retire-diff! uses (.-root this), (.-shift this), (.-root new-value)
  ;; All return nil because they're SAB fields, not JS properties
  ;; The correct pattern inside a method body is just: root, shift (bare names)
  ;; For new-value (a different instance), must use DataView
  (fresh-atom!)
  (let [v1 (reduce conj (sab-vec/empty-sab-vec) (range 100))
        v2 (conj v1 100)]
    (is (= 100 (count v1)))
    (is (= 101 (count v2)))))
```

#### D. SabVecRoot dispose! (3 bugs)

```clojure
(deftest test-sab-vec-dispose
  ;; Bug: dispose! uses (.-root sab-vec), (.-tail sab-vec), (.-shift sab-vec)
  ;; All return nil, so root trie and tail are never freed
  (fresh-atom!)
  (let [v (reduce conj (sab-vec/empty-sab-vec) (range 100))]
    (is (= 100 (count v)))
    ;; After fix: calling dispose! should actually free the memory
    ))
```

#### E. SabSetRoot field access (2 bugs)

```clojure
(deftest test-sab-set-retire-diff
  ;; Bug: -sab-retire-diff! uses (.-root-off new-value) which returns nil
  (fresh-atom!)
  (let [s1 (reduce conj (sab-set/empty-sab-set) (range 50))
        s2 (conj s1 50)]
    (is (= 50 (count s1)))
    (is (= 51 (count s2)))))

(deftest test-sab-set-dispose
  ;; Bug: dispose! uses (.-root-off sab-set) which returns nil
  (fresh-atom!)
  (let [s (reduce conj (sab-set/empty-sab-set) (range 50))]
    (is (= 50 (count s)))))
```

#### F. SabList field access (5 bugs)

```clojure
(deftest test-sab-list-retire-diff
  ;; Bug: -sab-retire-diff! uses (.-head-off this) and (.-head-off new-value)
  ;; Both return nil
  (fresh-atom!)
  (let [l1 (reduce conj (sab-list/empty-sab-list) (range 10))
        l2 (conj l1 10)]
    (is (= 10 (count l1)))
    (is (= 11 (count l2)))))

(deftest test-sab-list-dispose
  ;; Bug: dispose! uses (.-head-off sab-list), (.-chunk-size sab-list), etc.
  ;; All return nil
  (fresh-atom!)
  (let [l (reduce conj (sab-list/empty-sab-list) (range 10))]
    (is (= 10 (count l)))))
```

### Step 1.2: Fix the Bugs

For each broken field access, the fix depends on whether we're inside or outside a deftype method body.

**Pattern A — Inside protocol method, accessing `this`**: Use the bare field name (macro provides it).

Example in `sab_vec.cljs` `-sab-retire-diff!`:
```clojure
;; BROKEN:
(let [old-root (.-root this)
      old-shift (.-shift this)]

;; FIXED (bare names from macro let-binding):
(let [old-root root
      old-shift shift]
```

**Pattern B — Inside or outside, accessing a *different* instance**: Use DataView reads.

Example in `sab_map.cljs` `-sab-retire-diff!`:
```clojure
;; BROKEN:
(retire-tree-diff! s-atom-env old-root (.-root-off new-value) mode)

;; FIXED:
(let [dv (wasm/data-view)
      new-root-off (.getInt32 dv (+ (SabMapRoot-offset new-value)
                                    SABMAPROOT_ROOT_OFF_OFFSET) true)]
  (retire-tree-diff! s-atom-env old-root new-root-off mode))
```

**Pattern C — Standalone function (e.g., `dispose!`)**: Always use DataView.

Example in `sab_map.cljs` `dispose!`:
```clojure
;; BROKEN:
(when-let [root-off (.-root-off sab-map)]

;; FIXED:
(let [dv (wasm/data-view)
      root-off (.getInt32 dv (+ (SabMapRoot-offset sab-map)
                                SABMAPROOT_ROOT_OFF_OFFSET) true)]
  (when (> root-off -1)
    ...))
```

### Complete Bug List with Fix Locations

| # | File | Line | Field | Context | Fix Pattern |
|---|------|------|-------|---------|-------------|
| 1 | sab_map.cljs | ~303 | root-off | `dispose!` (standalone fn) | C: DataView read |
| 2 | sab_map.cljs | ~1662 | root-off | `-sab-retire-diff!` (on new-value) | B: DataView read of other instance |
| 3 | sab_map.cljs | ~2006-7 | cnt, root-off | `sab-preduce` (standalone fn) | C: DataView read |
| 4 | sab_set.cljs | ~1043 | root-off | `-sab-retire-diff!` (on new-value) | B: DataView read of other instance |
| 5 | sab_set.cljs | ~1108 | root-off | `dispose!` (standalone fn) | C: DataView read |
| 6 | sab_vec.cljs | ~588 | root | `-sab-retire-diff!` (on this) | A: Use bare name |
| 7 | sab_vec.cljs | ~589 | shift | `-sab-retire-diff!` (on this) | A: Use bare name |
| 8 | sab_vec.cljs | ~592 | root | `-sab-retire-diff!` (on new-value) | B: DataView read |
| 9 | sab_vec.cljs | ~609-11 | root,tail,shift | `dispose!` (standalone fn) | C: DataView read |
| 10 | sab_vec.cljs | ~613-14 | node-size | `dispose!` (standalone fn) | C: DataView/instanceof |
| 11 | sab_list.cljs | ~276 | head-off | `-sab-retire-diff!` (on this) | A: Use bare name |
| 12 | sab_list.cljs | ~278 | head-off | `-sab-retire-diff!` (on new-value) | B: DataView read |
| 13 | sab_list.cljs | ~348-49 | head-off | `dispose!` (standalone fn) | C: DataView read |
| 14 | sab_list.cljs | ~354-57 | chunk-size, head-off, head-idx | `dispose!` (standalone fn) | C: DataView read |

### Understanding the Field Offset Constants

To fix these, you need each field's byte offset within the SAB-deftype layout. Look at the deftype declarations at the top of each file:

- **SabMapRoot** `[^:int32 hash-id ^:int32 cnt ^:int32 root-off]`: type_id at byte 0, hash-id at offset 1, cnt at offset 5, root-off at offset 9. But check for alignment — the macro aligns to 4 bytes. You should look at how the macro computes layout or check what offsets are used in the protocol methods (those are correct).

- **SabVecRoot** fields: look at the deftype declaration for field order and check existing correct code in protocol methods for the actual offsets used.

- **SabSetRoot**: same structure as SabMapRoot.

- **SabList**: check the deftype declaration.

**Research approach**: Look at how fields are accessed in the protocol method bodies that DO work. The macro generates let-bindings with the correct DataView offsets. Copy that pattern for the standalone functions.

### How to Find the Correct Offsets

Search for existing correct field access patterns in the same file. For example, in `sab_map.cljs`, look at how `-count` or `-lookup` reads `root-off` — those method bodies have macro-generated let-bindings with the correct offset calculations. You can also look at the `->SabMapRoot` constructor to see the offsets used during write.

### Verification

After fixing all 14 bugs:
1. All new tests pass
2. All existing 67 tests still pass (no regressions)
3. Run stock-comparison benchmark — performance should not change significantly (these bugs are in dispose/retire paths, not hot read paths)

---

## Phase 2: Atom Swap! Write Path Optimization

### Background

The biggest performance gap is atom swap!: **75x slower** than stock CLJS. Here's what happens during a swap!:

```
swap!(atom, f)
  1. deref atom → deserialize root value from SAB          (deser cost)
  2. apply f to get new-val                                  (user fn)
  3. serialize new-val to SAB bytes                          (ser cost)
  4. CAS the atom root descriptor                            (CAS overhead)
  5. retire-diff old vs new tree                             (GC cost)
```

Stock CLJS swap! is just: `(loop [] (let [old @a, new (f old)] (if (CAS a old new) new (recur))))` — no serialization at all.

### Step 2.1: Profile the Swap Path

Before optimizing, understand where time goes. Write a test that instruments the swap path:

```clojure
(deftest test-swap-cost-breakdown
  ;; Time each phase of swap! separately
  (fresh-atom!)
  (let [m {:counter 0}
        _ (reset! a/*global-atom-instance* m)
        ;; Phase 1: deref cost
        t1 (bench (fn [] @a/*global-atom-instance*) :iters 1000)
        ;; Phase 2: serialize cost (assoc + re-serialize)
        base @a/*global-atom-instance*
        t2 (bench (fn [] (assoc base :counter 1)) :iters 1000)
        ;; Phase 3: full swap cost
        t3 (bench (fn [] (swap! a/*global-atom-instance* update :counter inc)) :iters 500)]
    (println "Deref only:" (:mean-us t1) "us")
    (println "Assoc only:" (:mean-us t2) "us")
    (println "Full swap: " (:mean-us t3) "us")
    (println "Overhead (swap - deref - assoc):"
             (- (:mean-us t3) (:mean-us t1) (:mean-us t2)) "us")))
```

This tells you whether the bottleneck is deserialization, serialization, CAS, or retirement.

### Step 2.2: Investigate the Serialization Path

Read `atom.cljs` carefully. Understand what `swap!` actually does. Key questions:
- Does swap! serialize the entire map or just the changed path?
- Does it re-serialize unchanged values?
- How much time is spent in `serialize-element` vs. allocating SAB blocks?

Look at `reset!` — it's 1125x slower for 20 keys. That means building a 20-key SabMap from a CLJS map is extremely expensive. This is the `register-cljs-to-sab-builder!` path in `serialize.cljs`.

### Step 2.3: Optimize reset! (CLJS map → SabMap conversion)

The current `reset!` path for a plain CLJS map:
1. Detects `map?` → calls registered builder
2. Builder does `(reduce-kv assoc (empty-sab-map) m)` — builds the SabMap entry by entry
3. Each `assoc` allocates nodes, serializes key+value, rebuilds HAMT path

**Potential optimizations**:
- **Batch allocation**: Pre-allocate all KV storage in one block instead of per-node
- **Batch serialization**: Serialize all keys+values first, then build the HAMT tree
- **Transient path**: Use `-as-transient` → bulk `conj!` → `persistent!` (check if transients are faster)
- **Direct HAMT construction**: Build the bitmap trie bottom-up with known hash values instead of top-down assoc

### Step 2.4: Optimize swap! Serialization

For `swap!`, the atom already contains a SabMap. The swap function returns a new SabMap. The critical question: **does the system avoid re-serializing the SabMap that was already built in SAB memory?**

Check `atom.cljs`: when `swap!` applies `f`, it gets a SabMapRoot back (because `assoc` on a SabMapRoot returns a SabMapRoot). Does the CAS path recognize that the new value is already a SabMapRoot and skip serialization?

If it DOES skip serialization (new value already has `IDirectSerialize`), then the swap overhead is purely:
1. Deref (deserialize root pointer → SabMapRoot wrapper — should be O(1) for SAB pointer)
2. Apply f (assoc, which builds new HAMT path)
3. CAS (atomic write of the new root descriptor)
4. Retire-diff (walk changed paths)

If the bottleneck is step 2 (assoc itself), then we need to optimize the HAMT assoc path. If it's step 1 or 4, optimize deref or retire-diff respectively.

### Step 2.5: Reduce Allocation Overhead

Each HAMT assoc allocates:
- New bitmap node (variable size: header + children + hashes + KV data)
- New KV data (serialized key + value)
- New root descriptor

**Optimization ideas**:
- **Arena allocation**: Pre-allocate a contiguous region for the entire path copy, then write all nodes into it
- **WASM bulk node copy**: The existing `build_node_replace_kv` copies node data in WASM, but the allocation itself is in JS. Could the allocation + copy be combined?
- **Reduce descriptor overhead**: Each allocated block needs a 28-byte descriptor. For small nodes, the descriptor overhead dominates

### Step 2.6: Reduce Serialization Overhead

**Key serialization**: For keyword keys (most common), the serialization path is:
1. Check if keyword
2. Encode namespace + name as UTF-8
3. Write tag byte + length prefix + UTF-8 bytes

**Optimization ideas**:
- **Keyword serialization cache**: Cache serialized bytes for frequently-used keywords. Map from `keyword identity hash` → `Uint8Array of serialized form`
- **Intern keywords in SAB**: Store unique keywords once, reference by offset. Dedup on write instead of re-serializing
- **Avoid TextEncoder for ASCII keywords**: Most keywords are ASCII. Direct byte-by-byte copy is faster than TextEncoder for short strings

### Expected Outcome

After Phase 2, target reductions:
- atom swap! from 75x → 20-30x slower (reduce allocation + serialization overhead)
- atom reset! from 1125x → 50-100x slower (batch construction)
- map assoc from 39x → 15-20x slower (reduce per-node overhead)

---

## Phase 3: HAMT Assoc Path Optimization (WASM)

### Background

HAMT assoc is the core write operation. Currently 39-47x slower than stock CLJS. The CLJS HAMT (BitmapIndexedNode) stores children as a flat JavaScript array — no serialization, no memory management. SAB HAMT stores children as serialized bytes in a flat memory buffer with bitmap indexing.

### Step 3.1: Profile HAMT Assoc

Write a benchmark that isolates just the HAMT assoc path (no atom overhead):

```clojure
(deftest test-hamt-assoc-profile
  (fresh-atom!)
  (let [m (loop [m (sab-map/empty-sab-map) i 0]
            (if (>= i 100) m (recur (assoc m (keyword (str "k" i)) i) (inc i))))]
    ;; Now time a single assoc on the existing map
    (let [result (bench (fn [] (assoc m :new-key 999)) :iters 2000)]
      (println "Single assoc on 100-key map:" (:mean-us result) "us"
               (:ops-s result) "ops/s"))))
```

Compare this to stock CLJS single assoc. The gap here tells you how much is HAMT vs. atom overhead.

### Step 3.2: WASM-Accelerated Assoc

Currently, the assoc path involves many JS↔WASM boundary crossings:
1. JS calls `hamt-find` to locate the insert point
2. JS allocates a new node
3. JS calls WASM `build_node_add_kv` or `build_node_replace_kv` to construct the node
4. JS walks up the path, allocating and building nodes at each level
5. JS allocates a new root

**Optimization**: Move the entire assoc path walk into WASM. A single WASM function that:
- Takes: root offset, key hash, key bytes ptr, key len, value bytes ptr, value len
- Does: walks HAMT, allocates new nodes (using the alloc scratch area), copies data
- Returns: new root offset (or same root if value unchanged)

This eliminates ALL JS↔WASM boundary crossings for the assoc path.

### Step 3.3: Implement `hamt_assoc` in WASM

This is a substantial WASM function. Plan it carefully:

```wat
;; Pseudocode for hamt_assoc:
;; Walk from root, depth 0, to leaf
;; At each level:
;;   - Read bitmap node header
;;   - Check if bit is set in data_bm (existing KV)
;;   - Check if bit is set in node_bm (existing child)
;;   - If neither: add KV to this node (build_node_add_kv already exists)
;;   - If data_bm: compare key, if equal replace value, else create child
;;   - If node_bm: recurse into child
;; Allocate all new nodes from a scratch/arena region
;; Return new root offset
```

**Challenge**: Allocation in WASM. The current alloc is in JS (`alloc-bytes!`). You need a way to allocate from WASM. Options:
- Pre-allocate a large arena in JS, pass it to WASM, let WASM do bump allocation within it
- Call back to JS for allocation (eliminates boundary crossing savings)
- Maintain a free list in WASM memory

**Recommendation**: Arena approach. Allocate a 4KB scratch arena per assoc call. WASM does bump allocation within it. JS finalizes by creating proper descriptors for each allocated block.

### Step 3.4: Arena-Based Allocation

```clojure
(defn hamt-assoc-fast [dv sab root-off key-hash key-buf key-len val-buf val-len]
  ;; Pre-allocate arena (enough for 7 levels × max-node-size)
  (let [arena-off (alloc-arena! 4096)
        result-off (wasm/hamt-assoc arena-off root-off
                                    key-hash key-buf key-len
                                    val-buf val-len)
        ;; Walk arena to create proper descriptors
        descriptors (register-arena-blocks! arena-off result-off)]
    result-off))
```

### Expected Outcome

After Phase 3, target:
- map assoc from 39x → 8-12x slower (eliminate JS↔WASM crossings)
- map build from 11x → 5-8x slower (n assocs benefit from faster assoc)
- atom swap! from 20-30x → 10-15x slower (assoc is the inner loop)

---

## Phase 4: Deserialization Optimization

### Background

Atom deref deserializes the root value. For a SabMapRoot, deref returns the wrapper object (O(1) via SAB pointer). But accessing values inside the map requires deserializing each KV entry on demand.

The keyword deserialization cache (Phase 2 of the Iteration plan) already helps, but there are more opportunities.

### Step 4.1: Profile Deref + Access

```clojure
(deftest test-deref-access-profile
  (fresh-atom!)
  (let [m {:a 1 :b 2 :c 3 :d 4 :e 5}]
    (reset! a/*global-atom-instance* m)
    ;; Pure deref (just unwrap pointer)
    (let [t1 (bench (fn [] @a/*global-atom-instance*) :iters 5000)]
      (println "Pure deref:" (:mean-us t1) "us"))
    ;; Deref + single get
    (let [t2 (bench (fn [] (get @a/*global-atom-instance* :c)) :iters 5000)]
      (println "Deref+get:" (:mean-us t2) "us"))
    ;; Deref + get-in
    (let [t3 (bench (fn [] (get-in @a/*global-atom-instance* [:a])) :iters 5000)]
      (println "Deref+get-in:" (:mean-us t3) "us"))))
```

### Step 4.2: Value Deserialization Cache

Currently only keywords are cached. Extend to cache deserialized values by their SAB offset:

```clojure
;; Cache deserialized values by (offset, length) pair
;; Since HAMT nodes are immutable, same (offset, len) → same value
(defonce ^:private value-deser-cache (js/Map.))
```

**Trade-off**: Cache memory vs. deser CPU. Set a reasonable limit (e.g., 8192 entries). LRU or FIFO eviction.

### Step 4.3: Integer Fast-Path

Integers are the most common value type. Current path:
1. Read tag byte from serialized data
2. Branch on tag
3. Read 4 bytes as int32

**Optimization**: Inline the integer check at the call site. If tag == INT32_TAG, read directly without function call overhead.

### Expected Outcome

After Phase 4, target:
- atom deref+get from 10x → 4-6x slower
- atom deref+get-in from 6x → 3-4x slower
- Overall: read-heavy workloads approach 2-3x of stock CLJS

---

## Phase 5: Reduce Descriptor Overhead

### Background

Every allocated SAB block has a 28-byte descriptor (7 × i32). For small HAMT nodes (64-128 bytes), the descriptor is 20-44% overhead. This overhead is also part of the allocation path — finding a free descriptor is part of every allocation.

### Step 5.1: Profile Allocation

```clojure
(deftest test-allocation-profile
  (fresh-atom!)
  ;; Time raw allocation (no content)
  (let [t1 (bench (fn [] (sab-map/alloc-bytes! 64)) :iters 2000)]
    (println "Alloc 64B:" (:mean-us t1) "us"))
  (let [t2 (bench (fn [] (sab-map/alloc-bytes! 256)) :iters 2000)]
    (println "Alloc 256B:" (:mean-us t2) "us")))
```

### Step 5.2: Slab Allocation for Small Nodes

Instead of allocating individual blocks for small nodes, allocate "slabs" — large blocks subdivided into fixed-size slots:

```
Slab (4KB):
┌──────────┬───────┬───────┬───────┬─────┐
│ Slab hdr │ Slot0 │ Slot1 │ Slot2 │ ... │
│ free-bm  │ 64B   │ 64B   │ 64B   │     │
└──────────┴───────┴───────┴───────┴─────┘
```

- One descriptor per slab (not per slot)
- Free-bitmap tracks which slots are in use
- Allocation: find first free bit (O(1) with CLZ), mark it
- Deallocation: clear the bit

This reduces descriptor overhead from 28 bytes per 64-byte node to ~0.5 bytes per node.

### Step 5.3: Embed Node Metadata in Node

Currently, the block descriptor stores `[status, offset, length, capacity, ...]` — separate from the node data. For HAMT nodes, the node header already has type info. Consider embedding the allocation metadata in the node itself:

```
Node with embedded alloc info:
┌──────────┬──────┬───────┬─────┬─────────┬─────────┬──────┐
│ alloc_hdr │type  │flags  │pad  │data_bm  │node_bm  │data  │
│ 4B        │1B    │1B     │2B   │4B       │4B       │...   │
└──────────┴──────┴───────┴─────┴─────────┴─────────┴──────┘
```

This eliminates the descriptor lookup entirely for HAMT node access.

### Expected Outcome

After Phase 5, target:
- Allocation from ~5-10us → 1-3us per block
- map assoc from 8-12x → 5-8x slower (allocation is a significant fraction)
- map build from 5-8x → 3-5x slower

---

## Phase 6: Transient Optimization

### Background

Stock CLJS transients are critical for bulk operations. `into` uses transients internally. The SAB system has transient support (`-as-transient`, `TransientSabMap`) but it may not be well optimized.

### Step 6.1: Benchmark Transients

```clojure
(deftest test-transient-perf
  (fresh-atom!)
  ;; Stock transient build
  (let [stock (bench (fn []
                       (persistent! (reduce (fn [t i] (assoc! t (keyword (str "k" i)) i))
                                           (transient {})
                                           (range 100))))
                     :iters 50)]
    (println "Stock transient build 100:" (:mean-us stock) "us"))
  ;; SAB transient build
  (let [sab (bench (fn []
                     (persistent! (reduce (fn [t i] (assoc! t (keyword (str "k" i)) i))
                                         (transient (sab-map/empty-sab-map))
                                         (range 100))))
                   :iters 50)]
    (println "SAB transient build 100:" (:mean-us sab) "us")))
```

### Step 6.2: Optimize Transient Path

Transients should avoid:
- Node copying (mutate in place)
- Descriptor allocation (reuse existing blocks)
- Same-value checks (transients are mutable, always write)

Check the `TransientSabMap` implementation. Ensure it's actually mutating in-place rather than creating new nodes on each `assoc!`.

### Expected Outcome

After Phase 6, target:
- Transient build from 11x → 3-5x slower
- reset! from 50-100x → 15-30x slower (if reset! uses transient path)

---

## Phase 7: Global Pool Reset Integration

### Background

The `node-pool` and `offset->desc` maps in `sab_map.cljs` and `sab_set.cljs` are `defonce` globals. They persist across `fresh-env` calls, causing stale references when the SAB changes.

### Step 7.1: Write a Test That Exposes the Bug

```clojure
(deftest test-node-pool-survives-fresh-env
  ;; Create env, build map, pool gets populated
  (fresh-atom!)
  (let [m1 (-> (sab-map/empty-sab-map) (assoc :a 1))]
    ;; Now create a new env (different SAB)
    (fresh-atom!)  ;; Should call reset-pools! internally
    ;; Build another map in the new env
    (let [m2 (-> (sab-map/empty-sab-map) (assoc :b 2))]
      ;; This should work without corruption
      (is (= 1 (count m2)))
      (is (= 2 (get m2 :b))))))
```

### Step 7.2: Auto-Reset Pools on Environment Change

Wire `reset-pools!` into the atom creation path so it's called automatically:
- In `atom.cljs` or wherever `fresh-env` / `private-atom` is called
- Clear `node-pool`, `offset->desc`, and keyword deser cache

---

## Phase 8: Continuous Performance Tracking

### Step 8.1: Add Performance Assertions

Add soft performance assertions to the benchmark (warn, don't fail):

```clojure
(defn check-regression [label sab-result stock-result max-ratio]
  (let [ratio (/ (:ops-s stock-result) (:ops-s sab-result))]
    (when (> ratio max-ratio)
      (println "WARNING: Performance regression!" label
               "ratio:" (.toFixed ratio 1) "x, max allowed:" max-ratio "x"))))
```

### Step 8.2: Track Progress Over Time

After each phase, run the stock-comparison benchmark and record the results. Track:
- Map get (n=100): Target ≤ 1.5x slower
- Map assoc (n=100): Target ≤ 10x slower
- Atom swap! inc: Target ≤ 15x slower
- Atom reset! 20-key: Target ≤ 30x slower

---

## Research & Exploration Guidance

This plan is a starting point. As you work through each phase, you should:

1. **Read the code deeply**. Don't just fix what the plan says — understand WHY the current code works the way it does. The HAMT implementation is sophisticated; study it before changing it.

2. **Research online**. Look into:
   - How V8 optimizes SharedArrayBuffer and DataView access
   - WASM best practices for minimizing JS↔WASM boundary crossings
   - How other WASM-backed data structures handle allocation (e.g., AssemblyScript, Rust wasm-bindgen)
   - HAMT implementation papers (Phil Bagwell's original paper, Clojure's approach)

3. **Experiment aggressively**. Try different approaches, measure, keep what works. Performance optimization is empirical — theory only gets you so far.

4. **Run benchmarks frequently**. After every change, run `stock-comparison` to check for regressions and measure progress. Small regressions compound.

5. **Check the WASM binary size**. Current: 7702 bytes. Keep it under 10KB. Each new WASM function adds ~100-500 bytes.

6. **Test edge cases**. Empty maps, single-element maps, maps at HAMT branching boundaries (32, 1024 elements), hash collisions, nil values, mixed key types.

7. **Read the ClojureScript HAMT source**. Compare the stock CLJS `BitmapIndexedNode` implementation with the SAB version. The structural differences reveal optimization opportunities.

---

## Appendix A: File-by-File Bug Inventory

### sab_map.cljs (3 bugs)

**Bug 1 — `dispose!` (~line 303)**
```clojure
;; BROKEN:
(when-let [root-off (.-root-off sab-map)] ...)
;; Impact: Memory leak — map's HAMT tree is never freed
```

**Bug 2 — `-sab-retire-diff!` (~line 1662)**
```clojure
;; BROKEN:
(retire-tree-diff! s-atom-env old-root (.-root-off new-value) mode)
;; Impact: Tree diff gets nil, fails to retire old nodes
```

**Bug 3 — `sab-preduce` (~lines 2006-2007)**
```clojure
;; BROKEN:
(let [cnt (.-cnt sab-map) root-off (.-root-off sab-map)] ...)
;; Impact: Parallel reduce operates on nil data
```

### sab_set.cljs (2 bugs)

**Bug 4 — `-sab-retire-diff!` (~line 1043)**
```clojure
;; BROKEN:
(retire-tree-diff! s-atom-env old-root (.-root-off new-value) mode)
```

**Bug 5 — `dispose!` (~line 1108)**
```clojure
;; BROKEN:
(when-let [root-off (.-root-off sab-set)] ...)
```

### sab_vec.cljs (4 bugs)

**Bug 6-7 — `-sab-retire-diff!` (~lines 588-589)**
```clojure
;; BROKEN:
(let [old-root (.-root this) old-shift (.-shift this)] ...)
;; Fix: use bare names: root, shift
```

**Bug 8 — `-sab-retire-diff!` (~line 592)**
```clojure
;; BROKEN:
(retire-replaced-trie-path! ... (.-root new-value) ...)
```

**Bug 9-10 — `dispose!` (~lines 609-614)**
```clojure
;; BROKEN:
(let [root-off (.-root sab-vec) tail-off (.-tail sab-vec) shift-val (.-shift sab-vec)] ...)
```

### sab_list.cljs (5 bugs)

**Bug 11-12 — `-sab-retire-diff!` (~lines 276-278)**
```clojure
;; BROKEN:
(let [old-head (.-head-off this) ...
      new-head (.-head-off new-value)] ...)
;; Fix for this: use bare name head-off
;; Fix for new-value: DataView read
```

**Bug 13-14 — `dispose!` (~lines 348-357)**
```clojure
;; BROKEN:
(exists? (.-head-off sab-list))
(let [head-off (.-head-off sab-list)] ...)
(exists? (.-chunk-size sab-list))
(let [head-off (.-head-off sab-list) head-idx (.-head-idx sab-list) cs (.-chunk-size sab-list)] ...)
```

---

## Appendix B: Performance Targets Summary

| Operation | Current | Phase 2 | Phase 3 | Phase 5 | Phase 6 | Ultimate |
|-----------|---------|---------|---------|---------|---------|----------|
| map get (100) | 1.6x | 1.6x | 1.6x | 1.5x | 1.5x | ≤1.5x |
| map assoc (100) | 39x | 20x | 8-12x | 5-8x | 3-5x | ≤5x |
| map build (100) | 11x | 8x | 5-8x | 3-5x | 3-5x | ≤5x |
| atom swap! inc | 75x | 20-30x | 10-15x | 8-12x | 8-12x | ≤10x |
| atom reset! (20) | 1125x | 50-100x | 30-50x | 15-30x | 15-30x | ≤20x |
| map reduce-kv (500) | 2.2x | 2.2x | 2.2x | 2.0x | 2.0x | ≤2x |

These are aspirational targets. Some may not be achievable without fundamental architectural changes. Measure and adjust as you go.

---

## Appendix C: Build Target Reference

```bash
# Unit tests (MUST pass)
shadow-compile sab-unit-test && node out/sab-unit-test.js

# Performance scoreboard
shadow-compile stock-comparison && node out/stock-comparison.js

# Detailed perf (single-env, reliable numbers)
shadow-compile perf-benchmark && node out/perf-benchmark.js

# Large scale stress
shadow-compile large-scale-test && node out/large-scale-test.js

# SIMD-specific benchmarks
shadow-compile simd-benchmark && node out/simd-benchmark.js
```

---

## Appendix D: WASM Development Workflow

The WASM binary is embedded as hex bytes in `wasm_mem.cljs`. To modify WASM:

1. Edit the `.wat` file (WebAssembly text format)
2. Compile: `wat2wasm input.wat -o output.wasm --enable-simd --enable-threads`
3. Convert to hex: Read the binary, convert each byte to hex
4. Update the `wasm-bytes` array in `wasm_mem.cljs`
5. Rebuild: `shadow-compile sab-unit-test && node out/sab-unit-test.js`

The `.wat` file may not exist in the repo — the binary is the source of truth. To get the `.wat` back:
```bash
wasm2wat output.wasm -o recovered.wat
```

Current WASM binary: 7702 bytes, 41 exports. Budget: stay under 10KB.

---

## Getting Started Checklist

1. [ ] Run `source scripts/ccweb-setup.sh`
2. [ ] Run tests: `shadow-compile sab-unit-test && node out/sab-unit-test.js` — verify 67 tests pass
3. [ ] Run benchmark: `shadow-compile stock-comparison && node out/stock-comparison.js` — record baseline
4. [ ] Read `core.clj` (the macro) — understand how fields work
5. [ ] Read `sab_map.cljs` — understand HAMT structure
6. [ ] Read `atom.cljs` — understand swap!/reset! flow
7. [ ] Start Phase 1: write regression tests for field-access bugs
8. [ ] Fix the 14 bugs
9. [ ] Re-run tests and benchmark
10. [ ] Move to Phase 2

# SAB-* Structures Performance Optimization Plan

## Overview

This document outlines the implementation plan for bringing performance optimizations from the old `sabp-*` structures to the new `sab-*` structures (sab-map, sab-set, sab-vec, sab-list).

**Target structures:**
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_map.cljs`
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_set.cljs`
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_vec.cljs`
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_list.cljs`

---

## Phase 1: Two-Bitmap HAMT Design (High Priority)

### Current State
- NEW: Single bitmap with separate leaf nodes for every entry
- OLD: `data_bitmap` (inline KV pairs) + `node_bitmap` (child pointers)

### Changes Required

#### 1.1 Update Node Layout (sab_map.cljs, sab_set.cljs)

```
Current Internal Node:
[type:u8][pad:u8][bitmap:u32][unused:u32][child0:i32]...[childN:i32]

New Bitmap Node:
[type:u8][pad:u8][data_bitmap:u32][node_bitmap:u32]
[child_offset:i32]...  (popcount(node_bitmap) entries)
[kv_entry]...          (popcount(data_bitmap) entries)

Each KV entry:
[key_len:u32][key_bytes...][val_len:u32][val_bytes...]
```

#### 1.2 New Constants

```clojure
(def ^:const NODE_TYPE_BITMAP 1)      ;; Replaces internal + leaf distinction
(def ^:const NODE_TYPE_COLLISION 3)   ;; Keep as-is
(def ^:const BITMAP_HEADER_SIZE 10)   ;; type:u8 + pad:u8 + data_bm:u32 + node_bm:u32
```

#### 1.3 Functions to Add/Modify

**New helper functions:**
```clojure
(defn- read-data-bitmap [dv offset] ...)
(defn- read-node-bitmap [dv offset] ...)
(defn- kv-data-start [base node-bitmap]
  (+ base BITMAP_HEADER_SIZE (* 4 (popcount32 node-bitmap))))
```

**Modify `hamt-find`:**
- Check `data_bitmap` first for inline KV lookup
- Fall through to `node_bitmap` for child traversal

**Modify `hamt-assoc`:**
- When adding to empty slot: add to `data_bitmap` (inline)
- When slot has inline KV with different key:
  - If same hash → collision node
  - If different hash → create child node, move to `node_bitmap`
- When slot has child: recurse

**Modify `hamt-dissoc`:**
- Remove from `data_bitmap` or recurse into child
- If child becomes single entry, promote to `data_bitmap` (inline back)

#### 1.4 Benefits
- **Fewer allocations**: Small entries stay inline, no separate leaf nodes
- **Better cache locality**: KV pairs contiguous in parent node
- **Reduced memory**: No leaf node headers for inline entries

#### 1.5 Files to Modify
- `sab_map.cljs`: Full implementation
- `sab_set.cljs`: Port changes (set uses same HAMT structure)

---

## Phase 2: Streaming Reduce (High Priority)

### Current State
- `reduce` materializes sequence via `hamt-seq`, then reduces
- No early termination support in tree walk

### Changes Required

#### 2.1 Add `hamt-kv-reduce` (sab_map.cljs)

```clojure
(defn- hamt-kv-reduce
  "Walk HAMT tree directly, calling (f acc k v) at each entry.
   Supports reduced? for early termination."
  [s-atom-env dv offset f init]
  (if (== offset -1)
    init
    (let [node-type (read-node-type dv offset)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv offset)
                node-bm (read-node-bitmap dv offset)
                data-count (popcount32 data-bm)
                kv-start (kv-data-start offset node-bm)
                ;; Reduce over inline KV entries
                acc-after-data
                (loop [i 0 pos kv-start acc init]
                  (if (or (>= i data-count) (reduced? acc))
                    acc
                    (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                      (recur (inc i) next-pos (f acc k v)))))
                child-count (popcount32 node-bm)]
            (if (reduced? acc-after-data)
              acc-after-data
              ;; Reduce over children
              (loop [i 0 acc acc-after-data]
                (if (or (>= i child-count) (reduced? acc))
                  acc
                  (let [child-off (read-child-offset dv offset i)]
                    (recur (inc i) (hamt-kv-reduce s-atom-env dv child-off f acc)))))))

        ;; Collision node
        3 (let [cnt (.getUint8 dv (+ offset 1))]
            (loop [i 0 pos (+ offset NODE_HEADER_SIZE) acc init]
              (if (or (>= i cnt) (reduced? acc))
                acc
                (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                  (recur (inc i) next-pos (f acc k v))))))

        init))))
```

#### 2.2 Implement IKVReduce Protocol

```clojure
IKVReduce
(-kv-reduce [_ f init]
  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
        dv (js/DataView. (:sab s-atom-env))
        result (hamt-kv-reduce s-atom-env dv root-off f init)]
    (if (reduced? result) @result result)))
```

#### 2.3 Optimize IReduce

```clojure
IReduce
(-reduce [this f]
  (-kv-reduce this (fn [acc k v] (f acc (MapEntry. k v nil))) (f)))

(-reduce [this f init]
  (-kv-reduce this (fn [acc k v] (f acc (MapEntry. k v nil))) init))
```

#### 2.4 Add `hamt-reduce` for Sets

```clojure
(defn- hamt-reduce
  "Walk HAMT tree directly, calling (f acc v) at each entry."
  [s-atom-env dv offset f init]
  ;; Similar to hamt-kv-reduce but single value
  ...)
```

#### 2.5 Benefits
- **No intermediate allocation**: Direct tree walk
- **Early termination**: `reduced?` stops traversal immediately
- **~2-5x faster** for large map reductions

---

## Phase 3: Lazy Sequences

### Current State
- `hamt-seq` materializes entire tree into vector, then converts to seq

### Changes Required

#### 3.1 Add `hamt-seq-lazy` (sab_map.cljs)

```clojure
(defn- hamt-seq-lazy
  "Produce lazy sequence of MapEntry from HAMT tree.
   Only materializes inline entries per node; child traversal is lazy."
  [s-atom-env dv offset]
  (when-not (== offset -1)
    (let [node-type (read-node-type dv offset)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv offset)
                node-bm (read-node-bitmap dv offset)
                data-count (popcount32 data-bm)
                child-count (popcount32 node-bm)
                kv-start (kv-data-start offset node-bm)
                ;; Materialize inline entries (bounded by 16)
                inline-entries
                (loop [i 0 pos kv-start acc []]
                  (if (>= i data-count)
                    acc
                    (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                      (recur (inc i) next-pos (conj acc (MapEntry. k v nil))))))
                ;; Lazy child traversal
                child-seqs
                (fn step [ci]
                  (lazy-seq
                    (when (< ci child-count)
                      (let [child-off (read-child-offset dv offset ci)]
                        (concat (hamt-seq-lazy s-atom-env dv child-off)
                                (step (inc ci)))))))]
            (concat inline-entries (child-seqs 0)))

        ;; Collision node
        3 (let [cnt (.getUint8 dv (+ offset 1))]
            (loop [i 0 pos (+ offset NODE_HEADER_SIZE) acc []]
              (if (>= i cnt)
                (seq acc)
                (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                  (recur (inc i) next-pos (conj acc (MapEntry. k v nil)))))))

        nil))))
```

#### 3.2 Update ISeqable

```clojure
ISeqable
(-seq [_]
  (when (pos? cnt)
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (js/DataView. (:sab s-atom-env))]
      (hamt-seq-lazy s-atom-env dv root-off))))
```

#### 3.3 Benefits
- **Memory efficient**: Only materializes entries as needed
- **Fast first/take**: No need to walk entire tree
- **Interruptible**: Can stop iteration early

---

## Phase 4: Skip Functions

### Current State
- Must deserialize entries to skip over them
- Inefficient for indexed access in collision nodes

### Changes Required

#### 4.1 Add Skip Functions

```clojure
(defn- skip-kv-at
  "Skip a KV pair, returning the offset after it (no deserialization)."
  [dv kv-offset]
  (let [key-len (.getUint32 dv kv-offset true)
        val-offset (+ kv-offset 4 key-len)
        val-len (.getUint32 dv val-offset true)]
    (+ val-offset 4 val-len)))

(defn- skip-key-at
  "Skip a key entry, returning offset after it."
  [dv key-offset]
  (let [key-len (.getUint32 dv key-offset true)]
    (+ key-offset 4 key-len)))

(defn- skip-val-at
  "Skip a value entry, returning offset after it."
  [dv val-offset]
  (let [val-len (.getUint32 dv val-offset true)]
    (+ val-offset 4 val-len)))
```

#### 4.2 Use in hamt-find for collision nodes

```clojure
;; Instead of reading all entries, skip to target
(loop [i 0 pos (+ offset NODE_HEADER_SIZE)]
  (if (>= i cnt)
    [false nil]
    (let [key-len (.getUint32 dv pos true)
          key-bytes (copy-from-sab sab (+ pos 4) key-len)
          entry-k (deserialize-element s-atom-env key-bytes)]
      (if (= k entry-k)
        ;; Found - now read value
        (let [val-offset (+ pos 4 key-len)
              val-len (.getUint32 dv val-offset true)
              val-bytes (copy-from-sab sab (+ val-offset 4) val-len)
              val-val (deserialize-element s-atom-env val-bytes)]
          [true val-val])
        ;; Skip entire KV without deserializing value
        (recur (inc i) (skip-kv-at dv pos))))))
```

#### 4.3 Benefits
- **Faster collision node lookup**: Skip non-matching entries without deserializing values
- **Efficient indexed access**: Skip to target index without reading intermediate entries

---

## Phase 5: Raw Byte Copying

### Current State
- Node reconstruction deserializes and re-serializes all entries

### Changes Required

#### 5.1 Add Raw Copy Functions

```clojure
(defn- copy-kv-data-except!
  "Copy all KV entries from src node to dst, skipping entry at skip-idx.
   No deserialization - raw byte copy."
  [s-atom-env dv src-offset src-data-bm src-node-bm dst-offset skip-idx]
  (let [data-count (popcount32 src-data-bm)
        src-kv-start (kv-data-start src-offset src-node-bm)
        sab (:sab s-atom-env)]
    (loop [i 0 src-pos src-kv-start dst-pos dst-offset]
      (if (>= i data-count)
        dst-pos
        (let [next-src (skip-kv-at dv src-pos)
              kv-len (- next-src src-pos)]
          (if (== i skip-idx)
            (recur (inc i) next-src dst-pos)
            (do
              ;; Raw copy
              (.set (js/Uint8Array. sab)
                    (js/Uint8Array. sab src-pos kv-len)
                    dst-pos)
              (recur (inc i) next-src (+ dst-pos kv-len)))))))))

(defn- copy-kv-data-all!
  "Copy all KV entries from src to dst. Raw byte copy, no deserialization."
  [s-atom-env dv src-offset src-data-bm src-node-bm dst-offset]
  (let [data-count (popcount32 src-data-bm)
        src-kv-start (kv-data-start src-offset src-node-bm)
        sab (:sab s-atom-env)]
    (loop [i 0 src-pos src-kv-start dst-pos dst-offset]
      (if (>= i data-count)
        dst-pos
        (let [next-src (skip-kv-at dv src-pos)
              kv-len (- next-src src-pos)
              src-bytes (js/Uint8Array. sab src-pos kv-len)]
          (.set (js/Uint8Array. sab) src-bytes dst-pos)
          (recur (inc i) next-src (+ dst-pos kv-len)))))))
```

#### 5.2 Use in Node Reconstruction

Replace deserialize→serialize patterns in `hamt-assoc` and `hamt-dissoc` with raw byte copies.

#### 5.3 Benefits
- **~3-5x faster node reconstruction**: Skip serialization overhead
- **Less memory churn**: No intermediate CLJS objects

---

## Phase 6: Parallel Reduce

### Current State
- All reduce operations are single-threaded

### Changes Required

#### 6.1 Add preduce Function

```clojure
(def ^:private ^:const MIN_PARALLEL_ENTRIES 1000)

(defn- get-top-level-subtrees
  "Get child offsets and inline KVs from root bitmap node."
  [s-atom-env dv root-offset]
  ...)

(defn- partition-offsets
  "Partition offsets into n roughly equal groups."
  [offsets n]
  (let [total (count offsets)
        per-partition (js/Math.ceil (/ total n))]
    (partition-all per-partition offsets)))

(defn sab-preduce
  "Parallel reduce over SabMapRoot. Splits tree at top level.
   init-fn:  (fn [] init-val) - called per partition
   rfn:      (fn [acc k v] acc') - per-entry reduction
   merge-fn: (fn [acc1 acc2] merged) - combines partition results"
  [sab-map init-fn rfn merge-fn]
  (let [cnt (.-cnt sab-map)
        root-off (.-root-off sab-map)]
    (if (< cnt MIN_PARALLEL_ENTRIES)
      ;; Sequential fallback
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (js/DataView. (:sab s-atom-env))
            result (hamt-kv-reduce s-atom-env dv root-off rfn (init-fn))]
        (if (reduced? result) @result result))
      ;; Parallel path
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (js/DataView. (:sab s-atom-env))
            {:keys [children inline-kvs]} (get-top-level-subtrees s-atom-env dv root-off)
            num-partitions (min (count children) 4)]
        (if (<= (count children) 1)
          ;; Too few children
          (let [result (hamt-kv-reduce s-atom-env dv root-off rfn (init-fn))]
            (if (reduced? result) @result result))
          ;; Reduce partitions independently
          (let [partitions (partition-offsets children num-partitions)
                inline-acc (reduce (fn [acc [k v]] (rfn acc k v))
                                   (init-fn)
                                   inline-kvs)
                partition-results
                (mapv (fn [offsets]
                        (reduce (fn [acc child-off]
                                  (let [r (hamt-kv-reduce s-atom-env dv child-off rfn acc)]
                                    (if (reduced? r) @r r)))
                                (init-fn)
                                offsets))
                      partitions)]
            (reduce merge-fn inline-acc partition-results)))))))
```

#### 6.2 Integration with IFold (Future)

```clojure
;; Future: true parallel execution via workers
IFold
(-fold [coll n combinef reducef]
  (sab-preduce coll combinef reducef combinef))
```

#### 6.3 Benefits
- **Near-linear speedup** for large maps with reducible operations
- **Foundation for worker-based parallelism**

---

## Phase 7: Chunked Storage (sab-list, sab-vec)

### Current State
- sab-list: Per-element linked list nodes
- sab-vec: Per-element value blocks in HAMT

### Changes Required

#### 7.1 Chunk Constants

```clojure
(def ^:const CHUNK_SIZE 32)
```

#### 7.2 Chunk Layout

```
Chunk:
[count:u32]
[elem_len:u32][elem_bytes...]  ;; repeated count times
```

#### 7.3 Directory Structure (for vec)

```
Directory:
[num_chunks:u32]
[chunk_offset:i32]...  ;; num_chunks entries
```

#### 7.4 IChunkedSeq Implementation

```clojure
IChunkedSeq
(-chunked-first [_]
  ;; Return ArrayChunk of first 32 elements
  ...)
(-chunked-rest [_]
  ;; Return seq starting at chunk 1
  ...)
(-chunked-more [_]
  ...)
```

#### 7.5 Benefits
- **Batch iteration**: Process 32 elements per chunk
- **O(1) indexed access**: Direct chunk lookup + scan within chunk
- **Reduced block descriptors**: One allocation per 32 elements

---

## Phase 8: Cached Deserialization

### Current State
- Every access deserializes from SAB

### Changes Required

#### 8.1 Add Cache Field to Types

```clojure
(eve-sab-deftype SabMapRoot
  [^:int32 cnt
   ^:int32 root-off
   ^:mutable _cache]  ;; atom for caching
  ...)
```

#### 8.2 Cached Accessor Pattern

```clojure
(defn- get-cached-or-compute [cache-atom key compute-fn]
  (if-let [cached (get @cache-atom key)]
    cached
    (let [value (compute-fn)]
      (swap! cache-atom assoc key value)
      value)))
```

#### 8.3 Cache Invalidation
- Structural operations (assoc, dissoc) return new instance with fresh cache
- Cache is instance-local, no sharing concerns

#### 8.4 Benefits
- **Repeated access speedup**: Avoid re-deserialization
- **Amortized cost**: First access pays, subsequent accesses are fast

---

## Phase 9: SIMD Optimizations

### Overview
Leverage WebAssembly SIMD for vectorized operations on SAB data.

### 9.1 Target Operations

**Bitmap operations:**
- `popcount` - Count set bits (SIMD popcnt)
- Bitmap AND/OR/XOR for set operations

**Hash operations:**
- Parallel hash computation for multiple keys
- SIMD comparison for collision node search

**Memory operations:**
- Vectorized memory copy (128-bit moves)
- Parallel byte comparison for key matching

### 9.2 Implementation Approach

#### Option A: Inline WASM (Preferred for small ops)

```clojure
;; Compile-time WASM module
(def ^:private simd-module
  (js/WebAssembly.Module.
    (js/Uint8Array. [0x00 0x61 0x73 0x6d ...])))  ;; WASM bytes

(def ^:private simd-instance
  (js/WebAssembly.Instance. simd-module))

(defn- simd-popcount [bitmap]
  ((.exports simd-instance).popcount bitmap))
```

#### Option B: SharedArrayBuffer + WASM

```clojure
;; WASM module with SAB access
(defn- simd-memcmp [sab offset1 offset2 len]
  "Compare len bytes at two SAB offsets using SIMD.
   Returns 0 if equal, non-zero otherwise."
  ((.exports simd-instance).memcmp sab offset1 offset2 len))

(defn- simd-memmove [sab src-off dst-off len]
  "Copy len bytes within SAB using SIMD."
  ((.exports simd-instance).memmove sab src-off dst-off len))
```

### 9.3 WASM Functions to Implement

```wat
;; popcount32 - count set bits
(func $popcount32 (param $x i32) (result i32)
  local.get $x
  i32.popcnt)

;; simd_memcmp - compare memory regions
(func $simd_memcmp (param $ptr1 i32) (param $ptr2 i32) (param $len i32) (result i32)
  ;; Use v128.load and v128.eq for 16-byte chunks
  ...)

;; simd_memmove - vectorized memory copy
(func $simd_memmove (param $dst i32) (param $src i32) (param $len i32)
  ;; Use v128.load/v128.store for 16-byte chunks
  ...)

;; simd_hash_batch - hash multiple keys in parallel
(func $simd_hash_batch (param $keys i32) (param $count i32) (param $hashes i32)
  ;; Parallel murmur3 or xxhash using SIMD lanes
  ...)
```

### 9.4 Feature Detection

```clojure
(def ^:private simd-available?
  (try
    (js/WebAssembly.validate
      (js/Uint8Array. [0x00 0x61 0x73 0x6d 0x01 0x00 0x00 0x00
                       ;; SIMD feature detection bytes
                       ]))
    (catch :default _ false)))

(defn- popcount32 [n]
  (if simd-available?
    (simd-popcount n)
    ;; Fallback to JS implementation
    (let [n (- n (bit-and (unsigned-bit-shift-right n 1) 0x55555555))
          n (+ (bit-and n 0x33333333)
               (bit-and (unsigned-bit-shift-right n 2) 0x33333333))
          n (bit-and (+ n (unsigned-bit-shift-right n 4)) 0x0f0f0f0f)
          n (+ n (unsigned-bit-shift-right n 8))
          n (+ n (unsigned-bit-shift-right n 16))]
      (bit-and n 0x3f))))
```

### 9.5 Priority SIMD Targets

1. **popcount32** - Used constantly in HAMT navigation
2. **memcmp** - Key comparison in collision nodes
3. **memmove** - Raw byte copying during node reconstruction
4. **hash_batch** - Parallel hashing for bulk operations

### 9.6 Benefits
- **2-8x speedup** for vectorizable operations
- **Better throughput** for memory-intensive operations
- **Future-proof** for advanced SIMD (AVX-512 via WASM)

---

## Implementation Order

### Tier 1: Foundation (Blocks other work)
1. **Two-Bitmap HAMT** - Must be first, changes core node structure
2. **Skip Functions** - Enables efficient implementation of other phases

### Tier 2: High-Impact (Independent)
3. **Streaming Reduce** - Major reduce-kv speedup
4. **Raw Byte Copying** - Major node reconstruction speedup
5. **Lazy Sequences** - Memory efficiency

### Tier 3: Advanced (Build on Tier 1-2)
6. **Parallel Reduce** - Requires streaming reduce
7. **SIMD Optimizations** - Independent, can be added incrementally

### Tier 4: Structure-Specific
8. **Chunked Storage** - sab-list and sab-vec specific
9. **Cached Deserialization** - Can add last, minimal code changes

---

## Testing Strategy

### Unit Tests
- Verify correctness after each phase
- Regression tests for all protocols (ISeq, IReduce, IKVReduce, etc.)

### Performance Benchmarks
- Run `performance_comparison_test.cljs` after each phase
- Track ops/sec for: build, lookup, reduce, iterate

### Contention Tests
- Run `contention_perf_test.cljs` to verify multi-threaded correctness
- Ensure SIMD operations are thread-safe with SAB

---

## Files to Create/Modify

### New Files
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/simd.cljs` - SIMD utilities
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/simd.wat` - WASM source

### Modified Files
- `sab_map.cljs` - Phases 1-6, 8-9
- `sab_set.cljs` - Phases 1-6, 8-9
- `sab_vec.cljs` - Phases 7-9
- `sab_list.cljs` - Phases 7-9

---

## Success Metrics

| Metric | Current | Target |
|--------|---------|--------|
| Map build (n=500) | ~25k ops/s | ~50k ops/s |
| Map lookup (n=500) | ~200k ops/s | ~400k ops/s |
| Map reduce-kv | ~50k ops/s | ~150k ops/s |
| Contention write | ~20 ops/s | ~50 ops/s |
| Memory per entry | ~50 bytes | ~30 bytes |

---

## Notes

- **Columnar layout preserved**: Current leaf/internal structure compatible with future SIMD column operations
- **Backward compatibility**: Changes should not break existing serialized data
- **Incremental rollout**: Each phase can be merged independently

---

## Architectural Understanding: Single-Root-in-Atom Model

### Key Insight (2026-02-06)

EVE uses persistent data structures rooted in a single atom. This constraint fundamentally simplifies memory management:

1. **Reachability = root pointer.** After CAS swap, old nodes are unreachable (no external code can follow old pointers).
2. **No zeroing needed.** The allocator already doesn't zero on free. Old bytes stay until overwritten.
3. **Reader safety handled.** Epoch tracking + reader map counters prevent premature reuse.
4. **Structural sharing safe to free around.** Tree-walk retires only replaced path (O(log n) nodes per swap).
5. **Nested collections are just more tree nodes.** No special lifecycle management.

**Implications for optimization:**
- `memset!` in allocation hot path can be removed (10-20% allocation speedup)
- `dispose!` is replaced by lighter-weight `retire-replaced-path!`
- Atom swap can integrate retire for automatic memory reclamation
- See `MEMORY_MANAGEMENT_PLAN.md` for full phased plan.

---

## Phase 10: Fressian Removal (Supersedes Fast-Path Expansion)

> **NOTE**: The original Phase 10 (fast-path expansion) has been superseded by a comprehensive
> Fressian removal plan. Phases 10.1-10.5 below are now Phase 0 of `FRESSIAN_REMOVAL_PLAN.md`.
> The full plan removes Fressian entirely, replacing it with SAB pointer encoding for nested
> collections and protocol-based extensibility. See `FRESSIAN_REMOVAL_PLAN.md` for details.

### Original Audit (Preserved for Reference)

### Audit Date: 2026-02-05

### Current Serialization Architecture

All SAB-backed data structures use a two-tier serialization approach:

1. **Fast-path** for common primitives (no Fressian, direct binary encoding)
2. **Fressian fallback** for complex/nested types

### Files with Serialization Code

| File | serialize-element | deserialize-element | raw/object->bytes | raw/bytes->object |
|------|-------------------|---------------------|-------------------|-------------------|
| sab_map.cljs | ✓ (lines 100-183) | ✓ (lines 185-220) | fallback | fallback |
| sab_vec.cljs | ✓ (lines 79-162) | ✓ (lines 164-199) | fallback | fallback |
| sab_set.cljs | ✓ (lines 63-146) | ✓ (lines 148-183) | fallback | fallback |
| raw.cljs | - | - | ✓ (main impl) | ✓ (main impl) |

### Current Fast-Path Types

Types currently handled without Fressian overhead:

| Type | Tag | Size (bytes) | Format |
|------|-----|--------------|--------|
| nil | - | 0 | Empty byte array |
| false | 0x01 | 3 | `[0xEE][0xDB][tag]` |
| true | 0x02 | 3 | `[0xEE][0xDB][tag]` |
| int32 | 0x03 | 7 | `[magic][tag][i32:4]` |
| float64 | 0x04 | 11 | `[magic][tag][f64:8]` |
| string (short) | 0x05 | 4+len | `[magic][tag][len:u8][bytes]` (len < 256) |
| string (long) | 0x06 | 7+len | `[magic][tag][len:u32][bytes]` |
| keyword (short) | 0x07 | 4+len | no namespace, len < 256 |
| keyword (long) | 0x08 | 7+len | no namespace, len >= 256 |

### Types Currently Using Fressian (Slow Path)

These fall through to `raw/object->bytes` → `fress.writer`:

| Type | Frequency | Fressian Size | Priority to Fix |
|------|-----------|---------------|-----------------|
| **Namespaced keywords** | Very high | ~50-100 bytes | **P0** |
| **UUID** | High | ~40 bytes | **P0** |
| Symbol | Medium | ~30 bytes | P1 |
| Date/Instant | Medium | ~20 bytes | P1 |
| BigInt (>i32) | Low | Variable | P2 |
| Nested maps | High | Variable | Keep Fressian |
| Nested vectors | High | Variable | Keep Fressian |
| Regex | Low | Variable | Keep Fressian |
| Records | Low | Variable | Keep Fressian |
| Custom types | Low | Variable | Keep Fressian |

### What MUST Stay Fressian

These types require Fressian's full serialization capabilities:

1. **Nested collections** - Maps, vectors, sets containing arbitrary values
2. **Records (defrecord)** - Custom record types with type metadata
3. **Custom registered handlers** - User-defined serialization via `raw/reg!`
4. **Typed arrays** - Int8Array, Float32Array, etc.
5. **Complex objects** - Regex, URI, arbitrary JS objects

### What SHOULD Become Fast-Path

Types that are simple, fixed-size, or extremely common:

| Type | Proposed Tag | Proposed Format | Savings |
|------|--------------|-----------------|---------|
| Namespaced kw (short) | 0x09 | `[magic][tag][ns_len:u8][ns][name_len:u8][name]` | ~40-80 bytes |
| Namespaced kw (long) | 0x0A | `[magic][tag][ns_len:u32][ns][name_len:u32][name]` | ~40-80 bytes |
| UUID | 0x0B | `[magic][tag][16 bytes]` = 19 bytes | ~20 bytes |
| Symbol (simple) | 0x0C | Same as keyword 0x07 | ~25 bytes |
| Symbol (namespaced) | 0x0D | Same as keyword 0x09/0x0A | ~25 bytes |
| Date/Instant | 0x0E | `[magic][tag][i64 millis]` = 11 bytes | ~10 bytes |
| int64 | 0x0F | `[magic][tag][i64]` = 11 bytes | Variable |

### Phase 10.1: Namespaced Keywords (Highest Impact)

**Current problem**: Keywords like `:user/name`, `:db/type` go through Fressian at ~100+ bytes each.

**Implementation**:

```clojure
;; In serialize-element, add before string handling:

;; Namespaced keyword
(and (keyword? elem) (namespace elem))
(let [ns-str (namespace elem)
      name-str (name elem)
      ns-enc (.encode fast-encoder ns-str)
      name-enc (.encode fast-encoder name-str)
      ns-len (.-length ns-enc)
      name-len (.-length name-enc)]
  (if (and (<= ns-len 255) (<= name-len 255))
    ;; Short format
    (let [buf (js/Uint8Array. (+ 5 ns-len name-len))]
      (aset buf 0 d/DIRECT_MAGIC_0)
      (aset buf 1 d/DIRECT_MAGIC_1)
      (aset buf 2 0x09)  ;; FAST_TAG_KEYWORD_NS_SHORT
      (aset buf 3 ns-len)
      (.set buf ns-enc 4)
      (aset buf (+ 4 ns-len) name-len)
      (.set buf name-enc (+ 5 ns-len))
      buf)
    ;; Long format (0x0A)
    ...))
```

**Estimated gain**: 5-10x faster for namespaced keyword heavy workloads

### Phase 10.2: UUID (High Impact)

**Current**: Uses Fressian STRUCTTYPE wrapper (~40 bytes)
**Proposed**: 19 bytes fixed

```clojure
;; In serialize-element:
(uuid? elem)
(let [buf (js/Uint8Array. 19)
      dv (js/DataView. (.-buffer buf))
      uuid-str (.toString elem)]
  (aset buf 0 d/DIRECT_MAGIC_0)
  (aset buf 1 d/DIRECT_MAGIC_1)
  (aset buf 2 0x0B)  ;; FAST_TAG_UUID
  ;; Parse hex string to 16 bytes
  (dotimes [i 16]
    (let [hex-idx (* i 2)
          ;; Skip hyphens at positions 8, 13, 18, 23
          adj-idx (cond
                    (>= hex-idx 20) (+ hex-idx 4)
                    (>= hex-idx 16) (+ hex-idx 3)
                    (>= hex-idx 12) (+ hex-idx 2)
                    (>= hex-idx 8) (+ hex-idx 1)
                    :else hex-idx)
          byte-val (js/parseInt (.substring uuid-str adj-idx (+ adj-idx 2)) 16)]
      (aset buf (+ 3 i) byte-val)))
  buf)
```

### Phase 10.3: Symbol

Same format as keywords but different tag values (0x0C for simple, 0x0D for namespaced).

### Phase 10.4: Date/Instant

```clojure
(instance? js/Date elem)
(let [buf (js/ArrayBuffer. 11)
      dv (js/DataView. buf)
      u8 (js/Uint8Array. buf)]
  (.setUint8 dv 0 d/DIRECT_MAGIC_0)
  (.setUint8 dv 1 d/DIRECT_MAGIC_1)
  (.setUint8 dv 2 0x0E)  ;; FAST_TAG_DATE
  ;; Store as i64 milliseconds (use two i32s for JS compat)
  (let [ms (.getTime elem)]
    (.setFloat64 dv 3 ms true))  ;; Use float64 for full range
  u8)
```

### Phase 10.5: int64 for Large Integers

```clojure
;; In serialize-element, modify number handling:
(and (number? elem) (js/Number.isInteger elem))
(if (and (>= elem -2147483648) (<= elem 2147483647))
  ;; Existing int32 path
  ...
  ;; New int64 path using BigInt64Array
  (let [buf (js/ArrayBuffer. 11)
        dv (js/DataView. buf)
        u8 (js/Uint8Array. buf)]
    (.setUint8 dv 0 d/DIRECT_MAGIC_0)
    (.setUint8 dv 1 d/DIRECT_MAGIC_1)
    (.setUint8 dv 2 0x0F)  ;; FAST_TAG_INT64
    (.setBigInt64 dv 3 (js/BigInt elem) true)
    u8))
```

---

## Phase 11: Node Pooling (IMPLEMENTED)

> **Status**: Implemented in commits 60fc5d7 and 823148b. Pool size-class normalization [64, 128, 256, 512],
> MAX_POOL_SIZE=200, batch pre-allocation of 8 blocks on pool miss. Both sab_map and sab_set have full
> pool infrastructure. See README optimization #4 (Pool Size-Class Normalization) and #5 (Batch Pre-Allocation).

### Original Design (Preserved for Reference)

```clojure
;; Add to s-atom-env structure
{:node-pool {
   32   #queue [offset1 offset2 ...]   ;; 32-byte nodes
   64   #queue [offset3 offset4 ...]   ;; 64-byte nodes
   128  #queue [offset5 ...]           ;; etc.
   256  #queue [...]
   512  #queue [...]
 }}
```

### Size Classes (Updated — 32 dropped, too small for typical HAMT nodes)

| Class | Size Range | Common Use |
|-------|------------|------------|
| ~~32~~ | ~~up to 32 bytes~~ | ~~Single-KV bitmap nodes~~ (dropped) |
| 64 | up to 64 bytes | 1-2 KV nodes |
| 128 | 65-128 bytes | Typical internal nodes |
| 256 | 129-256 bytes | Larger nodes |
| 512 | 257-512 bytes | Collision nodes |

### Implementation

1. Modify `free-hamt-node!` to add to pool instead of freeing
2. Modify `alloc-bytes!` to check pool first
3. Add pool size limits (e.g., max 100 nodes per class)
4. Zero pooled memory before reuse

---

## Revised Implementation Order (Updated 2026-02-07)

### Completed
- **Phase 1**: Two-Bitmap HAMT — DONE (sab_map.cljs, sab_set.cljs)
- **Phase 2**: Streaming Reduce — DONE (hamt-kv-reduce with reduced?)
- **Phase 3**: Lazy Sequences — DONE (lazy-seq child traversal)
- **Phase 4**: Skip Functions — DONE (skip-kv-at, skip-key-at)
- **Phase 5**: Raw Byte Copying — DONE (memcpy for unchanged KV pairs)
- **Phase 6**: Parallel Reduce — DONE (sab-preduce)
- **Phase 7**: Chunked Storage — DONE (SabVecN, SabListN)
- **Phase 8**: Cached Deserialization — DONE (SabMapRoot _cache, cache-get/cache-put!)
- **Phase 9**: SIMD Optimizations — DONE (simd.cljs, simd_wasm.cljs, simd_hamt.cljs)
- **Phase 10.1-10.5**: Fast-path expansion (namespaced kw, UUID, symbol, date, int64) — DONE in serialize.cljs (commit 4ae0ebd)
- **Phase 11**: Node pooling — DONE (commits 60fc5d7, 823148b)
- **Fressian Removal** — COMPLETE (all 6 phases, see `FRESSIAN_REMOVAL_PLAN.md`)
- **Memory Management** — COMPLETE (all phases, see `MEMORY_MANAGEMENT_PLAN.md`)
  - memset! removed from alloc hot path
  - retire-replaced-path! + retire-tree-diff! for all data structures
  - ISabRetirable wired into atom swap
  - Demand-driven sweep in alloc/batch-alloc fallback
  - O(1) offset→desc lookup
- **Same-value assoc detection** — COMPLETE (commit 8ac4fa6)
  - hamt-assoc compares value bytes before allocating
  - -assoc/-dissoc return `this` when root unchanged
  - Same-value swap: 89.2K ops/s (5.8x faster)

- **Stored CLJS hash per KV entry** — COMPLETE (commit 4c69fac)
  - KV layout: [cljs_hash:i32][key_len:u32][key_bytes...][val_len:u32][val_bytes...]
  - hamt-assoc/dissoc use stored hash, no key deserialization
- **Immutable block flags + COW** (Opt 7.1/7.2) — N/A (not needed with current architecture)
- **No-op transient round-trip** (Opt 7.3c) — COMPLETE (commit 981df4f)
- **ArrayMap for small maps** — REVERTED (caused regression, commit 981df4f)
- **WASM HAMT node builders** — COMPLETE
  - 5 new WASM functions: calc_kv_total_size, build_node_replace_child,
    build_node_replace_kv, build_node_add_kv, build_node_remove_kv_add_child
  - Consolidates header+children+KV construction into single WASM calls
  - Eliminates dozens of JS↔WASM boundary crossings per node build
  - WASM binary: 3872 bytes (up from 2633), 28 exports total

### Status: ALL OPTIMIZATIONS COMPLETE

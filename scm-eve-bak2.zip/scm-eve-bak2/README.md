# scm-eve

**EVE** (Extensible Value Encoding) — persistent data structures backed by WebAssembly.Memory (SharedArrayBuffer) for zero-copy cross-worker sharing in JavaScript/ClojureScript.

Published by SeniorCareMarket.com.

## What is this?

`scm-eve` provides ClojureScript-compatible persistent data structures (maps, vectors, sets, lists) where **all data lives in WebAssembly shared memory**. This enables:

- **Zero-copy sharing** between Web Workers / threads — no structured clone, no postMessage serialization
- **Full ClojureScript protocol support** — `assoc`, `dissoc`, `get`, `conj`, `reduce`, `seq`, etc.
- **Epoch-based garbage collection** — safe concurrent reads with CAS-based allocation
- **WASM SIMD acceleration** — popcount, memcmp, hamt_find, descriptor scanning in hand-written WAT

The trade-off: operations are slower than stock ClojureScript (which uses JS objects). The value proposition is cross-worker data sharing that would otherwise require serialization/deserialization at every boundary.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    ClojureScript Protocols                       │
│     IAssociative, ILookup, ISeqable, IReduce, ITransient...    │
├──────────┬──────────┬───────────┬───────────┬───────────────────┤
│ SabMapRoot│SabVecRoot│SabSetRoot │SabListRoot│  TransientSabMap  │
│ (HAMT)   │ (trie+  │ (HAMT)    │ (linked)  │  (HAMT or flat HT)│
│          │  tail)   │           │           │                   │
├──────────┴──────────┴───────────┴───────────┴───────────────────┤
│              Serialization Layer (serialize.cljs)                │
│  keyword cache │ scratch buffers │ fast-path encode/decode      │
├─────────────────────────────────────────────────────────────────┤
│           Allocation Layer (atom.cljs)                          │
│  descriptor scan │ CAS locking │ remainder split │ batch-alloc  │
│  node pool │ size-class normalization │ WASM-accelerated scan   │
├─────────────────────────────────────────────────────────────────┤
│           WebAssembly.Memory (shared)                           │
│  WASM module: popcount, memcpy, memset, hamt_find, SIMD ops    │
│  descriptor table │ data blocks │ reader maps │ worker registry │
└─────────────────────────────────────────────────────────────────┘
```

### Key Modules

| File | Purpose |
|------|---------|
| `src/com/seniorcaremarket/eve_sab_deftype/sab_map.cljs` | Persistent map — two-bitmap HAMT with inline KV pairs |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_vec.cljs` | Persistent vector — 32-way trie with SAB tail |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_set.cljs` | Persistent set — two-bitmap HAMT with inline values |
| `src/com/seniorcaremarket/eve_sab_deftype/sab_list.cljs` | Persistent list — O(1) cons/first/rest |
| `src/com/seniorcaremarket/eve_sab_deftype/serialize.cljs` | Shared serialization — keyword cache, scratch buffers |
| `src/com/seniorcaremarket/eve_sab_deftype/core.clj` | `eve-sab-deftype` macro — generates SAB-backed types |
| `src/com/seniorcaremarket/eve/atom.cljs` | Allocator — descriptor-based coalescing with CAS, batch-alloc |
| `src/com/seniorcaremarket/eve/wasm_mem.cljs` | WASM memory management — views, SIMD wrappers, init |
| `resources/wasm/wasm_mem.wat` | Hand-written WAT — SIMD ops, hamt_find, descriptor scan |

### HAMT Node Layout

Two-bitmap design for both maps and sets:

```
[type:u8][pad:u8][data_bitmap:u32][node_bitmap:u32][children...][kv_data...]
  │                  │                  │               │           │
  │                  │                  │               │           └─ [klen:u32][kbytes...][vlen:u32][vbytes...]
  │                  │                  │               └─ 4-byte i32 offsets to child nodes
  │                  │                  └─ bits marking slots with child node pointers
  │                  └─ bits marking slots with inline key-value data
  └─ 1=bitmap, 3=collision
```

### Allocator

Descriptor-based coalescing allocator in SharedArrayBuffer:
- **Descriptor table**: Array of 28-byte descriptors (status, offset, capacity, lock, epoch)
- **CAS locking**: Compare-and-swap for concurrent allocation/deallocation
- **Remainder splitting**: Large blocks split on allocation, coalesced on free
- **Reader tracking**: Per-descriptor reader counts for safe concurrent reads
- **Epoch-based GC**: Workers register epochs, blocks freed when no readers remain

### Memory Model: Single-Root-in-Atom

All EVE data structures are accessed through a single root pointer in an atom. This constraint enables a simplified memory management model:

- **Reachability = root pointer.** After a CAS swap, old unreachable nodes are logically dead. No one can traverse old pointers — the root is the only entry point.
- **No zeroing needed.** The allocator doesn't zero data on free (only flips descriptor STATUS). Old bytes stay until overwritten by future allocations. This is safe because new nodes are fully populated before the CAS swap makes them visible.
- **Structural sharing is safe to free around.** After a swap, `retire-replaced-path!` walks old/new trees and retires only the O(log n) replaced path nodes. Shared subtrees (the common case) are skipped via `old-off == new-off`.
- **Nested collections are just more tree nodes.** A SabMap containing a nested SabVec is a tree pointing to another tree. Freeing walks both. No special lifecycle management needed.
- **Reader safety via epochs.** `retire-block!` marks nodes RETIRED at the current epoch. `sweep-retired-blocks!` frees them when `min_active_epoch > retired_epoch` (no readers from that epoch remain).

See `MEMORY_MANAGEMENT_PLAN.md` for the full phased implementation plan.

## Building

```bash
# Source the setup script (handles proxy, Maven deps, classpath)
source scripts/ccweb-setup.sh

# Run unit tests
shadow-compile sab-unit-test && node out/sab-unit-test.js

# Run performance benchmarks
shadow-compile perf-comparison && node out/perf-comparison.js

# Compile a specific target
shadow-compile <target-name>
```

Build targets are defined in `shadow-cljs.edn`.

## Performance Optimizations

### Implemented Optimizations

#### 1. Cached WASM Views
**Files**: `sab_map.cljs`, `sab_vec.cljs`, `sab_set.cljs`, `sab_list.cljs`, `core.clj`

Replaced per-call `(js/DataView. sab)` and `(js/Uint8Array. sab)` with cached module-level views via `(wasm/data-view)` and `(wasm/u8-view)`. The `eve-sab-deftype` macro emits cached view access instead of `js/DataView.` constructor calls. Eliminates thousands of view object allocations per operation.

**Impact**: Foundation for all other optimizations. Map lookup 18.85x faster.

#### 2. JS memcpy/memset Fallbacks
**Files**: `wasm_mem.cljs`

WASM module loads asynchronously. Before it's ready, `memcpy!` and `memset!` now use `Uint8Array.copyWithin`/`Uint8Array.fill` instead of failing. All code paths work from first call.

#### 3. Shared Serialization Module
**File**: `serialize.cljs`

Centralized serialization previously duplicated across sab_map, sab_vec, sab_set, sab_list. Key optimizations:

- **Keyword cache** (`js/Map`, up to 2048 entries): Keywords are interned in CLJS — cache serialized `Uint8Array` form. Avoids `TextEncoder` + allocation on every keyword serialize.
- **Dual scratch buffers** (A/B, 32 bytes each): Reusable `ArrayBuffer`s for numeric serialization (nil, bool, int32, float64). `.subarray()` returns a VIEW, so two buffers prevent aliasing when key+value coexist.
- **Fast-path encoding**: Direct `DataView` writes for nil, boolean, int32, float64, string, keyword. Only falls back to Fressian for complex types.

**Impact**: Set contains 3.14x faster. Eliminated ~200 lines of duplicated serialization code.

#### 4. Pool Size-Class Normalization (Option C)
**File**: `sab_map.cljs`

Allocations rounded up to fixed size classes `[64, 128, 256, 512]` bytes. When a node is freed, its block returns to the pool at its size class. When a new node is needed, it gets a same-sized block from the pool — no capacity mismatch.

Key changes:
- `alloc-bytes!` allocates `size-class` bytes, not exact `n` bytes
- `maybe-pool-or-free!` stores `size-class` in pool metadata
- `MAX_POOL_SIZE` increased to 200 per class
- Dropped 32-byte class (too small for typical HAMT nodes)

**Design rationale**: Typical HAMT node sizes:
- Leaf (1 KV, keyword+int32): ~32 bytes → class 64
- Two-entry node: ~54 bytes → class 64
- Three-entry/branchy: ~76-100 bytes → class 128
- Root with many entries: ~128-256 bytes → class 128/256

#### 5. Batch Pre-Allocation (Option A)
**Files**: `atom.cljs`, `sab_map.cljs`

On pool miss, `alloc-bytes!` calls `batch-alloc` to grab 8 blocks in one descriptor scan instead of 1. Returns the first block and pools the other 7. Subsequent allocations are O(1) pool hits.

`batch-alloc` does a single scan through the descriptor table, CAS-locking and claiming each matching block. Uses WASM-accelerated scan when available, JS fallback when not.

**Why this matters**: Persistent HAMT operations create new nodes but never free old ones (structural sharing). The pool stays cold during map construction. Batch pre-allocation is the only way to warm it.

#### 6. WASM Descriptor Scan (Option B)
**Files**: `wasm_mem.wat`, `wasm_mem.cljs`, `atom.cljs`

Added two new WASM functions for scanning the descriptor table:
- `find_free_descriptor`: Single-result scan — returns first free descriptor with sufficient capacity
- `find_free_descriptors_batch`: Multi-result scan — fills output buffer with up to N matching indices

The scan runs entirely in WASM (`i32.load` loop, 28-byte stride per descriptor), avoiding JS↔WASM boundary overhead per descriptor. The JS side CAS-locks and verifies candidates.

Automatic fallback to JS scan when WASM isn't ready (during initialization).

#### 7. Two-Bitmap HAMT Design
**Files**: `sab_map.cljs`, `sab_set.cljs`

Separate `data_bitmap` and `node_bitmap` instead of single bitmap. Inline KV data lives directly in the node, child pointers are separate. Reduces indirection and makes node scanning cache-friendly.

#### 8. Skip Functions
**Files**: `sab_map.cljs`, `sab_set.cljs`

Fast-forward through KV pairs without deserialization during node traversal. `skip-kv-at` reads only length prefixes, not actual data. Essential for finding the N-th entry in a bitmap node.

#### 9. Raw Byte Copying
**Files**: `sab_map.cljs`, `sab_set.cljs`

When restructuring HAMT nodes (e.g., adding an entry), unchanged KV pairs are copied as raw bytes via `memcpy` — no deserialize→reserialize cycle. Only the changed entry is serialized fresh.

#### 10. Streaming Reduce with Early Termination
**File**: `sab_map.cljs`

`hamt-kv-reduce` traverses the HAMT and calls the reducing function inline. Supports `reduced?` for early termination. No intermediate sequence allocation.

#### 11. Lazy Sequences
**File**: `sab_map.cljs`

`hamt-seq` uses `lazy-seq` for child node traversal. Only materializes entries as they're consumed. Essential for `(take 5 (seq large-map))` performance.

#### 12. Parallel Reduce
**File**: `sab_map.cljs`

`sab-preduce` partitions top-level HAMT subtrees for parallel reduction across workers (leveraging the shared memory architecture).

#### 13. Proactive Writer Cleanup
**File**: `atom.cljs`

Writers retry freeing blocks up to 4 times with exponential backoff (2ms, 4ms, 8ms, 16ms) before marking as ORPHANED. Reduces memory fragmentation from short-lived reader holds.

#### 14. Block Coalescing
**File**: `atom.cljs`

Adjacent free blocks are merged after deallocation. Prevents fragmentation over time where total free space is sufficient but no single block is large enough.

#### 15. Explicit Disposal for All Data Structures
**Files**: `sab_map.cljs`, `sab_set.cljs`, `sab_vec.cljs`, `sab_list.cljs`

All four data structures now expose a `dispose!` function that recursively frees the entire tree/chain and returns memory to the allocator or node pool. Due to structural sharing in persistent data structures, old nodes cannot be freed automatically during assoc/dissoc/conj/disj operations (other versions may still reference them). `dispose!` is the explicit cleanup mechanism for when a structure is no longer needed.

- **sab_map**: `(sab-map/dispose! m)` — frees entire HAMT tree, nodes go to pool
- **sab_set**: `(sab-set/dispose! s)` — frees entire HAMT tree, nodes go to pool (now with pool + batch-alloc matching sab_map)
- **sab_vec**: `(sab-vec/dispose! v)` — frees trie nodes, tail, and all value blocks
- **sab_list**: `(sab-list/dispose! l)` — frees linked list chain (SabList) or chunk chain + value blocks (SabListN)

#### 16. Set Pool + Batch Pre-Allocation
**File**: `sab_set.cljs`

sab_set now has the same pool infrastructure as sab_map: size-class normalization `[64, 128, 256, 512]`, batch pre-allocation of 8 blocks on pool miss, and `maybe-pool-or-free!` for recycling nodes. Previously, every set allocation was a fresh descriptor scan.

### Recently Completed

| Optimization | Impact | Status |
|-------------|--------|--------|
| Fressian removal (SAB pointer encoding) | O(1) atom deref/swap (was O(n) Fressian) | **COMPLETE** — `FRESSIAN_REMOVAL_PLAN.md` |
| Memory management (retire-tree-diff, sweep) | Closes HAMT memory leak, atom swap 29-38% faster | **COMPLETE** — `MEMORY_MANAGEMENT_PLAN.md` |
| Remove memset! from allocation hot path | Eliminated unnecessary zeroing in alloc | **COMPLETE** |
| Same-value assoc detection | 89.2K ops/s for no-op swap (5.8x faster) | **COMPLETE** |

**Remaining:**

| Optimization | Expected Impact | Status |
|-------------|----------------|--------|
| ArrayMap for small maps (≤8 entries) | 10x build speedup | Planned |
| WASM hamt_assoc | 4-5x build speedup | Planned |

See `OPTIMIZATION_PLAN.md` for the full roadmap.

## Performance

Current benchmarks (JIT-warmed, single-threaded):

| Operation | Stock CLJS | EVE SAB | Ratio |
|-----------|-----------|---------|-------|
| Map build (n=100) | 142μs | ~10ms | ~70x slower |
| Map lookup (n=100) | 321μs | ~800μs | ~2.5x slower |
| Set contains | — | 3.14x faster than previous | — |

Target: within 5x of stock CLJS for typical operations, with the benefit of zero-copy cross-worker sharing.

## Testing

```bash
# Unit tests (45 tests, 346 assertions)
shadow-compile sab-unit-test && node out/sab-unit-test.js

# Full test suite (includes core-test which may have pre-existing failures)
shadow-compile test && node out/test.js
```

## Project Structure

```
scm-eve/
├── src/com/seniorcaremarket/
│   ├── eve/                         # Core infrastructure
│   │   ├── atom.cljs                # Allocator + GC
│   │   ├── wasm_mem.cljs            # WASM memory backend
│   │   ├── data.cljs                # Constants + layout
│   │   ├── util.cljs                # Worker utilities
│   │   ├── raw.cljs                 # Fressian handlers
│   │   └── conveyance.cljs          # Cross-worker transport
│   └── eve_sab_deftype/             # Persistent data structures
│       ├── sab_map.cljs             # HAMT map + transient
│       ├── sab_vec.cljs             # Trie vector + tail
│       ├── sab_set.cljs             # HAMT set
│       ├── sab_list.cljs            # Linked list
│       ├── serialize.cljs           # Shared serialization
│       ├── simd.cljs                # SIMD utilities
│       └── core.clj                 # eve-sab-deftype macro
├── resources/wasm/
│   ├── wasm_mem.wat                 # WASM source (hand-written)
│   └── wasm_mem.wasm                # Compiled WASM binary
├── test/                            # 31 test files
├── scripts/ccweb-setup.sh           # Build environment setup
├── shadow-cljs.edn                  # Build configuration
├── FRESSIAN_REMOVAL_PLAN.md         # 6-phase plan to remove Fressian
├── MEMORY_MANAGEMENT_PLAN.md        # Single-root-in-atom memory model
├── OPTIMIZATION_PLAN.md             # Performance optimization plan
├── MISSING_OPTIMIZATIONS_PLAN.md    # Gap analysis vs old sabp-* impls
└── docs/                            # Additional documentation
```

## License

See the parent project for license information.

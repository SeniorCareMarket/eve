(ns com.seniorcaremarket.eve.chunked-list
  "SabpChunkedList: A chunked persistent list backed by SharedArrayBuffer.
   Elements stored in chunks of 32 for O(1) indexed access, efficient
   chunked iteration (IChunkedSeq), and reduced block descriptor usage
   compared to the per-node linked list."
  (:require
    [com.seniorcaremarket.eve.ab-list :as ab]
    [com.seniorcaremarket.eve.atom :as a]
    [com.seniorcaremarket.eve.data :as d]
    [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]
    [com.seniorcaremarket.eve.util :as u]))

(declare ->SabpChunkedList ->SabpChunkedSeq ->SabpChunkBuffer ->SabpChunkedVec)

;; ============================================================================
;; Chunk read/write helpers
;; ============================================================================

(def ^:private ^:const CHUNK_SIZE d/CHUNKED_LIST_CHUNK_SIZE)

(defn- read-chunk-element-count
  "Read the element count (u32) at the start of a chunk."
  [^js dv ^number chunk-offset]
  (.getUint32 dv chunk-offset true))

(defn- scan-to-element
  "Scan within a chunk to find the offset and length of element at index i.
   Returns [abs-offset length] within the SAB."
  [^js dv ^number chunk-offset ^number elem-idx]
  (let [num-elems (read-chunk-element-count dv chunk-offset)]
    (when (< elem-idx num-elems)
      (loop [i 0
             pos (+ chunk-offset 4)] ;; skip num_elements header
        (if (== i elem-idx)
          (let [elem-len (.getUint32 dv pos true)]
            [(+ pos 4) elem-len])
          (let [elem-len (.getUint32 dv pos true)]
            (recur (inc i) (+ pos 4 elem-len))))))))

(defn- read-element-at
  "Read and deserialize the element at index elem-idx within a chunk."
  [s-atom-env ^js dv ^number chunk-offset ^number elem-idx]
  (when-let [[abs-offset length] (scan-to-element dv chunk-offset elem-idx)]
    (if (zero? length)
      nil
      (let [sab (:sab s-atom-env)
            elem-bytes (js/Uint8Array. sab abs-offset length)
            copied (js/Uint8Array. length)]
        (.set copied elem-bytes)
        (ser/deserialize-element s-atom-env copied)))))

(defn- chunk-total-data-size
  "Calculate the total byte size of a chunk's data (including length prefixes)."
  [^js dv ^number chunk-offset]
  (let [n (read-chunk-element-count dv chunk-offset)]
    (loop [i 0 pos (+ chunk-offset 4)]
      (if (>= i n)
        (- pos chunk-offset 4)
        (let [elem-len (.getUint32 dv pos true)]
          (recur (inc i) (+ pos 4 elem-len)))))))

;; ============================================================================
;; Directory read helpers
;; ============================================================================

(defn- read-directory-num-chunks
  "Read the number of chunks from a directory block."
  [^js dv ^number dir-offset]
  (.getUint32 dv dir-offset true))

(defn- read-directory-chunk-offset
  "Read the i-th chunk's data offset from the directory."
  [^js dv ^number dir-offset ^number chunk-idx]
  (.getInt32 dv (+ dir-offset 4 (* chunk-idx 4)) true))

;; ============================================================================
;; Chunk/Directory allocation helpers
;; ============================================================================

(defn- write-chunk!
  "Write a chunk into SAB. elements-bytes is a vector of Uint8Array (serialized elements).
   Returns the data offset of the written chunk."
  [s-atom-env elements-bytes]
  (let [n (count elements-bytes)
        ;; Calculate total chunk size: 4 (count) + sum(4 + elem-len for each)
        total-size (+ 4 (reduce (fn [acc ^js eb] (+ acc 4 (.-length eb))) 0 elements-bytes))
        alloc-info (a/alloc s-atom-env total-size)]
    (when (:error alloc-info)
      (throw (js/Error. (str "Chunked list chunk alloc failed: " (:error alloc-info)))))
    (let [offset (:offset alloc-info)
          desc-idx (:descriptor-idx alloc-info)
          dv (js/DataView. (:sab s-atom-env))
          data-view (:data-view s-atom-env)]
      ;; Write element count
      (.setUint32 dv offset n true)
      ;; Write elements with length prefixes
      (loop [i 0 pos (+ offset 4)]
        (when (< i n)
          (let [^js eb (nth elements-bytes i)
                eb-len (.-length eb)]
            (.setUint32 dv pos eb-len true)
            (when (pos? eb-len)
              (.set data-view eb (+ pos 4)))
            (recur (inc i) (+ pos 4 eb-len)))))
      ;; Update descriptor length
      (u/write-block-descriptor-field! (:index-view s-atom-env) desc-idx
                                       d/OFFSET_BD_DATA_LENGTH total-size)
      offset)))

(defn- write-directory!
  "Write a directory block into SAB. chunk-offsets is a vector of i32 data offsets.
   Returns the data offset of the directory."
  [s-atom-env chunk-offsets]
  (let [n (count chunk-offsets)
        total-size (+ 4 (* n 4))
        alloc-info (a/alloc s-atom-env total-size)]
    (when (:error alloc-info)
      (throw (js/Error. (str "Chunked list directory alloc failed: " (:error alloc-info)))))
    (let [offset (:offset alloc-info)
          desc-idx (:descriptor-idx alloc-info)
          dv (js/DataView. (:sab s-atom-env))]
      (.setUint32 dv offset n true)
      (dotimes [i n]
        (.setInt32 dv (+ offset 4 (* i 4)) (nth chunk-offsets i) true))
      (u/write-block-descriptor-field! (:index-view s-atom-env) desc-idx
                                       d/OFFSET_BD_DATA_LENGTH total-size)
      offset)))

(defn- copy-chunk-elements-bytes
  "Read all serialized element bytes from a chunk. Returns vector of Uint8Array."
  [s-atom-env ^js dv ^number chunk-offset]
  (let [n (read-chunk-element-count dv chunk-offset)]
    (loop [i 0 pos (+ chunk-offset 4) acc (transient [])]
      (if (>= i n)
        (persistent! acc)
        (let [elem-len (.getUint32 dv pos true)
              elem-bytes (if (zero? elem-len)
                           (js/Uint8Array. 0)
                           (let [src (js/Uint8Array. (:sab s-atom-env) (+ pos 4) elem-len)
                                 dst (js/Uint8Array. elem-len)]
                             (.set dst src)
                             dst))]
          (recur (inc i) (+ pos 4 elem-len) (conj! acc elem-bytes)))))))

(defn- all-chunk-offsets
  "Read all chunk offsets from the directory."
  [^js dv ^number dir-offset]
  (let [n (read-directory-num-chunks dv dir-offset)]
    (loop [i 0 acc (transient [])]
      (if (>= i n)
        (persistent! acc)
        (recur (inc i) (conj! acc (read-directory-chunk-offset dv dir-offset i)))))))

;; ============================================================================
;; SabpChunkBuffer - for IChunkedSeq
;; ============================================================================

(deftype SabpChunkBuffer [s-atom-env ^number chunk-offset ^number elem-count]
  ICounted
  (-count [_] elem-count)

  IIndexed
  (-nth [_ i]
    (let [dv (js/DataView. (:sab s-atom-env))]
      (read-element-at s-atom-env dv chunk-offset i)))
  (-nth [_ i not-found]
    (if (and (>= i 0) (< i elem-count))
      (let [dv (js/DataView. (:sab s-atom-env))]
        (read-element-at s-atom-env dv chunk-offset i))
      not-found))

  IReduce
  (-reduce [_ f]
    (let [dv (js/DataView. (:sab s-atom-env))]
      (if (zero? elem-count)
        (f)
        (loop [i 1
               acc (read-element-at s-atom-env dv chunk-offset 0)]
          (if (or (>= i elem-count) (reduced? acc))
            (if (reduced? acc) @acc acc)
            (recur (inc i) (f acc (read-element-at s-atom-env dv chunk-offset i))))))))
  (-reduce [_ f init]
    (let [dv (js/DataView. (:sab s-atom-env))]
      (loop [i 0 acc init]
        (if (or (>= i elem-count) (reduced? acc))
          (if (reduced? acc) @acc acc)
          (recur (inc i) (f acc (read-element-at s-atom-env dv chunk-offset i))))))))

;; ============================================================================
;; SabpChunkedSeq - IChunkedSeq for efficient chunked iteration
;; ============================================================================

(deftype SabpChunkedSeq [s-atom-env
                          ^number dir-offset
                          chunk-offsets-vec  ;; cached CLJS vector of chunk offsets
                          ^number chunk-idx  ;; current chunk index
                          ^number elem-idx   ;; current element index within chunk
                          ^number total-count ;; total elements in list
                          ^:mutable __hash
                          meta-map]
  ISequential

  IEquiv (-equiv [this other] (u/-equiv-sequential this other))
  IHash (-hash [coll] (if-not (nil? __hash) __hash (set! __hash (hash-ordered-coll coll))))
  IMeta (-meta [_] meta-map)
  IWithMeta (-with-meta [_ new-meta]
              (SabpChunkedSeq. s-atom-env dir-offset chunk-offsets-vec
                               chunk-idx elem-idx total-count __hash new-meta))

  ICounted
  (-count [_]
    ;; Count remaining elements from current position
    (let [dv (js/DataView. (:sab s-atom-env))
          num-chunks (count chunk-offsets-vec)]
      (loop [ci chunk-idx acc 0]
        (if (>= ci num-chunks)
          acc
          (let [co (nth chunk-offsets-vec ci)
                n (read-chunk-element-count dv co)]
            (recur (inc ci) (+ acc (if (== ci chunk-idx) (- n elem-idx) n))))))))

  ISeqable
  (-seq [this] this)

  ISeq
  (-first [_]
    (let [dv (js/DataView. (:sab s-atom-env))
          co (nth chunk-offsets-vec chunk-idx)]
      (read-element-at s-atom-env dv co elem-idx)))
  (-rest [this]
    (let [n (or (-next this) ())]
      n))

  INext
  (-next [_]
    (let [dv (js/DataView. (:sab s-atom-env))
          co (nth chunk-offsets-vec chunk-idx)
          chunk-elem-count (read-chunk-element-count dv co)
          next-elem-idx (inc elem-idx)]
      (if (< next-elem-idx chunk-elem-count)
        ;; More elements in current chunk
        (SabpChunkedSeq. s-atom-env dir-offset chunk-offsets-vec
                         chunk-idx next-elem-idx total-count nil meta-map)
        ;; Move to next chunk
        (let [next-chunk-idx (inc chunk-idx)]
          (when (< next-chunk-idx (count chunk-offsets-vec))
            (SabpChunkedSeq. s-atom-env dir-offset chunk-offsets-vec
                             next-chunk-idx 0 total-count nil meta-map))))))

  IChunkedSeq
  (-chunked-first [_]
    (let [co (nth chunk-offsets-vec chunk-idx)
          dv (js/DataView. (:sab s-atom-env))
          n (read-chunk-element-count dv co)]
      (SabpChunkBuffer. s-atom-env co (- n elem-idx))))
  (-chunked-rest [_]
    (let [next-chunk-idx (inc chunk-idx)]
      (if (< next-chunk-idx (count chunk-offsets-vec))
        (SabpChunkedSeq. s-atom-env dir-offset chunk-offsets-vec
                         next-chunk-idx 0 total-count nil meta-map)
        ())))

  IChunkedNext
  (-chunked-next [_]
    (let [next-chunk-idx (inc chunk-idx)]
      (when (< next-chunk-idx (count chunk-offsets-vec))
        (SabpChunkedSeq. s-atom-env dir-offset chunk-offsets-vec
                         next-chunk-idx 0 total-count nil meta-map))))

  IReduce
  (-reduce [this f]
    (let [dv (js/DataView. (:sab s-atom-env))
          num-chunks (count chunk-offsets-vec)]
      (if (and (== chunk-idx (dec num-chunks))
               (let [co (nth chunk-offsets-vec chunk-idx)]
                 (>= elem-idx (read-chunk-element-count dv co))))
        (f)
        (loop [ci chunk-idx
               ei elem-idx
               acc ::none]
          (if (>= ci num-chunks)
            (if (= acc ::none) (f) acc)
            (let [co (nth chunk-offsets-vec ci)
                  n (read-chunk-element-count dv co)
                  start-ei (if (== ci chunk-idx) ei 0)]
              (let [acc' (loop [j start-ei acc acc]
                           (if (or (>= j n) (reduced? acc))
                             acc
                             (let [elem (read-element-at s-atom-env dv co j)
                                   acc' (if (= acc ::none) elem (f acc elem))]
                               (recur (inc j) acc'))))]
                (if (reduced? acc')
                  @acc'
                  (recur (inc ci) 0 acc')))))))))
  (-reduce [this f init]
    (let [dv (js/DataView. (:sab s-atom-env))
          num-chunks (count chunk-offsets-vec)]
      (loop [ci chunk-idx
             ei elem-idx
             acc init]
        (if (or (>= ci num-chunks) (reduced? acc))
          (if (reduced? acc) @acc acc)
          (let [co (nth chunk-offsets-vec ci)
                n (read-chunk-element-count dv co)
                start-ei (if (== ci chunk-idx) ei 0)]
            (let [acc' (loop [j start-ei acc acc]
                         (if (or (>= j n) (reduced? acc))
                           acc
                           (recur (inc j) (f acc (read-element-at s-atom-env dv co j)))))]
              (recur (inc ci) 0 acc')))))))

  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (pr-sequential-writer writer pr-writer "(" " " ")" opts coll)))

;; ============================================================================
;; SabpChunkedList - the main list type
;; ============================================================================

(deftype SabpChunkedList [s-atom-env
                           ^number dir-offset ;; SAB data offset of directory, or -1 for empty
                           ^number total-count
                           ^:mutable __hash
                           meta-map]
  ISequential
  d/ISabpType
  (-sabp-type-key [_] "com.seniorcaremarket.eve.chunked-list/SabpChunkedList")

  Object
  (equiv [this other] (u/-equiv-sequential this other))
  (toString [coll] (pr-str (seq coll)))

  IEquiv
  (-equiv [this other] (u/-equiv-sequential this other))

  IMeta (-meta [_] meta-map)
  IWithMeta (-with-meta [this new-meta]
              (if (identical? meta-map new-meta)
                this
                (SabpChunkedList. s-atom-env dir-offset total-count __hash new-meta)))

  ICounted
  (-count [_] total-count)

  IEmptyableCollection
  (-empty [_]
    (SabpChunkedList. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil meta-map))

  IIndexed
  (-nth [this n]
    (if (or (neg? n) (>= n total-count))
      (throw (js/Error. (str "Index out of bounds: " n)))
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 remaining n]
          (when (< ci num-chunks)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  chunk-n (read-chunk-element-count dv co)]
              (if (< remaining chunk-n)
                (read-element-at s-atom-env dv co remaining)
                (recur (inc ci) (- remaining chunk-n)))))))))
  (-nth [this n not-found]
    (if (or (neg? n) (>= n total-count))
      not-found
      (-nth this n)))

  ISeqable
  (-seq [_]
    (when (pos? total-count)
      (let [dv (js/DataView. (:sab s-atom-env))
            chunk-offs (all-chunk-offsets dv dir-offset)]
        (SabpChunkedSeq. s-atom-env dir-offset chunk-offs 0 0 total-count nil meta-map))))

  ICollection
  (-conj [_ element]
    ;; Prepend element to front (like a stack/list)
    (let [elem-bytes (ser/serialize-val element)
          elem-bytes (or elem-bytes (js/Uint8Array. 0))]
      (if (== dir-offset d/ROOT_POINTER_NIL_SENTINEL)
        ;; Empty list: create single chunk + directory
        (let [chunk-off (write-chunk! s-atom-env [elem-bytes])
              new-dir-off (write-directory! s-atom-env [chunk-off])]
          (SabpChunkedList. s-atom-env new-dir-off 1 nil meta-map))
        ;; Non-empty: check first chunk
        (let [dv (js/DataView. (:sab s-atom-env))
              first-chunk-off (read-directory-chunk-offset dv dir-offset 0)
              first-chunk-n (read-chunk-element-count dv first-chunk-off)]
          (if (< first-chunk-n CHUNK_SIZE)
            ;; Room in first chunk: path-copy with new element prepended
            (let [existing-bytes (copy-chunk-elements-bytes s-atom-env dv first-chunk-off)
                  new-chunk-bytes (into [elem-bytes] existing-bytes)
                  new-chunk-off (write-chunk! s-atom-env new-chunk-bytes)
                  ;; Path-copy directory with updated first chunk offset
                  old-chunk-offs (all-chunk-offsets dv dir-offset)
                  new-chunk-offs (assoc old-chunk-offs 0 new-chunk-off)
                  new-dir-off (write-directory! s-atom-env new-chunk-offs)]
              (SabpChunkedList. s-atom-env new-dir-off (inc total-count) nil meta-map))
            ;; First chunk full: create new chunk, prepend to directory
            (let [new-chunk-off (write-chunk! s-atom-env [elem-bytes])
                  old-chunk-offs (all-chunk-offsets dv dir-offset)
                  new-chunk-offs (into [new-chunk-off] old-chunk-offs)
                  new-dir-off (write-directory! s-atom-env new-chunk-offs)]
              (SabpChunkedList. s-atom-env new-dir-off (inc total-count) nil meta-map)))))))

  IStack
  (-peek [_]
    (when (pos? total-count)
      (let [dv (js/DataView. (:sab s-atom-env))
            first-chunk-off (read-directory-chunk-offset dv dir-offset 0)]
        (read-element-at s-atom-env dv first-chunk-off 0))))

  (-pop [this]
    (if (zero? total-count)
      this
      (let [dv (js/DataView. (:sab s-atom-env))
            first-chunk-off (read-directory-chunk-offset dv dir-offset 0)
            first-chunk-n (read-chunk-element-count dv first-chunk-off)]
        (if (> first-chunk-n 1)
          ;; More than one element in first chunk: path-copy without first
          (let [existing-bytes (copy-chunk-elements-bytes s-atom-env dv first-chunk-off)
                new-chunk-bytes (subvec existing-bytes 1)
                new-chunk-off (write-chunk! s-atom-env new-chunk-bytes)
                old-chunk-offs (all-chunk-offsets dv dir-offset)
                new-chunk-offs (assoc old-chunk-offs 0 new-chunk-off)
                new-dir-off (write-directory! s-atom-env new-chunk-offs)]
            (SabpChunkedList. s-atom-env new-dir-off (dec total-count) nil meta-map))
          ;; Only one element in first chunk: drop this chunk
          (let [old-chunk-offs (all-chunk-offsets dv dir-offset)]
            (if (<= (count old-chunk-offs) 1)
              ;; Last chunk, list becomes empty
              (SabpChunkedList. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil meta-map)
              ;; More chunks remain
              (let [new-chunk-offs (subvec old-chunk-offs 1)
                    new-dir-off (write-directory! s-atom-env new-chunk-offs)]
                (SabpChunkedList. s-atom-env new-dir-off (dec total-count) nil meta-map))))))))

  IReduce
  (-reduce [_ f]
    (if (zero? total-count)
      (f)
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 acc ::none]
          (if (>= ci num-chunks)
            (if (= acc ::none) (f) acc)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  n (read-chunk-element-count dv co)
                  acc' (loop [j 0 acc acc]
                         (if (or (>= j n) (reduced? acc))
                           acc
                           (let [elem (read-element-at s-atom-env dv co j)
                                 acc' (if (= acc ::none) elem (f acc elem))]
                             (recur (inc j) acc'))))]
              (if (reduced? acc')
                @acc'
                (recur (inc ci) acc'))))))))
  (-reduce [_ f init]
    (if (zero? total-count)
      init
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 acc init]
          (if (or (>= ci num-chunks) (reduced? acc))
            (if (reduced? acc) @acc acc)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  n (read-chunk-element-count dv co)
                  acc' (loop [j 0 acc acc]
                         (if (or (>= j n) (reduced? acc))
                           acc
                           (recur (inc j) (f acc (read-element-at s-atom-env dv co j)))))]
              (recur (inc ci) acc')))))))

  IHash (-hash [coll] (if-not (nil? __hash) __hash (set! __hash (hash-ordered-coll coll))))

  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (pr-sequential-writer writer pr-writer "(" " " ")" opts coll)))

;; ============================================================================
;; SabpChunkedVec - vector semantics (append conj, IVector, IAssociative)
;; Same chunked SAB storage as SabpChunkedList, but with vector behavior.
;; ============================================================================

(deftype SabpChunkedVec [s-atom-env
                          ^number dir-offset
                          ^number total-count
                          ^:mutable __hash
                          meta-map]
  ISequential
  d/ISabpType
  (-sabp-type-key [_] "com.seniorcaremarket.eve.chunked-list/SabpChunkedVec")

  Object
  (equiv [this other] (-equiv this other))
  (toString [coll] (pr-str* coll))

  ICloneable
  (-clone [_] (SabpChunkedVec. s-atom-env dir-offset total-count __hash meta-map))

  IEquiv
  (-equiv [this other]
    (if (instance? SabpChunkedVec other)
      (if (not= total-count (count other))
        false
        (let [s1 (seq this) s2 (seq other)]
          (loop [a s1 b s2]
            (cond
              (nil? a) (nil? b)
              (nil? b) false
              (= (first a) (first b)) (recur (next a) (next b))
              :else false))))
      (u/-equiv-sequential this other)))

  IMeta (-meta [_] meta-map)
  IWithMeta (-with-meta [this new-meta]
              (if (identical? meta-map new-meta)
                this
                (SabpChunkedVec. s-atom-env dir-offset total-count __hash new-meta)))

  ICounted
  (-count [_] total-count)

  IEmptyableCollection
  (-empty [_]
    (SabpChunkedVec. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil meta-map))

  IIndexed
  (-nth [this n]
    (if (or (neg? n) (>= n total-count))
      (throw (js/Error. (str "Index out of bounds: " n)))
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 remaining n]
          (when (< ci num-chunks)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  chunk-n (read-chunk-element-count dv co)]
              (if (< remaining chunk-n)
                (read-element-at s-atom-env dv co remaining)
                (recur (inc ci) (- remaining chunk-n)))))))))
  (-nth [this n not-found]
    (if (or (neg? n) (>= n total-count))
      not-found
      (-nth this n)))

  ISeqable
  (-seq [_]
    (when (pos? total-count)
      (let [dv (js/DataView. (:sab s-atom-env))
            chunk-offs (all-chunk-offsets dv dir-offset)]
        (SabpChunkedSeq. s-atom-env dir-offset chunk-offs 0 0 total-count nil meta-map))))

  ICollection
  (-conj [_ element]
    ;; Append element to end (vector semantics)
    (let [elem-bytes (ser/serialize-val element)
          elem-bytes (or elem-bytes (js/Uint8Array. 0))]
      (if (== dir-offset d/ROOT_POINTER_NIL_SENTINEL)
        ;; Empty vec: create single chunk + directory
        (let [chunk-off (write-chunk! s-atom-env [elem-bytes])
              new-dir-off (write-directory! s-atom-env [chunk-off])]
          (SabpChunkedVec. s-atom-env new-dir-off 1 nil meta-map))
        ;; Non-empty: check last chunk
        (let [dv (js/DataView. (:sab s-atom-env))
              num-chunks (read-directory-num-chunks dv dir-offset)
              last-ci (dec num-chunks)
              last-chunk-off (read-directory-chunk-offset dv dir-offset last-ci)
              last-chunk-n (read-chunk-element-count dv last-chunk-off)]
          (if (< last-chunk-n CHUNK_SIZE)
            ;; Room in last chunk: path-copy with new element appended
            (let [existing-bytes (copy-chunk-elements-bytes s-atom-env dv last-chunk-off)
                  new-chunk-bytes (conj existing-bytes elem-bytes)
                  new-chunk-off (write-chunk! s-atom-env new-chunk-bytes)
                  old-chunk-offs (all-chunk-offsets dv dir-offset)
                  new-chunk-offs (assoc old-chunk-offs last-ci new-chunk-off)
                  new-dir-off (write-directory! s-atom-env new-chunk-offs)]
              (SabpChunkedVec. s-atom-env new-dir-off (inc total-count) nil meta-map))
            ;; Last chunk full: create new chunk, append to directory
            (let [new-chunk-off (write-chunk! s-atom-env [elem-bytes])
                  old-chunk-offs (all-chunk-offsets dv dir-offset)
                  new-chunk-offs (conj old-chunk-offs new-chunk-off)
                  new-dir-off (write-directory! s-atom-env new-chunk-offs)]
              (SabpChunkedVec. s-atom-env new-dir-off (inc total-count) nil meta-map)))))))

  IStack
  (-peek [_]
    (when (pos? total-count)
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)
            last-ci (dec num-chunks)
            last-chunk-off (read-directory-chunk-offset dv dir-offset last-ci)
            last-n (read-chunk-element-count dv last-chunk-off)]
        (read-element-at s-atom-env dv last-chunk-off (dec last-n)))))

  (-pop [this]
    (cond
      (zero? total-count)
      (throw (js/Error. "Can't pop empty vector"))

      (== total-count 1)
      (SabpChunkedVec. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil meta-map)

      :else
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)
            last-ci (dec num-chunks)
            last-chunk-off (read-directory-chunk-offset dv dir-offset last-ci)
            last-n (read-chunk-element-count dv last-chunk-off)]
        (if (> last-n 1)
          ;; Last chunk has multiple elements: path-copy without last
          (let [existing-bytes (copy-chunk-elements-bytes s-atom-env dv last-chunk-off)
                new-chunk-bytes (pop existing-bytes)
                new-chunk-off (write-chunk! s-atom-env new-chunk-bytes)
                old-chunk-offs (all-chunk-offsets dv dir-offset)
                new-chunk-offs (assoc old-chunk-offs last-ci new-chunk-off)
                new-dir-off (write-directory! s-atom-env new-chunk-offs)]
            (SabpChunkedVec. s-atom-env new-dir-off (dec total-count) nil meta-map))
          ;; Last chunk has 1 element: drop entire chunk
          (let [old-chunk-offs (all-chunk-offsets dv dir-offset)
                new-chunk-offs (pop old-chunk-offs)
                new-dir-off (write-directory! s-atom-env new-chunk-offs)]
            (SabpChunkedVec. s-atom-env new-dir-off (dec total-count) nil meta-map))))))

  IVector
  (-assoc-n [this n val]
    (cond
      (== n total-count)
      (-conj this val)

      (or (neg? n) (> n total-count))
      (throw (js/Error. (str "Index " n " out of bounds [0," total-count "]")))

      :else
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)
            val-bytes (ser/serialize-val val)
            val-bytes (or val-bytes (js/Uint8Array. 0))]
        ;; Find which chunk contains index n
        (loop [ci 0 remaining n]
          (when (< ci num-chunks)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  chunk-n (read-chunk-element-count dv co)]
              (if (< remaining chunk-n)
                ;; Found: path-copy chunk with replacement
                (let [existing-bytes (copy-chunk-elements-bytes s-atom-env dv co)
                      new-chunk-bytes (assoc existing-bytes remaining val-bytes)
                      new-chunk-off (write-chunk! s-atom-env new-chunk-bytes)
                      old-chunk-offs (all-chunk-offsets dv dir-offset)
                      new-chunk-offs (assoc old-chunk-offs ci new-chunk-off)
                      new-dir-off (write-directory! s-atom-env new-chunk-offs)]
                  (SabpChunkedVec. s-atom-env new-dir-off total-count nil meta-map))
                (recur (inc ci) (- remaining chunk-n)))))))))

  IAssociative
  (-assoc [this k v]
    (if (integer? k)
      (-assoc-n this k v)
      (throw (js/Error. "Vector's key for assoc must be a number."))))
  (-contains-key? [_ k]
    (and (integer? k) (>= k 0) (< k total-count)))

  ILookup
  (-lookup [this k] (-lookup this k nil))
  (-lookup [this k not-found]
    (if (and (integer? k) (>= k 0) (< k total-count))
      (-nth this k)
      not-found))

  IFn
  (-invoke [this k]
    (-lookup this k))
  (-invoke [this k not-found]
    (-lookup this k not-found))

  IReduce
  (-reduce [_ f]
    (if (zero? total-count)
      (f)
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 acc ::none]
          (if (>= ci num-chunks)
            (if (= acc ::none) (f) acc)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  n (read-chunk-element-count dv co)
                  acc' (loop [j 0 acc acc]
                         (if (or (>= j n) (reduced? acc))
                           acc
                           (let [elem (read-element-at s-atom-env dv co j)
                                 acc' (if (= acc ::none) elem (f acc elem))]
                             (recur (inc j) acc'))))]
              (if (reduced? acc')
                @acc'
                (recur (inc ci) acc'))))))))
  (-reduce [_ f init]
    (if (zero? total-count)
      init
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 acc init]
          (if (or (>= ci num-chunks) (reduced? acc))
            (if (reduced? acc) @acc acc)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  n (read-chunk-element-count dv co)
                  acc' (loop [j 0 acc acc]
                         (if (or (>= j n) (reduced? acc))
                           acc
                           (recur (inc j) (f acc (read-element-at s-atom-env dv co j)))))]
              (recur (inc ci) acc')))))))

  IKVReduce
  (-kv-reduce [this f init]
    (if (zero? total-count)
      init
      (let [dv (js/DataView. (:sab s-atom-env))
            num-chunks (read-directory-num-chunks dv dir-offset)]
        (loop [ci 0 idx 0 acc init]
          (if (or (>= ci num-chunks) (reduced? acc))
            (if (reduced? acc) @acc acc)
            (let [co (read-directory-chunk-offset dv dir-offset ci)
                  n (read-chunk-element-count dv co)
                  [acc' idx'] (loop [j 0 acc acc idx idx]
                                (if (or (>= j n) (reduced? acc))
                                  [acc idx]
                                  (recur (inc j)
                                         (f acc idx (read-element-at s-atom-env dv co j))
                                         (inc idx))))]
              (recur (inc ci) idx' acc')))))))

  IHash (-hash [coll] (if-not (nil? __hash) __hash (set! __hash (hash-ordered-coll coll))))

  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (pr-sequential-writer writer pr-writer "[" " " "]" opts coll)))

;; ============================================================================
;; Constructor
;; ============================================================================

(defn sabp-chunked-vec
  "Create an empty SabpChunkedVec."
  [s-atom-env]
  (SabpChunkedVec. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil nil))

(defn build-chunked-vec
  "Build a SabpChunkedVec from a sequence of elements. Efficient batch construction."
  [s-atom-env elements]
  (let [elems (vec elements)]
    (if (empty? elems)
      (sabp-chunked-vec s-atom-env)
      (let [all-bytes (mapv (fn [e]
                              (let [b (ser/serialize-val e)]
                                (or b (js/Uint8Array. 0))))
                            elems)
            chunks (partition-all CHUNK_SIZE all-bytes)
            chunk-offsets (mapv (fn [chunk-bytes]
                                 (write-chunk! s-atom-env (vec chunk-bytes)))
                               chunks)
            dir-off (write-directory! s-atom-env chunk-offsets)]
        (SabpChunkedVec. s-atom-env dir-off (count elems) nil (meta elements))))))

(defn sabp-chunked-list
  "Create an empty SabpChunkedList."
  [s-atom-env]
  (SabpChunkedList. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil nil))

(defn build-chunked-list
  "Build a SabpChunkedList from a sequence of elements. Efficient batch construction."
  [s-atom-env elements]
  (let [elems (vec elements)]
    (if (empty? elems)
      (sabp-chunked-list s-atom-env)
      (let [;; Serialize all elements
            all-bytes (mapv (fn [e]
                              (let [b (ser/serialize-val e)]
                                (or b (js/Uint8Array. 0))))
                            elems)
            ;; Split into chunks of CHUNK_SIZE
            chunks (partition-all CHUNK_SIZE all-bytes)
            ;; Write each chunk
            chunk-offsets (mapv (fn [chunk-bytes]
                                 (write-chunk! s-atom-env (vec chunk-bytes)))
                               chunks)
            ;; Write directory
            dir-off (write-directory! s-atom-env chunk-offsets)]
        (SabpChunkedList. s-atom-env dir-off (count elems) nil (meta elements))))))

;; ============================================================================
;; SAB→AB conversion
;; ============================================================================

(defn- chunked-list->ab-list
  "Convert SabpChunkedList to AbList."
  [^SabpChunkedList cl]
  (if (or (nil? cl) (zero? (.-total-count cl)))
    (ab/empty-ab-list (.-meta-map cl))
    (let [elems (loop [s (seq cl) acc []]
                  (if s
                    (recur (next s) (conj acc (first s)))
                    acc))]
      (apply ab/ab-list (with-meta elems (.-meta-map cl))))))

(defn- chunked-vec->clj-vec
  "Convert SabpChunkedVec to a regular CLJS vector."
  [^SabpChunkedVec cv]
  (if (or (nil? cv) (zero? (.-total-count cv)))
    (with-meta [] (.-meta-map cv))
    (with-meta (vec (seq cv)) (.-meta-map cv))))

;; sab->ab registration removed (Fressian Phase 5)

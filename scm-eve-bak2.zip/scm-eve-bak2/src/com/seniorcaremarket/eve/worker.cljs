(ns com.seniorcaremarket.eve.worker
  (:require
   [clojure.edn :as edn]
   [cljs.nodejs :as nodejs]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve.ab-list :as ab]
   [com.seniorcaremarket.eve.simple-atom :as sa]
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.conveyance :as conveyance]
   [com.seniorcaremarket.eve.data :as d]))

;; Worker creation and management
(nodejs/enable-util-print!)

(def acwd (js/process.cwd))
(def worker-path (str acwd "/out/worker.js"))
(def worker-threads (nodejs/require "worker_threads"))
(def Worker (.-Worker worker-threads))

(defn get-s-atom-env-map []
  (if a/*global-atom-instance*
    (a/get-env a/*global-atom-instance*)
    (throw (js/Error. "Global atom instance not initialized. Call initialize-worker! first."))))

(defn handle-message [msg]
  (case (:type msg)
    "println" (println (:msg msg))
    "error" (js/console.error (:msg msg))
    (println "[MAIN] NO HANDLER FOR:" msg)))

(def worker-ids (atom 999))

(defn next-id []
  (swap! worker-ids inc))

(defn spawn-worker [id sab reader-map-sab]
  (let [worker (Worker. worker-path #js{:workerData
                                        #js{"worker-id" id
                                            "sab" sab
                                            "reader-map-sab" reader-map-sab}})]
    (.on worker "message"
         (fn [msg-js]
           (let [msg-clj (js->clj msg-js :keywordize-keys true)]
             (handle-message msg-clj))))
    (.on worker "error" (fn [err] (println (str "[MAIN] Error from worker " id ":") err)))
    (.on worker "exit" (fn [code] (println (str "[MAIN] Worker " id " exited with code " code))))
    worker))

(defn mk-worker []
  (let [id (next-id)
        s-atom-env-map (get-s-atom-env-map)
        sab (:sab s-atom-env-map)
        reader-map-sab (:reader-map-sab s-atom-env-map)
        w (Worker.
           worker-path
           #js{:workerData
               #js{"worker-id" id
                   "sab" sab
                   "reader-map-sab" reader-map-sab}})]
    (doto w
      (.on "message"
           (fn [msg-js]
             (let [msg-clj (js->clj msg-js :keywordize-keys true)]
               (handle-message msg-clj))))
      (.on "error" (fn [err] (println (str "[MAIN] Error from worker " id ":") err)))
      (.on "exit" (fn [code] (println (str "[MAIN] Worker " id " exited with code " code)))))
    w))

;; Worker-side functionality

(def _sa1 (sa/create-simple-atom-sab "marker" 100))

(def id (:worker-id u/raw-worker-data))

(set! d/*worker-id* id)

(defn worker-print-fn [& args]
  (let [log-string (try
                     (apply str args)
                     (catch :default e
                       (str "[PRINT_ERROR: " (.-message e) "]")))]
    (if u/raw-parent-port
      (try
        (.postMessage u/raw-parent-port #js{:type "println"
                                            :msg (str "[" id "] " log-string)
                                            :worker-id id})
        (catch js/Error e
          (js/console.log (str "[WORKER_DIRECT_CONSOLE " id "] ERROR during postMessage: ") e)))
      (js/console.log (str "[WORKER_DIRECT_CONSOLE " id "] Fallback: parentPort was nil. Msg: ") log-string))))

(set-print-fn! worker-print-fn)

(defn worker-print-error-fn [& args]
  (let [log-string (try
                     (apply str args)
                     (catch :default e
                       (str "[PRINT_ERROR: " (.-message e) "]")))]
    (if u/raw-parent-port
      (try
        (.postMessage u/raw-parent-port #js{:type "error"
                                            :msg (str "[" id "] " log-string)
                                            :worker-id id})
        (catch js/Error e
          (js/console.error (str "[WORKER_DIRECT_CONSOLE " id "] ERROR during postMessage: ") e)))
      (js/console.error (str "[WORKER_DIRECT_CONSOLE " id "] Fallback: parentPort was nil. Msg: ") log-string))))

(set-print-err-fn! worker-print-error-fn)

(println "Worker" id "starting with data keys:" (keys u/raw-worker-data))

(defonce worker-s-atom-env-global (cljs.core/atom nil))

(defn reconstruct-s-atom-env [sab-from-main reader-map-sab]
  (println "reconstructing s-atom-env")
  (let [index-view (js/Int32Array. sab-from-main)
        data-view (js/Uint8Array. sab-from-main)
        reader-map-view (if reader-map-sab (js/Int32Array. reader-map-sab) nil)]

    (println "[DEBUG] SAB reconstruction:")
    (println "  - SAB byteLength:" (.-byteLength sab-from-main))
    (println "  - Index view length:" (.-length index-view))
    (println "  - Data view length:" (.-length data-view))
    (when reader-map-sab
      (println "  - Reader map SAB byteLength:" (.-byteLength reader-map-sab))
      (println "  - Reader map view length:" (.-length reader-map-view)))

    (when (and reader-map-sab (not reader-map-view))
      (println "CRITICAL: Received reader-map-sab but failed to create view!"))
    (when (not reader-map-sab)
      (println "WARNING: No reader-map-sab received in config."))

    (try
      (let [test-idx (/ d/OFFSET_SAB_TOTAL_SIZE d/SIZE_OF_INT32)]
        (println "[DEBUG] Testing atomic-load-int at idx" test-idx "on array length" (.-length index-view))
        (let [test-result (u/atomic-load-int index-view test-idx)]
          (println "[DEBUG] Test atomic load successful, result:" test-result)))
      (catch js/Error e
        (println "[DEBUG] Test atomic load FAILED:" (.-message e))))

    (let [s-atom-env {:sab sab-from-main
                      :index-view index-view
                      :data-view data-view
                      :reader-map-sab reader-map-sab
                      :reader-map-view reader-map-view
                      :config {:sab-total-size-bytes (.-byteLength sab-from-main)
                               :max-block-descriptors (u/atomic-load-int index-view (/ d/OFFSET_MAX_BLOCK_DESCRIPTORS d/SIZE_OF_INT32))
                               :index-region-size (u/atomic-load-int index-view (/ d/OFFSET_INDEX_REGION_SIZE d/SIZE_OF_INT32))
                               :data-region-start-offset (u/atomic-load-int index-view (/ d/OFFSET_DATA_REGION_START d/SIZE_OF_INT32))}}

          the-private-atom-instance (a/->SharedAtom s-atom-env
                                                    (fn [& args] (println "worker constructed shared-atom validator fired with args:" args))
                                                    {} (cljs.core/atom {:default (fn [& args] (println "worker constructed shared-atom watcher fired with args:" args))}))]
      (println "[DEBUG] WORKER SETTING *global-atom-instance* with s-atom-env index-view length:" (.-length (:index-view s-atom-env)))
      (set! a/*global-atom-instance* the-private-atom-instance)
      (println "[DEBUG] WORKER *global-atom-instance* SET! Env index-view length:" (.-length (:index-view (a/get-env a/*global-atom-instance*))))
      s-atom-env)))

(def custom-tag-map {'eve/fn (fn [arg] (js/eval arg))})

(defn eve-read [s] (edn/read-string {:readers custom-tag-map} s))

(defn evel [form]
  (if-not (coll? form)
    form
    (let [processed-elements (mapv #(evel %) form)
          first-el (first processed-elements)
          rest-els (rest processed-elements)]
      (if-not first-el
        processed-elements
        (apply (eve-read first-el) rest-els)))))

(defn evel-str [s]
  (evel (eve-read s)))

(defn initialize-worker! []
  (let [worker-id-global (:worker-id u/raw-worker-data)
        _ (println "Initializing...")
        main-sab-global (:sab u/raw-worker-data)
        reader-map-sab (:reader-map-sab u/raw-worker-data)]
    (if-not main-sab-global
      (do
        (println "CRITICAL: SharedArrayBuffer not received from workerData!")
        (.postMessage u/raw-parent-port #js{:type "error" :message "SAB not received from workerData"})
        (nodejs/process.exit 1))
      (println "SAB successfully retrieved from workerData."))

    (reset! worker-s-atom-env-global (reconstruct-s-atom-env main-sab-global reader-map-sab))

    (println "SAB received, byteLength:" (.-byteLength main-sab-global))
    (println "Reconstructed s-atom-env, SAB hash:" (hash (:sab @worker-s-atom-env-global)))
    (println "Reconstructed s-atom-env, Reader Map SAB hash:" (hash (:reader-map-sab @worker-s-atom-env-global)))
    (.on u/raw-parent-port "message"
         (fn [message-js]
           (let [clj-message (js->clj message-js :keywordize-keys true)]
             (case (:type clj-message)
               "do" (try (let [sfn (:sfn clj-message)
                               conveyer (mapv (comp conveyance/<-conveyable ab/<-conveyable) (:conveyer clj-message))
                               opts (:opts clj-message)]
                           (apply (js/eval sfn) conveyer)
                           conveyer)
                         (catch :default e
                           (worker-print-error-fn e)))
               :else
               (println "Unknown message type:" (:type clj-message))))))

    (.postMessage u/raw-parent-port #js{:type "initialized" :worker-id worker-id-global})
    (println "Initialized and ready.")))

(if (and u/wt-module (not u/is-main-thread?))
  (if (and u/raw-worker-data u/raw-parent-port)
    (initialize-worker!)
    (do
      (println "[WORKER SCRIPT] CRITICAL: raw-worker-data or raw-parent-port is nil. Cannot initialize.")
      (when u/raw-parent-port
        (.postMessage u/raw-parent-port #js{:type "error" :message "Worker data or parent port nil during init check."}))))
  (when (and u/wt-module u/is-main-thread?)
    (println "worker.cljs appears to have been loaded in the main thread. Worker initialization skipped.")))

(ns com.seniorcaremarket.eve.simple-atom
  (:require
    [cljs.reader :as edn]
    [com.seniorcaremarket.eve.data :as d]
    [clojure.string :as string]
    [com.seniorcaremarket.eve.util :as u]))

(def SIZE_OF_INT32 4)

(def OFFSET_SAB_WRITE_LOCK 0)
(def OFFSET_SAB_DATA_POINTER 1)
(def OFFSET_SAB_DATA_LENGTH 2)
(def OFFSET_SAB_READER_COUNT 3)
(def METADATA_SIZE_INTS 4)
(def METADATA_SIZE_BYTES (* METADATA_SIZE_INTS SIZE_OF_INT32))
(def DATA_START_OFFSET METADATA_SIZE_BYTES)
(def LOCK_FREE 0)
(def MAX_LOCK_ACQUIRE_RETRIES 200)
(def MAX_READER_WAIT_RETRIES 200)
(def MAX_DEREF_META_RETRIES 5)

(defn sab-metadata-view [^js sab]
  (js/Int32Array. sab 0 METADATA_SIZE_INTS))

(defn create-simple-atom-sab [initial-value sab-byte-size]
  (let [sab (js/SharedArrayBuffer. sab-byte-size)
        metadata-view (sab-metadata-view sab)
        initial-value-str (pr-str initial-value)
        initial-value-bytes (u/string->uint8array initial-value-str)
        data-region-capacity (- sab-byte-size METADATA_SIZE_BYTES)]
    (when (> (.-length initial-value-bytes) data-region-capacity)
      (throw (js/Error. (str "Initial value too large. Need: " (.-length initial-value-bytes) ", Has: " data-region-capacity))))
    (.set (js/Uint8Array. sab DATA_START_OFFSET) initial-value-bytes 0)
    (u/atomic-store-int metadata-view OFFSET_SAB_WRITE_LOCK LOCK_FREE)
    (u/atomic-store-int metadata-view OFFSET_SAB_DATA_POINTER DATA_START_OFFSET)
    (u/atomic-store-int metadata-view OFFSET_SAB_DATA_LENGTH (.-length initial-value-bytes))
    (u/atomic-store-int metadata-view OFFSET_SAB_READER_COUNT 0)
    sab))

(defn- acquire-write-lock! [^js metadata-view worker-id]
  (loop [retries MAX_LOCK_ACQUIRE_RETRIES]
    (if (zero? retries) false
        (if (== LOCK_FREE (u/atomic-compare-exchange-int metadata-view OFFSET_SAB_WRITE_LOCK LOCK_FREE worker-id))
          true
          (do
            (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.1))
            (recur (dec retries)))))))

(defn- release-write-lock! [^js metadata-view worker-id]
  (let [prev-lock-owner (u/atomic-compare-exchange-int metadata-view OFFSET_SAB_WRITE_LOCK worker-id LOCK_FREE)]
    (when (not= prev-lock-owner worker-id)
      (println (str "[W:" worker-id "] CRITICAL_SA_LOCK_RELEASE_ERR: Tried to release lock held by " prev-lock-owner " or free lock.")))))

(defn- simple-start-read [^js sab]
  (let [metadata-view (sab-metadata-view sab)]
    (loop [retries MAX_LOCK_ACQUIRE_RETRIES]
      (if (zero? retries) {:status :error :reason :start-read-writer-lock-timeout}
          (if (not= LOCK_FREE (u/atomic-load-int metadata-view OFFSET_SAB_WRITE_LOCK))
            (do
              (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.1))
              (recur (dec retries)))
            (let [old-readers (u/atomic-add-int metadata-view OFFSET_SAB_READER_COUNT 1)
                  writer-lock-after-inc (u/atomic-load-int metadata-view OFFSET_SAB_WRITE_LOCK)]
              (if (not= LOCK_FREE writer-lock-after-inc)
                (do
                  (u/atomic-sub-int metadata-view OFFSET_SAB_READER_COUNT 1)
                  (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.1))
                  (recur (dec retries)))
                {:status :ok})))))))

(defn- simple-end-read [^js sab]
  (let [metadata-view (sab-metadata-view sab)]
    (let [old-val-before-sub (u/atomic-sub-int metadata-view OFFSET_SAB_READER_COUNT 1)
          new-val-after-sub (dec old-val-before-sub)]
      (when (< new-val-after-sub 0)
        (println (str "[W:" d/*worker-id* "] CRITICAL_SA_ER_POST_SUB - Reader count WENT NEGATIVE:" new-val-after-sub)))))
  :ok)

(defn- simple-check-readers-for-writer [^js sab]
  (let [metadata-view (sab-metadata-view sab)]
    (loop [retries MAX_READER_WAIT_RETRIES]
      (let [current-readers (u/atomic-load-int metadata-view OFFSET_SAB_READER_COUNT)]
        (cond
          (zero? current-readers) :ok
          (< current-readers 0) {:error :negative-reader-count}
          (pos? retries)
          (do
            (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.1))
            (recur (dec retries)))
          :else {:error :timeout_waiting_for_readers})))))

(defn simple-deref [^js sab]
  (let [start-read-outcome (simple-start-read sab)]
    (if-not (= (:status start-read-outcome) :ok)
      (do
        (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.1))
        (simple-deref sab))
      (try
        (loop [read-meta-retries MAX_DEREF_META_RETRIES]
          (if (zero? read-meta-retries)
            (throw (js/Error. "simple-deref: Max retries for consistent metadata read."))
            (let [metadata-view (sab-metadata-view sab)
                  p1 (u/atomic-load-int metadata-view OFFSET_SAB_DATA_POINTER)
                  l1 (u/atomic-load-int metadata-view OFFSET_SAB_DATA_LENGTH)
                  p2 (u/atomic-load-int metadata-view OFFSET_SAB_DATA_POINTER)]
              (if (not= p1 p2)
                (do (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.01))
                    (recur (dec read-meta-retries)))
                (let [data-offset p1 data-length l1]
                  (if (or (< data-offset DATA_START_OFFSET) (< data-length 0) (> (+ data-offset data-length) (.-byteLength sab)))
                    (throw (js/Error. (str "simple-deref read invalid metadata: P=" p1 ", L=" l1)))
                    (if (zero? data-length) (edn/read-string "\"\"")
                        (try (let [value-bytes (.subarray (js/Uint8Array. sab) data-offset (+ data-offset data-length))
                                   value-str (u/uint8array->string value-bytes)]
                               (edn/read-string value-str))
                             (catch :default e (println "[W:" d/*worker-id* "] Error simple-deref deser:" (.-message e)) (throw e))))))))))
        (finally (simple-end-read sab))))))

(defn simple-swap! [^js sab f & args]
  (loop [outer-retries 10000]
    (if (zero? outer-retries)
      (throw (js/Error. (str "simple-swap! failed after max outer retries. Worker: " d/*worker-id*)))
      (let [optimistic-old-value (try (simple-deref sab)
                                      (catch js/Error e
                                        (if (string/includes? (.-message e) "simple-deref failed to read consistent metadata")
                                          ::deref-failed-consistency
                                          (throw e))))]
        (if (= optimistic-old-value ::deref-failed-consistency)
          (do (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.001))
              (recur (dec outer-retries)))
          (let [tentative-new-cljs-value (apply f optimistic-old-value args)
                new-value-str (pr-str tentative-new-cljs-value)
                new-value-bytes (u/string->uint8array new-value-str)
                new-data-length (.-length new-value-bytes)
                data-region-capacity (- (.-byteLength sab) METADATA_SIZE_BYTES)
                new-data-offset DATA_START_OFFSET
                metadata-view (sab-metadata-view sab)
                sab-uint8-view (js/Uint8Array. sab)]
            (when (> new-data-length data-region-capacity)
              (throw (js/Error. (str "New value too large. Worker: " d/*worker-id*))))
            (if (acquire-write-lock! metadata-view d/*worker-id*)
              (let [locked-op-result
                    (try
                      (let [p (u/atomic-load-int metadata-view OFFSET_SAB_DATA_POINTER)
                            l (u/atomic-load-int metadata-view OFFSET_SAB_DATA_LENGTH)
                            current-value-under-lock
                            (if (or (< p DATA_START_OFFSET) (< l 0) (> (+ p l) (.-byteLength sab)))
                              ::retry-swap
                              (if (zero? l)
                                (edn/read-string "\"\"")
                                (try (edn/read-string (u/uint8array->string (.subarray sab-uint8-view p (+ p l))))
                                     (catch :default e
                                       (println (str "[W:" d/*worker-id* "] simple-swap: Error deserializing current-value-locked:" (.-message e)))
                                       ::retry-swap))))]
                        (cond
                          (= current-value-under-lock ::retry-swap) ::retry-swap
                          (not= current-value-under-lock optimistic-old-value) ::retry-swap
                          :else
                          (let [reader-check-status (simple-check-readers-for-writer sab)]
                            (if-not (= reader-check-status :ok)
                              ::retry-swap
                              (do
                                (.set sab-uint8-view new-value-bytes new-data-offset)
                                (u/atomic-store-int metadata-view OFFSET_SAB_DATA_POINTER new-data-offset)
                                (u/atomic-store-int metadata-view OFFSET_SAB_DATA_LENGTH new-data-length)
                                tentative-new-cljs-value)))))
                      (finally
                        (release-write-lock! metadata-view d/*worker-id*)))]
                (if (= locked-op-result ::retry-swap)
                  (recur (dec outer-retries))
                  locked-op-result))
              (recur (dec outer-retries)))))))))

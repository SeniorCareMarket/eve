(ns com.seniorcaremarket.eve.atom
  (:refer-clojure :exclude [atom])
  (:require
   [clojure.string :as string]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve.conveyance :as conveyance]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]))

(def ^:dynamic *global-atom-instance* nil)

;; Alloc cursor: tracks where the last successful allocation ended.
;; Next scan starts here instead of 0, giving O(1) amortized alloc.
(defonce ^:private alloc-cursor (volatile! 0))

(defn reset-alloc-cursor!
  "Reset the allocation cursor to 0. Call when creating a new SAB environment."
  []
  (vreset! alloc-cursor 0))

(defn get-env [obj]
  (if-let [parent (.-parent-shared-atom obj)]
    (.-s-atom-env parent)
    (if-let [sab (.-s-atom-env obj)]
      sab
      (throw (js/Error. "Error: get-env requires a shared atom or shared private atom.")))))

;;;;====================================================================================================
;;;; SoA Mirror Helpers (Phase 1 — SIMD descriptor scanning)
;;;;====================================================================================================
;; Mirror arrays: contiguous status[N] and capacity[N] alongside the AoS descriptor table.
;; Layout: [desc_table][status_mirror][capacity_mirror][scratch][data]

(defn- mirror-offsets
  "Compute status/capacity mirror byte offsets from index-view header.
   Returns [status-mirror-byte-offset capacity-mirror-byte-offset]."
  [index-view]
  (let [max-blocks (aget index-view (/ d/OFFSET_MAX_BLOCK_DESCRIPTORS d/SIZE_OF_INT32))
        desc-end (+ d/OFFSET_BLOCK_DESCRIPTORS_ARRAY_START (* max-blocks d/SIZE_OF_BLOCK_DESCRIPTOR))
        cap-start (+ desc-end (* max-blocks d/SIZE_OF_INT32))]
    [desc-end cap-start]))

(defn- update-status-mirror!
  "Update the status mirror for a descriptor. status-mirror-start is byte offset."
  [index-view status-mirror-start desc-idx status]
  (aset index-view (+ (/ status-mirror-start 4) desc-idx) status))

(defn- update-capacity-mirror!
  "Update the capacity mirror for a descriptor. capacity-mirror-start is byte offset."
  [index-view capacity-mirror-start desc-idx capacity]
  (aset index-view (+ (/ capacity-mirror-start 4) desc-idx) capacity))

(defn- update-mirrors!
  "Update both status and capacity mirrors for a descriptor.
   Pass nil for capacity to skip capacity update."
  [index-view desc-idx status capacity]
  (let [[sm cm] (mirror-offsets index-view)]
    (update-status-mirror! index-view sm desc-idx status)
    (when (some? capacity)
      (update-capacity-mirror! index-view cm desc-idx capacity))))

;;;;====================================================================================================
;;;; Allocator Logic
;;;;====================================================================================================

(defn- clear-descriptor-fields! [index-view descriptor-idx]
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_STATUS d/STATUS_ZEROED_UNUSED)
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_DATA_OFFSET 0)
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_DATA_LENGTH 0)
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_BLOCK_CAPACITY 0)
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_LOCK_OWNER 0)
  (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_RETIRED_EPOCH 0)
  (update-mirrors! index-view descriptor-idx d/STATUS_ZEROED_UNUSED 0)
  nil)

(defn- try-claim-descriptor!
  "Try to CAS-lock a candidate descriptor and allocate it.
   Returns {:offset :descriptor-idx} on success, nil on failure."
  [index-view max-descriptors candidate requested-size-bytes]
  (let [desc-base (u/get-block-descriptor-base-int32-offset candidate)
        lock-field (+ desc-base (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))]
    (when (== 0 (u/atomic-compare-exchange-int index-view lock-field 0 d/*worker-id*))
      (let [status (u/read-block-descriptor-field index-view candidate d/OFFSET_BD_STATUS)
            capacity (u/read-block-descriptor-field index-view candidate d/OFFSET_BD_BLOCK_CAPACITY)]
        (if (and (or (== status d/STATUS_FREE)
                     (== status d/STATUS_ZEROED_UNUSED))
                 (>= capacity requested-size-bytes))
          (let [data-offset (u/read-block-descriptor-field index-view candidate d/OFFSET_BD_DATA_OFFSET)
                remainder-size (- capacity requested-size-bytes)]
            (u/write-block-descriptor-field! index-view candidate d/OFFSET_BD_BLOCK_CAPACITY requested-size-bytes)
            (u/write-block-descriptor-field! index-view candidate d/OFFSET_BD_DATA_LENGTH 0)
            (u/write-block-descriptor-field! index-view candidate d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
            (u/write-block-descriptor-field! index-view candidate d/OFFSET_BD_STATUS d/STATUS_ALLOCATED)
            (update-mirrors! index-view candidate d/STATUS_ALLOCATED requested-size-bytes)
            ;; Split remainder into a new free descriptor
            (when (and (== status d/STATUS_FREE)
                       (>= remainder-size d/MINIMUM_USABLE_BLOCK_SIZE))
              (let [cursor-start @alloc-cursor]
                (loop [rem-scan cursor-start wrapped? false]
                  (let [rem-scan (if (>= rem-scan max-descriptors) 0 rem-scan)]
                    (when-not (and wrapped? (>= rem-scan cursor-start))
                      (if (== rem-scan candidate)
                        (recur (inc rem-scan) wrapped?)
                        (let [rem-status (u/read-block-descriptor-field index-view rem-scan d/OFFSET_BD_STATUS)]
                          (if (== rem-status d/STATUS_ZEROED_UNUSED)
                            (let [rem-desc-base (u/get-block-descriptor-base-int32-offset rem-scan)
                                  rem-lock-field (+ rem-desc-base (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))]
                              (if (== 0 (u/atomic-compare-exchange-int index-view rem-lock-field 0 d/*worker-id*))
                                (do
                                  (clear-descriptor-fields! index-view rem-scan)
                                  (u/write-block-descriptor-field! index-view rem-scan d/OFFSET_BD_DATA_OFFSET (+ data-offset requested-size-bytes))
                                  (u/write-block-descriptor-field! index-view rem-scan d/OFFSET_BD_BLOCK_CAPACITY remainder-size)
                                  (u/write-block-descriptor-field! index-view rem-scan d/OFFSET_BD_STATUS d/STATUS_FREE)
                                  (update-mirrors! index-view rem-scan d/STATUS_FREE remainder-size)
                                  (u/atomic-store-int index-view rem-lock-field 0)
                                  (vreset! alloc-cursor (inc rem-scan))
                                  true)
                                (recur (inc rem-scan) wrapped?)))
                            (recur (inc rem-scan)
                                   (or wrapped? (>= (inc rem-scan) max-descriptors)))))))))))
            (u/atomic-store-int index-view lock-field 0)
            #js [data-offset candidate])
          ;; Stale — release lock
          (do (u/atomic-store-int index-view lock-field 0)
              nil))))))

(defn- batch-alloc-js
  "JS fallback for batch-alloc when WASM isn't ready.
   Uses alloc-cursor to avoid rescanning from 0."
  [index-view max-descriptors requested-size-bytes max-count]
  (let [results #js []
        cursor-start @alloc-cursor]
    (loop [scan-idx cursor-start wrapped? false]
      (let [scan-idx (if (>= scan-idx max-descriptors) 0 scan-idx)]
        (if (or (>= (.-length results) max-count)
                (and wrapped? (>= scan-idx cursor-start)))
          (do (when (pos? (.-length results))
                (vreset! alloc-cursor scan-idx))
              results)
          (let [status (u/read-block-descriptor-field index-view scan-idx d/OFFSET_BD_STATUS)]
            (if (and (or (== status d/STATUS_FREE) (== status d/STATUS_ZEROED_UNUSED))
                     (>= (u/read-block-descriptor-field index-view scan-idx d/OFFSET_BD_BLOCK_CAPACITY) requested-size-bytes))
              (if-let [result (try-claim-descriptor! index-view max-descriptors scan-idx requested-size-bytes)]
                (do (.push results result)
                    (recur (inc scan-idx) wrapped?))
                (recur (inc scan-idx) wrapped?))
              (recur (inc scan-idx)
                     (or wrapped? (>= (inc scan-idx) max-descriptors))))))))))

(defn- batch-alloc-wasm
  "WASM-accelerated batch-alloc using find_free_descriptor (scalar AoS scan).
   Uses alloc-cursor to avoid rescanning from 0."
  [index-view max-descriptors requested-size-bytes max-count]
  (let [results #js []
        cursor-start @alloc-cursor]
    ;; Scan from cursor to end
    (loop [start-idx cursor-start]
      (when (and (< start-idx max-descriptors)
                 (< (.-length results) max-count))
        (let [candidate (wasm/find-free-descriptor
                          d/OFFSET_BLOCK_DESCRIPTORS_ARRAY_START
                          max-descriptors requested-size-bytes start-idx)]
          (when-not (== candidate -1)
            (if-let [result (try-claim-descriptor! index-view max-descriptors
                                                    candidate requested-size-bytes)]
              (do (.push results result)
                  (recur (inc candidate)))
              (recur (inc candidate)))))))
    ;; If not enough found, wrap around and scan from 0 to cursor-start
    (when (and (< (.-length results) max-count) (pos? cursor-start))
      (loop [start-idx 0]
        (when (and (< start-idx cursor-start)
                   (< (.-length results) max-count))
          (let [candidate (wasm/find-free-descriptor
                            d/OFFSET_BLOCK_DESCRIPTORS_ARRAY_START
                            cursor-start requested-size-bytes start-idx)]
            (when-not (== candidate -1)
              (if-let [result (try-claim-descriptor! index-view max-descriptors
                                                      candidate requested-size-bytes)]
                (do (.push results result)
                    (recur (inc candidate)))
                (recur (inc candidate))))))))
    (when (pos? (.-length results))
      (let [last-result (aget results (dec (.-length results)))]
        (vreset! alloc-cursor (inc (aget last-result 1)))))
    results))

(defn- batch-alloc-simd
  "SIMD-accelerated batch-alloc using v128 scan over SoA mirror arrays.
   4 descriptors per SIMD iteration vs 1 per scalar.
   Uses alloc-cursor to avoid rescanning from 0."
  [index-view max-descriptors requested-size-bytes max-count
   status-mirror-start capacity-mirror-start]
  (let [results #js []
        cursor-start @alloc-cursor]
    ;; Scan from cursor to end
    (loop [start-idx cursor-start]
      (when (and (< start-idx max-descriptors)
                 (< (.-length results) max-count))
        (let [candidate (wasm/find-free-descriptor-simd
                          status-mirror-start capacity-mirror-start
                          max-descriptors requested-size-bytes start-idx)]
          (when-not (== candidate -1)
            (if-let [result (try-claim-descriptor! index-view max-descriptors
                                                    candidate requested-size-bytes)]
              (do (.push results result)
                  (recur (inc candidate)))
              (recur (inc candidate)))))))
    ;; Wrap around if needed
    (when (and (< (.-length results) max-count) (pos? cursor-start))
      (loop [start-idx 0]
        (when (and (< start-idx cursor-start)
                   (< (.-length results) max-count))
          (let [candidate (wasm/find-free-descriptor-simd
                            status-mirror-start capacity-mirror-start
                            cursor-start requested-size-bytes start-idx)]
            (when-not (== candidate -1)
              (if-let [result (try-claim-descriptor! index-view max-descriptors
                                                      candidate requested-size-bytes)]
                (do (.push results result)
                    (recur (inc candidate)))
                (recur (inc candidate))))))))
    (when (pos? (.-length results))
      (let [last-result (aget results (dec (.-length results)))]
        (vreset! alloc-cursor (inc (aget last-result 1)))))
    results))

(defn batch-alloc
  "Allocate up to `max-count` blocks of `requested-size-bytes` each.
   Uses SIMD scan over SoA mirrors when available, falls back to scalar WASM,
   then JS scan.
   Returns a JS array of #js [offset descriptor-idx] pairs."
  [s-atom-env requested-size-bytes max-count]
  (let [index-view (:index-view s-atom-env)
        max-descriptors (u/get-max-block-descriptors index-view)]
    (if @wasm/wasm-ready
      (if-let [sm (:status-mirror-start s-atom-env)]
        (batch-alloc-simd index-view max-descriptors requested-size-bytes max-count
                          sm (:capacity-mirror-start s-atom-env))
        (batch-alloc-wasm index-view max-descriptors requested-size-bytes max-count))
      (batch-alloc-js index-view max-descriptors requested-size-bytes max-count))))

(defn- alloc-wasm
  "WASM-accelerated single allocation. Uses find_free_descriptor for fast scan.
   Returns #js [offset descriptor-idx] on success, nil on failure."
  [index-view max-descriptors requested-size-bytes s-atom-env]
  (let [cursor-start @alloc-cursor]
    ;; Phase 1: Scan from cursor to end
    (loop [start-idx cursor-start
           phase :forward
           swept? false]
      (let [limit (if (= phase :forward) max-descriptors cursor-start)
            candidate (wasm/find-free-descriptor
                        d/OFFSET_BLOCK_DESCRIPTORS_ARRAY_START
                        limit requested-size-bytes start-idx)]
        (if (not= candidate -1)
          ;; Found candidate — try to claim it
          (if-let [result (try-claim-descriptor! index-view max-descriptors candidate requested-size-bytes)]
            (do (vreset! alloc-cursor (inc candidate))
                result)
            ;; CAS contention — skip and keep scanning
            (recur (inc candidate) phase swept?))
          ;; No free descriptor in this range
          (case phase
            :forward (if (pos? cursor-start)
                       ;; Wrap around: scan from 0 to cursor
                       (recur 0 :backward swept?)
                       ;; cursor was 0, full scan done
                       (if (not swept?)
                         (let [freed (sweep-retired-blocks! s-atom-env)]
                           (if (pos? freed)
                             (recur 0 :forward true)
                             nil))
                         nil))
            :backward (if (not swept?)
                        (let [freed (sweep-retired-blocks! s-atom-env)]
                          (if (pos? freed)
                            (recur 0 :forward true)
                            nil))
                        nil)))))))

(defn- alloc-js
  "JS fallback allocation using linear descriptor scan.
   Returns #js [offset descriptor-idx] on success, nil on failure."
  [index-view max-descriptors requested-size-bytes s-atom-env]
  (let [cursor-start @alloc-cursor]
    (loop [scan-idx cursor-start
           wrapped? false
           swept? false]
      (let [scan-idx (if (>= scan-idx max-descriptors) 0 scan-idx)]
        (if (and wrapped? (>= scan-idx cursor-start))
          (if (not swept?)
            (let [freed (sweep-retired-blocks! s-atom-env)]
              (if (pos? freed)
                (recur 0 false true)
                nil))
            nil)
          (let [current-status-nolock (u/read-block-descriptor-field index-view scan-idx d/OFFSET_BD_STATUS)]
            (if (and (or (== current-status-nolock d/STATUS_FREE)
                         (== current-status-nolock d/STATUS_ZEROED_UNUSED))
                     (>= (u/read-block-descriptor-field index-view scan-idx d/OFFSET_BD_BLOCK_CAPACITY) requested-size-bytes))
              (if-let [result (try-claim-descriptor! index-view max-descriptors scan-idx requested-size-bytes)]
                (do (vreset! alloc-cursor (inc scan-idx))
                    result)
                (recur (inc scan-idx) wrapped? swept?))
              (recur (inc scan-idx)
                     (or wrapped? (>= (inc scan-idx) max-descriptors))
                     swept?))))))))

(defn alloc
  "Allocate a block of requested-size-bytes.
   Uses WASM-accelerated descriptor scan when available, JS fallback otherwise.
   Uses alloc-cursor for O(1) amortized allocation.
   On OOM, sweeps retired blocks and retries once before failing.
   Returns {:offset :descriptor-idx} on success, {:error ...} on failure."
  [s-atom-env requested-size-bytes]
  (let [index-view (:index-view s-atom-env)
        max-descriptors (u/get-max-block-descriptors index-view)
        result (if @wasm/wasm-ready
                 (alloc-wasm index-view max-descriptors requested-size-bytes s-atom-env)
                 (alloc-js index-view max-descriptors requested-size-bytes s-atom-env))]
    (if result
      {:offset (aget result 0) :descriptor-idx (aget result 1)}
      {:error :out-of-memory})))

;; Root-pointer block pool — avoids expensive free/alloc cycle for atom root blocks.
;; Root pointer serialization is always 7 bytes (SAB pointer encoding).
;; After a successful CAS, the old root block can be pooled instead of freed,
;; and reused on the next swap!/reset! — skipping lock acquisition + reader check + descriptor scan.
(defonce ^:private root-block-pool #js [])
(def ^:const ^:private ROOT_POOL_MAX 16)

(defn- pool-root-block!
  "Pool an old root pointer block for reuse. Returns true if pooled, false if pool full."
  [offset desc-idx]
  (if (< (.-length root-block-pool) ROOT_POOL_MAX)
    (do (.push root-block-pool #js [offset desc-idx]) true)
    false))

(defn- alloc-root-block
  "Allocate a block for root pointer storage. Uses pool first, falls back to alloc.
   Returns #js [offset descriptor-idx] on success, nil on failure.
   Uses JS array instead of CLJS map to avoid PersistentArrayMap allocation per swap."
  [s-atom-env size]
  (if (pos? (.-length root-block-pool))
    (.pop root-block-pool) ;; Already #js [offset desc-idx]
    (let [result (alloc s-atom-env size)]
      (when-not (:error result)
        #js [(:offset result) (:descriptor-idx result)]))))

(defn reset-root-pool!
  "Clear the root block pool. Called when SAB environment changes."
  []
  (set! (.-length root-block-pool) 0))

(defn start-read! [s-atom-env descriptor-idx]
  (let [log-prefix (str "[W:" d/*worker-id* " StartRead desc:" descriptor-idx "] ")
        rm-view (:reader-map-view s-atom-env)]
    (if (and rm-view (.-buffer rm-view) (> (.-length rm-view) 0))
      (let [map-idx (u/get-reader-map-idx descriptor-idx)]
        (if (or (< map-idx 0) (>= map-idx (.-length rm-view)))
          (do
            (println log-prefix "CRITICAL_SR - Reader map IDX OUT OF BOUNDS:" map-idx)
            {:status :error :reason :sr-map-idx-bounds})
          (let [old-val-before-add (u/atomic-add-int rm-view map-idx 1)
                new-val-after-add (inc old-val-before-add)]
            (println (str "SR;" d/*worker-id* ";" descriptor-idx ";" map-idx ";" (js/performance.now) ";" new-val-after-add))
            {:status :ok :map-idx map-idx :new-count new-val-after-add})))
      (do (println log-prefix "CRITICAL_SR - Invalid reader-map-view:" (pr-str rm-view))
          {:status :error :reason :sr-invalid-rm-view}))))

(defn- check-readers [s-atom-env descriptor-idx]
  (if-let [rm-view (:reader-map-view s-atom-env)]
    (if (and rm-view (.-buffer rm-view) (> (.-length rm-view) 0))
      (let [map_idx (u/get-reader-map-idx descriptor-idx)]
        (if (or (< map_idx 0) (>= map_idx (.-length rm-view)))
          (do (println (str "[W:" d/*worker-id* " CheckReaders] CRITICAL - IDX OUT OF BOUNDS:" map_idx " for desc:" descriptor-idx))
              {:error :cr-map-idx-bounds})
          (loop [retries 400]
            (let [current-readers (u/atomic-load-int rm-view map_idx)]
              (cond
                (zero? current-readers) :ok
                (< current-readers 0)
                (do (println (str "[W:" d/*worker-id* " CheckReaders] CRITICAL_ERROR - Negative reader count " current-readers " for desc_idx:" descriptor-idx " (map_idx:" map_idx ")"))
                    {:error :cr-negative-count :count current-readers})
                (pos? retries)
                (do
                  (when (= 0 (mod retries 100))
                    (println (str "[W:" d/*worker-id* " CheckReaders] Waiting on desc_idx:" descriptor-idx "(map_idx:" map_idx "), count:" current-readers ", retries left:" retries)))
                  (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.01))
                  (recur (dec retries)))
                :else
                (do
                  (println (str "[W:" d/*worker-id* " CheckReaders] Timeout waiting for readers on desc_idx:" descriptor-idx "(map_idx:" map_idx "), count:" current-readers))
                  {:error :cr-timeout :count current-readers}))))))
      (do (println (str "[W:" d/*worker-id* " CheckReaders] Invalid rm-view for desc_idx:" descriptor-idx)) :ok))
    (do (println (str "[W:" d/*worker-id* " CheckReaders] :reader-map-view is nil for desc_idx:" descriptor-idx) :ok))))

(defn end-read! [s-atom-env target-descriptor-idx worker-id-for-log]
  (let [log-prefix (str "[W:" worker-id-for-log " EndRead desc:" target-descriptor-idx "] ")
        index-view (:index-view s-atom-env)
        rm-view (:reader-map-view s-atom-env)]
    (if (and rm-view (.-buffer rm-view) (> (.-length rm-view) 0))
      (let [map-idx (u/get-reader-map-idx target-descriptor-idx)]
        (if (or (< map-idx 0) (>= map-idx (.-length rm-view)))
          (println log-prefix "CRITICAL_ER - Reader map IDX OUT OF BOUNDS:" map-idx)
          (let [current-val-before-sub (u/atomic-load-int rm-view map-idx)]
            (if (<= current-val-before-sub 0)
              (println log-prefix "CRITICAL_ER_PRE_SUB - Count for map_idx:" map-idx " is ALREADY " current-val-before-sub ". NOT decrementing.")
              (let [old-val-returned-by-sub (u/atomic-sub-int rm-view map-idx 1)
                    new-val-after-sub (dec old-val-returned-by-sub)]
                (println (str "ER;" worker-id-for-log ";" target-descriptor-idx ";" map-idx ";" (js/performance.now) ";" new-val-after-sub
                              ";(was " old-val-returned-by-sub ")"))
                (when (< new-val-after-sub 0)
                  (println log-prefix "CRITICAL_ER_POST_SUB - Reader count for map_idx:" map-idx " WENT NEGATIVE:" new-val-after-sub)))))))
      (println log-prefix "CRITICAL_ER - Invalid reader-map-view:" (pr-str rm-view)))

   ;; Orphaned block cleanup logic
    (when (and index-view (.-buffer index-view)) ; Ensure index-view is valid
      (let [current_block_status (u/read-block-descriptor-field index-view target-descriptor-idx d/OFFSET_BD_STATUS)]
        (when (= current_block_status d/STATUS_ORPHANED)
          (let [log-prefix-cleanup (str "[W:" worker-id-for-log " EndReadCleanup desc:" target-descriptor-idx "] ")
                lock_owner_field_idx (+ (u/get-block-descriptor-base-int32-offset target-descriptor-idx) (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))]
           ;; (println log-prefix-cleanup "Block is ORPHANED. Attempting cleanup.")
           ;; Try to acquire lock with a few retries for orphan cleanup
            (loop [lock-cleanup-retries 5]
              (if (== 0 (u/atomic-compare-exchange-int index-view lock_owner_field_idx 0 worker-id-for-log))
                (try
                 ;; (println log-prefix-cleanup "Lock ACQUIRED.")
                 ;; CRITICAL: Re-verify status AND reader count while holding the lock
                  (let [status_now (u/read-block-descriptor-field index-view target-descriptor-idx d/OFFSET_BD_STATUS)
                        reader-check-result-final (check-readers s-atom-env target-descriptor-idx)]
                    (if (and (= status_now d/STATUS_ORPHANED) (= :ok reader-check-result-final))
                      (do
                        (println log-prefix-cleanup "Confirmed ORPHANED and LAST READER. Performing final free.")
                        (u/write-block-descriptor-field! index-view target-descriptor-idx d/OFFSET_BD_DATA_LENGTH 0)
                        (u/write-block-descriptor-field! index-view target-descriptor-idx d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
                        (u/write-block-descriptor-field! index-view target-descriptor-idx d/OFFSET_BD_STATUS d/STATUS_FREE)
                        (update-mirrors! index-view target-descriptor-idx d/STATUS_FREE nil))
                      (when (not= status_now d/STATUS_ORPHANED) (println log-prefix-cleanup "Status changed from ORPHANED to " status_now " during cleanup."))))
                  (finally (u/atomic-store-int index-view lock_owner_field_idx 0)))
                (when (pos? lock-cleanup-retries)
                  #_(println log-prefix-cleanup "Could not acquire lock for ORPHANED cleanup. Retrying lock.")
                  (let [s (js/SharedArrayBuffer. 4) v (js/Int32Array. s)] (js/Atomics.store v 0 0) (js/Atomics.wait v 0 0 0.01))
                  (recur (dec lock-cleanup-retries)))))))))))

#_(defn end-read! [s-atom-env target-descriptor-idx worker-id-for-log]
    (let [log-prefix (str "[W:" worker-id-for-log " EndRead desc:" target-descriptor-idx "] ")
          index-view (:index-view s-atom-env)
          rm-view (:reader-map-view s-atom-env)]
      (if (and rm-view (.-buffer rm-view) (> (.-length rm-view) 0))
        (let [map-idx (u/get-reader-map-idx target-descriptor-idx)]
          (if (or (< map-idx 0) (>= map-idx (.-length rm-view)))
            (println log-prefix "CRITICAL_ER - Reader map IDX OUT OF BOUNDS:" map-idx)
            (let [current-val-before-sub (u/atomic-load-int rm-view map-idx)]
              (if (<= current-val-before-sub 0)
                (println log-prefix "CRITICAL_ER_PRE_SUB - Count for map_idx:" map-idx " is ALREADY " current-val-before-sub ". NOT decrementing.")
                (let [old-val-returned-by-sub (u/atomic-sub-int rm-view map-idx 1)
                      new-val-after-sub (dec old-val-returned-by-sub)]
                  (println (str "ER;" worker-id-for-log ";" target-descriptor-idx ";" map-idx ";" (js/performance.now) ";" new-val-after-sub
                                ";(was " old-val-returned-by-sub ")"))
                  (when (< new-val-after-sub 0)
                    (println log-prefix "CRITICAL_ER_POST_SUB - Reader count for map_idx:" map-idx " WENT NEGATIVE:" new-val-after-sub)))))))
        (println log-prefix "CRITICAL_ER - Invalid reader-map-view:" (pr-str rm-view)))

      (when (and index-view (.-buffer index-view))
        (let [current_block_status (u/read-block-descriptor-field index-view target-descriptor-idx d/OFFSET_BD_STATUS)]
          (when (= current_block_status d/STATUS_ORPHANED)
            (let [lock_owner_field_idx (+ (u/get-block-descriptor-base-int32-offset target-descriptor-idx) (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))]
              (if (== 0 (u/atomic-compare-exchange-int index-view lock_owner_field_idx 0 worker-id-for-log))
                (try
                  (let [status_now (u/read-block-descriptor-field index-view target-descriptor-idx d/OFFSET_BD_STATUS)
                        reader-check-result-final (check-readers s-atom-env target-descriptor-idx)]
                    (if (and (= status_now d/STATUS_ORPHANED) (= :ok reader-check-result-final))
                      (do
                        (println log-prefix "ORPHANED_CLEANUP: desc " target-descriptor-idx " - Confirmed last reader, performing final free.")
                        (u/write-block-descriptor-field! index-view target-descriptor-idx d/OFFSET_BD_DATA_LENGTH 0)
                        (u/write-block-descriptor-field! index-view target-descriptor-idx d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
                        (u/write-block-descriptor-field! index-view target-descriptor-idx d/OFFSET_BD_STATUS d/STATUS_FREE))
                      (when (not= status_now d/STATUS_ORPHANED) (println log-prefix "ORPHANED_CLEANUP: desc " target-descriptor-idx " - Status changed from ORPHANED to " status_now " during cleanup attempt."))))
                  (finally (u/atomic-store-int index-view lock_owner_field_idx 0)))
                #_(println log-prefix "ORPHANED_CLEANUP: desc " target-descriptor-idx " - Could not acquire lock.")))))) ; Minimal logging for this case
      :ok))

(defn free [s-atom-env desc-idx-to-free]
  (let [index-view (:index-view s-atom-env)
        lock-owner-field-idx (+ (u/get-block-descriptor-base-int32-offset desc-idx-to-free) (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))
        log-prefix (str "[W:" d/*worker-id* " Free desc:" desc-idx-to-free "] ")]
    (loop [lock-retries 400]
      (if (zero? lock-retries)
        (do (println log-prefix "!!! FAILED to lock descriptor for freeing after retries.")
            {:error :free-lock-timeout})
        (if (== 0 (u/atomic-compare-exchange-int index-view lock-owner-field-idx 0 d/*worker-id*))
          (let [status-initially (u/read-block-descriptor-field index-view desc-idx-to-free d/OFFSET_BD_STATUS)
                lock-cleared-by-clear-descriptor? (volatile! false) ;; <<< Corrected flag name
                processing-outcome
                (try
                  (cond
                    (== status-initially d/STATUS_ALLOCATED)
                    (let [reader-check-outcome (check-readers s-atom-env desc-idx-to-free)]
                      (if (= :ok reader-check-outcome)
                        (do
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_DATA_LENGTH 0)
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_STATUS d/STATUS_FREE)
                          (update-mirrors! index-view desc-idx-to-free d/STATUS_FREE nil)
                          {:success true :type :data-block-freed})
                        (do
                          (println log-prefix "CheckReaders for ALLOCATED failed: " (pr-str reader-check-outcome) ". Marking as ORPHANED.")
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_STATUS d/STATUS_ORPHANED)
                          (update-mirrors! index-view desc-idx-to-free d/STATUS_ORPHANED nil)
                          {:error :active-readers-became-orphaned :details reader-check-outcome})))

                    (== status-initially d/STATUS_EMBEDDED_ATOM_HEADER)
                    (do
                      (clear-descriptor-fields! index-view desc-idx-to-free)
                      (vreset! lock-cleared-by-clear-descriptor? true) ;; <<< Set flag
                      (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_STATUS d/STATUS_ZEROED_UNUSED)
                      ;; Note: clear-descriptor-fields! already updated mirrors
                      {:success true :type :atom-header-freed})

                    (== status-initially d/STATUS_ORPHANED)
                    (let [reader-check-outcome (check-readers s-atom-env desc-idx-to-free)]
                      (if (= :ok reader-check-outcome)
                        (do
                          (println log-prefix "ORPHANED block has no readers now during explicit free. Finalizing free.")
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_DATA_LENGTH 0)
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
                          (u/write-block-descriptor-field! index-view desc-idx-to-free d/OFFSET_BD_STATUS d/STATUS_FREE)
                          (update-mirrors! index-view desc-idx-to-free d/STATUS_FREE nil)
                          {:success true :type :orphaned-block-cleaned-by-free})
                        (do
                          (println log-prefix "ORPHANED block still has readers during explicit free:" (pr-str reader-check-outcome) ". Leaving as ORPHANED.")
                          {:error :orphaned-still-has-readers :details reader-check-outcome})))

                    (or (== status-initially d/STATUS_FREE) (== status-initially d/STATUS_ZEROED_UNUSED))
                    {:success true :type :already-handled}

                    :else {:error :unknown-state-during-free, :status status-initially})
                  (finally
                    (if-not @lock-cleared-by-clear-descriptor? ;; <<< Check flag
                      (u/atomic-store-int index-view lock-owner-field-idx 0)
                      #_(println log-prefix "Lock release handled by clear_descriptor_fields! (free)."))))]
            processing-outcome)
          (recur (dec lock-retries)))))))

;;;;====================================================================================================
;;;; Epoch-Based GC: Worker Registry
;;;;====================================================================================================

(defn- get-worker-slot-byte-offset
  "Calculate byte offset for a worker slot in the registry."
  [slot-idx]
  (+ d/OFFSET_WORKER_REGISTRY_START (* slot-idx d/WORKER_SLOT_SIZE)))

(defn- get-worker-slot-int32-offset
  "Calculate Int32Array index for start of a worker slot."
  [slot-idx]
  (/ (get-worker-slot-byte-offset slot-idx) d/SIZE_OF_INT32))

(defn register-worker!
  "Claim a slot in the worker registry. Returns slot index or nil if registry full.
   Should be called once per worker at startup."
  [s-atom-env worker-id]
  (let [index-view (:index-view s-atom-env)]
    (loop [slot-idx 0]
      (when (< slot-idx d/MAX_WORKERS)
        (let [slot-int32-offset (get-worker-slot-int32-offset slot-idx)
              status-idx slot-int32-offset]
          (if (== d/WORKER_STATUS_INACTIVE
                  (js/Atomics.compareExchange index-view status-idx
                                              d/WORKER_STATUS_INACTIVE
                                              d/WORKER_STATUS_ACTIVE))
            ;; Successfully claimed this slot
            (let [slot-byte-offset (get-worker-slot-byte-offset slot-idx)]
              ;; Write worker ID
              (js/Atomics.store index-view
                                (/ (+ slot-byte-offset d/OFFSET_WS_WORKER_ID) d/SIZE_OF_INT32)
                                worker-id)
              ;; Clear current epoch (not reading)
              (js/Atomics.store index-view
                                (/ (+ slot-byte-offset d/OFFSET_WS_CURRENT_EPOCH) d/SIZE_OF_INT32)
                                0)
              ;; Update heartbeat
              (update-heartbeat! s-atom-env slot-idx)
              slot-idx)
            ;; Slot taken, try next
            (recur (inc slot-idx))))))))

(defn unregister-worker!
  "Release a worker slot. Should be called when worker shuts down."
  [s-atom-env slot-idx]
  (when (and (>= slot-idx 0) (< slot-idx d/MAX_WORKERS))
    (let [index-view (:index-view s-atom-env)
          slot-int32-offset (get-worker-slot-int32-offset slot-idx)]
      ;; Clear epoch first
      (js/Atomics.store index-view
                        (+ slot-int32-offset (/ d/OFFSET_WS_CURRENT_EPOCH d/SIZE_OF_INT32))
                        0)
      ;; Mark as inactive
      (js/Atomics.store index-view slot-int32-offset d/WORKER_STATUS_INACTIVE))))

(defn update-heartbeat!
  "Update worker's heartbeat timestamp. Should be called periodically."
  [s-atom-env slot-idx]
  (when (and (>= slot-idx 0) (< slot-idx d/MAX_WORKERS))
    (let [index-view (:index-view s-atom-env)
          slot-byte-offset (get-worker-slot-byte-offset slot-idx)
          now (js/Date.now)
          lo (bit-and now 0xFFFFFFFF)
          hi (unsigned-bit-shift-right now 32)]
      (js/Atomics.store index-view
                        (/ (+ slot-byte-offset d/OFFSET_WS_HEARTBEAT_LO) d/SIZE_OF_INT32)
                        lo)
      (js/Atomics.store index-view
                        (/ (+ slot-byte-offset d/OFFSET_WS_HEARTBEAT_HI) d/SIZE_OF_INT32)
                        hi))))

(defn- read-heartbeat
  "Read a worker's heartbeat timestamp."
  [index-view slot-idx]
  (let [slot-byte-offset (get-worker-slot-byte-offset slot-idx)
        lo (js/Atomics.load index-view
                            (/ (+ slot-byte-offset d/OFFSET_WS_HEARTBEAT_LO) d/SIZE_OF_INT32))
        hi (js/Atomics.load index-view
                            (/ (+ slot-byte-offset d/OFFSET_WS_HEARTBEAT_HI) d/SIZE_OF_INT32))]
    ;; Reconstruct 64-bit timestamp (JS numbers can handle up to 2^53)
    (+ (bit-and lo 0xFFFFFFFF) (* hi 0x100000000))))

(defn check-worker-liveness
  "Check if a worker is still alive based on heartbeat. Returns true if alive."
  [s-atom-env slot-idx]
  (let [index-view (:index-view s-atom-env)
        heartbeat (read-heartbeat index-view slot-idx)
        now (js/Date.now)]
    (< (- now heartbeat) d/HEARTBEAT_TIMEOUT_MS)))

(defn mark-stale-workers!
  "Scan registry and mark workers with stale heartbeats.
   Returns count of workers marked stale."
  [s-atom-env]
  (let [index-view (:index-view s-atom-env)]
    (loop [slot-idx 0
           stale-count 0]
      (if (< slot-idx d/MAX_WORKERS)
        (let [slot-int32-offset (get-worker-slot-int32-offset slot-idx)
              status (js/Atomics.load index-view slot-int32-offset)]
          (if (== status d/WORKER_STATUS_ACTIVE)
            (if (check-worker-liveness s-atom-env slot-idx)
              (recur (inc slot-idx) stale-count)
              ;; Worker is stale - try to mark it
              (do
                (js/Atomics.compareExchange index-view slot-int32-offset
                                            d/WORKER_STATUS_ACTIVE
                                            d/WORKER_STATUS_STALE)
                (recur (inc slot-idx) (inc stale-count))))
            (recur (inc slot-idx) stale-count)))
        stale-count))))

;;;;====================================================================================================
;;;; Epoch-Based GC: Epoch Management
;;;;====================================================================================================

(defn get-current-epoch
  "Read the current global epoch."
  [s-atom-env]
  (js/Atomics.load (:index-view s-atom-env) (/ d/OFFSET_GLOBAL_EPOCH d/SIZE_OF_INT32)))

(defn increment-epoch!
  "Atomically increment global epoch. Returns the NEW epoch value."
  [s-atom-env]
  (inc (js/Atomics.add (:index-view s-atom-env) (/ d/OFFSET_GLOBAL_EPOCH d/SIZE_OF_INT32) 1)))

(defn begin-read!
  "Begin a read operation - record current epoch in worker slot.
   Returns the epoch being read. Must be paired with end-read-epoch!."
  [s-atom-env slot-idx]
  (let [index-view (:index-view s-atom-env)
        epoch (get-current-epoch s-atom-env)
        slot-byte-offset (get-worker-slot-byte-offset slot-idx)]
    ;; Record that this worker is reading at this epoch
    (js/Atomics.store index-view
                      (/ (+ slot-byte-offset d/OFFSET_WS_CURRENT_EPOCH) d/SIZE_OF_INT32)
                      epoch)
    epoch))

(defn end-read-epoch!
  "End a read operation - clear epoch from worker slot."
  [s-atom-env slot-idx]
  (let [index-view (:index-view s-atom-env)
        slot-byte-offset (get-worker-slot-byte-offset slot-idx)]
    (js/Atomics.store index-view
                      (/ (+ slot-byte-offset d/OFFSET_WS_CURRENT_EPOCH) d/SIZE_OF_INT32)
                      0)))

(defn get-min-active-epoch
  "Find the minimum epoch still being read by any active (non-stale) worker.
   Returns nil if no workers are actively reading."
  [s-atom-env]
  (let [index-view (:index-view s-atom-env)]
    (loop [slot-idx 0
           min-epoch nil]
      (if (< slot-idx d/MAX_WORKERS)
        (let [slot-int32-offset (get-worker-slot-int32-offset slot-idx)
              status (js/Atomics.load index-view slot-int32-offset)]
          ;; Only consider ACTIVE workers (ignore INACTIVE and STALE)
          (if (== status d/WORKER_STATUS_ACTIVE)
            (let [slot-byte-offset (get-worker-slot-byte-offset slot-idx)
                  epoch (js/Atomics.load index-view
                                         (/ (+ slot-byte-offset d/OFFSET_WS_CURRENT_EPOCH) d/SIZE_OF_INT32))]
              ;; Only count if actually reading (epoch > 0)
              (if (and (pos? epoch)
                       (or (nil? min-epoch) (< epoch min-epoch)))
                (recur (inc slot-idx) epoch)
                (recur (inc slot-idx) min-epoch)))
            (recur (inc slot-idx) min-epoch)))
        min-epoch))))

;;;;====================================================================================================
;;;; Epoch-Based GC: Cooperative Block Retirement & Cleanup
;;;;====================================================================================================

(defn retire-block!
  "Mark a block as retired at the current epoch.
   Called by writer after successful update to mark old blocks for cleanup.
   Returns true if successfully retired, false if already being processed."
  [s-atom-env descriptor-idx]
  (let [index-view (:index-view s-atom-env)
        current-epoch (get-current-epoch s-atom-env)
        desc-base (u/get-block-descriptor-base-int32-offset descriptor-idx)
        status-idx (+ desc-base (/ d/OFFSET_BD_STATUS d/SIZE_OF_INT32))]
    ;; CAS status from ALLOCATED to RETIRED
    (when (== d/STATUS_ALLOCATED
              (js/Atomics.compareExchange index-view status-idx
                                          d/STATUS_ALLOCATED
                                          d/STATUS_RETIRED))
      ;; Record the epoch when retired
      (u/write-block-descriptor-field! index-view descriptor-idx
                                       d/OFFSET_BD_RETIRED_EPOCH current-epoch)
      (update-mirrors! index-view descriptor-idx d/STATUS_RETIRED nil)
      true)))

(defn try-free-retired!
  "Try to free a retired block if safe (no readers in its epoch or earlier).
   Returns :freed, :has-readers, or :not-retired.
   This is the cooperative cleanup - call opportunistically."
  [s-atom-env descriptor-idx]
  (let [index-view (:index-view s-atom-env)
        status (u/read-block-descriptor-field index-view descriptor-idx d/OFFSET_BD_STATUS)]
    (if (== status d/STATUS_RETIRED)
      (let [retired-epoch (u/read-block-descriptor-field index-view descriptor-idx
                                                         d/OFFSET_BD_RETIRED_EPOCH)
            min-active (get-min-active-epoch s-atom-env)]
        (if (or (nil? min-active) (> min-active retired-epoch))
          ;; Safe to free - no readers in or before this epoch
          (let [lock-owner-idx (+ (u/get-block-descriptor-base-int32-offset descriptor-idx)
                                  (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))]
            ;; Try to acquire lock for cleanup
            (if (== 0 (js/Atomics.compareExchange index-view lock-owner-idx 0 (or d/*worker-id* -1)))
              (try
                ;; Re-check status under lock
                (let [status-now (u/read-block-descriptor-field index-view descriptor-idx d/OFFSET_BD_STATUS)]
                  (if (== status-now d/STATUS_RETIRED)
                    (do
                      (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_DATA_LENGTH 0)
                      (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
                      (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_RETIRED_EPOCH 0)
                      (u/write-block-descriptor-field! index-view descriptor-idx d/OFFSET_BD_STATUS d/STATUS_FREE)
                      (update-mirrors! index-view descriptor-idx d/STATUS_FREE nil)
                      :freed)
                    ;; Status changed while we were getting lock
                    :not-retired))
                (finally
                  (js/Atomics.store index-view lock-owner-idx 0)))
              ;; Couldn't get lock - someone else is handling it
              :has-readers))
          ;; Still has readers in that epoch
          :has-readers))
      :not-retired)))

(defn- sweep-retired-blocks-simd!
  "SIMD-accelerated sweep: use v128 scan over status mirror to find retired
   descriptors, then only try-free-retired! on those. O(N/4) scan + O(R) frees."
  [s-atom-env index-view max-descriptors]
  (let [sm (:status-mirror-start s-atom-env)
        scratch (:scratch-region-start s-atom-env)
        count-found (wasm/find-retired-descriptors-simd
                      sm max-descriptors scratch max-descriptors)]
    (if (zero? count-found)
      0
      (loop [i 0
             freed-count 0]
        (if (< i count-found)
          (let [desc-idx (aget index-view (+ (/ scratch 4) i))
                result (try-free-retired! s-atom-env desc-idx)]
            (recur (inc i)
                   (if (= result :freed) (inc freed-count) freed-count)))
          freed-count)))))

(defn sweep-retired-blocks!
  "GC sweep: scan for retired blocks and free those safe to free.
   Returns count of blocks freed. Call this periodically or opportunistically.
   Uses SIMD-accelerated status mirror scan when available."
  [s-atom-env]
  (let [index-view (:index-view s-atom-env)
        max-descriptors (u/get-max-block-descriptors index-view)]
    ;; First, mark stale workers to release their epochs
    (mark-stale-workers! s-atom-env)
    ;; Then sweep retired blocks — SIMD path when available
    (if (and @wasm/wasm-ready (:status-mirror-start s-atom-env))
      (sweep-retired-blocks-simd! s-atom-env index-view max-descriptors)
      ;; Scalar fallback
      (loop [desc-idx 0
             freed-count 0]
        (if (< desc-idx max-descriptors)
          (let [result (try-free-retired! s-atom-env desc-idx)]
            (recur (inc desc-idx)
                   (if (= result :freed) (inc freed-count) freed-count)))
          freed-count)))))

(defn with-read-epoch
  "Execute f within a read epoch context. Ensures proper begin/end-read-epoch! calls.
   Returns the result of f."
  [s-atom-env slot-idx f]
  (let [epoch (begin-read! s-atom-env slot-idx)]
    (try
      (f epoch)
      (finally
        (end-read-epoch! s-atom-env slot-idx)))))

;;;;====================================================================================================
;;;; Serialization
;;;;====================================================================================================

(defn atom-serialize
  "Serialize a value for storage in SAB.
   Uses fast-path encoding for primitives and SAB pointer encoding for collections."
  [value]
  (ser/serialize-element value))

(defn atom-deserialize
  "Deserialize bytes from SAB back to a CLJS/SAB value.
   Returns SAB-backed types directly (zero-copy for collections)."
  ([byte-array-view] (atom-deserialize byte-array-view {}))
  ([byte-array-view read-handler-context]
   (when byte-array-view
     (try
       (let [s-atom-env (or (:s-atom-env read-handler-context) {})
             bytes (if (and (some? byte-array-view) (instance? js/Uint8Array byte-array-view)
                            (or (not (zero? (.-byteOffset byte-array-view)))
                                (not= (.-byteLength byte-array-view) (.-byteLength (.-buffer byte-array-view)))))
                     (js/Uint8Array. byte-array-view)
                     byte-array-view)]
         (ser/deserialize-element s-atom-env bytes))
       (catch :default e
         (println "!!! ERROR during atom/atom-deserialize:" e (.-stack e))
         (when byte-array-view (println "    Input bytes (hex, first 64):" (u/format-bytes-as-hex byte-array-view 64)))
         nil)))))

;; Backward compatibility aliases
(def default-serializer atom-serialize)
(def default-deserializer atom-deserialize)

(defn- notify-watches [watchers-atom-ref old-val new-val]
  (doseq [[key f] @watchers-atom-ref]
    (try (f key watchers-atom-ref old-val new-val)
         (catch :default e (println "Error in watcher" key ":" e)))))

(declare ->SharedAtom ->EmbeddedSharedAtom)

(defn private-atom
  "Create a private atom backed by WebAssembly.Memory.

   All EVE atoms use WASM memory for storage, enabling SIMD-accelerated
   operations on data structures.

   Options:
   - :sab-size - Total memory size in bytes (default 2MB, rounded to 64KB page)
   - :max-blocks - Maximum block descriptors (default 256)
   - :metamap - Metadata map
   - :validator - Validator function"
  [initial-cljs-map-value & {:keys [metamap validator sab-size max-blocks]
                             :as _opts
                             ;; Default 2MB to accommodate: index + scratch (256KB for 64 workers) + data
                             :or {sab-size (* 2 1024 1024) max-blocks 256}}]
  (let [block-descriptors-array-total-size (* max-blocks d/SIZE_OF_BLOCK_DESCRIPTOR)
        index-region-fixed-metadata-size d/OFFSET_BLOCK_DESCRIPTORS_ARRAY_START
        ;; SoA mirror arrays for SIMD descriptor scanning (Phase 1)
        ;; status_mirror[max_blocks]:  i32 per descriptor — contiguous for v128 scan
        ;; capacity_mirror[max_blocks]: i32 per descriptor — contiguous for v128 scan
        mirror-arrays-size (* max-blocks 2 d/SIZE_OF_INT32) ;; status + capacity
        status-mirror-start (+ index-region-fixed-metadata-size block-descriptors-array-total-size)
        capacity-mirror-start (+ status-mirror-start (* max-blocks d/SIZE_OF_INT32))
        index-region-size (+ index-region-fixed-metadata-size block-descriptors-array-total-size mirror-arrays-size)
        ;; Add scratch region for WASM operations (per-worker scratch space)
        scratch-region-size (* wasm/MAX_WORKERS wasm/SCRATCH_SIZE)
        data-region-start-offset (+ index-region-size scratch-region-size)
        data-region-size (- sab-size data-region-start-offset)]
    (when (< data-region-size d/MINIMUM_USABLE_BLOCK_SIZE)
      (throw (js/Error. (str "SAB total size " sab-size " is too small. Index:" index-region-size
                             " Scratch:" scratch-region-size " Data:" data-region-size))))
    ;; Always create WebAssembly.Memory - all EVE uses WASM for acceleration
    (let [;; Round up to 64KB page boundary for WASM
          wasm-pages (js/Math.ceil (/ sab-size wasm/PAGE_SIZE))
          actual-sab-size (* wasm-pages wasm/PAGE_SIZE)
          ;; Create WebAssembly.Memory - its buffer IS a SharedArrayBuffer
          wasm-memory (js/WebAssembly.Memory.
                       #js {:initial wasm-pages
                            :maximum wasm/MAX_PAGES
                            :shared true})
          sab (.-buffer wasm-memory)
          index-view (js/Int32Array. sab)
          data-view (js/Uint8Array. sab)
          reader-map-sab (js/SharedArrayBuffer. d/READER_MAP_SAB_SIZE_BYTES)
          reader-map-view (js/Int32Array. reader-map-sab)
          _ (.fill reader-map-view 0)
          ;; Recalculate data region size with actual (page-aligned) SAB size
          actual-data-region-size (- actual-sab-size data-region-start-offset)
          scratch-region-start index-region-size
          _ (js/Atomics.store index-view (/ d/OFFSET_SAB_TOTAL_SIZE d/SIZE_OF_INT32) actual-sab-size)
          _ (js/Atomics.store index-view (/ d/OFFSET_INDEX_REGION_SIZE d/SIZE_OF_INT32) index-region-size)
          _ (js/Atomics.store index-view (/ d/OFFSET_DATA_REGION_START d/SIZE_OF_INT32) data-region-start-offset)
          _ (js/Atomics.store index-view (/ d/OFFSET_MAX_BLOCK_DESCRIPTORS d/SIZE_OF_INT32) max-blocks)
          _ (js/Atomics.store index-view (/ d/OFFSET_ATOM_ROOT_DATA_DESC_IDX d/SIZE_OF_INT32) d/ROOT_POINTER_NIL_SENTINEL)
          ;; Initialize global epoch to 1 (0 is reserved for "not reading")
          _ (js/Atomics.store index-view (/ d/OFFSET_GLOBAL_EPOCH d/SIZE_OF_INT32) 1)
          ;; Initialize worker registry - all slots inactive
          _ (dotimes [slot-idx d/MAX_WORKERS]
              (let [slot-byte-offset (+ d/OFFSET_WORKER_REGISTRY_START (* slot-idx d/WORKER_SLOT_SIZE))]
                (js/Atomics.store index-view (/ slot-byte-offset d/SIZE_OF_INT32) d/WORKER_STATUS_INACTIVE)))
          ;; Initialize first block descriptor
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_STATUS d/STATUS_FREE)
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_DATA_OFFSET data-region-start-offset)
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_DATA_LENGTH 0)
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_BLOCK_CAPACITY actual-data-region-size)
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_VALUE_DATA_DESC_IDX d/ROOT_POINTER_NIL_SENTINEL)
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_LOCK_OWNER 0)
          _ (u/write-block-descriptor-field! index-view 0 d/OFFSET_BD_RETIRED_EPOCH 0)
          _ (doseq [i (range 1 max-blocks)] (clear-descriptor-fields! index-view i))
          ;; Initialize SoA mirror arrays for SIMD descriptor scanning
          ;; status_mirror[0] = STATUS_FREE, capacity_mirror[0] = data-region-size
          ;; status_mirror[1..N] = STATUS_ZEROED_UNUSED (-1), capacity_mirror[1..N] = 0
          _ (aset index-view (/ status-mirror-start 4) d/STATUS_FREE)
          _ (aset index-view (/ capacity-mirror-start 4) actual-data-region-size)
          _ (dotimes [i (dec max-blocks)]
              (let [idx (inc i)]
                (aset index-view (+ (/ status-mirror-start 4) idx) d/STATUS_ZEROED_UNUSED)
                (aset index-view (+ (/ capacity-mirror-start 4) idx) 0)))
          _ (reset-alloc-cursor!)
          s-atom-env {:sab sab :index-view index-view :data-view data-view
                      :reader-map-sab reader-map-sab :reader-map-view reader-map-view
                      :wasm-memory wasm-memory
                      :scratch-region-start scratch-region-start
                      :status-mirror-start status-mirror-start
                      :capacity-mirror-start capacity-mirror-start
                      :config {:sab-total-size-bytes actual-sab-size :max-block-descriptors max-blocks
                               :index-region-size index-region-size
                               :scratch-region-start scratch-region-start
                               :status-mirror-start status-mirror-start
                               :capacity-mirror-start capacity-mirror-start
                               :data-region-start-offset data-region-start-offset}}
          the-private-atom-instance (->SharedAtom s-atom-env validator (or metamap {}) (cljs.core/atom {}))
          ;; Set global atom instance so serialize-element can build SAB types
          _ (set! *global-atom-instance* the-private-atom-instance)
          ;; Cache views at module level for hot-path access (avoids PersistentHashMap lookup)
          _ (set! cached-atom-iv index-view)
          _ (set! cached-atom-uv data-view)
          ;; Update WASM views to point to new atom's memory BEFORE serializing,
          ;; so that try-build-sab / HAMT operations use the correct DataView.
          _ (wasm/update-views! wasm-memory)
          initial-map (if (map? initial-cljs-map-value) initial-cljs-map-value {})
          serialized-initial-map (binding [d/*parent-atom* the-private-atom-instance] (default-serializer initial-map))
          initial-root-data-block-desc-idx
          (if-not serialized-initial-map
            d/ROOT_POINTER_NIL_SENTINEL
            (if (zero? (.-length serialized-initial-map))
              d/ROOT_POINTER_NIL_SENTINEL
              (let [alloc-info (alloc s-atom-env (.-length serialized-initial-map))]
                (if (:error alloc-info)
                  (throw (js/Error. (str "private-atom init alloc for map: " (:error alloc-info))))
                  (do
                    (.set (:data-view s-atom-env) serialized-initial-map (:offset alloc-info))
                    (u/write-block-descriptor-field! (:index-view s-atom-env) (:descriptor-idx alloc-info) d/OFFSET_BD_DATA_LENGTH (.-length serialized-initial-map))
                    (:descriptor-idx alloc-info))))))]
      (js/Atomics.store index-view (/ d/OFFSET_ATOM_ROOT_DATA_DESC_IDX d/SIZE_OF_INT32) initial-root-data-block-desc-idx)
      the-private-atom-instance)))

(defn- read-private-atom-root-data-block-desc-idx [_s-atom-env-map]
  (js/Atomics.load cached-atom-iv (/ d/OFFSET_ATOM_ROOT_DATA_DESC_IDX d/SIZE_OF_INT32)))

(defn- cas-private-atom-root-data-block-desc-idx! [_s-atom-env-map expected-old-desc-idx new-desc-idx]
  (js/Atomics.compareExchange cached-atom-iv
                              (/ d/OFFSET_ATOM_ROOT_DATA_DESC_IDX d/SIZE_OF_INT32)
                              expected-old-desc-idx new-desc-idx))

;; Cached atom views: avoids PersistentHashMap keyword lookup on s-atom-env per operation.
;; Set once in private-atom, used in hot-path functions (swap!, deref, CAS).
(def ^:private ^:mutable cached-atom-iv nil)  ;; Int32Array (index view)
(def ^:private ^:mutable cached-atom-uv nil)  ;; Uint8Array (data view)

;; Deref cache: avoids re-deserializing SAB data when descriptor index hasn't changed.
(def ^:private ^:mutable cached-deref-env nil)
(def ^:private ^:mutable cached-deref-desc-idx -1)
(def ^:private ^:mutable cached-deref-val nil)

(defn- -update-fn-for-shared-atom-swap!
  [s-env current-root-data-block-desc-idx validator-fn user-f user-args-arr]
  (let [index-view cached-atom-iv
        data-view cached-atom-uv
        old-map-cljs-value
        (if (= current-root-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
          {}
          (let [status (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_STATUS)
                data-offset (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                data-len (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
            (if (and (== status d/STATUS_ALLOCATED) (>= data-len 0))
              (ser/deserialize-from-dv s-env (wasm/data-view) data-offset data-len)
              (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn SharedAtomRoot: desc_idx " current-root-data-block-desc-idx))))))]
    (when-not (map? old-map-cljs-value) (throw (js/Error. (str "SharedAtom integrity error: expected map, got " (type old-map-cljs-value)))))
    (let [new-map-cljs-value (if user-args-arr
                                (case (.-length user-args-arr)
                                  1 (user-f old-map-cljs-value (aget user-args-arr 0))
                                  2 (user-f old-map-cljs-value (aget user-args-arr 0) (aget user-args-arr 1))
                                  (apply user-f old-map-cljs-value (array-seq user-args-arr)))
                                (user-f old-map-cljs-value))]
      (when-not (map? new-map-cljs-value) (throw (js/Error. (str "SharedAtom swap fn must return map. Got: " (type new-map-cljs-value)))))
      (when (and validator-fn (not (validator-fn new-map-cljs-value))) (throw (js/Error. "Swap (SharedAtom) validator failed.")))
      (if (identical? new-map-cljs-value old-map-cljs-value)
        ;; Use JS object instead of CLJS map for CAS outcome — avoids HAMT allocation
        #js {:cas_idx current-root-data-block-desc-idx :free_idx nil
             :alloc_idx nil :final_val old-map-cljs-value
             :old_val old-map-cljs-value :changed false}
        ;; Fast path: SAB-backed types are already in shared memory, just encode pointer
        (let [new_map_bytes (if (satisfies? d/ISabStorable new-map-cljs-value)
                              (d/-sab-encode new-map-cljs-value nil)
                              (default-serializer new-map-cljs-value))]
          (if (or (nil? new_map_bytes) (zero? (.-length new_map_bytes)))
            #js {:cas_idx d/ROOT_POINTER_NIL_SENTINEL :free_idx current-root-data-block-desc-idx
                 :alloc_idx nil :final_val new-map-cljs-value
                 :old_val old-map-cljs-value :changed true}
            (let [alloc-info (alloc-root-block s-env (.-length new_map_bytes))]
              (if-not alloc-info (throw (js/Error. "AllocFailedInUpdate SharedAtomRoot: out-of-memory"))
                  (let [new-data-offset (aget alloc-info 0) new-data-desc-idx (aget alloc-info 1)]
                    (.set data-view new_map_bytes new-data-offset)
                    (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_LENGTH (.-length new_map_bytes))
                    (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_OFFSET new-data-offset)
                    #js {:cas_idx new-data-desc-idx :free_idx current-root-data-block-desc-idx
                         :alloc_idx new-data-desc-idx :final_val new-map-cljs-value
                         :old_val old-map-cljs-value :changed true})))))))))

(defn- -update-fn-for-shared-atom-reset!
  [s-env current-root-data-block-desc-idx validator-fn new-map-cljs-value _user-args-arr]
  (assert (map? new-map-cljs-value) "SharedAtom -reset! new value must be a map.")
  (when (and validator-fn (not (validator-fn new-map-cljs-value))) (throw (js/Error. "Reset (SharedAtom) validator failed.")))
  ;; Fast path: SAB-backed types are already in shared memory, just encode pointer
  (let [new_map_bytes (if (satisfies? d/ISabStorable new-map-cljs-value)
                        (d/-sab-encode new-map-cljs-value nil)
                        (default-serializer new-map-cljs-value))
        index-view cached-atom-iv
        data-view cached-atom-uv]
    (if (or (nil? new_map_bytes) (zero? (.-length new_map_bytes)))
      ;; Empty value path
      (let [old-map-cljs-value
            (if (= current-root-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
              {}
              (let [status (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_STATUS)
                    data-offset (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                    data-len (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                (if (and (== status d/STATUS_ALLOCATED) (>= data-len 0))
                  (ser/deserialize-from-dv s-env (wasm/data-view) data-offset data-len)
                  {})))]
        #js {:cas_idx d/ROOT_POINTER_NIL_SENTINEL :free_idx current-root-data-block-desc-idx
             :alloc_idx nil :final_val new-map-cljs-value
             :old_val old-map-cljs-value :changed true})
      ;; Non-empty value: check if bytes match existing data (same-value reset fast path).
      ;; When build-hamt-from-cljs returns a cached result, the encoded pointer bytes
      ;; are identical to what's already stored. Skip alloc/write/retirement entirely.
      (if (and (not= current-root-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
               (let [old-len (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                 (and (== old-len (.-length new_map_bytes))
                      (let [old-off (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                            new-len (.-length new_map_bytes)]
                        ;; Compare bytes directly (typically 7 bytes for SAB pointer)
                        (loop [i 0]
                          (if (>= i new-len)
                            true
                            (if (== (aget data-view (+ old-off i)) (aget new_map_bytes i))
                              (recur (inc i))
                              false)))))))
        ;; Bytes match — same value, skip everything (no alloc, no write, no retirement)
        #js {:cas_idx current-root-data-block-desc-idx :free_idx nil
             :alloc_idx nil :final_val new-map-cljs-value
             :old_val new-map-cljs-value :changed false}
        ;; Bytes differ — normal path
        (let [old-map-cljs-value
              (if (= current-root-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
                {}
                (let [status (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_STATUS)
                      data-offset (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                      data-len (u/read-block-descriptor-field index-view current-root-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                  (if (and (== status d/STATUS_ALLOCATED) (>= data-len 0))
                    (ser/deserialize-from-dv s-env (wasm/data-view) data-offset data-len)
                    {})))
              alloc-info (alloc-root-block s-env (.-length new_map_bytes))]
          (if-not alloc-info (throw (js/Error. "AllocFailedInUpdate SharedAtomRoot (reset): out-of-memory"))
              (let [new-data-offset (aget alloc-info 0) new-data-desc-idx (aget alloc-info 1)]
                (.set data-view new_map_bytes new-data-offset)
                (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_LENGTH (.-length new_map_bytes))
                (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_OFFSET new-data-offset)
                #js {:cas_idx new-data-desc-idx :free_idx current-root-data-block-desc-idx
                     :alloc_idx new-data-desc-idx :final_val new-map-cljs-value
                     :old_val old-map-cljs-value :changed true})))))))

(defn- do-private-atom-swap!
  "Core swap! implementation. user-args-arr is nil or a JS array of extra args
   (avoids CLJS seq creation from variadic & rest args on every swap! call)."
  [shared-atom-instance update-logic-fn user-fn-or-new-value user-args-arr]
  (let [s-atom-env (.-s-atom-env shared-atom-instance)
        validator-fn (.-validator-fn shared-atom-instance)]
    (loop [retries d/MAX_SWAP_RETRIES]
      (when (zero? retries) (throw (js/Error. "do-private-atom-swap! failed after max retries.")))
      (let [current-root-desc-idx (read-private-atom-root-data-block-desc-idx s-atom-env)
            update-outcome (try
                             (update-logic-fn s-atom-env current-root-desc-idx validator-fn user-fn-or-new-value user-args-arr)
                             (catch js/Error e
                               (let [error-msg (.-message e)]
                                 (if (or (string/includes? error-msg "StaleReadOrInvalidState")
                                         (string/includes? error-msg "AllocFailedInUpdate"))
                                   ::retry-needed-for-cas-loop
                                   (do (println "!!! Unrecoverable error in update-logic-fn of do-private-atom-swap!:" e (.-stack e))
                                       (throw e))))))]
        (if (= ::retry-needed-for-cas-loop update-outcome)
          (recur (dec retries))
          ;; JS object outcome: cas-idx, free-idx, alloc-idx, final-val, old-val, changed
          (if-not (.-changed update-outcome)
            ;; Fast path: value unchanged — skip CAS, free, and retirement entirely.
            (do (let [fv (.-final-val update-outcome)]
                  (when (satisfies? d/ISabRetirable fv)
                    (set! cached-deref-env s-atom-env)
                    (set! cached-deref-desc-idx current-root-desc-idx)
                    (set! cached-deref-val fv)))
                update-outcome)
            (let [new-desc-idx-for-cas (let [v (.-cas-idx update-outcome)] (if (nil? v) d/ROOT_POINTER_NIL_SENTINEL v))
                  actual-old-root-desc-idx (cas-private-atom-root-data-block-desc-idx! s-atom-env current-root-desc-idx new-desc-idx-for-cas)]
              (if (== actual-old-root-desc-idx current-root-desc-idx)
                (do
                  (let [old_desc_to_free (.-free-idx update-outcome)]
                    (when (and old_desc_to_free
                               (not= old_desc_to_free d/ROOT_POINTER_NIL_SENTINEL)
                               (not= old_desc_to_free new-desc-idx-for-cas))
                      ;; Pool old root block for reuse instead of expensive free
                      ;; (free requires lock acquisition + reader check + descriptor writes)
                      (let [old-offset (u/read-block-descriptor-field cached-atom-iv old_desc_to_free d/OFFSET_BD_DATA_OFFSET)]
                        (when-not (pool-root-block! old-offset old_desc_to_free)
                          ;; Pool full — fall back to free
                          (let [free_outcome (free s-atom-env old_desc_to_free)]
                            (when (:error free_outcome)
                              (println (str "[W:" d/*worker-id* "] do-private-atom-swap! CAS_SUCCESS_BUT_FREE_FAILED: " (pr-str (:error free_outcome))))))))))
                  ;; Retire replaced tree nodes (closes the memory leak)
                  (let [old-val (.-old-val update-outcome)
                        new-val (.-final-val update-outcome)]
                    (when (satisfies? d/ISabRetirable old-val)
                      (d/-sab-retire-diff! old-val new-val s-atom-env :free)))
                  ;; Update deref cache if final value is ISabRetirable (SabMapRoot).
                  ;; Plain CLJS maps from reset! must NOT be cached — they break
                  ;; retirement when used as old-val in swap!.
                  (let [fv (.-final-val update-outcome)]
                    (if (satisfies? d/ISabRetirable fv)
                      (do (set! cached-deref-env s-atom-env)
                          (set! cached-deref-desc-idx new-desc-idx-for-cas)
                          (set! cached-deref-val fv))
                      (set! cached-deref-desc-idx -1)))
                  update-outcome)
                (do
                  (let [newly-alloc-desc-idx (.-alloc-idx update-outcome)]
                    (when (and newly-alloc-desc-idx
                               (not= newly-alloc-desc-idx d/ROOT_POINTER_NIL_SENTINEL))
                      (free s-atom-env newly-alloc-desc-idx)))
                  (recur (dec retries)))))))))))

(deftype SharedAtom [s-atom-env validator-fn meta-map watchers-atom]
  IMeta (-meta [_this] meta-map)
  IWithMeta (-with-meta [_ new-meta] (->SharedAtom s-atom-env validator-fn new-meta watchers-atom))
  IDeref (-deref [_this]
           (let [index-view cached-atom-iv
                 root-data-block-desc-idx (read-private-atom-root-data-block-desc-idx s-atom-env)]
             (if (and (identical? s-atom-env cached-deref-env)
                      (== root-data-block-desc-idx cached-deref-desc-idx))
               cached-deref-val
               (if (= root-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL) {}
                   (let [status (u/read-block-descriptor-field index-view root-data-block-desc-idx d/OFFSET_BD_STATUS)
                         data-offset (u/read-block-descriptor-field index-view root-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                         data-len (u/read-block-descriptor-field index-view root-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                     (if (and (== status d/STATUS_ALLOCATED) (>= data-len 0))
                       (let [val (ser/deserialize-from-dv s-atom-env (wasm/data-view) data-offset data-len)]
                         (set! cached-deref-env s-atom-env)
                         (set! cached-deref-desc-idx root-data-block-desc-idx)
                         (set! cached-deref-val val)
                         val)
                       {}))))))
  IReset (-reset! [this new-map-cljs-value]
           (when-not (map? new-map-cljs-value) (throw (js/Error. "SharedAtom can only be reset to a map.")))
           (let [outcome (do-private-atom-swap! this -update-fn-for-shared-atom-reset! new-map-cljs-value nil)]
             (when (.-changed outcome) (notify-watches watchers-atom (.-old-val outcome) (.-final-val outcome)))
             (.-final-val outcome)))
  ISwap
  (-swap! [this f] ; arity 1 (fn only)
    (let [outcome (do-private-atom-swap! this -update-fn-for-shared-atom-swap! f nil)]
      (when (.-changed outcome) (notify-watches watchers-atom (.-old-val outcome) (.-final-val outcome)))
      (.-final-val outcome)))
  (-swap! [this f x] ; arity 2 (fn + 1 arg)
    (let [outcome (do-private-atom-swap! this -update-fn-for-shared-atom-swap! f #js [x])]
      (when (.-changed outcome) (notify-watches watchers-atom (.-old-val outcome) (.-final-val outcome)))
      (.-final-val outcome)))
  (-swap! [this f x y] ; arity 3 (fn + 2 args)
    (let [outcome (do-private-atom-swap! this -update-fn-for-shared-atom-swap! f #js [x y])]
      (when (.-changed outcome) (notify-watches watchers-atom (.-old-val outcome) (.-final-val outcome)))
      (.-final-val outcome)))
  (-swap! [this f x y r] ; arity 4+ (fn + 2 args + rest seq)
    (let [outcome (do-private-atom-swap! this -update-fn-for-shared-atom-swap! f (to-array (cons x (cons y r))))]
      (when (.-changed outcome) (notify-watches watchers-atom (.-old-val outcome) (.-final-val outcome)))
      (.-final-val outcome)))
  IWatchable
  (-notify-watches [_this oldval newval] (notify-watches watchers-atom oldval newval))
  (-add-watch [this k cb-fn] (swap! watchers-atom assoc k cb-fn) this)
  (-remove-watch [this k] (swap! watchers-atom dissoc k) this))

;;;;====================================================================================================
;;;; EmbeddedSharedAtom
;;;;====================================================================================================

(defn -update-fn-for-embedded-atom-reset! ;; <<< NEWLY ADDED COMPLETE FUNCTION >>>
  [embedded-atom-instance parent-s-env
   current-value-data-block-desc-idx
   validator-fn new-user-value _ignored-user-args-seq]
  (let [index-view (:index-view parent-s-env)
        data-view (:data-view parent-s-env)
        atom-id (.-embedded-atom-id embedded-atom-instance)
        hdr-idx (.-header-descriptor-idx embedded-atom-instance)
        log-prefix (str "[W:" d/*worker-id* " A:" atom-id " H:" hdr-idx " UpdateFnReset InPtr:" current-value-data-block-desc-idx "] ")]
    #_(println log-prefix "ENTER_UPDATE_FN_RESET")
    (when (and validator-fn (not (validator-fn new-user-value)))
      (let [err-msg (str "ValidatorFailed on Reset: AtomID " atom-id)]
        (println log-prefix "THROWING " err-msg) ; Keep critical error logs
        (throw (js/Error. err-msg))))

    (let [old-sabp-representative-value
          (if (= current-value-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
            nil
            (let [start-read-outcome (start-read! parent-s-env current-value-data-block-desc-idx)]
              (if-not (= (:status start-read-outcome) :ok)
                (do (println log-prefix "ReadingOldForReset: Failed start-read!: " (pr-str start-read-outcome) ". THROWING StaleRead.")
                    (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn (Reset) FailedStartReadDetails: " (pr-str start-read-outcome)))))
                (try
                  (let [initial-data-block-status (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_STATUS)
                        initial-data-block-offset (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                        initial-data-block-length (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                    (if (and (== initial-data-block-status d/STATUS_ALLOCATED) (>= initial-data-block-length 0))
                      (let [status-after-read (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_STATUS)
                            length-after-read (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                        (if (or (not= status-after-read d/STATUS_ALLOCATED) (not= length-after-read initial-data-block-length))
                          (let [err-msg-detail (str "DataStateChangedDuringRead (Reset): AtomID " atom-id ", desc_idx: " current-value-data-block-desc-idx)]
                            (println log-prefix "THROWING StaleReadOrInvalidStateUpdateFn - " err-msg-detail)
                            (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn " err-msg-detail))))
                          ;; Zero-copy: read directly from SAB DataView
                          (ser/deserialize-from-dv parent-s-env (js/DataView. (:sab parent-s-env)) initial-data-block-offset initial-data-block-length)))
                      (let [err-msg-detail (str "InitialDescriptorCheckFailed_AfterStartRead (Reset): AtomID " atom-id ", desc_idx: " current-value-data-block-desc-idx " StatusWas_" initial-data-block-status)]
                        (println log-prefix "THROWING StaleReadOrInvalidStateUpdateFn - " err-msg-detail)
                        (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn " err-msg-detail))))))
                  (finally
                    (end-read! parent-s-env current-value-data-block-desc-idx d/*worker-id*))))))]
      (let [old-value-for-user-fn old-sabp-representative-value
            new_serialized_sab_state_bytes (binding [d/*parent-atom* embedded-atom-instance] (atom-serialize new-user-value))
            alloc-info (if (and new_serialized_sab_state_bytes (> (.-length new_serialized_sab_state_bytes) 0)) (alloc parent-s-env (.-length new_serialized_sab_state_bytes)) nil)]
        (cond
          (nil? alloc-info) (do (when (and new_serialized_sab_state_bytes (> (.-length new_serialized_sab_state_bytes) 0))
                                  (let [err-msg (str "AllocFailedInUpdate (Reset): AtomID " atom-id ". Allocation returned nil for non-empty bytes.")]
                                    (println log-prefix "THROWING " err-msg)
                                    (throw (js/Error. err-msg))))
                                {:new-value-data-block-desc-idx-for-header d/ROOT_POINTER_NIL_SENTINEL :old-data-desc-idx-to-free-on-success current-value-data-block-desc-idx :old-sabp-representative-value old-sabp-representative-value :newly-allocated-data-desc-idx-to-free-on-cas-fail nil :newly-serialized-sab-state-bytes new_serialized_sab_state_bytes :final-cljs-value new-user-value :value-read-for-this-attempt old-value-for-user-fn :changed? true})
          (:error alloc-info) (let [err-msg (str "AllocFailedInUpdate (Reset): AtomID " atom-id ". Alloc failed: " (:error alloc-info))]
                                (println log-prefix "THROWING " err-msg) (throw (js/Error. err-msg)))
          :else (let [new-data-offset (:offset alloc-info) new-data-desc-idx (:descriptor-idx alloc-info)]
                  (.set data-view new_serialized_sab_state_bytes new-data-offset)
                  (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_LENGTH (.-length new_serialized_sab_state_bytes))
                  (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_OFFSET new-data-offset)
                  {:new-value-data-block-desc-idx-for-header new-data-desc-idx :old-data-desc-idx-to-free-on-success current-value-data-block-desc-idx :old-sabp-representative-value old-sabp-representative-value :newly-allocated-data-desc-idx-to-free-on-cas-fail new-data-desc-idx :newly-serialized-sab-state-bytes new_serialized_sab_state_bytes :final-cljs-value new-user-value :value-read-for-this-attempt old-value-for-user-fn :changed? true}))))))

(defn- -try-cas-header-field! [^js index-view ^number field-idx ^number expected-ptr ^number new-ptr num-inner-retries atom-id]
  (loop [n num-inner-retries]
    (let [actual-old-ptr-from-cas (js/Atomics.compareExchange index-view field-idx expected-ptr new-ptr)]
      (if (== actual-old-ptr-from-cas expected-ptr)
        {:success true}
        (if (zero? n)
          (do
            #_(println (str "[W:" d/*worker-id* " A:" atom-id "] InnerCASLoop: FAILED after " num-inner-retries " attempts for expected_ptr: " expected-ptr " -> new_ptr: " new-ptr))
            {:success false :actual-ptr-at-failure actual-old-ptr-from-cas})
          (recur (dec n)))))))

(defn- do-embedded-swap!
  [atom-instance update-logic-fn user-fn-or-new-value & user-args-seq]
  (let [parent-s-atom-env (get-env atom-instance)
        index-view (:index-view parent-s-atom-env)
        header-desc-idx (.-header-descriptor-idx atom-instance)
        atom-id (.-embedded-atom-id atom-instance)
        target-value-desc-idx-in-header-field (+ (u/get-block-descriptor-base-int32-offset header-desc-idx)
                                                 (/ d/OFFSET_BD_VALUE_DATA_DESC_IDX d/SIZE_OF_INT32))
        INNER_CAS_RETRIES 10] ; Set to 1 for standard behavior, >1 for inner CAS retry experiment

    (loop [outer-retries d/MAX_SWAP_RETRIES]
      (when (zero? outer-retries)
        (let [err-msg (str "do-embedded-swap! [AtomID: " atom-id ", HdrIdx: " header-desc-idx "] failed OUTER_LOOP after " d/MAX_SWAP_RETRIES " retries.")]
          (println err-msg)
          (throw (js/Error. err-msg))))

      (let [current_data_block_desc_idx (js/Atomics.load index-view target-value-desc-idx-in-header-field)
            update-outcome (try
                             (update-logic-fn ; Fixed: removed apply since user-args-seq should be passed as a single sequence argument
                              atom-instance
                              parent-s-atom-env
                              current_data_block_desc_idx
                              (.-validator-fn atom-instance)
                              user-fn-or-new-value
                              user-args-seq)
                             (catch js/Error e
                               (let [error-msg (.-message e)]
                                 (if (or (string/includes? error-msg "StaleReadOrInvalidState")
                                         (string/includes? error-msg "AllocFailedInUpdate"))
                                   ::retry-outer-swap-loop
                                   (do (println (str "!!! Unrecoverable error in update-logic-fn for AtomID " atom-id " Error: " error-msg) e)
                                       (throw e))))))]
        (if (= update-outcome ::retry-outer-swap-loop)
          (recur (dec outer-retries))
          (let [new_ptr_for_cas (get update-outcome :new-value-data-block-desc-idx-for-header d/ROOT_POINTER_NIL_SENTINEL)
                cas-attempt-result (-try-cas-header-field! index-view
                                                           target-value-desc-idx-in-header-field
                                                           current_data_block_desc_idx
                                                           new_ptr_for_cas
                                                           INNER_CAS_RETRIES
                                                           atom-id)]
            (if (:success cas-attempt-result)
              (do
                (let [val-read-this-attempt (:value-read-for-this-attempt update-outcome)
                      val-written (:final-cljs-value update-outcome)
                      changed? (:changed? update-outcome)]
                  (println (str "[WORKER " d/*worker-id* "] CAS_SUCCESS: AtomID " atom-id
                                ", HdrIdx " header-desc-idx
                                ", ExpectedHdrPointsTo " current_data_block_desc_idx
                                ", UpdateFnReadVal " (pr-str val-read-this-attempt)
                                ", HeaderNowPointsTo " new_ptr_for_cas
                                ", ActualValWritten " (pr-str val-written)
                                ", Changed? " changed?)))
                (when-let [old_desc_to_free (:old-data-desc-idx-to-free-on-success update-outcome)]
                  (when (and (not= old_desc_to_free d/ROOT_POINTER_NIL_SENTINEL)
                             (not= old_desc_to_free new_ptr_for_cas))
                    (let [free_outcome (free parent-s-atom-env old_desc_to_free)]
                      (condp = (:error free_outcome) nil nil
                             :active-readers-became-orphaned
                             (println (str "[W:" d/*worker-id* "] CAS_SUCCESS_NOTE: Old_desc " old_desc_to_free " ORPHANED for A:" atom-id))
                             (println (str "[W:" d/*worker-id* "] CAS_SUCCESS_WARN: Freeing old_desc " old_desc_to_free " for A:" atom-id " error: " (pr-str free_outcome)))))))
                (let [sabp-val-to-cleanup (:old-sabp-representative-value update-outcome)]
                  (when (and sabp-val-to-cleanup (satisfies? d/ISabpType sabp-val-to-cleanup))
                    (let [type-key (d/-sabp-type-key sabp-val-to-cleanup)]
                      (if-let [cleanup-fn (d/get-sabp-cleanup-fn type-key)]
                        (cleanup-fn sabp-val-to-cleanup parent-s-atom-env)))))
                update-outcome)
              (do
                #_(println (str "[WORKER " d/*worker-id* "] CAS_FAILED_INNER_LOOP: AtomID " atom-id ...)) ; Keep this commented for now
                (when-let [newly-alloc-desc-idx (:newly-allocated-data-desc-idx-to-free-on-cas-fail update-outcome)]
                  (when (not= newly-alloc-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
                    (free parent-s-atom-env newly-alloc-desc-idx)))
                (when-let [newly-created-state-bytes (:newly-serialized-sab-state-bytes update-outcome)]
                  (let [sabp-value-from-new-state (atom-deserialize newly-created-state-bytes {:s-atom-env parent-s-atom-env})]
                    (when (and sabp-value-from-new-state (satisfies? d/ISabpType sabp-value-from-new-state))
                      (let [type-key (d/-sabp-type-key sabp-value-from-new-state)]
                        (if-let [cleanup-fn (d/get-sabp-cleanup-fn type-key)]
                          (cleanup-fn sabp-value-from-new-state parent-s-atom-env))))))
                (recur (dec outer-retries))))))))))

(defn- -try-read-embedded-atom-value [_this value-data-block-idx parent-s-env log-prefix-outer _read-context]
  (let [parent-idx-view (:index-view parent-s-env)
        log-prefix (str log-prefix-outer " TryRead desc:" value-data-block-idx "] ")]

    (if (= value-data-block-idx d/ROOT_POINTER_NIL_SENTINEL)
      {:value nil}
      (let [start-read-status (start-read! parent-s-env value-data-block-idx)]
        (if (:error start-read-status)
          (do (println log-prefix "Failed start-read!: " (pr-str start-read-status) ". Signaling retry.")
              {:retry true})
          (try
            (let [data-block-status (u/read-block-descriptor-field parent-idx-view value-data-block-idx d/OFFSET_BD_STATUS)
                  data-block-offset (u/read-block-descriptor-field parent-idx-view value-data-block-idx d/OFFSET_BD_DATA_OFFSET)
                  data-block-length (u/read-block-descriptor-field parent-idx-view value-data-block-idx d/OFFSET_BD_DATA_LENGTH)]
              (if (and (== data-block-status d/STATUS_ALLOCATED) (>= data-block-length 0))
                ;; Zero-copy: read directly from SAB DataView
                {:value (ser/deserialize-from-dv parent-s-env (js/DataView. (:sab parent-s-env)) data-block-offset data-block-length)}
                (do (println log-prefix "Path: STALE_BLOCK_DESC (Status was " data-block-status ") after start-read. Signaling retry.")
                    {:retry true})))
            (finally
              (end-read! parent-s-env value-data-block-idx d/*worker-id*))))))))

(defn -update-fn-for-embedded-atom-swap!
  [embedded-atom-instance parent-s-env
   current-value-data-block-desc-idx
   validator-fn user-f user-args-seq]
  (let [index-view (:index-view parent-s-env)
        data-view (:data-view parent-s-env)
        atom-id (.-embedded-atom-id embedded-atom-instance)
        hdr-idx (.-header-descriptor-idx embedded-atom-instance)
        log-prefix (str "[W:" d/*worker-id* " A:" atom-id " H:" hdr-idx " UpdateFn InPtr:" current-value-data-block-desc-idx "] ")]

    (let [old-sabp-representative-value
          (if (= current-value-data-block-desc-idx d/ROOT_POINTER_NIL_SENTINEL)
            nil
            (let [start-read-status (start-read! parent-s-env current-value-data-block-desc-idx)]
              (if (:error start-read-status)
                (do (println log-prefix "ReadingOld: Failed start-read!: " (pr-str start-read-status) ". THROWING StaleRead.")
                    (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn FailedStartRead: " (pr-str start-read-status)))))
                (try
                  (let [initial-data-block-status (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_STATUS)
                        initial-data-block-offset (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_DATA_OFFSET)
                        initial-data-block-length (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                    (if (and (== initial-data-block-status d/STATUS_ALLOCATED) (>= initial-data-block-length 0))
                      (let [status-after-read (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_STATUS)
                            length-after-read (u/read-block-descriptor-field index-view current-value-data-block-desc-idx d/OFFSET_BD_DATA_LENGTH)]
                        (if (or (not= status-after-read d/STATUS_ALLOCATED) (not= length-after-read initial-data-block-length))
                          (let [err-msg-detail (str "DataStateChangedDuringRead: AtomID " atom-id)]
                            (println log-prefix "THROWING StaleReadOrInvalidStateUpdateFn - " err-msg-detail)
                            (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn " err-msg-detail))))
                          ;; Zero-copy: read directly from SAB DataView
                          (ser/deserialize-from-dv parent-s-env (js/DataView. (:sab parent-s-env)) initial-data-block-offset initial-data-block-length)))
                      (let [err-msg-detail (str "InitialDescriptorCheckFailed_AfterStartRead: AtomID " atom-id " StatusWas_" initial-data-block-status)]
                        (println log-prefix "THROWING StaleReadOrInvalidStateUpdateFn - " err-msg-detail)
                        (throw (js/Error. (str "StaleReadOrInvalidStateUpdateFn " err-msg-detail))))))
                  (finally
                    (end-read! parent-s-env current-value-data-block-desc-idx d/*worker-id*))))))]
      ;; Pass deserialized value directly to user function (zero-copy: SAB-backed types returned as-is)
      (let [old-value-for-user-fn old-sabp-representative-value
            new-ab-native-value-from-user-fn (apply user-f old-value-for-user-fn user-args-seq)]
        (when (and validator-fn (not (validator-fn new-ab-native-value-from-user-fn)))
          (throw (js/Error. (str "ValidatorFailed: AtomID " atom-id))))
        (if (= new-ab-native-value-from-user-fn old-value-for-user-fn)
          {:new-value-data-block-desc-idx-for-header current-value-data-block-desc-idx
           :old-data-desc-idx-to-free-on-success nil
           :old-sabp-representative-value old-sabp-representative-value
           :newly-allocated-data-desc-idx-to-free-on-cas-fail nil
           :newly-serialized-sab-state-bytes nil
           :final-cljs-value old-value-for-user-fn
           :value-read-for-this-attempt old-value-for-user-fn
           :changed? false}
          (let [new_serialized_sab_state_bytes (binding [d/*parent-atom* embedded-atom-instance] (default-serializer new-ab-native-value-from-user-fn))
                alloc-info (if (and new_serialized_sab_state_bytes (> (.-length new_serialized_sab_state_bytes) 0)) (alloc parent-s-env (.-length new_serialized_sab_state_bytes)) nil)]
            (cond
              (nil? alloc-info) (do (when (and new_serialized_sab_state_bytes (> (.-length new_serialized_sab_state_bytes) 0)) (throw (js/Error. (str "AllocFailedInUpdate AtomID " atom-id ": Alloc returned nil for non-empty bytes."))))
                                    {:new-value-data-block-desc-idx-for-header d/ROOT_POINTER_NIL_SENTINEL :old-data-desc-idx-to-free-on-success current-value-data-block-desc-idx :old-sabp-representative-value old-sabp-representative-value :newly-allocated-data-desc-idx-to-free-on-cas-fail nil :newly-serialized-sab-state-bytes new_serialized_sab_state_bytes :final-cljs-value new-ab-native-value-from-user-fn :value-read-for-this-attempt old-value-for-user-fn :changed? true})
              (:error alloc-info) (throw (js/Error. (str "AllocFailedInUpdate AtomID " atom-id ": " (:error alloc-info))))
              :else (let [new-data-offset (:offset alloc-info) new-data-desc-idx (:descriptor-idx alloc-info)]
                      (.set data-view new_serialized_sab_state_bytes new-data-offset)
                      (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_LENGTH (.-length new_serialized_sab_state_bytes))
                      (u/write-block-descriptor-field! index-view new-data-desc-idx d/OFFSET_BD_DATA_OFFSET new-data-offset)
                      {:new-value-data-block-desc-idx-for-header new-data-desc-idx :old-data-desc-idx-to-free-on-success current-value-data-block-desc-idx :old-sabp-representative-value old-sabp-representative-value :newly-allocated-data-desc-idx-to-free-on-cas-fail new-data-desc-idx :newly-serialized-sab-state-bytes new_serialized_sab_state_bytes :final-cljs-value new-ab-native-value-from-user-fn :value-read-for-this-attempt old-value-for-user-fn :changed? true}))))))))

(defprotocol IEmbeddedSharedAtom)
(deftype EmbeddedSharedAtom [^SharedAtom parent-shared-atom
                             ^number embedded-atom-id
                             ^number header-descriptor-idx
                             validator-fn meta-map watchers-atom]
  IEmbeddedSharedAtom
  IMeta (-meta [_this] meta-map)
  IWithMeta (-with-meta [_ new-meta] (->EmbeddedSharedAtom parent-shared-atom embedded-atom-id header-descriptor-idx validator-fn new-meta watchers-atom))
  IDeref
  (-deref [_this]
    (let [parent-s-env (.-s-atom-env parent-shared-atom)
          parent-idx-view (:index-view parent-s-env)
          atom-id (.-embedded-atom-id _this)
          hdr-idx (.-header-descriptor-idx _this)
          atom-header-base-int32 (u/get-block-descriptor-base-int32-offset header-descriptor-idx)
          value-data-desc-idx-field-in-header (+ atom-header-base-int32 (/ d/OFFSET_BD_VALUE_DATA_DESC_IDX d/SIZE_OF_INT32))
          read-context {:s-atom-env parent-s-env}
          log-prefix (str "[W:" d/*worker-id* " A:" atom-id " H:" hdr-idx " DerefLoop] ")]
      (loop [deref-retries 5]
        (when (zero? deref-retries)
          (let [err-msg (str "EmbeddedSharedAtom -deref ID " atom-id ", HdrIdx: " hdr-idx " failed after " 5 " retries.")]
            (println log-prefix "!!! MAX_DEREF_RETRIES " err-msg)
            (throw (js/Error. err-msg))))
        (let [value-data-block-idx (js/Atomics.load parent-idx-view value-data-desc-idx-field-in-header)
              read-attempt-result (-try-read-embedded-atom-value _this value-data-block-idx parent-s-env log-prefix read-context)]
          (if (:retry read-attempt-result)
            (recur (dec deref-retries))
            (:value read-attempt-result))))))
  IReset
  (-reset! [this new-user-value]
    (let [old-user-value-for-watchers @this
          _ (when (and validator-fn (not (validator-fn new-user-value)))
              (throw (js/Error. (str "EmbeddedSharedAtom -reset! for ID " (.-embedded-atom-id this) ": Validator function returned false.")))) ; Use this. to access field
          outcome (apply do-embedded-swap! this -update-fn-for-embedded-atom-reset! new-user-value [])]
      (when (:changed? outcome)
        (notify-watches watchers-atom old-user-value-for-watchers (:final-cljs-value outcome)))
      (:final-cljs-value outcome)))
  ISwap ;; These apply calls are correct because do-embedded-swap! takes varargs
  (-swap! [this f] (let [old @this outcome (apply do-embedded-swap! this -update-fn-for-embedded-atom-swap! f [])] (when (:changed? outcome) (notify-watches watchers-atom old (:final-cljs-value outcome))) (:final-cljs-value outcome)))
  (-swap! [this f x] (let [old @this outcome (apply do-embedded-swap! this -update-fn-for-embedded-atom-swap! f [x])] (when (:changed? outcome) (notify-watches watchers-atom old (:final-cljs-value outcome))) (:final-cljs-value outcome)))
  (-swap! [this f x y] (let [old @this outcome (apply do-embedded-swap! this -update-fn-for-embedded-atom-swap! f [x y])] (when (:changed? outcome) (notify-watches watchers-atom old (:final-cljs-value outcome))) (:final-cljs-value outcome)))
  (-swap! [this f x y r] (let [old @this user-args (into [x y] r) outcome (apply do-embedded-swap! this -update-fn-for-embedded-atom-swap! f user-args)] (when (:changed? outcome) (notify-watches watchers-atom old (:final-cljs-value outcome))) (:final-cljs-value outcome)))
  IWatchable
  (-notify-watches [_this oldval newval] (notify-watches watchers-atom oldval newval))
  (-add-watch [this k cb-fn] (swap! watchers-atom assoc k cb-fn) this)
  (-remove-watch [this k] (swap! watchers-atom dissoc k) this))

(def atom-id-counter (cljs.core/atom 0))
(defn next-atom-id [] (swap! atom-id-counter inc))

(defn atom
  [initial-cljs-value & {:keys [metamap validator]
                         :or {metamap {}} :as _opts}]
  (let [target-shared-atom (or d/*parent-atom* *global-atom-instance*)]
    (when-not target-shared-atom
      (throw (js/Error. "Target SharedAtom not bound for new atom.")))
    (let [parent-s-env (.-s-atom-env ^SharedAtom target-shared-atom)
          parent-idx-view (:index-view parent-s-env)
          serialized-initial-bytes (binding [d/*parent-atom* target-shared-atom]
                                     (default-serializer initial-cljs-value))
          alloc-result-value (if (and serialized-initial-bytes (> (.-length serialized-initial-bytes) 0))
                               (alloc parent-s-env (.-length serialized-initial-bytes))
                               nil)
          value_data_block_desc_idx (if alloc-result-value
                                      (:descriptor-idx alloc-result-value)
                                      d/ROOT_POINTER_NIL_SENTINEL)]
      (when (and serialized-initial-bytes alloc-result-value (:error alloc-result-value))
        (throw (js/Error. (str "atom constructor: Failed to alloc state block: " (:error alloc-result-value)))))
      (when (and alloc-result-value (not (:error alloc-result-value)) serialized-initial-bytes)
        (.set (:data-view parent-s-env) serialized-initial-bytes (:offset alloc-result-value))
        (u/write-block-descriptor-field! parent-idx-view value_data_block_desc_idx d/OFFSET_BD_DATA_LENGTH (.-length serialized-initial-bytes)))
      (loop [candidate-header-idx 0 scan-retries 2]
        (if (>= candidate-header-idx (u/get-max-block-descriptors parent-idx-view))
          (if (> scan-retries 0) (recur 0 (dec scan-retries))
              (do (when (not= value_data_block_desc_idx d/ROOT_POINTER_NIL_SENTINEL)
                    (free parent-s-env value_data_block_desc_idx))
                  (throw (js/Error. "atom constructor: No suitable ZEROED_UNUSED descriptor slot for embedded atom header."))))
          (let [header-status (u/read-block-descriptor-field parent-idx-view candidate-header-idx d/OFFSET_BD_STATUS)
                header-lock-field-idx (+ (u/get-block-descriptor-base-int32-offset candidate-header-idx) (/ d/OFFSET_BD_LOCK_OWNER d/SIZE_OF_INT32))]
            (if (and (== header-status d/STATUS_ZEROED_UNUSED)
                     (== 0 (u/atomic-compare-exchange-int parent-idx-view header-lock-field-idx 0 d/*worker-id*)))
              (let [next-id (next-atom-id)
                    final-atom-instance (->EmbeddedSharedAtom target-shared-atom next-id candidate-header-idx validator metamap (cljs.core/atom {}))]
                (try
                  (clear-descriptor-fields! parent-idx-view candidate-header-idx)
                  (u/write-block-descriptor-field! parent-idx-view candidate-header-idx d/OFFSET_BD_VALUE_DATA_DESC_IDX value_data_block_desc_idx)
                  (u/write-block-descriptor-field! parent-idx-view candidate-header-idx d/OFFSET_BD_STATUS d/STATUS_EMBEDDED_ATOM_HEADER)
                  (update-mirrors! parent-idx-view candidate-header-idx d/STATUS_EMBEDDED_ATOM_HEADER nil)
                  ;; <<< CORRECTED call to swap! for SharedAtom >>>
                  (swap! target-shared-atom assoc next-id {:header-descriptor-idx candidate-header-idx})
                  final-atom-instance
                  (finally
                    (u/atomic-store-int parent-idx-view header-lock-field-idx 0))))
              (recur (inc candidate-header-idx) scan-retries))))))))

(when u/is-main-thread?
  (set! *global-atom-instance*
        (private-atom {}))  ;; Uses default 2MB size with 256 block descriptors
  ;; Initialize WASM module in background with the atom's memory
  (when-let [wasm-memory (:wasm-memory (.-s-atom-env *global-atom-instance*))]
    (-> (wasm/init! wasm-memory)
        (.then (fn [_] (js/console.log "EVE WASM module initialized")))
        (.catch (fn [err] (js/console.warn "EVE WASM init failed (using JS fallback):" err))))))

(defn embedded-atom? [obj] (instance? EmbeddedSharedAtom obj))

(defn conveyable-> [t]
  (cond
    (embedded-atom? t)
    #js {:type "embedded-atom"
         :parent-shared-atom-id "global"
         :embedded-atom-id (.-embedded-atom-id t)
         :header-descriptor-idx (.-header-descriptor-idx t)
         :meta-map (clj->js (.-meta-map t))}

    (instance? SharedAtom t)
    #js {:type "shared-atom"
         :meta-map (clj->js (.-meta-map t))
         :validator-fn nil} ; Can't serialize functions, will use global atom's validator

    :else t))

(defn <-conveyable [m]
  (cond
    (and (map? m) (= "embedded-atom" (:type m)))
    (let [parent-shared-atom-id (:parent-shared-atom-id m)
          parent-shared-atom (cond
                               (= parent-shared-atom-id "global") *global-atom-instance*
                               :else (do (println "!!! <-conveyable: Unknown parent-shared-atom-id:" parent-shared-atom-id) nil))
          received-id (:embedded-atom-id m)
          header-idx (:header-descriptor-idx m)
          meta-from-conveyed (:meta-map m {})]
      (if (or (nil? parent-shared-atom) (nil? received-id) (nil? header-idx))
        (do (println "!!! atom/<-conveyable: CRITICAL - Cannot reconstruct EmbeddedSharedAtom." (pr-str m)) nil)
        (->EmbeddedSharedAtom parent-shared-atom received-id header-idx nil meta-from-conveyed (cljs.core/atom {}))))

    (and (map? m) (= "shared-atom" (:type m)))
    (if *global-atom-instance*
      (let [meta-from-conveyed (:meta-map m {})]
        ;; Return the global atom instance, optionally with updated metadata
        (if (empty? meta-from-conveyed)
          *global-atom-instance*
          (-with-meta *global-atom-instance* meta-from-conveyed)))
      (do (println "!!! atom/<-conveyable: CRITICAL - No global atom instance for SharedAtom reconstruction") nil))

    :else m))

(defn mem-window
  ([shared-atom-deftype-instance] (mem-window shared-atom-deftype-instance {}))
  ([shared-atom-deftype-instance opts]
   (let [s-atom-env-map (get-env shared-atom-deftype-instance)
         {:keys [sab index-view data-view config]} s-atom-env-map]
     (when (or (nil? sab) (nil? index-view) (nil? data-view) (nil? config))
       (throw (js/Error. "mem-window: s-atom-env components are nil.")))
     (let [{:keys [sab-total-size-bytes max-block-descriptors index-region-size data-region-start-offset]} config
           {:keys [max-descriptors-to-show max-view-lines chars-per-line show-legend? descriptors-per-table-row focus-offset]
            :or {max-descriptors-to-show 32 max-view-lines 12 chars-per-line 32 show-legend? false descriptors-per-table-row 16 focus-offset nil}} opts]
       (println (str "--- Atom Memory Window (SAB Size: " sab-total-size-bytes ", MaxDesc: " max-block-descriptors ") ---"))
       (println (str "IndexRegionSz: " index-region-size ", DataRegionStart: " data-region-start-offset))
       (when (instance? SharedAtom shared-atom-deftype-instance)
         (println (str "SharedAtom Root Ptr (data block desc_idx): "
                       (js/Atomics.load index-view (/ d/OFFSET_ATOM_ROOT_DATA_DESC_IDX d/SIZE_OF_INT32)))))
       (println "--- Block Descriptors ---")
       (if (pos? max-descriptors-to-show)
         (loop [current-idx (or (:start-descriptor opts) 0)]
           (when (< current-idx (min (+ (or (:start-descriptor opts) 0) max-descriptors-to-show) max-block-descriptors))
             (u/print-descriptor-table index-view current-idx descriptors-per-table-row (min (+ (or (:start-descriptor opts) 0) max-descriptors-to-show) max-block-descriptors))
             (recur (+ current-idx descriptors-per-table-row))))
         (println "  (No descriptors requested to be shown)"))
       (let [data-region-actual-size (max 0 (- sab-total-size-bytes data-region-start-offset))
             max_display_bytes (* max-view-lines chars-per-line)
             max_addr_to_display (+ data-region-start-offset (min data-region-actual-size max_display_bytes) -1)
             target_addr_hex_len (max 6 (count (.toString max_addr_to_display 16)))
             model-char-map-full-str (u/generate-model-char-map-str index-view config data-region-actual-size)]
         (println (str "Model Char View (Data Region, " chars-per-line " chars/line): #=alloc +=cont _=free .=unused/zeroed"))
         (if (pos? data-region-actual-size)
           (loop [line-idx 0 current-char-map-offset 0]
             (when (and (< line-idx max-view-lines) (< current-char-map-offset (count model-char-map-full-str)))
               (let [chars-on-this-line (min chars-per-line (- (count model-char-map-full-str) current-char-map-offset))
                     line-abs-sab-offset (+ data-region-start-offset current-char-map-offset)
                     hex-addr-raw (.toString line-abs-sab-offset 16)
                     addr-padding-needed (max 0 (- target_addr_hex_len (count hex-addr-raw)))
                     address-str (str (apply str (repeat addr-padding-needed "0")) hex-addr-raw ": ")
                     is-focused-line? (and focus-offset (>= focus-offset line-abs-sab-offset) (< focus-offset (+ line-abs-sab-offset chars-per-line)))]
                 (println (str (if is-focused-line? ">> " "   ")
                               (u/format-char-data-line address-str model-char-map-full-str current-char-map-offset chars-on-this-line chars-per-line))))
               (recur (inc line-idx) (+ current-char-map-offset chars-per-line))))
           (println "Data Region is empty or invalid for Model Char View."))
         (println (str "Raw Data (Enhanced Char View, " chars-per-line " bytes/line):"))
         (if (pos? data-region-actual-size)
           (u/hex-window sab {:offset data-region-start-offset :length (min data-region-actual-size (* max-view-lines chars-per-line)) :bytes-per-row chars-per-line :show-legend? show-legend?})
           (println "Data Region is empty or invalid for Raw Data View.")))
       (let [value-data-block-desc-idx-to-decode
             (cond
               (instance? SharedAtom shared-atom-deftype-instance)
               (js/Atomics.load index-view (/ d/OFFSET_ATOM_ROOT_DATA_DESC_IDX d/SIZE_OF_INT32))
               (instance? EmbeddedSharedAtom shared-atom-deftype-instance)
               (let [hdr-desc-idx (.-header-descriptor-idx ^EmbeddedSharedAtom shared-atom-deftype-instance)
                     ptr-field-offset (+ (u/get-block-descriptor-base-int32-offset hdr-desc-idx) (/ d/OFFSET_BD_VALUE_DATA_DESC_IDX d/SIZE_OF_INT32))]
                 (js/Atomics.load index-view ptr-field-offset))
               :else d/ROOT_POINTER_NIL_SENTINEL)]
         (when (not= value-data-block-desc-idx-to-decode d/ROOT_POINTER_NIL_SENTINEL)
           (println (str "Decode of Atom's Value (from data_block_desc_idx: " value-data-block-desc-idx-to-decode ")"))
           (let [data-block-status (u/read-block-descriptor-field index-view value-data-block-desc-idx-to-decode d/OFFSET_BD_STATUS)
                 data-offset (u/read-block-descriptor-field index-view value-data-block-desc-idx-to-decode d/OFFSET_BD_DATA_OFFSET)
                 data-length (u/read-block-descriptor-field index-view value-data-block-desc-idx-to-decode d/OFFSET_BD_DATA_LENGTH)]
             (if (and (or (== data-block-status d/STATUS_ALLOCATED) (== data-block-status d/STATUS_EMBEDDED_ATOM_HEADER))
                      (>= data-length 0)
                      (<= (+ data-offset data-length) sab-total-size-bytes))
               (let [block-data-segment (if (> data-length 0) (js/Uint8Array. sab data-offset data-length) (js/Uint8Array. 0))]
                 (println (str "  Raw Hex (first 32 bytes): " (u/format-bytes-as-hex block-data-segment 32)))
                 (println "  Decoded:" (try (pr-str (default-deserializer block-data-segment {:s-atom-env s-atom-env-map})) (catch :default e (str "ERROR Deserializing: " e))))
                 (when (= data-block-status d/STATUS_EMBEDDED_ATOM_HEADER) (println "  (Note: Decoded an EMBEDDED_ATOM_HEADER's value pointer field)")))
               (println (str "Atom's value data block (desc_idx: " value-data-block-desc-idx-to-decode ") invalid/empty. Status: " data-block-status ", Length: " data-length)))))
         (when (= value-data-block-desc-idx-to-decode d/ROOT_POINTER_NIL_SENTINEL)
           (println "Atom's value is nil (pointer is NIL_SENTINEL).")))
       (println "--- End Atom Memory Window ---")))))

;; Register SharedAtom conveyance functions with the pluggable registry
(conveyance/register-conveyable!
 #(instance? SharedAtom %)
 conveyable->
 #(and (map? %) (= "shared-atom" (:type %)))
 <-conveyable)

(conveyance/register-conveyable!
 embedded-atom?
 conveyable->
 #(and (map? %) (= "embedded-atom" (:type %)))
 <-conveyable)

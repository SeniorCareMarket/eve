(ns com.seniorcaremarket.eve.sabp-list
  (:require
    [com.seniorcaremarket.eve.ab-list :as ab]
    [com.seniorcaremarket.eve.atom :as a]
    [com.seniorcaremarket.eve.data :as d]
    [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]
    [com.seniorcaremarket.eve.util :as u]))

;; --- Forward Declarations ---
(declare ->SabpLinkedList SabpLinkedList ->SabpLinkedListSequence SabpLinkedListSequence)
(declare sabp-linked-list->ab-list)

;; --- SabpLinkedListSequence (Iterator for SabpLinkedList) ---
(deftype SabpLinkedListSequence [s-atom-env
                                 current-node-offset
                                 ^:mutable __hash
                                 meta-map]
  ISequential
  d/ISabpType
  (-sabp-type-key [_] "com.seniorcaremarket.eve.sabp-list/SabpLinkedListSequence")
  IEquiv (-equiv [this other] (u/-equiv-sequential this other))
  IHash (-hash [coll] (if-not (nil? __hash) __hash (set! __hash (hash-ordered-coll coll))))
  IMeta (-meta [_] meta-map)
  IWithMeta (-with-meta [_ new-meta] (->SabpLinkedListSequence s-atom-env current-node-offset __hash new-meta))
  ISeqable (-seq [this] (when (not= current-node-offset d/ROOT_POINTER_NIL_SENTINEL) this))
  ISeq
  (-first [_this]
          (when (not= current-node-offset d/ROOT_POINTER_NIL_SENTINEL)
            (let [desc-info (u/find-descriptor-for-data-offset s-atom-env current-node-offset)]
              (when (and desc-info (== (:status desc-info) d/STATUS_ALLOCATED))
                (let [desc-idx (:descriptor-idx desc-info)]
                  (a/start-read! s-atom-env desc-idx)
                  (try
                    (let [node-data-len (:data-length desc-info)
                          elem-byte-len (- node-data-len d/LL_NODE_NEXT_OFFSET_SIZE_BYTES)
                          original-element-segment-view (js/Uint8Array. (:sab s-atom-env)
                                                                        (+ current-node-offset d/OFFSET_LL_NODE_VALUE)
                                                                        elem-byte-len)
                          copied-element-buffer (js/ArrayBuffer. elem-byte-len)
                          copied-view-for-deser (js/Uint8Array. copied-element-buffer)]
                      (.set copied-view-for-deser original-element-segment-view 0)
                      (ser/deserialize-element s-atom-env copied-view-for-deser))
                    (finally
                      (a/end-read! s-atom-env desc-idx d/*worker-id*))))))))
  (-rest [this] (let [next-s (-next this)] (if next-s next-s ())))
  INext
  (-next [_this]
         (when (not= current-node-offset d/ROOT_POINTER_NIL_SENTINEL)
           (let [desc-info (u/find-descriptor-for-data-offset s-atom-env current-node-offset)]
             (when (and desc-info (== (:status desc-info) d/STATUS_ALLOCATED))
               (let [desc-idx (:descriptor-idx desc-info)]
                 (a/start-read! s-atom-env desc-idx)
                 (try
                   (let [dv (js/DataView. (:sab s-atom-env))
                         node-data-len (:data-length desc-info)
                         elem-byte-len (- node-data-len d/LL_NODE_NEXT_OFFSET_SIZE_BYTES)
                         next-node-offset (.getInt32 dv (+ current-node-offset d/OFFSET_LL_NODE_VALUE elem-byte-len) true)]
                     (when (not= next-node-offset d/ROOT_POINTER_NIL_SENTINEL)
                       (SabpLinkedListSequence. s-atom-env next-node-offset nil meta-map)))
                   (finally
                     (a/end-read! s-atom-env desc-idx d/*worker-id*)))))))))

;; --- SabpLinkedList Deftype (Represents state in SAB) ---
(deftype SabpLinkedList [s-atom-env ; <<<< NEW FIRST FIELD (the map itself)
                         ^number head-offset
                         ^number list-count
                         ^:mutable __hash
                         meta-map]
  ISequential ; Satisfied by ISeqable if -seq returns self or nil for empty
  d/ISabpType
  (-sabp-type-key [_] "com.seniorcaremarket.eve.sabp-list/SabpLinkedList")

  Object
  (equiv [this other] (u/-equiv-sequential this other))
  (toString [coll] (pr-str (seq coll))) ; vec will call seq, which uses internal s-atom-env
  IEquiv
  (-equiv [this other] (u/-equiv-sequential this other))
  IMeta (-meta [_] meta-map)
  IWithMeta (-with-meta [this new-meta]
              (if (identical? meta-map new-meta)
                this
                (->SabpLinkedList s-atom-env head-offset list-count __hash new-meta))) ; Pass s-atom-env
  ICounted
  (-count [_this] list-count)
  IEmptyableCollection
  (-empty [_this]
    (->SabpLinkedList s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil meta-map)) ; New empty list shares s-atom-env

  ISeqable
  (-seq [_this]
    (u/log ">>> SabpLinkedList -seq: ENTER. head:" head-offset "count:" list-count "s-atom-env from instance:" (some? s-atom-env))
    (when-not s-atom-env (throw (js/Error. "SabpLinkedList -seq: Instance s-atom-env is nil.")))
    (when (not= head-offset d/ROOT_POINTER_NIL_SENTINEL)
      (->SabpLinkedListSequence s-atom-env head-offset nil meta-map)))

  ICollection
  (-conj [_this element]
    (u/log ">>> SabpLinkedList -conj: ENTER. Element:" (pr-str element) "onto SLL head:" head-offset "s-atom-env from instance:" (some? s-atom-env))
    (when-not s-atom-env (throw (js/Error. "SabpLinkedList -conj: Instance s-atom-env is nil.")))
    ;; d/*parent-atom* should be bound by the caller (e.g. atom swap) if the 'element'
    ;; itself needs to be serialized into the *same* SAB as this list's parent atom.
    ;; The s-atom-env for *this list's nodes* comes from the instance field.
    (binding [d/*parent-atom* (if (instance? com.seniorcaremarket.eve.atom/SharedAtom s-atom-env) s-atom-env d/*parent-atom*)] ; Crude way to provide a parent if s-atom-env is from a SharedAtom. Needs refinement if s-atom-env isn't the atom itself.
                                                                                                                      ; Better: if element is list-like, its own writer should use current d/*parent-atom*.
                                                                                                                      ; For simple elements, d/*parent-atom* binding here has no effect on their serialization.
      (let [serialized-element (ser/serialize-val element)
            val-bytes-len (if serialized-element (.-length serialized-element) 0)
            new-node-total-size (+ val-bytes-len d/LL_NODE_NEXT_OFFSET_SIZE_BYTES)
            alloc-info (a/alloc s-atom-env new-node-total-size)] ; Uses this list's s-atom-env for node allocation
        (if (:error alloc-info)
          (throw (js/Error. (str "SabpLinkedList -conj: SAB alloc failed: " (:error alloc-info)))))
        (let [new-node-offset (:offset alloc-info)
              new-node-desc-idx (:descriptor-idx alloc-info)
              dv (js/DataView. (:sab s-atom-env))]
          (when serialized-element
            (.set (js/Uint8Array. (:sab s-atom-env)) serialized-element (+ new-node-offset d/OFFSET_LL_NODE_VALUE)))
          (.setInt32 dv (+ new-node-offset d/OFFSET_LL_NODE_VALUE val-bytes-len) head-offset true)
          (u/write-block-descriptor-field! (:index-view s-atom-env) new-node-desc-idx d/OFFSET_BD_DATA_LENGTH new-node-total-size)
          (->SabpLinkedList s-atom-env new-node-offset (inc list-count) nil meta-map))))) ; Pass s-atom-env

  IStack
  (-peek [_this]
    (u/log ">>> SabpLinkedList -peek: ENTER. head:" head-offset "s-atom-env from instance:" (some? s-atom-env))
    (when-not s-atom-env (throw (js/Error. "SabpLinkedList -peek: Instance s-atom-env is nil.")))
    (when (not= head-offset d/ROOT_POINTER_NIL_SENTINEL)
      (first (->SabpLinkedListSequence s-atom-env head-offset nil meta-map))))

  (-pop [this]
    (u/log ">>> SabpLinkedList -pop: ENTER. From SLL head:" head-offset "s-atom-env from instance:" (some? s-atom-env))
    (when-not s-atom-env (throw (js/Error. "SabpLinkedList -pop: Instance s-atom-env is nil.")))
    (if (= head-offset d/ROOT_POINTER_NIL_SENTINEL)
      this
      (let [head-desc-info (u/find-descriptor-for-data-offset s-atom-env head-offset)]
        (if head-desc-info
          (let [head-desc-idx (:descriptor-idx head-desc-info)
                dv (js/DataView. (:sab s-atom-env))
                node-data-len (u/read-block-descriptor-field (:index-view s-atom-env) head-desc-idx d/OFFSET_BD_DATA_LENGTH)
                elem-byte-len (- node-data-len d/LL_NODE_NEXT_OFFSET_SIZE_BYTES)
                _ (when (< elem-byte-len 0) (throw (js/Error. (str "SabpLinkedList -pop: Invalid element byte length " elem-byte-len))))
                next-ptr-read-offset (+ head-offset d/OFFSET_LL_NODE_VALUE elem-byte-len)
                next-node-offset (.getInt32 dv next-ptr-read-offset true)
                free-result (a/free s-atom-env head-desc-idx)] ; Uses this list's s-atom-env
            (when (:error free-result)
              (js/console.error "SabpLinkedList -pop: Error freeing popped SAB node: " free-result))
            (->SabpLinkedList s-atom-env next-node-offset (dec list-count) nil meta-map)) ; Pass s-atom-env
          (throw (js/Error. (str "SabpLinkedList -pop: Corrupt list, head descriptor not found for offset: " head-offset)))))))

  IHash (-hash [coll] (if-not (nil? __hash) __hash (set! __hash (hash-ordered-coll coll))))
  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (binding [*out* writer] (pr-sequential-writer writer pr-writer "(" " " ")" opts coll))))

(defn free-sabp-list-nodes! [^SabpLinkedList sabp-list-value s-atom-env-param]
  (u/log :free-sabp-list-nodes! :sabp-list-value-type (type sabp-list-value) :s-atom-env-param-type (type s-atom-env-param))
  (u/log ">>> sabp_list/free-sabp-list-nodes!: Freeing nodes of SLL, head:" (.-head-offset sabp-list-value))
  ;; Use the s-atom-env passed in, or if SLL instance now stores it, use that.
  ;; For now, assume s-atom-env-param is the correct one for the nodes.
  ;; If SabpLinkedList instance itself has s-atom-env, this param might become redundant.
  (let [s-env (or (when (and sabp-list-value (.-s-atom-env sabp-list-value)) ; If SLL instance has it
                    (.-s-atom-env sabp-list-value))
                  s-atom-env-param)] ; Fallback to param
    (when-not s-env (js/console.error "!!! free-sabp-list-nodes!: s-atom-env is nil. Cannot free nodes." (pr-str sabp-list-value)))
    (loop [current-node-offset (.-head-offset sabp-list-value)]
      (when (not= current-node-offset d/ROOT_POINTER_NIL_SENTINEL)
        (if-let [desc-info (u/find-descriptor-for-data-offset s-env current-node-offset)]
          (let [dv (js/DataView. (:sab s-env))
                node-data-len (u/read-block-descriptor-field (:index-view s-env) (:descriptor-idx desc-info) d/OFFSET_BD_DATA_LENGTH)
                elem-byte-len (- node-data-len d/LL_NODE_NEXT_OFFSET_SIZE_BYTES)
                next-offset (if (>= elem-byte-len 0)
                              (.getInt32 dv (+ current-node-offset d/OFFSET_LL_NODE_VALUE elem-byte-len) true)
                              d/ROOT_POINTER_NIL_SENTINEL)
                _ (u/log ">>> sabp_list/free-sabp-list-nodes!: Freeing node at offset" current-node-offset "desc_idx" (:descriptor-idx desc-info))]
            (a/free s-env (:descriptor-idx desc-info))
            (recur next-offset))
          (do (js/console.error "!!! free-sabp-list-nodes!: Could not find descriptor for node offset" current-node-offset "during cleanup.")
              nil))))))

;; Fressian handlers removed — serialization now uses ser/ fast-path (Phase 5)

;; --- Conversion Function: SabpLinkedList value -> AbList value ---
(defn sabp-linked-list->ab-list
  [^SabpLinkedList sll]
  (u/log :sabp-linked-list->ab-list :sll-type (type sll))
  (u/log ">>> sabp_list/sabp-linked-list->ab-list: Converting SLL head:" (.-head-offset sll) "count:" (.-list-count sll))
  (if (or (nil? sll) (zero? (.-list-count sll)))
    (ab/empty-ab-list (.-meta-map sll))
    (let [s-atom-env-from-instance (.-s-atom-env sll)] ; Get s-atom-env from the SLL instance
      (when-not s-atom-env-from-instance
        (throw (js/Error. "sabp-linked-list->ab-list: s-atom-env from SLL instance is nil.")))
      (u/log ">>> sabp_list/sabp-linked-list->ab-list: Using s-atom-env from SLL (SAB hash:" (hash (:sab s-atom-env-from-instance)) ") for conversion.")
      (let [elements (loop [sabp-seq (seq (->SabpLinkedListSequence s-atom-env-from-instance (.-head-offset sll) nil (.-meta-map sll)))
                            acc []]
                       (if-let [item (first sabp-seq)]
                         (recur (next sabp-seq) (conj acc item))
                         acc))]
        (apply ab/ab-list (with-meta elements (.-meta-map sll)))))))

;; Register SAB→AB converters and cleanup
(d/register-sabp-cleanup! "com.seniorcaremarket.eve.sabp-list/SabpLinkedList" free-sabp-list-nodes!)

;; Development scratch code (comment block) removed — used Fressian raw/ calls (Phase 5)

;; Legacy Fressian test snippets removed (Phase 5)

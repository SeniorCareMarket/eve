(ns com.seniorcaremarket.eve.sabp-set
  (:refer-clojure :exclude [atom])
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.sabp-map :as sm]
   [com.seniorcaremarket.eve.util :as u]))

;; Forward declarations
(declare ->SabpSet ->TransientSabpSet SabpSet TransientSabpSet)

;; ============================================================================
;; SabpSet deftype - wraps SabpMap with values always true
;; ============================================================================

(deftype SabpSet [^sm/SabpMap backing-map ^:mutable __hash meta-map]
  d/ISabpType
  (-sabp-type-key [_] "com.seniorcaremarket.eve.sabp-set/SabpSet")

  Object
  (toString [coll] (pr-str coll))
  (equiv [this other] (-equiv this other))

  ICloneable
  (-clone [_] (SabpSet. backing-map __hash meta-map))

  IWithMeta
  (-with-meta [_ new-meta]
    (SabpSet. backing-map __hash new-meta))

  IMeta
  (-meta [_] meta-map)

  ICounted
  (-count [_] (count backing-map))

  IHash
  (-hash [coll]
    (when (nil? __hash)
      (set! __hash (hash-unordered-coll coll)))
    __hash)

  IEquiv
  (-equiv [this other]
    (cond
      (identical? this other) true
      (not (set? other)) false
      (not= (count this) (count other)) false
      :else (every? #(contains? this %) other)))

  ILookup
  (-lookup [this v] (-lookup this v nil))
  (-lookup [_ v not-found]
    (if (contains? backing-map v) v not-found))

  ISet
  (-disjoin [_ v]
    (SabpSet. (dissoc backing-map v) nil meta-map))

  ISeqable
  (-seq [_]
    (when-let [s (seq backing-map)]
      (map key s)))

  ICollection
  (-conj [_ v]
    (SabpSet. (assoc backing-map v true) nil meta-map))

  IEmptyableCollection
  (-empty [_]
    (SabpSet. (empty backing-map) nil meta-map))

  IFn
  (-invoke [this v] (-lookup this v))
  (-invoke [this v not-found] (-lookup this v not-found))

  IReduce
  (-reduce [_ f]
    (let [sentinel (js/Object.)
          result (reduce-kv
                   (fn [acc k _v]
                     (if (identical? acc sentinel) k (f acc k)))
                   sentinel
                   backing-map)]
      (if (identical? result sentinel) (f) result)))
  (-reduce [_ f init]
    (reduce-kv (fn [acc k _v] (f acc k)) init backing-map))

  IEditableCollection
  (-as-transient [_]
    (TransientSabpSet. (transient backing-map) nil))

  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (pr-sequential-writer writer pr-writer "#{" " " "}" opts (seq coll))))

;; ============================================================================
;; TransientSabpSet
;; ============================================================================

(deftype TransientSabpSet [^:mutable t-backing-map
                           ^:mutable __hash]
  ICounted
  (-count [_] (count t-backing-map))

  ILookup
  (-lookup [this v] (-lookup this v nil))
  (-lookup [_ v not-found]
    (if (identical? (-lookup t-backing-map v ::not-found) ::not-found)
      not-found
      v))

  ITransientCollection
  (-conj! [this v]
    (set! t-backing-map (assoc! t-backing-map v true))
    this)
  (-persistent! [_]
    (let [pm (persistent! t-backing-map)]
      (SabpSet. pm nil nil)))

  ITransientSet
  (-disjoin! [this v]
    (set! t-backing-map (dissoc! t-backing-map v))
    this))

;; ============================================================================
;; Constructor
;; ============================================================================

(defn sabp-set
  "Create a new SabpSet."
  [s-atom-env & vals]
  (let [m (sm/sabp-map s-atom-env)]
    (if (seq vals)
      (let [t (transient (SabpSet. m nil nil))]
        (loop [remaining vals ts t]
          (if (seq remaining)
            (recur (next remaining) (conj! ts (first remaining)))
            (persistent! ts))))
      (SabpSet. m nil nil))))

;; ============================================================================
;; SAB→AB conversion
;; ============================================================================

(defn- sabp-set->clj-set [^SabpSet s]
  (into #{} (seq s)))

;; sab->ab registration removed (Fressian Phase 5)

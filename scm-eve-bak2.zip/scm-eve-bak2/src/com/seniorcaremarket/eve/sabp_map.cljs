(ns com.seniorcaremarket.eve.sabp-map
  (:refer-clojure :exclude [atom])
  (:require
   [com.seniorcaremarket.eve.atom :as a]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]))

;; Forward declarations
(declare ->SabpMap ->TransientSabpMap SabpMap TransientSabpMap)
(declare hamt-assoc hamt-dissoc hamt-lookup hamt-seq hamt-count-nodes)
(declare hamt-assoc! hamt-dissoc!)

;; ============================================================================
;; Allocation helper
;; ============================================================================

(defn- alloc-for-node
  "Allocate size bytes. Returns {:offset n :descriptor-idx m}."
  [s-atom-env size]
  (let [r (a/alloc s-atom-env size)]
    (if (:error r)
      (throw (js/Error. (str "SabpMap alloc-for-node failed: " (:error r))))
      {:offset (:offset r) :descriptor-idx (:descriptor-idx r)})))

;; ============================================================================
;; Element serialization/deserialization
;; Delegates to serialize.cljs fast-path (Phase 4: Fressian removal)
;; ============================================================================

(defn- serialize-element [elem]
  (ser/serialize-key elem))

(defn- deserialize-element [s-atom-env ^js bytes]
  (ser/deserialize-element s-atom-env bytes))

;; ============================================================================
;; Low-level HAMT node read/write on SAB DataView
;; ============================================================================

(defn- popcount [^number x]
  ;; Brian Kernighan's bit counting
  (let [x (bit-and x 0xFFFFFFFF)]
    (loop [v x c 0]
      (if (zero? v)
        c
        (recur (bit-and v (dec v)) (inc c))))))

(defn- mask [^number hash ^number shift]
  (bit-and (unsigned-bit-shift-right hash shift) 0x1F))

(defn- bitpos [^number hash ^number shift]
  (bit-shift-left 1 (mask hash shift)))

;; --- BitmapIndexedNode layout ---
;; [type:u8][pad:u8][data_bitmap:u32][node_bitmap:u32]  = 10 bytes header
;; Then: child-offsets (4 bytes each, popcount(node_bitmap) entries)
;; Then: KV entries for data_bitmap positions
;; Each KV: [key_len:u32][key_bytes...][val_len:u32][val_bytes...]

(defn- read-node-type [^js dv ^number offset]
  (.getUint8 dv offset))

(defn- read-bitmap-data [^js dv ^number offset]
  (.getUint32 dv (+ offset 2) true))

(defn- read-bitmap-nodes [^js dv ^number offset]
  (.getUint32 dv (+ offset 6) true))

(defn- read-child-offset [^js dv ^number base ^number child-idx]
  ;; Children start at base + 10
  (.getInt32 dv (+ base 10 (* child-idx 4)) true))

(defn- read-collision-count [^js dv ^number offset]
  (.getUint8 dv (+ offset 1)))

(defn- read-collision-hash [^js dv ^number offset]
  (.getInt32 dv (+ offset 4) true))

(defn- copy-from-sab
  "Copy bytes from SharedArrayBuffer to a regular ArrayBuffer-backed Uint8Array."
  [^js sab ^number offset ^number len]
  (let [src (js/Uint8Array. sab offset len)
        dst-buf (js/ArrayBuffer. len)
        dst (js/Uint8Array. dst-buf)]
    (.set dst src 0)
    dst))

(defn- read-kv-at
  "Read a KV pair from the given byte offset. Returns [key val next-offset]."
  [s-atom-env ^js data-view ^number kv-offset]
  (let [sab (:sab s-atom-env)
        key-len (.getUint32 data-view kv-offset true)
        key-start (+ kv-offset 4)
        key-bytes (copy-from-sab sab key-start key-len)
        key-val (deserialize-element s-atom-env key-bytes)
        val-offset (+ key-start key-len)
        val-len (.getUint32 data-view val-offset true)
        val-start (+ val-offset 4)
        val-bytes (copy-from-sab sab val-start val-len)
        val-val (deserialize-element s-atom-env val-bytes)
        next-off (+ val-start val-len)]
    [key-val val-val next-off]))

(defn- skip-kv-at
  "Skip a KV pair, returning the offset after it."
  [^js dv ^number kv-offset]
  (let [key-len (.getUint32 dv kv-offset true)
        val-offset (+ kv-offset 4 key-len)
        val-len (.getUint32 dv val-offset true)]
    (+ val-offset 4 val-len)))

(defn- kv-data-start
  "Offset where KV data starts within a BitmapIndexedNode."
  [^number base ^number node-bitmap]
  (+ base d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 (popcount node-bitmap))))

;; ============================================================================
;; Columnar node helpers (type tag 6 — d/HAMT_BITMAP_NODE_COLUMNAR_TYPE)
;;
;; Layout:
;;   [type:u8][pad:u8][data_bitmap:u32][node_bitmap:u32]  = 10 bytes header
;;   [child_offsets: 4*N]  where N = popcount(node_bitmap)
;;   KEY REGION: [key_len:u32][key_bytes]... repeated for each data entry
;;   [val_region_offset:u32]  absolute SAB offset to separate value region
;;
;; Value Region (separate allocation):
;;   [val_len:u32][val_bytes]... same order as key region
;; ============================================================================

(defn- columnar-key-region-start
  "Offset where the key region starts in a columnar node."
  [^number base ^number node-bitmap]
  (+ base d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 (popcount node-bitmap))))

(defn- read-columnar-key-at
  "Read just the key at a given offset in the key region.
   Returns [key-val next-key-offset]."
  [s-atom-env ^js dv ^number key-offset]
  (let [sab (:sab s-atom-env)
        key-len (.getUint32 dv key-offset true)
        key-start (+ key-offset 4)
        key-bytes (copy-from-sab sab key-start key-len)
        key-val (deserialize-element s-atom-env key-bytes)]
    [key-val (+ key-start key-len)]))

(defn- skip-key-at
  "Skip a key entry, returning the offset after it."
  [^js dv ^number key-offset]
  (let [key-len (.getUint32 dv key-offset true)]
    (+ key-offset 4 key-len)))

(defn- read-val-at
  "Read a value from the value region at the given offset.
   Returns [val-val next-val-offset]."
  [s-atom-env ^js dv ^number val-offset]
  (let [sab (:sab s-atom-env)
        val-len (.getUint32 dv val-offset true)
        val-start (+ val-offset 4)
        val-bytes (copy-from-sab sab val-start val-len)
        val-val (deserialize-element s-atom-env val-bytes)]
    [val-val (+ val-start val-len)]))

(defn- skip-val-at
  "Skip a value entry, returning the offset after it."
  [^js dv ^number val-offset]
  (let [val-len (.getUint32 dv val-offset true)]
    (+ val-offset 4 val-len)))

(defn- columnar-val-region-offset-pos
  "Position of the u32 storing the value region offset.
   It comes right after all keys in the key region."
  [^js dv ^number base ^number data-bm ^number node-bm]
  (let [data-count (popcount data-bm)
        key-start (columnar-key-region-start base node-bm)]
    (loop [i 0 pos key-start]
      (if (>= i data-count)
        pos
        (recur (inc i) (skip-key-at dv pos))))))

(defn- read-columnar-val-region-offset
  "Read the absolute SAB offset of the value region from a columnar node."
  [^js dv ^number base ^number data-bm ^number node-bm]
  (let [vro-pos (columnar-val-region-offset-pos dv base data-bm node-bm)]
    (.getUint32 dv vro-pos true)))

(defn- write-columnar-bitmap-node!
  "Write a columnar bitmap node. Keys and values stored in separate regions.
   key-entries: seq of {:kb key-bytes}
   val-entries: seq of {:vb val-bytes}  (same order as key-entries)
   child-offsets: seq of child offsets
   Returns {:node-offset ... :val-region-offset ...}"
  [s-atom-env ^number data-bm ^number node-bm child-offsets key-entries val-entries]
  (let [child-count (count child-offsets)
        ;; Calculate key region size
        key-region-size (reduce (fn [acc {:keys [kb]}] (+ acc 4 (.-length kb))) 0 key-entries)
        ;; Node size = header + children + key region + val_region_offset pointer (4 bytes)
        node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE
                     (* 4 child-count)
                     key-region-size
                     4) ;; val_region_offset u32
        {:keys [offset]} (alloc-for-node s-atom-env node-size)
        dv (js/DataView. (:sab s-atom-env))
        sab (:sab s-atom-env)]
    ;; Write header with columnar type tag
    (.setUint8 dv offset d/HAMT_BITMAP_NODE_COLUMNAR_TYPE)
    (.setUint8 dv (+ offset 1) 0) ;; pad
    (.setUint32 dv (+ offset 2) data-bm true)
    (.setUint32 dv (+ offset 6) node-bm true)
    ;; Write child offsets
    (dotimes [i child-count]
      (.setInt32 dv (+ offset 10 (* i 4)) (nth child-offsets i) true))
    ;; Write key region
    (let [key-start (+ offset d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count))
          key-end (loop [entries (seq key-entries) pos key-start]
                    (if-not entries
                      pos
                      (let [{:keys [kb]} (first entries)
                            klen (.-length kb)]
                        (.setUint32 dv pos klen true)
                        (when (pos? klen)
                          (.set (js/Uint8Array. sab) kb (+ pos 4)))
                        (recur (next entries) (+ pos 4 klen)))))]
      ;; Calculate value region size and allocate separately
      (let [val-region-size (reduce (fn [acc {:keys [vb]}] (+ acc 4 (.-length vb))) 0 val-entries)
            val-region-off (if (zero? val-region-size)
                             0
                             (:offset (alloc-for-node s-atom-env val-region-size)))]
        ;; Write val_region_offset pointer at end of key region
        (.setUint32 dv key-end val-region-off true)
        ;; Write value region
        (when (pos? val-region-size)
          (loop [entries (seq val-entries) pos val-region-off]
            (when entries
              (let [{:keys [vb]} (first entries)
                    vlen (.-length vb)]
                (.setUint32 dv pos vlen true)
                (when (pos? vlen)
                  (.set (js/Uint8Array. sab) vb (+ pos 4)))
                (recur (next entries) (+ pos 4 vlen))))))
        {:node-offset offset :val-region-offset val-region-off}))))

;; ============================================================================
;; HAMT lookup
;; ============================================================================

(defn- hamt-find
  "Find value for key in HAMT rooted at offset. Returns [found? value]."
  [s-atom-env ^js dv ^number offset key ^number key-hash ^number shift]
  (if (== offset d/ROOT_POINTER_NIL_SENTINEL)
    [false nil]
    (let [node-type (read-node-type dv offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv offset)
              node-bm (read-bitmap-nodes dv offset)
              bit (bitpos key-hash shift)]
          (cond
            ;; Key is in a child node
            (not (zero? (bit-and node-bm bit)))
            (let [child-idx (popcount (bit-and node-bm (dec bit)))
                  child-off (read-child-offset dv offset child-idx)]
              (hamt-find s-atom-env dv child-off key key-hash (+ shift 5)))

            ;; Key is inline data
            (not (zero? (bit-and data-bm bit)))
            (let [data-idx (popcount (bit-and data-bm (dec bit)))
                  kv-start (kv-data-start offset node-bm)]
              ;; Skip data-idx KV pairs
              (loop [i 0 pos kv-start]
                (if (== i data-idx)
                  (let [[k v _] (read-kv-at s-atom-env dv pos)]
                    (if (= k key)
                      [true v]
                      [false nil]))
                  (recur (inc i) (skip-kv-at dv pos)))))

            :else [false nil]))

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        (let [cnt (read-collision-count dv offset)]
          (loop [i 0 pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
            (if (>= i cnt)
              [false nil]
              (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                (if (= k key)
                  [true v]
                  (recur (inc i) next-pos))))))

        :else
        (throw (js/Error. (str "Unknown HAMT node type: " node-type " at offset " offset)))))))

;; ============================================================================
;; HAMT seq (collect all KV pairs)
;; ============================================================================

(defn- hamt-seq-acc
  "Accumulate all [k v] pairs from HAMT into acc."
  [s-atom-env ^js dv ^number offset acc]
  (if (== offset d/ROOT_POINTER_NIL_SENTINEL)
    acc
    (let [node-type (read-node-type dv offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv offset)
              node-bm (read-bitmap-nodes dv offset)
              ;; First collect inline KV pairs
              data-count (popcount data-bm)
              kv-start (kv-data-start offset node-bm)
              acc-with-data (loop [i 0 pos kv-start a acc]
                              (if (>= i data-count)
                                a
                                (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                                  (recur (inc i) next-pos (conj! a (MapEntry. k v nil))))))
              ;; Then recurse into child nodes
              child-count (popcount node-bm)]
          (loop [i 0 a acc-with-data]
            (if (>= i child-count)
              a
              (let [child-off (read-child-offset dv offset i)]
                (recur (inc i) (hamt-seq-acc s-atom-env dv child-off a))))))

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        (let [cnt (read-collision-count dv offset)]
          (loop [i 0 pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE) a acc]
            (if (>= i cnt)
              a
              (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                (recur (inc i) next-pos (conj! a (MapEntry. k v nil)))))))

        :else acc))))

;; ============================================================================
;; HAMT streaming reduce (direct tree walk, no materialization)
;; ============================================================================

(defn- hamt-kv-reduce
  "Walk HAMT tree directly, calling (f acc k v) at each leaf entry.
   Supports reduced? for early termination. Returns final accumulator
   (may be a Reduced wrapper - caller must unwrap)."
  [s-atom-env ^js dv ^number offset f init]
  (if (== offset d/ROOT_POINTER_NIL_SENTINEL)
    init
    (let [node-type (read-node-type dv offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv offset)
              node-bm (read-bitmap-nodes dv offset)
              data-count (popcount data-bm)
              kv-start (kv-data-start offset node-bm)
              ;; First reduce over inline KV entries
              acc-after-data
              (loop [i 0 pos kv-start acc init]
                (if (or (>= i data-count) (reduced? acc))
                  acc
                  (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                    (recur (inc i) next-pos (f acc k v)))))
              ;; Then reduce over child nodes if not already reduced
              child-count (popcount node-bm)]
          (if (reduced? acc-after-data)
            acc-after-data
            (loop [i 0 acc acc-after-data]
              (if (or (>= i child-count) (reduced? acc))
                acc
                (let [child-off (read-child-offset dv offset i)]
                  (recur (inc i) (hamt-kv-reduce s-atom-env dv child-off f acc)))))))

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        (let [cnt (read-collision-count dv offset)]
          (loop [i 0 pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE) acc init]
            (if (or (>= i cnt) (reduced? acc))
              acc
              (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                (recur (inc i) next-pos (f acc k v))))))

        :else init))))

(defn- hamt-seq-lazy
  "Produce a lazy sequence of MapEntry from HAMT tree.
   Only materializes entries within each node; child traversal is lazy."
  [s-atom-env ^js dv ^number offset]
  (when-not (== offset d/ROOT_POINTER_NIL_SENTINEL)
    (let [node-type (read-node-type dv offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv offset)
              node-bm (read-bitmap-nodes dv offset)
              data-count (popcount data-bm)
              child-count (popcount node-bm)
              kv-start (kv-data-start offset node-bm)
              ;; Materialize inline entries for this node (small, bounded by 16)
              inline-entries (loop [i 0 pos kv-start acc []]
                               (if (>= i data-count)
                                 acc
                                 (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                                   (recur (inc i) next-pos (conj acc (MapEntry. k v nil))))))
              ;; Lazily traverse children
              child-seqs (fn step [^number ci]
                           (lazy-seq
                             (when (< ci child-count)
                               (let [child-off (read-child-offset dv offset ci)]
                                 (concat (hamt-seq-lazy s-atom-env dv child-off)
                                         (step (inc ci)))))))]
          (concat inline-entries (child-seqs 0)))

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        (let [cnt (read-collision-count dv offset)]
          (loop [i 0 pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE) acc []]
            (if (>= i cnt)
              (seq acc)
              (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                (recur (inc i) next-pos (conj acc (MapEntry. k v nil)))))))

        :else nil))))

;; ============================================================================
;; HAMT write helpers (persistent path-copying)
;; ============================================================================

(defn- write-kv!
  "Write a KV pair at offset. Returns offset after written data."
  [s-atom-env ^js dv ^number offset ^js key-bytes ^js val-bytes]
  (let [sab (:sab s-atom-env)]
    (.setUint32 dv offset (.-length key-bytes) true)
    (.set (js/Uint8Array. sab) key-bytes (+ offset 4))
    (let [val-off (+ offset 4 (.-length key-bytes))]
      (.setUint32 dv val-off (.-length val-bytes) true)
      (.set (js/Uint8Array. sab) val-bytes (+ val-off 4))
      (+ val-off 4 (.-length val-bytes)))))

(defn- calc-kv-size [^js key-bytes ^js val-bytes]
  (+ 4 (.-length key-bytes) 4 (.-length val-bytes)))

(defn- calc-node-kv-total-size
  "Calculate total size of all KV pairs in an existing bitmap node's data section."
  [^js dv ^number offset ^number data-bm ^number node-bm]
  (let [data-count (popcount data-bm)
        kv-start (kv-data-start offset node-bm)]
    (loop [i 0 pos kv-start]
      (if (>= i data-count)
        (- pos kv-start)
        (recur (inc i) (skip-kv-at dv pos))))))

(defn- copy-kv-data-except!
  "Copy all KV entries from src node to dst offset, skipping the entry at skip-data-idx.
   Returns the offset after the last written KV."
  [s-atom-env ^js dv ^number src-node-offset ^number src-data-bm ^number src-node-bm
   ^number dst-kv-offset ^number skip-data-idx]
  (let [data-count (popcount src-data-bm)
        src-kv-start (kv-data-start src-node-offset src-node-bm)
        sab (:sab s-atom-env)]
    (loop [i 0 src-pos src-kv-start dst-pos dst-kv-offset]
      (if (>= i data-count)
        dst-pos
        (let [next-src (skip-kv-at dv src-pos)
              kv-len (- next-src src-pos)]
          (if (== i skip-data-idx)
            (recur (inc i) next-src dst-pos)
            (do
              ;; Copy the raw KV bytes
              (let [src-bytes (js/Uint8Array. sab src-pos kv-len)]
                (.set (js/Uint8Array. sab) src-bytes dst-pos))
              (recur (inc i) next-src (+ dst-pos kv-len)))))))))

(defn- copy-kv-data-all!
  "Copy all KV entries from src node to dst offset. Returns offset after last KV."
  [s-atom-env ^js dv ^number src-node-offset ^number src-data-bm ^number src-node-bm ^number dst-kv-offset]
  (let [data-count (popcount src-data-bm)
        src-kv-start (kv-data-start src-node-offset src-node-bm)
        sab (:sab s-atom-env)]
    (loop [i 0 src-pos src-kv-start dst-pos dst-kv-offset]
      (if (>= i data-count)
        dst-pos
        (let [next-src (skip-kv-at dv src-pos)
              kv-len (- next-src src-pos)
              src-bytes (js/Uint8Array. sab src-pos kv-len)]
          (.set (js/Uint8Array. sab) src-bytes dst-pos)
          (recur (inc i) next-src (+ dst-pos kv-len)))))))

(defn- collect-raw-kv-entries
  "Collect [{:kb key-bytes :vb val-bytes} ...] from a bitmap node's data section."
  [s-atom-env ^js dv ^number offset ^number data-bm ^number node-bm]
  (let [data-count (popcount data-bm)
        sab (:sab s-atom-env)
        kv-start (kv-data-start offset node-bm)]
    (loop [i 0 pos kv-start acc []]
      (if (>= i data-count)
        acc
        (let [klen (.getUint32 dv pos true)
              kb (copy-from-sab sab (+ pos 4) klen)
              val-off (+ pos 4 klen)
              vlen (.getUint32 dv val-off true)
              vb (copy-from-sab sab (+ val-off 4) vlen)]
          (recur (inc i) (+ val-off 4 vlen)
                 (conj acc {:kb kb :vb vb})))))))

(defn- rebuild-bitmap-node
  "Rebuild a bitmap node with given entries and children.
   entries: [{:kb :vb} ...]  child-offsets: [offset ...]
   Returns new node offset."
  [s-atom-env ^number data-bm ^number node-bm entries child-offsets]
  (let [child-count (count child-offsets)
        kv-size (reduce (fn [acc {:keys [kb vb]}] (+ acc 4 (.-length kb) 4 (.-length vb))) 0 entries)
        node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count) kv-size)
        {:keys [offset]} (alloc-for-node s-atom-env node-size)
        dv (js/DataView. (:sab s-atom-env))
        sab (:sab s-atom-env)]
    (.setUint8 dv offset d/HAMT_BITMAP_NODE_TYPE)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint32 dv (+ offset 2) data-bm true)
    (.setUint32 dv (+ offset 6) node-bm true)
    ;; Write child offsets
    (dotimes [i child-count]
      (.setInt32 dv (+ offset 10 (* i 4)) (nth child-offsets i) true))
    ;; Write KV pairs
    (let [kv-start (+ offset d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count))]
      (loop [es (seq entries) pos kv-start]
        (when es
          (let [{:keys [kb vb]} (first es)
                next-pos (write-kv! s-atom-env dv pos kb vb)]
            (recur (next es) next-pos)))))
    offset))

(defn- write-bitmap-node-header! [^js dv ^number offset ^number data-bm ^number node-bm]
  (.setUint8 dv offset d/HAMT_BITMAP_NODE_TYPE)
  (.setUint8 dv (+ offset 1) 0) ;; pad
  (.setUint32 dv (+ offset 2) data-bm true)
  (.setUint32 dv (+ offset 6) node-bm true))

(defn- write-collision-node-header! [^js dv ^number offset ^number cnt ^number hash-val]
  (.setUint8 dv offset d/HAMT_COLLISION_NODE_TYPE)
  (.setUint8 dv (+ offset 1) cnt)
  (.setUint16 dv (+ offset 2) 0 true) ;; pad
  (.setInt32 dv (+ offset 4) hash-val true))

;; ============================================================================
;; HAMT assoc (persistent, path-copying)
;; ============================================================================

(defn- create-leaf-node
  "Create a single-entry BitmapIndexedNode. Returns new node offset."
  [s-atom-env ^number kh ^number shift ^js kb ^js vb]
  (let [bit (bitpos kh shift)
        node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (calc-kv-size kb vb))
        {:keys [offset]} (alloc-for-node s-atom-env node-size)
        dv (js/DataView. (:sab s-atom-env))]
    (write-bitmap-node-header! dv offset bit 0)
    (write-kv! s-atom-env dv (+ offset d/HAMT_BITMAP_NODE_HEADER_SIZE) kb vb)
    offset))

(defn- create-collision-node
  "Create a HashCollisionNode with two KV pairs."
  [s-atom-env ^number hash-val ^js k1b ^js v1b ^js k2b ^js v2b]
  (let [node-size (+ d/HAMT_COLLISION_NODE_HEADER_SIZE
                     (calc-kv-size k1b v1b)
                     (calc-kv-size k2b v2b))
        {:keys [offset]} (alloc-for-node s-atom-env node-size)
        dv (js/DataView. (:sab s-atom-env))]
    (write-collision-node-header! dv offset 2 hash-val)
    (let [after-first (write-kv! s-atom-env dv (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE) k1b v1b)]
      (write-kv! s-atom-env dv after-first k2b v2b))
    offset))

(defn- hamt-assoc-impl
  "Assoc key/value into HAMT. Returns [new-root-offset added?]."
  [s-atom-env ^js dv ^number offset key ^number key-hash ^js key-bytes ^js val-bytes ^number shift]
  (if (== offset d/ROOT_POINTER_NIL_SENTINEL)
    ;; Empty tree - create a single-entry node
    [(create-leaf-node s-atom-env key-hash shift key-bytes val-bytes) true]

    (let [node-type (read-node-type dv offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv offset)
              node-bm (read-bitmap-nodes dv offset)
              bit (bitpos key-hash shift)]
          (cond
            ;; Descend into child node
            (not (zero? (bit-and node-bm bit)))
            (let [child-idx (popcount (bit-and node-bm (dec bit)))
                  child-off (read-child-offset dv offset child-idx)
                  [new-child-off added?] (hamt-assoc-impl s-atom-env dv child-off key key-hash key-bytes val-bytes (+ shift 5))
                  ;; Copy this node with updated child pointer
                  child-count (popcount node-bm)
                  existing-kv-size (calc-node-kv-total-size dv offset data-bm node-bm)
                  new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count) existing-kv-size)
                  new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
              (write-bitmap-node-header! dv new-offset data-bm node-bm)
              ;; Copy child pointers, updating the changed one
              (dotimes [i child-count]
                (let [co (if (== i child-idx) new-child-off (read-child-offset dv offset i))]
                  (.setInt32 dv (+ new-offset 10 (* i 4)) co true)))
              ;; Copy KV data
              (copy-kv-data-all! s-atom-env dv offset data-bm node-bm
                                 (kv-data-start new-offset node-bm))
              [new-offset added?])

            ;; Key position is in data
            (not (zero? (bit-and data-bm bit)))
            (let [data-idx (popcount (bit-and data-bm (dec bit)))
                  kv-start (kv-data-start offset node-bm)]
              ;; Find the existing key at data-idx
              (let [pos (loop [i 0 p kv-start]
                          (if (== i data-idx) p (recur (inc i) (skip-kv-at dv p))))
                    [existing-key _ _] (read-kv-at s-atom-env dv pos)]
                (if (= existing-key key)
                  ;; Replace value - copy node with new value for this key
                  (let [existing-kv-size (calc-node-kv-total-size dv offset data-bm node-bm)
                        old-kv-end (skip-kv-at dv pos)
                        old-kv-len (- old-kv-end pos)
                        new-kv-len (calc-kv-size key-bytes val-bytes)
                        size-diff (- new-kv-len old-kv-len)
                        child-count (popcount node-bm)
                        new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count) existing-kv-size size-diff)
                        new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                    (write-bitmap-node-header! dv new-offset data-bm node-bm)
                    ;; Copy child pointers
                    (dotimes [i child-count]
                      (.setInt32 dv (+ new-offset 10 (* i 4)) (read-child-offset dv offset i) true))
                    ;; Copy KV data, replacing the one at data-idx
                    (let [data-count (popcount data-bm)
                          src-kv-start (kv-data-start offset node-bm)
                          dst-kv-start (kv-data-start new-offset node-bm)
                          sab (:sab s-atom-env)]
                      (loop [i 0 src-pos src-kv-start dst-pos dst-kv-start]
                        (when (< i data-count)
                          (if (== i data-idx)
                            (let [next-dst (write-kv! s-atom-env dv dst-pos key-bytes val-bytes)]
                              (recur (inc i) (skip-kv-at dv src-pos) next-dst))
                            (let [next-src (skip-kv-at dv src-pos)
                                  kv-len (- next-src src-pos)
                                  src-b (js/Uint8Array. sab src-pos kv-len)]
                              (.set (js/Uint8Array. sab) src-b dst-pos)
                              (recur (inc i) next-src (+ dst-pos kv-len)))))))
                    [new-offset false])

                  ;; Different key at same hash prefix - need to push down
                  (let [existing-key-hash (hash existing-key)]
                    (if (>= (+ shift 5) 32)
                      ;; Hash exhausted - create collision node
                      (let [;; Read existing key/value bytes
                            ek-bytes (serialize-element existing-key)
                            old-kv-start pos
                            old-val-off (+ old-kv-start 4 (.getUint32 dv old-kv-start true))
                            old-val-len (.getUint32 dv old-val-off true)
                            ev-bytes (copy-from-sab (:sab s-atom-env) (+ old-val-off 4) old-val-len)
                            collision-off (create-collision-node s-atom-env key-hash ek-bytes ev-bytes key-bytes val-bytes)
                            ;; Now rebuild this node: remove this data entry, add child
                            new-data-bm (bit-and data-bm (bit-not bit))
                            new-node-bm (bit-or node-bm bit)
                            child-count-old (popcount node-bm)
                            child-idx-new (popcount (bit-and new-node-bm (dec bit)))
                            remaining-kv-size (- (calc-node-kv-total-size dv offset data-bm node-bm)
                                                 (- (skip-kv-at dv pos) pos))
                            new-child-count (inc child-count-old)
                            new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 new-child-count) remaining-kv-size)
                            new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                        (write-bitmap-node-header! dv new-offset new-data-bm new-node-bm)
                        ;; Copy old children, insert new collision node at right position
                        (loop [old-i 0 new-i 0]
                          (when (< new-i new-child-count)
                            (if (== new-i child-idx-new)
                              (do (.setInt32 dv (+ new-offset 10 (* new-i 4)) collision-off true)
                                  (recur old-i (inc new-i)))
                              (do (.setInt32 dv (+ new-offset 10 (* new-i 4)) (read-child-offset dv offset old-i) true)
                                  (recur (inc old-i) (inc new-i))))))
                        ;; Copy KV data, skipping removed entry
                        (copy-kv-data-except! s-atom-env dv offset data-bm node-bm
                                              (kv-data-start new-offset new-node-bm) data-idx)
                        [new-offset true])

                      ;; Push both down one more level
                      (let [ek-bytes (serialize-element existing-key)
                            old-kv-start pos
                            old-val-off (+ old-kv-start 4 (.getUint32 dv old-kv-start true))
                            old-val-len (.getUint32 dv old-val-off true)
                            ev-bytes (copy-from-sab (:sab s-atom-env) (+ old-val-off 4) old-val-len)
                            ;; Create a sub-node containing the existing entry
                            sub-node-off (create-leaf-node s-atom-env existing-key-hash (+ shift 5) ek-bytes ev-bytes)
                            ;; Assoc the new key into that sub-node
                            [final-sub-off _] (hamt-assoc-impl s-atom-env dv sub-node-off key key-hash key-bytes val-bytes (+ shift 5))
                            ;; Now rebuild this node: remove data entry, add child pointer
                            new-data-bm (bit-and data-bm (bit-not bit))
                            new-node-bm (bit-or node-bm bit)
                            child-count-old (popcount node-bm)
                            child-idx-new (popcount (bit-and new-node-bm (dec bit)))
                            remaining-kv-size (- (calc-node-kv-total-size dv offset data-bm node-bm)
                                                 (- (skip-kv-at dv pos) pos))
                            new-child-count (inc child-count-old)
                            new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 new-child-count) remaining-kv-size)
                            new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                        (write-bitmap-node-header! dv new-offset new-data-bm new-node-bm)
                        (loop [old-i 0 new-i 0]
                          (when (< new-i new-child-count)
                            (if (== new-i child-idx-new)
                              (do (.setInt32 dv (+ new-offset 10 (* new-i 4)) final-sub-off true)
                                  (recur old-i (inc new-i)))
                              (do (.setInt32 dv (+ new-offset 10 (* new-i 4)) (read-child-offset dv offset old-i) true)
                                  (recur (inc old-i) (inc new-i))))))
                        (copy-kv-data-except! s-atom-env dv offset data-bm node-bm
                                              (kv-data-start new-offset new-node-bm) data-idx)
                        [new-offset true]))))))

            ;; Empty slot - add inline KV
            :else
            (let [new-data-bm (bit-or data-bm bit)
                  child-count (popcount node-bm)
                  existing-kv-size (calc-node-kv-total-size dv offset data-bm node-bm)
                  new-kv-size (calc-kv-size key-bytes val-bytes)
                  new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count) existing-kv-size new-kv-size)
                  new-offset (:offset (alloc-for-node s-atom-env new-node-size))
                  new-data-idx (popcount (bit-and new-data-bm (dec bit)))]
              (write-bitmap-node-header! dv new-offset new-data-bm node-bm)
              ;; Copy child pointers
              (dotimes [i child-count]
                (.setInt32 dv (+ new-offset 10 (* i 4)) (read-child-offset dv offset i) true))
              ;; Copy KV data, inserting new entry at correct position
              (let [data-count (popcount data-bm)
                    src-kv-start (kv-data-start offset node-bm)
                    dst-kv-start (kv-data-start new-offset node-bm)
                    sab (:sab s-atom-env)]
                (loop [src-i 0 dst-i 0 src-pos src-kv-start dst-pos dst-kv-start]
                  (cond
                    ;; Insert new KV at this position
                    (and (== dst-i new-data-idx) (< dst-i (popcount new-data-bm)))
                    (let [next-dst (write-kv! s-atom-env dv dst-pos key-bytes val-bytes)]
                      (recur src-i (inc dst-i) src-pos next-dst))
                    ;; Copy remaining source KVs
                    (< src-i data-count)
                    (let [next-src (skip-kv-at dv src-pos)
                          kv-len (- next-src src-pos)
                          src-b (js/Uint8Array. sab src-pos kv-len)]
                      (.set (js/Uint8Array. sab) src-b dst-pos)
                      (recur (inc src-i) (inc dst-i) next-src (+ dst-pos kv-len)))
                    ;; We might need to append the new KV at the end
                    (and (== dst-i new-data-idx) (== src-i data-count))
                    (write-kv! s-atom-env dv dst-pos key-bytes val-bytes)
                    :else nil)))
              [new-offset true])))

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        (let [cnt (read-collision-count dv offset)
              coll-hash (read-collision-hash dv offset)]
          (if (== key-hash coll-hash)
            ;; Same hash - check if key exists in collision
            (let [result (loop [i 0 pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE) found-idx -1]
                           (if (>= i cnt)
                             {:found-idx found-idx}
                             (let [[k _ next-pos] (read-kv-at s-atom-env dv pos)]
                               (if (= k key)
                                 {:found-idx i :found-pos pos}
                                 (recur (inc i) next-pos found-idx)))))]
              (if (>= (:found-idx result) 0)
                ;; Replace existing entry
                (let [old-total-kv-size (loop [i 0 p (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                                          (if (>= i cnt) (- p (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE))
                                              (recur (inc i) (skip-kv-at dv p))))
                      old-entry-start (:found-pos result)
                      old-entry-end (skip-kv-at dv old-entry-start)
                      old-entry-len (- old-entry-end old-entry-start)
                      new-entry-len (calc-kv-size key-bytes val-bytes)
                      new-total (+ d/HAMT_COLLISION_NODE_HEADER_SIZE (- old-total-kv-size old-entry-len) new-entry-len)
                      new-offset (:offset (alloc-for-node s-atom-env new-total))
                      sab (:sab s-atom-env)]
                  (write-collision-node-header! dv new-offset cnt coll-hash)
                  ;; Copy all entries, replacing the found one
                  (loop [i 0
                         src-pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)
                         dst-pos (+ new-offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                    (when (< i cnt)
                      (if (== i (:found-idx result))
                        (let [nd (write-kv! s-atom-env dv dst-pos key-bytes val-bytes)]
                          (recur (inc i) (skip-kv-at dv src-pos) nd))
                        (let [ns-pos (skip-kv-at dv src-pos)
                              kv-len (- ns-pos src-pos)
                              sb (js/Uint8Array. sab src-pos kv-len)]
                          (.set (js/Uint8Array. sab) sb dst-pos)
                          (recur (inc i) ns-pos (+ dst-pos kv-len))))))
                  [new-offset false])
                ;; Add new entry to collision
                (let [old-total-kv-size (loop [i 0 p (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                                          (if (>= i cnt) (- p (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE))
                                              (recur (inc i) (skip-kv-at dv p))))
                      new-entry-len (calc-kv-size key-bytes val-bytes)
                      new-total (+ d/HAMT_COLLISION_NODE_HEADER_SIZE old-total-kv-size new-entry-len)
                      new-offset (:offset (alloc-for-node s-atom-env new-total))
                      sab (:sab s-atom-env)]
                  (write-collision-node-header! dv new-offset (inc cnt) coll-hash)
                  ;; Copy existing entries
                  (let [src-start (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)
                        dst-start (+ new-offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                    (.set (js/Uint8Array. sab) (js/Uint8Array. sab src-start old-total-kv-size) dst-start)
                    (write-kv! s-atom-env dv (+ dst-start old-total-kv-size) key-bytes val-bytes))
                  [new-offset true])))
            ;; Different hash - need to create a bitmap node containing both
            ;; the collision node and the new entry
            (let [coll-bit (bitpos coll-hash shift)
                  new-bit (bitpos key-hash shift)]
              (if (== coll-bit new-bit)
                ;; Same bit position at this level - need to go deeper
                ;; Wrap collision in a bitmap node at next level
                (let [wrapper-bm-node-bm coll-bit
                      wrapper-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE 4) ;; header + 1 child pointer
                      wrapper-offset (:offset (alloc-for-node s-atom-env wrapper-size))]
                  (write-bitmap-node-header! dv wrapper-offset 0 wrapper-bm-node-bm)
                  (.setInt32 dv (+ wrapper-offset 10) offset true) ;; child = existing collision
                  ;; Now assoc the new key into wrapper
                  (hamt-assoc-impl s-atom-env dv wrapper-offset key key-hash key-bytes val-bytes shift))
                ;; Different bit positions - create node with data + child
                (let [new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE 4 (calc-kv-size key-bytes val-bytes))
                      new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                  (write-bitmap-node-header! dv new-offset new-bit coll-bit)
                  ;; Write child pointer (collision node)
                  (.setInt32 dv (+ new-offset 10) offset true)
                  ;; Write new KV
                  (write-kv! s-atom-env dv (+ new-offset 10 4) key-bytes val-bytes)
                  [new-offset true])))))

        :else
        (throw (js/Error. (str "Unknown node type in assoc: " node-type)))))))

;; ============================================================================
;; HAMT dissoc (persistent)
;; ============================================================================

(defn- hamt-dissoc-impl
  "Remove key from HAMT. Returns [new-root-offset removed?]."
  [s-atom-env ^js dv ^number offset key ^number key-hash ^number shift]
  (if (== offset d/ROOT_POINTER_NIL_SENTINEL)
    [d/ROOT_POINTER_NIL_SENTINEL false]
    (let [node-type (read-node-type dv offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv offset)
              node-bm (read-bitmap-nodes dv offset)
              bit (bitpos key-hash shift)]
          (cond
            ;; Key might be in a child node
            (not (zero? (bit-and node-bm bit)))
            (let [child-idx (popcount (bit-and node-bm (dec bit)))
                  child-off (read-child-offset dv offset child-idx)
                  [new-child-off removed?] (hamt-dissoc-impl s-atom-env dv child-off key key-hash (+ shift 5))]
              (if-not removed?
                [offset false]
                (if (== new-child-off d/ROOT_POINTER_NIL_SENTINEL)
                  ;; Child became empty, remove it
                  (let [new-node-bm (bit-and node-bm (bit-not bit))
                        new-child-count (popcount new-node-bm)
                        existing-kv-size (calc-node-kv-total-size dv offset data-bm node-bm)]
                    (if (and (zero? new-node-bm) (zero? data-bm))
                      [d/ROOT_POINTER_NIL_SENTINEL true]
                      (let [new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 new-child-count) existing-kv-size)
                            new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                        (write-bitmap-node-header! dv new-offset data-bm new-node-bm)
                        ;; Copy children except removed
                        (loop [old-i 0 new-i 0]
                          (when (< new-i new-child-count)
                            (if (== old-i child-idx)
                              (recur (inc old-i) new-i)
                              (do (.setInt32 dv (+ new-offset 10 (* new-i 4))
                                             (read-child-offset dv offset old-i) true)
                                  (recur (inc old-i) (inc new-i))))))
                        (copy-kv-data-all! s-atom-env dv offset data-bm node-bm
                                           (kv-data-start new-offset new-node-bm))
                        [new-offset true])))
                  ;; Child still exists, just update pointer
                  (let [child-count (popcount node-bm)
                        existing-kv-size (calc-node-kv-total-size dv offset data-bm node-bm)
                        new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count) existing-kv-size)
                        new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                    (write-bitmap-node-header! dv new-offset data-bm node-bm)
                    (dotimes [i child-count]
                      (let [co (if (== i child-idx) new-child-off (read-child-offset dv offset i))]
                        (.setInt32 dv (+ new-offset 10 (* i 4)) co true)))
                    (copy-kv-data-all! s-atom-env dv offset data-bm node-bm
                                       (kv-data-start new-offset node-bm))
                    [new-offset true]))))

            ;; Key in data
            (not (zero? (bit-and data-bm bit)))
            (let [data-idx (popcount (bit-and data-bm (dec bit)))
                  kv-start (kv-data-start offset node-bm)
                  pos (loop [i 0 p kv-start]
                        (if (== i data-idx) p (recur (inc i) (skip-kv-at dv p))))
                  [existing-key _ _] (read-kv-at s-atom-env dv pos)]
              (if-not (= existing-key key)
                [offset false]
                ;; Remove this KV entry
                (let [new-data-bm (bit-and data-bm (bit-not bit))
                      child-count (popcount node-bm)
                      remaining-kv-size (- (calc-node-kv-total-size dv offset data-bm node-bm)
                                           (- (skip-kv-at dv pos) pos))]
                  (if (and (zero? new-data-bm) (zero? node-bm))
                    [d/ROOT_POINTER_NIL_SENTINEL true]
                    (let [new-node-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (* 4 child-count) remaining-kv-size)
                          new-offset (:offset (alloc-for-node s-atom-env new-node-size))]
                      (write-bitmap-node-header! dv new-offset new-data-bm node-bm)
                      (dotimes [i child-count]
                        (.setInt32 dv (+ new-offset 10 (* i 4)) (read-child-offset dv offset i) true))
                      (copy-kv-data-except! s-atom-env dv offset data-bm node-bm
                                            (kv-data-start new-offset node-bm) data-idx)
                      [new-offset true])))))

            :else [offset false]))

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        (let [cnt (read-collision-count dv offset)
              coll-hash (read-collision-hash dv offset)]
          (if-not (== key-hash coll-hash)
            [offset false]
            (let [found (loop [i 0 pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                          (if (>= i cnt)
                            nil
                            (let [[k _ next-pos] (read-kv-at s-atom-env dv pos)]
                              (if (= k key)
                                {:idx i :pos pos}
                                (recur (inc i) next-pos)))))]
              (if-not found
                [offset false]
                (if (== cnt 2)
                  ;; Collision with 2 entries, removing one leaves a single entry
                  ;; Return nil sentinel to signal parent should inline the remaining entry
                  ;; Actually, create a single-entry bitmap node
                  (let [other-pos (if (== (:idx found) 0)
                                    (skip-kv-at dv (:pos found))
                                    (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE))
                        [other-key other-val _] (read-kv-at s-atom-env dv other-pos)
                        ok-bytes (serialize-element other-key)
                        ov-bytes (serialize-element other-val)
                        other-hash (hash other-key)
                        ;; Create a leaf node - parent will point to this
                        ;; Use shift=0 since this will be placed appropriately by the parent
                        leaf-size (+ d/HAMT_BITMAP_NODE_HEADER_SIZE (calc-kv-size ok-bytes ov-bytes))
                        leaf-offset (:offset (alloc-for-node s-atom-env leaf-size))
                        leaf-bit (bitpos other-hash shift)]
                    ;; NOTE: We use shift here but the parent doesn't know what shift
                    ;; to use. For simplicity, create a node with the data at bit position.
                    ;; The parent will just replace its child pointer.
                    (write-bitmap-node-header! dv leaf-offset leaf-bit 0)
                    (write-kv! s-atom-env dv (+ leaf-offset d/HAMT_BITMAP_NODE_HEADER_SIZE) ok-bytes ov-bytes)
                    [leaf-offset true])
                  ;; More than 2 entries, create new collision without removed entry
                  (let [old-total-kv (loop [i 0 p (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                                       (if (>= i cnt) (- p (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE))
                                           (recur (inc i) (skip-kv-at dv p))))
                        removed-len (- (skip-kv-at dv (:pos found)) (:pos found))
                        new-total (+ d/HAMT_COLLISION_NODE_HEADER_SIZE (- old-total-kv removed-len))
                        new-offset (:offset (alloc-for-node s-atom-env new-total))
                        sab (:sab s-atom-env)]
                    (write-collision-node-header! dv new-offset (dec cnt) coll-hash)
                    (loop [i 0
                           src-pos (+ offset d/HAMT_COLLISION_NODE_HEADER_SIZE)
                           dst-pos (+ new-offset d/HAMT_COLLISION_NODE_HEADER_SIZE)]
                      (when (< i cnt)
                        (let [ns-pos (skip-kv-at dv src-pos)
                              kv-len (- ns-pos src-pos)]
                          (if (== i (:idx found))
                            (recur (inc i) ns-pos dst-pos)
                            (do (.set (js/Uint8Array. sab) (js/Uint8Array. sab src-pos kv-len) dst-pos)
                                (recur (inc i) ns-pos (+ dst-pos kv-len)))))))
                    [new-offset true]))))))

        :else [offset false]))))

;; ============================================================================
;; SabpMap deftype
;; ============================================================================

(deftype SabpMap [s-atom-env ^number root-offset ^number cnt ^:mutable __hash meta-map]
  d/ISabpType
  (-sabp-type-key [_] "com.seniorcaremarket.eve.sabp-map/SabpMap")

  Object
  (toString [coll] (pr-str coll))
  (equiv [this other] (-equiv this other))

  ICloneable
  (-clone [_] (SabpMap. s-atom-env root-offset cnt __hash meta-map))

  IWithMeta
  (-with-meta [_ new-meta]
    (SabpMap. s-atom-env root-offset cnt __hash new-meta))

  IMeta
  (-meta [_] meta-map)

  ICounted
  (-count [_] cnt)

  IHash
  (-hash [coll]
    (when (nil? __hash)
      (set! __hash (hash-unordered-coll coll)))
    __hash)

  IEquiv
  (-equiv [this other]
    (cond
      (identical? this other) true
      (not (map? other)) false
      (not= cnt (count other)) false
      :else (every? (fn [[k v]]
                      (let [[found? ov] (hamt-find s-atom-env (js/DataView. (:sab s-atom-env)) root-offset k (hash k) 0)]
                        (and found? (= v ov))))
                    other)))

  ILookup
  (-lookup [this k] (-lookup this k nil))
  (-lookup [_ k not-found]
    (let [dv (js/DataView. (:sab s-atom-env))
          [found? v] (hamt-find s-atom-env dv root-offset k (hash k) 0)]
      (if found? v not-found)))

  IAssociative
  (-assoc [this k v]
    (let [dv (js/DataView. (:sab s-atom-env))
          kh (hash k)
          [found? existing-v] (hamt-find s-atom-env dv root-offset k kh 0)]
      ;; Skip all work when assoc'ing same value for existing key
      (if (and found? (= existing-v v))
        this
        (let [kb (serialize-element k)
              vb (serialize-element v)
              [new-root added?] (hamt-assoc-impl s-atom-env dv root-offset k kh kb vb 0)]
          (SabpMap. s-atom-env new-root (if added? (inc cnt) cnt) nil meta-map)))))
  (-contains-key? [_ k]
    (let [dv (js/DataView. (:sab s-atom-env))
          [found? _] (hamt-find s-atom-env dv root-offset k (hash k) 0)]
      found?))

  IMap
  (-dissoc [_ k]
    (let [dv (js/DataView. (:sab s-atom-env))
          [new-root removed?] (hamt-dissoc-impl s-atom-env dv root-offset k (hash k) 0)]
      (SabpMap. s-atom-env new-root (if removed? (dec cnt) cnt) nil meta-map)))

  ISeqable
  (-seq [_]
    (when (pos? cnt)
      (let [dv (js/DataView. (:sab s-atom-env))]
        (hamt-seq-lazy s-atom-env dv root-offset))))

  ICollection
  (-conj [this entry]
    (if (vector? entry)
      (-assoc this (nth entry 0) (nth entry 1))
      (if (instance? MapEntry entry)
        (-assoc this (key entry) (val entry))
        (reduce -conj this entry))))

  IEmptyableCollection
  (-empty [_]
    (SabpMap. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil meta-map))

  IFn
  (-invoke [this k] (-lookup this k))
  (-invoke [this k not-found] (-lookup this k not-found))

  IKVReduce
  (-kv-reduce [_ f init]
    (if (zero? cnt)
      init
      (let [dv (js/DataView. (:sab s-atom-env))
            result (hamt-kv-reduce s-atom-env dv root-offset f init)]
        (if (reduced? result) @result result))))

  IReduce
  (-reduce [this f]
    (let [dv (js/DataView. (:sab s-atom-env))
          sentinel (js/Object.)
          result (hamt-kv-reduce s-atom-env dv root-offset
                   (fn [acc k v]
                     (let [entry (MapEntry. k v nil)]
                       (if (identical? acc sentinel)
                         entry
                         (f acc entry))))
                   sentinel)]
      (let [r (if (reduced? result) @result result)]
        (if (identical? r sentinel)
          (f)
          r))))
  (-reduce [this f init]
    (let [dv (js/DataView. (:sab s-atom-env))
          result (hamt-kv-reduce s-atom-env dv root-offset
                   (fn [acc k v] (f acc (MapEntry. k v nil)))
                   init)]
      (if (reduced? result) @result result)))

  IEditableCollection
  (-as-transient [_]
    (if d/*use-flat-hashtable*
      ;; Flat hashtable mode: create HT and bulk-load existing entries
      (let [dv (js/DataView. (:sab s-atom-env))
            ht-off (fht-create! s-atom-env dv (max 16 (* cnt 2)))]
        ;; Bulk-load existing HAMT entries into flat table
        (when (pos? cnt)
          (hamt-kv-reduce s-atom-env dv root-offset
            (fn [_ k v]
              (let [kb (serialize-element k)
                    vb (serialize-element v)
                    kh (hash k)]
                (fht-assoc! s-atom-env dv ht-off kh kb vb))
              nil)
            nil)
          ;; Restore correct count (fht-assoc! incremented it)
          (fht-write-count! dv ht-off cnt))
        (TransientSabpMap. s-atom-env ht-off cnt (js/Object.) :flat))
      ;; Standard HAMT transient path
      (TransientSabpMap. s-atom-env root-offset cnt (js/Object.) :hamt)))

  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (let [entries (-seq coll)]
      (pr-sequential-writer writer
                            (fn [e w o]
                              (-write w "[")
                              (pr-writer (key e) w o)
                              (-write w " ")
                              (pr-writer (val e) w o)
                              (-write w "]"))
                            "{" ", " "}" opts entries))))

;; ============================================================================
;; Flat Hashtable for Transients (flagged via d/*use-flat-hashtable*)
;; Chaining with inline K/V in chain nodes. Used only during transient phase,
;; converted back to HAMT on persistent!.
;; ============================================================================

;; FlatHT header layout (16 bytes):
;;   0: u8  type tag (unused, reserved)
;;   1: u8  load_factor_pct (75)
;;   2-3: padding
;;   4: u32 count
;;   8: u32 capacity (bucket count, power-of-2)
;;  12: u32 bucket_table_offset (absolute SAB offset)

(def ^:private ^:const FHT_HEADER_SIZE 16)
(def ^:private ^:const FHT_OFFSET_COUNT 4)
(def ^:private ^:const FHT_OFFSET_CAPACITY 8)
(def ^:private ^:const FHT_OFFSET_BUCKETS 12)
(def ^:private ^:const FHT_LOAD_FACTOR_PCT 75)
(def ^:private ^:const FHT_EMPTY_BUCKET -1)

;; ChainNode layout (variable):
;;   0: i32 hash
;;   4: i32 next offset (-1 = end of chain)
;;   8: u32 key_len
;;  12: key_bytes[key_len]
;;  12+kl: u32 val_len
;;  16+kl: val_bytes[val_len]

(def ^:private ^:const FHT_CN_HASH 0)
(def ^:private ^:const FHT_CN_NEXT 4)
(def ^:private ^:const FHT_CN_KEY_LEN 8)
(def ^:private ^:const FHT_CN_KEY_START 12)

(defn- fht-next-pow2 [^number n]
  (loop [p 1]
    (if (>= p n) p (recur (bit-shift-left p 1)))))

(defn- fht-create!
  "Create a flat hashtable. Returns the header offset."
  [s-atom-env ^js dv ^number initial-capacity]
  (let [cap (fht-next-pow2 (max 16 initial-capacity))
        ;; Allocate header
        {:keys [offset]} (alloc-for-node s-atom-env FHT_HEADER_SIZE)
        header-off offset
        ;; Allocate bucket table
        bucket-size (* cap 4)
        bucket-off (:offset (alloc-for-node s-atom-env bucket-size))]
    ;; Write header
    (.setUint8 dv header-off 5)           ;; type tag
    (.setUint8 dv (+ header-off 1) FHT_LOAD_FACTOR_PCT)
    (.setUint32 dv (+ header-off FHT_OFFSET_COUNT) 0 true)
    (.setUint32 dv (+ header-off FHT_OFFSET_CAPACITY) cap true)
    (.setUint32 dv (+ header-off FHT_OFFSET_BUCKETS) bucket-off true)
    ;; Fill buckets with -1 (empty)
    (dotimes [i cap]
      (.setInt32 dv (+ bucket-off (* i 4)) FHT_EMPTY_BUCKET true))
    header-off))

(defn- fht-read-count [^js dv ^number ht-off]
  (.getUint32 dv (+ ht-off FHT_OFFSET_COUNT) true))

(defn- fht-write-count! [^js dv ^number ht-off ^number c]
  (.setUint32 dv (+ ht-off FHT_OFFSET_COUNT) c true))

(defn- fht-read-capacity [^js dv ^number ht-off]
  (.getUint32 dv (+ ht-off FHT_OFFSET_CAPACITY) true))

(defn- fht-read-buckets-off [^js dv ^number ht-off]
  (.getUint32 dv (+ ht-off FHT_OFFSET_BUCKETS) true))

(defn- fht-bucket-idx [^number kh ^number cap]
  (bit-and kh (dec cap)))

(defn- fht-bytes-equal? [^js dv ^number off1 ^js bytes2 ^number len]
  (let [u8 (js/Uint8Array. (.-buffer dv))]
    (loop [i 0]
      (if (>= i len)
        true
        (if (== (aget u8 (+ off1 i)) (aget bytes2 i))
          (recur (inc i))
          false)))))

(defn- fht-find
  "Find a key in the flat hashtable. Returns [found? deserialized-value]."
  [s-atom-env ^js dv ^number ht-off ^number kh ^js kb]
  (let [cap (fht-read-capacity dv ht-off)
        buckets-off (fht-read-buckets-off dv ht-off)
        bi (fht-bucket-idx kh cap)
        klen (.-length kb)]
    (loop [node-off (.getInt32 dv (+ buckets-off (* bi 4)) true)]
      (if (== node-off FHT_EMPTY_BUCKET)
        [false nil]
        (let [node-hash (.getInt32 dv (+ node-off FHT_CN_HASH) true)
              node-klen (.getUint32 dv (+ node-off FHT_CN_KEY_LEN) true)]
          (if (and (== node-hash kh)
                   (== node-klen klen)
                   (fht-bytes-equal? dv (+ node-off FHT_CN_KEY_START) kb klen))
            ;; Found: read value bytes
            (let [val-off (+ node-off FHT_CN_KEY_START klen)
                  vlen (.getUint32 dv val-off true)
                  vb (js/Uint8Array. vlen)]
              (when (pos? vlen)
                (.set vb (js/Uint8Array. (.-buffer dv) (+ val-off 4) vlen)))
              [true (deserialize-element s-atom-env vb)])
            ;; Not this node, follow chain
            (recur (.getInt32 dv (+ node-off FHT_CN_NEXT) true))))))))

(defn- fht-alloc-node!
  "Allocate a chain node. Returns offset."
  [s-atom-env ^number klen ^number vlen]
  (let [node-size (+ 12 klen 4 vlen)] ;; hash(4) + next(4) + klen(4) + kbytes + vlen(4) + vbytes
    (:offset (alloc-for-node s-atom-env node-size))))

(defn- fht-resize!
  "Double the bucket table capacity and redistribute all entries."
  [s-atom-env ^js dv ^number ht-off]
  (let [old-cap (fht-read-capacity dv ht-off)
        old-buckets-off (fht-read-buckets-off dv ht-off)
        new-cap (* old-cap 2)
        new-bucket-size (* new-cap 4)
        new-buckets-off (:offset (alloc-for-node s-atom-env new-bucket-size))]
    ;; Init new buckets to -1
    (dotimes [i new-cap]
      (.setInt32 dv (+ new-buckets-off (* i 4)) FHT_EMPTY_BUCKET true))
    ;; Redistribute existing entries
    (dotimes [bi old-cap]
      (loop [node-off (.getInt32 dv (+ old-buckets-off (* bi 4)) true)]
        (when (not= node-off FHT_EMPTY_BUCKET)
          (let [next-off (.getInt32 dv (+ node-off FHT_CN_NEXT) true)
                node-hash (.getInt32 dv (+ node-off FHT_CN_HASH) true)
                new-bi (fht-bucket-idx node-hash new-cap)
                existing-head (.getInt32 dv (+ new-buckets-off (* new-bi 4)) true)]
            ;; Prepend to new bucket chain
            (.setInt32 dv (+ node-off FHT_CN_NEXT) existing-head true)
            (.setInt32 dv (+ new-buckets-off (* new-bi 4)) node-off true)
            (recur next-off)))))
    ;; Update header
    (.setUint32 dv (+ ht-off FHT_OFFSET_CAPACITY) new-cap true)
    (.setUint32 dv (+ ht-off FHT_OFFSET_BUCKETS) new-buckets-off true)))

(defn- fht-assoc!
  "Insert or update a key in the flat hashtable. Returns [ht-off added?]."
  [s-atom-env ^js dv ^number ht-off ^number kh ^js kb ^js vb]
  (let [cap (fht-read-capacity dv ht-off)
        cnt (fht-read-count dv ht-off)
        buckets-off (fht-read-buckets-off dv ht-off)
        bi (fht-bucket-idx kh cap)
        klen (.-length kb)
        vlen (.-length vb)]
    ;; Check for existing key
    (loop [node-off (.getInt32 dv (+ buckets-off (* bi 4)) true)
           prev-off nil]
      (if (== node-off FHT_EMPTY_BUCKET)
        ;; Not found: check load factor, maybe resize, then insert
        (do
          (when (> (* (inc cnt) 100) (* cap FHT_LOAD_FACTOR_PCT))
            (fht-resize! s-atom-env dv ht-off))
          ;; Re-read capacity/buckets after potential resize
          (let [cap2 (fht-read-capacity dv ht-off)
                buckets-off2 (fht-read-buckets-off dv ht-off)
                bi2 (fht-bucket-idx kh cap2)
                node-off (fht-alloc-node! s-atom-env klen vlen)
                existing-head (.getInt32 dv (+ buckets-off2 (* bi2 4)) true)
                u8 (js/Uint8Array. (.-buffer dv))]
            ;; Write chain node
            (.setInt32 dv (+ node-off FHT_CN_HASH) kh true)
            (.setInt32 dv (+ node-off FHT_CN_NEXT) existing-head true)
            (.setUint32 dv (+ node-off FHT_CN_KEY_LEN) klen true)
            (when (pos? klen) (.set u8 kb (+ node-off FHT_CN_KEY_START)))
            (.setUint32 dv (+ node-off FHT_CN_KEY_START klen) vlen true)
            (when (pos? vlen) (.set u8 vb (+ node-off FHT_CN_KEY_START klen 4)))
            ;; Prepend to bucket
            (.setInt32 dv (+ buckets-off2 (* bi2 4)) node-off true)
            ;; Update count
            (fht-write-count! dv ht-off (inc cnt))
            [ht-off true]))
        ;; Check if this node matches
        (let [node-hash (.getInt32 dv (+ node-off FHT_CN_HASH) true)
              node-klen (.getUint32 dv (+ node-off FHT_CN_KEY_LEN) true)]
          (if (and (== node-hash kh)
                   (== node-klen klen)
                   (fht-bytes-equal? dv (+ node-off FHT_CN_KEY_START) kb klen))
            ;; Found: replace value by allocating new node in place of old
            (let [new-node-off (fht-alloc-node! s-atom-env klen vlen)
                  u8 (js/Uint8Array. (.-buffer dv))
                  next-off (.getInt32 dv (+ node-off FHT_CN_NEXT) true)]
              (.setInt32 dv (+ new-node-off FHT_CN_HASH) kh true)
              (.setInt32 dv (+ new-node-off FHT_CN_NEXT) next-off true)
              (.setUint32 dv (+ new-node-off FHT_CN_KEY_LEN) klen true)
              (when (pos? klen) (.set u8 kb (+ new-node-off FHT_CN_KEY_START)))
              (.setUint32 dv (+ new-node-off FHT_CN_KEY_START klen) vlen true)
              (when (pos? vlen) (.set u8 vb (+ new-node-off FHT_CN_KEY_START klen 4)))
              ;; Relink: update previous node's next or bucket head
              (if prev-off
                (.setInt32 dv (+ prev-off FHT_CN_NEXT) new-node-off true)
                (.setInt32 dv (+ buckets-off (* bi 4)) new-node-off true))
              [ht-off false])
            ;; Continue chain
            (recur (.getInt32 dv (+ node-off FHT_CN_NEXT) true) node-off)))))))

(defn- fht-dissoc!
  "Remove a key from the flat hashtable. Returns [ht-off removed?]."
  [s-atom-env ^js dv ^number ht-off ^number kh ^js kb]
  (let [cap (fht-read-capacity dv ht-off)
        buckets-off (fht-read-buckets-off dv ht-off)
        bi (fht-bucket-idx kh cap)
        klen (.-length kb)]
    (loop [node-off (.getInt32 dv (+ buckets-off (* bi 4)) true)
           prev-off nil]
      (if (== node-off FHT_EMPTY_BUCKET)
        [ht-off false]
        (let [node-hash (.getInt32 dv (+ node-off FHT_CN_HASH) true)
              node-klen (.getUint32 dv (+ node-off FHT_CN_KEY_LEN) true)]
          (if (and (== node-hash kh)
                   (== node-klen klen)
                   (fht-bytes-equal? dv (+ node-off FHT_CN_KEY_START) kb klen))
            ;; Found: unlink
            (let [next-off (.getInt32 dv (+ node-off FHT_CN_NEXT) true)]
              (if prev-off
                (.setInt32 dv (+ prev-off FHT_CN_NEXT) next-off true)
                (.setInt32 dv (+ buckets-off (* bi 4)) next-off true))
              (fht-write-count! dv ht-off (dec (fht-read-count dv ht-off)))
              [ht-off true])
            (recur (.getInt32 dv (+ node-off FHT_CN_NEXT) true) node-off)))))))

(defn- fht-to-hamt
  "Convert flat hashtable entries to a HAMT root. Used on persistent!."
  [s-atom-env ^js dv ^number ht-off]
  (let [cap (fht-read-capacity dv ht-off)
        buckets-off (fht-read-buckets-off dv ht-off)]
    (loop [bi 0 root d/ROOT_POINTER_NIL_SENTINEL]
      (if (>= bi cap)
        root
        (let [new-root
              (loop [node-off (.getInt32 dv (+ buckets-off (* bi 4)) true)
                     r root]
                (if (== node-off FHT_EMPTY_BUCKET)
                  r
                  (let [node-hash (.getInt32 dv (+ node-off FHT_CN_HASH) true)
                        klen (.getUint32 dv (+ node-off FHT_CN_KEY_LEN) true)
                        kb (js/Uint8Array. klen)
                        _ (when (pos? klen)
                            (.set kb (js/Uint8Array. (.-buffer dv) (+ node-off FHT_CN_KEY_START) klen)))
                        val-pos (+ node-off FHT_CN_KEY_START klen)
                        vlen (.getUint32 dv val-pos true)
                        vb (js/Uint8Array. vlen)
                        _ (when (pos? vlen)
                            (.set vb (js/Uint8Array. (.-buffer dv) (+ val-pos 4) vlen)))
                        k (deserialize-element s-atom-env kb)
                        [new-r _added?] (hamt-assoc-impl s-atom-env dv r k node-hash kb vb 0)
                        next-off (.getInt32 dv (+ node-off FHT_CN_NEXT) true)]
                    (recur next-off new-r))))]
          (recur (inc bi) new-root))))))

;; ============================================================================
;; TransientSabpMap
;; ============================================================================

(deftype TransientSabpMap [s-atom-env
                           ^:mutable root-offset
                           ^:mutable cnt
                           ^:mutable edit
                           ^:mutable mode]  ;; :hamt or :flat
  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [this k] (-lookup this k nil))
  (-lookup [_ k not-found]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [dv (js/DataView. (:sab s-atom-env))
          kh (hash k)]
      (if (= mode :flat)
        (let [kb (serialize-element k)
              [found? v] (fht-find s-atom-env dv root-offset kh kb)]
          (if found? v not-found))
        (let [[found? v] (hamt-find s-atom-env dv root-offset k kh 0)]
          (if found? v not-found)))))

  ITransientCollection
  (-conj! [this entry]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (if (vector? entry)
      (-assoc! this (nth entry 0) (nth entry 1))
      (if (instance? MapEntry entry)
        (-assoc! this (key entry) (val entry))
        (reduce -conj! this entry))))
  (-persistent! [_]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (set! edit nil)
    (let [final-root
          (if (= mode :flat)
            ;; Convert flat hashtable back to HAMT for persistent storage
            (let [dv (js/DataView. (:sab s-atom-env))]
              (fht-to-hamt s-atom-env dv root-offset))
            root-offset)]
      (SabpMap. s-atom-env final-root cnt nil nil)))

  ITransientAssociative
  (-assoc! [this k v]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [dv (js/DataView. (:sab s-atom-env))
          kh (hash k)]
      (if (= mode :flat)
        (let [kb (serialize-element k)
              ;; No-op detection: check if key exists with same value
              [found? existing-v] (fht-find s-atom-env dv root-offset kh kb)]
          (when-not (and found? (= existing-v v))
            (let [vb (serialize-element v)
                  [_ added?] (fht-assoc! s-atom-env dv root-offset kh kb vb)]
              (when added? (set! cnt (inc cnt))))))
        ;; HAMT path
        (let [[found? existing-v] (hamt-find s-atom-env dv root-offset k kh 0)]
          (when-not (and found? (= existing-v v))
            (let [kb (serialize-element k)
                  vb (serialize-element v)
                  [new-root added?] (hamt-assoc-impl s-atom-env dv root-offset k kh kb vb 0)]
              (set! root-offset new-root)
              (when added? (set! cnt (inc cnt))))))))
    this)

  ITransientMap
  (-dissoc! [this k]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [dv (js/DataView. (:sab s-atom-env))
          kh (hash k)]
      (if (= mode :flat)
        (let [kb (serialize-element k)
              [_ removed?] (fht-dissoc! s-atom-env dv root-offset kh kb)]
          (when removed? (set! cnt (dec cnt))))
        (let [[new-root removed?] (hamt-dissoc-impl s-atom-env dv root-offset k kh 0)]
          (set! root-offset new-root)
          (when removed? (set! cnt (dec cnt))))))
    this))

;; ============================================================================
;; Parallel reduce (flagged via d/*parallel-reduce*)
;; Splits HAMT at top-level children and reduces each subtree independently.
;; Currently uses in-process sequential execution of partitioned work;
;; structured so future worker dispatch can be dropped in.
;; ============================================================================

(def ^:private ^:const MIN_PARALLEL_ENTRIES 1000)

(defn- get-top-level-subtrees
  "Get the top-level child offsets and any inline KV data from the root node.
   Returns {:children [offset ...] :inline-kvs [[k v] ...]}."
  [s-atom-env ^js dv ^number root-offset]
  (if (== root-offset d/ROOT_POINTER_NIL_SENTINEL)
    {:children [] :inline-kvs []}
    (let [node-type (read-node-type dv root-offset)]
      (cond
        (== node-type d/HAMT_BITMAP_NODE_TYPE)
        (let [data-bm (read-bitmap-data dv root-offset)
              node-bm (read-bitmap-nodes dv root-offset)
              child-count (popcount node-bm)
              children (vec (for [i (range child-count)]
                              (read-child-offset dv root-offset i)))
              ;; Collect inline KV entries at root level
              data-count (popcount data-bm)
              inline-kvs (if (zero? data-count)
                           []
                           (let [kv-start (kv-data-start root-offset node-bm)]
                             (loop [i 0 pos kv-start acc []]
                               (if (>= i data-count)
                                 acc
                                 (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                                   (recur (inc i) next-pos (conj acc [k v])))))))]
          {:children children :inline-kvs inline-kvs})

        (== node-type d/HAMT_COLLISION_NODE_TYPE)
        ;; Collision node at root — treat as single partition
        {:children [root-offset] :inline-kvs []}

        :else {:children [] :inline-kvs []}))))

(defn- partition-offsets
  "Partition a vector of offsets into n roughly equal groups."
  [offsets ^number n]
  (let [total (count offsets)
        per-group (max 1 (quot total n))]
    (loop [remaining offsets groups []]
      (if (empty? remaining)
        groups
        (let [take-n (if (< (count groups) (dec n))
                       per-group
                       (count remaining))]
          (recur (subvec remaining take-n)
                 (conj groups (subvec remaining 0 take-n))))))))

(defn sabp-preduce
  "Parallel reduce over a SabpMap. Splits the HAMT tree at the top level
   and reduces each subtree independently, then merges results.

   Only active when d/*parallel-reduce* is true AND map has >= 1000 entries.
   Falls back to sequential reduce otherwise.

   init-fn:  (fn [] init-val) - called per partition
   rfn:      (fn [acc k v] acc') - per-entry reduction
   merge-fn: (fn [acc1 acc2] merged) - combines partition results"
  [^SabpMap sabp-map init-fn rfn merge-fn]
  (let [env (.-s-atom-env sabp-map)
        cnt (.-cnt sabp-map)
        root (.-root-offset sabp-map)]
    (if (or (not d/*parallel-reduce*) (< cnt MIN_PARALLEL_ENTRIES))
      ;; Sequential fallback
      (let [dv (js/DataView. (:sab env))
            result (hamt-kv-reduce env dv root rfn (init-fn))]
        (if (reduced? result) @result result))
      ;; Parallel path: split tree at top level
      (let [dv (js/DataView. (:sab env))
            {:keys [children inline-kvs]} (get-top-level-subtrees env dv root)
            num-partitions (min (count children) 4)]
        (if (<= (count children) 1)
          ;; Too few children to parallelize
          (let [result (hamt-kv-reduce env dv root rfn (init-fn))]
            (if (reduced? result) @result result))
          ;; Reduce each partition independently, then merge
          (let [partitions (partition-offsets children num-partitions)
                ;; Reduce inline KVs into first partition's result
                inline-acc (reduce (fn [acc [k v]] (rfn acc k v))
                                    (init-fn)
                                    inline-kvs)
                ;; Reduce each partition of subtrees
                partition-results
                (mapv (fn [offsets]
                        (let [init (init-fn)]
                          (reduce (fn [acc child-off]
                                    (let [r (hamt-kv-reduce env dv child-off rfn acc)]
                                      (if (reduced? r) @r r)))
                                  init
                                  offsets)))
                      partitions)
                ;; Merge all results
                merged (reduce merge-fn inline-acc partition-results)]
            merged))))))

;; ============================================================================
;; Constructor
;; ============================================================================

(defn sabp-map
  "Create a new SabpMap from key-value pairs."
  [s-atom-env & kvs]
  (let [m (SabpMap. s-atom-env d/ROOT_POINTER_NIL_SENTINEL 0 nil nil)]
    (if (seq kvs)
      (let [t (transient m)]
        (loop [remaining kvs tm t]
          (if (seq remaining)
            (let [k (first remaining)
                  v (second remaining)]
              (recur (nnext remaining) (assoc! tm k v)))
            (persistent! tm))))
      m)))

;; ============================================================================
;; SAB→AB conversion
;; ============================================================================

(defn- sabp-map->clj-map [^SabpMap m]
  (into {} (seq m)))

;; sab->ab registration removed (Fressian Phase 5)

(ns com.seniorcaremarket.eve.conveyance
  "Pluggable conveyance registry system for cross-worker data transport.
   
   This system allows different atom implementations (SharedAtom, three-SAB, etc.) 
   to register their own conveyance functions without creating hard dependencies
   between the transport layer and specific atom implementations.")

;; Global registry for conveyance functions
(def ^:private *conveyance-registry* (atom {}))

(defn register-conveyable!
  "Register conveyance functions for a specific type.
   
   Parameters:
   - convey-pred: Predicate function for objects that need conveyance (obj -> boolean)
   - convey-fn: Function to convert object for transport (obj -> conveyed-obj)
   - unconvey-pred: Predicate function for conveyed objects that need reconstruction (conveyed-obj -> boolean)
   - unconvey-fn: Function to reconstruct object from transport (conveyed-obj -> obj)
   
   Example:
   (register-conveyable! 
     #(instance? SharedAtom %) 
     shared-atom-convey
     #(and (map? %) (= \"shared-atom\" (:type %)))
     shared-atom-unconvey)"
  [convey-pred convey-fn unconvey-pred unconvey-fn]
  (swap! *conveyance-registry* assoc
         convey-pred {:convey convey-fn}
         unconvey-pred {:unconvey unconvey-fn}))

(defn conveyable->
  "Apply registered conveyance functions to prepare object for transport.
   
   Searches the registry for a predicate that matches the object type,
   then applies the corresponding convey function. If no match is found,
   returns the object unchanged."
  [obj]
  (if-let [handler (some (fn [[pred {:keys [convey]}]]
                           (when (and convey (pred obj)) convey))
                         @*conveyance-registry*)]
    (handler obj)
    obj))

(defn <-conveyable
  "Apply registered unconveyance functions to reconstruct object from transport.
   
   Searches the registry for a predicate that matches the conveyed object type,
   then applies the corresponding unconvey function. If no match is found,
   returns the object unchanged."
  [obj]
  (if-let [handler (some (fn [[pred {:keys [unconvey]}]]
                           (when (and unconvey (pred obj)) unconvey))
                         @*conveyance-registry*)]
    (handler obj)
    obj))

(defn list-registered-conveyables
  "Development helper: List all registered conveyance types.
   Returns a sequence of {:predicate pred :convey-fn convey :unconvey-fn unconvey}"
  []
  (map (fn [[pred {:keys [convey unconvey]}]]
         {:predicate pred :convey-fn convey :unconvey-fn unconvey})
       @*conveyance-registry*))

(defn clear-registry!
  "Development helper: Clear all registered conveyance functions.
   Useful for testing and development."
  []
  (reset! *conveyance-registry* {}))

(ns com.seniorcaremarket.eve.array
  "Simple typed arrays backed by SharedArrayBuffer with full Atomics API.

   These arrays are mutable and do not provide persistence guarantees.
   They are designed for building high-performance lock-free data structures.

   The SAB abstraction is completely hidden - users create arrays via
   constructors like (int32-array 10) and interact via standard operations.

   SIMD-accelerated operations (afill-simd!, acopy-simd!, asum-simd, etc.)
   are available for bulk operations when atomicity is not required."
  (:refer-clojure :exclude [aget aset areduce amap])
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]))

;; Forward declarations
(declare int32-array aget aset!)

;;-----------------------------------------------------------------------------
;; Int32Array - A fixed-size int32 array backed by SharedArrayBuffer
;;-----------------------------------------------------------------------------

(deftype Int32Array [^js/SharedArrayBuffer sab
                     ^number offset         ;; byte offset into SAB
                     ^number length         ;; number of elements
                     ^number descriptor-idx ;; block descriptor for GC tracking
                     ^:mutable __hash
                     ^IPersistentMap _meta]

  Object
  (toString [this]
    (str "#eve/int32-array ["
         (clojure.string/join " " (take 10 (map #(nth this %) (range (min 10 length)))))
         (when (> length 10) " ...")
         "]"))

  IMeta
  (-meta [_] _meta)

  IWithMeta
  (-with-meta [_ new-meta]
    (Int32Array. sab offset length descriptor-idx __hash new-meta))

  ICounted
  (-count [_] length)

  IIndexed
  (-nth [this n]
    (if (and (>= n 0) (< n length))
      (js/Atomics.load (js/Int32Array. sab) (+ (unsigned-bit-shift-right offset 2) n))
      (throw (js/Error. (str "Index out of bounds: " n " for length " length)))))
  (-nth [this n not-found]
    (if (and (>= n 0) (< n length))
      (js/Atomics.load (js/Int32Array. sab) (+ (unsigned-bit-shift-right offset 2) n))
      not-found))

  ILookup
  (-lookup [this k]
    (-nth this k nil))
  (-lookup [this k not-found]
    (-nth this k not-found))

  IFn
  (-invoke [this k]
    (-nth this k))
  (-invoke [this k not-found]
    (-nth this k not-found))

  ISeqable
  (-seq [this]
    (when (pos? length)
      (map #(-nth this %) (range length))))

  IReduce
  (-reduce [this f]
    (if (zero? length)
      (f)
      (loop [i 1
             acc (-nth this 0)]
        (if (< i length)
          (let [result (f acc (-nth this i))]
            (if (reduced? result)
              @result
              (recur (inc i) result)))
          acc))))
  (-reduce [this f start]
    (loop [i 0
           acc start]
      (if (< i length)
        (let [result (f acc (-nth this i))]
          (if (reduced? result)
            @result
            (recur (inc i) result)))
        acc)))

  IHash
  (-hash [this]
    (if __hash
      __hash
      (let [h (loop [i 0 h 1]
                (if (< i length)
                  (recur (inc i) (+ (* 31 h) (-nth this i)))
                  h))]
        (set! __hash h)
        h)))

  IEquiv
  (-equiv [this other]
    (cond
      (identical? this other) true
      (not (instance? Int32Array other)) false
      (not= length (count other)) false
      :else (loop [i 0]
              (if (< i length)
                (if (= (-nth this i) (nth other i))
                  (recur (inc i))
                  false)
                true))))

  IPrintWithWriter
  (-pr-writer [this writer opts]
    (-write writer "#eve/int32-array [")
    (loop [i 0]
      (when (< i (min 20 length))
        (when (pos? i) (-write writer " "))
        (-write writer (str (-nth this i)))
        (recur (inc i))))
    (when (> length 20)
      (-write writer " ..."))
    (-write writer "]")))

;;-----------------------------------------------------------------------------
;; Constructors (defined early for forward references)
;;-----------------------------------------------------------------------------

(defn- alloc-int32-region
  "Allocate a region for n int32 elements. Returns {:sab sab :offset offset :descriptor-idx idx}."
  [n]
  (let [byte-size (* n 4) ;; 4 bytes per int32
        eve-env (if atom/*global-atom-instance*
                  (atom/get-env atom/*global-atom-instance*)
                  (throw (js/Error. "No global atom instance. Call (eve.atom/private-atom {}) first.")))
        alloc-result (atom/alloc eve-env byte-size)]
    (if (:error alloc-result)
      (throw (js/Error. (str "Failed to allocate int32-array: " (:error alloc-result))))
      {:sab (:sab eve-env)
       :offset (:offset alloc-result)
       :descriptor-idx (:descriptor-idx alloc-result)})))

(defn int32-array
  "Create a new Int32Array with n elements, all initialized to 0.
   Allocates from the global SharedArrayBuffer."
  ([n]
   (let [{:keys [sab offset descriptor-idx]} (alloc-int32-region n)
         arr (Int32Array. sab offset n descriptor-idx nil nil)]
     ;; Zero-fill (Atomics.store for each element)
     (dotimes [i n]
       (js/Atomics.store (js/Int32Array. sab)
                         (+ (unsigned-bit-shift-right offset 2) i)
                         0))
     arr))
  ([n init-val]
   (let [{:keys [sab offset descriptor-idx]} (alloc-int32-region n)
         arr (Int32Array. sab offset n descriptor-idx nil nil)]
     ;; Fill with init-val
     (dotimes [i n]
       (js/Atomics.store (js/Int32Array. sab)
                         (+ (unsigned-bit-shift-right offset 2) i)
                         init-val))
     arr)))

(defn int32-array-from
  "Create a new Int32Array from a collection of integers."
  [coll]
  (let [v (vec coll)
        n (count v)]
    (if (zero? n)
      (int32-array 0)
      (let [{:keys [sab offset descriptor-idx]} (alloc-int32-region n)
            arr (Int32Array. sab offset n descriptor-idx nil nil)]
        (dotimes [i n]
          (js/Atomics.store (js/Int32Array. sab)
                            (+ (unsigned-bit-shift-right offset 2) i)
                            (nth v i)))
        arr))))

;;-----------------------------------------------------------------------------
;; Atomic Operations on Int32Array
;;-----------------------------------------------------------------------------

(defn aget
  "Read element at index atomically. Equivalent to Atomics.load."
  [^Int32Array arr idx]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.load (js/Int32Array. sab) (+ (unsigned-bit-shift-right offset 2) idx))))

(defn aset!
  "Write element at index atomically. Returns the value written.
   Equivalent to Atomics.store."
  [^Int32Array arr idx val]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.store (js/Int32Array. sab) (+ (unsigned-bit-shift-right offset 2) idx) val)
    val))

(defn cas!
  "Compare-and-swap at index. Returns true if successful.
   Equivalent to Atomics.compareExchange."
  [^Int32Array arr idx expected new-val]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (== expected
        (js/Atomics.compareExchange (js/Int32Array. sab)
                                    (+ (unsigned-bit-shift-right offset 2) idx)
                                    expected new-val))))

(defn exchange!
  "Atomically replace value at index, returning the old value.
   Equivalent to Atomics.exchange."
  [^Int32Array arr idx new-val]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.exchange (js/Int32Array. sab)
                         (+ (unsigned-bit-shift-right offset 2) idx)
                         new-val)))

(defn add!
  "Atomically add to value at index, returning the old value.
   Equivalent to Atomics.add."
  [^Int32Array arr idx delta]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.add (js/Int32Array. sab)
                    (+ (unsigned-bit-shift-right offset 2) idx)
                    delta)))

(defn sub!
  "Atomically subtract from value at index, returning the old value.
   Equivalent to Atomics.sub."
  [^Int32Array arr idx delta]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.sub (js/Int32Array. sab)
                    (+ (unsigned-bit-shift-right offset 2) idx)
                    delta)))

(defn band!
  "Atomically bitwise-AND value at index, returning the old value.
   Equivalent to Atomics.and."
  [^Int32Array arr idx mask]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.and (js/Int32Array. sab)
                    (+ (unsigned-bit-shift-right offset 2) idx)
                    mask)))

(defn bor!
  "Atomically bitwise-OR value at index, returning the old value.
   Equivalent to Atomics.or."
  [^Int32Array arr idx mask]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.or (js/Int32Array. sab)
                   (+ (unsigned-bit-shift-right offset 2) idx)
                   mask)))

(defn bxor!
  "Atomically bitwise-XOR value at index, returning the old value.
   Equivalent to Atomics.xor."
  [^Int32Array arr idx mask]
  (let [sab (.-sab arr)
        offset (.-offset arr)
        length (.-length arr)]
    (when (or (< idx 0) (>= idx length))
      (throw (js/Error. (str "Index out of bounds: " idx))))
    (js/Atomics.xor (js/Int32Array. sab)
                    (+ (unsigned-bit-shift-right offset 2) idx)
                    mask)))

;;-----------------------------------------------------------------------------
;; Wait/Notify (for coordination)
;;-----------------------------------------------------------------------------

(defn wait!
  "Block until the value at index is not equal to `expected`, or until timeout.
   Returns :ok, :not-equal, or :timed-out.
   Equivalent to Atomics.wait."
  ([^Int32Array arr idx expected]
   (wait! arr idx expected ##Inf))
  ([^Int32Array arr idx expected timeout-ms]
   (let [sab (.-sab arr)
         offset (.-offset arr)
         length (.-length arr)]
     (when (or (< idx 0) (>= idx length))
       (throw (js/Error. (str "Index out of bounds: " idx))))
     (let [result (js/Atomics.wait (js/Int32Array. sab)
                                   (+ (unsigned-bit-shift-right offset 2) idx)
                                   expected
                                   timeout-ms)]
       (case result
         "ok" :ok
         "not-equal" :not-equal
         "timed-out" :timed-out
         result)))))

(defn wait-async
  "Async version of wait!. Returns a promise that resolves to :ok, :not-equal, or :timed-out.
   Equivalent to Atomics.waitAsync."
  ([^Int32Array arr idx expected]
   (wait-async arr idx expected ##Inf))
  ([^Int32Array arr idx expected timeout-ms]
   (let [sab (.-sab arr)
         offset (.-offset arr)
         length (.-length arr)]
     (when (or (< idx 0) (>= idx length))
       (throw (js/Error. (str "Index out of bounds: " idx))))
     (let [result (js/Atomics.waitAsync (js/Int32Array. sab)
                                        (+ (unsigned-bit-shift-right offset 2) idx)
                                        expected
                                        timeout-ms)]
       (if (.-async result)
         ;; Async path - returns a promise
         (-> (.-value result)
             (.then (fn [r]
                      (case r
                        "ok" :ok
                        "not-equal" :not-equal
                        "timed-out" :timed-out
                        r))))
         ;; Sync path - value immediately available
         (let [v (.-value result)]
           (js/Promise.resolve
            (case v
              "ok" :ok
              "not-equal" :not-equal
              "timed-out" :timed-out
              v))))))))

(defn notify!
  "Wake up waiting agents on the value at index.
   count defaults to ##Inf (wake all waiters).
   Returns the number of agents woken.
   Equivalent to Atomics.notify."
  ([^Int32Array arr idx]
   (notify! arr idx ##Inf))
  ([^Int32Array arr idx cnt]
   (let [sab (.-sab arr)
         offset (.-offset arr)
         length (.-length arr)]
     (when (or (< idx 0) (>= idx length))
       (throw (js/Error. (str "Index out of bounds: " idx))))
     (js/Atomics.notify (js/Int32Array. sab)
                        (+ (unsigned-bit-shift-right offset 2) idx)
                        cnt))))

;;-----------------------------------------------------------------------------
;; Functional operations
;;-----------------------------------------------------------------------------

(defn areduce
  "Reduce over array elements with index.
   f is (fn [acc idx val] ...).
   Returns the final accumulated value."
  [^Int32Array arr init f]
  (let [len (.-length arr)]
    (loop [i 0
           acc init]
      (if (< i len)
        (let [result (f acc i (aget arr i))]
          (if (reduced? result)
            @result
            (recur (inc i) result)))
        acc))))

(defn amap
  "Map f over array indices, returning a new Int32Array.
   f is (fn [idx current-val] ...) and must return an int32."
  [^Int32Array arr f]
  (let [len (.-length arr)
        result (int32-array len)]
    (dotimes [i len]
      (aset! result i (f i (aget arr i))))
    result))

(defn amap!
  "Map f over array indices in-place, mutating the array.
   f is (fn [idx current-val] ...) and must return an int32.
   Returns the array."
  [^Int32Array arr f]
  (let [len (.-length arr)]
    (dotimes [i len]
      (aset! arr i (f i (aget arr i))))
    arr))

(defn afill!
  "Fill array with value, optionally in range [start, end).
   Returns the array."
  ([^Int32Array arr val]
   (afill! arr val 0 (.-length arr)))
  ([^Int32Array arr val start]
   (afill! arr val start (.-length arr)))
  ([^Int32Array arr val start end]
   (let [len (.-length arr)
         end (min end len)]
     (loop [i start]
       (when (< i end)
         (aset! arr i val)
         (recur (inc i))))
     arr)))

(defn acopy!
  "Copy elements from src to dest array.
   src-start, dest-start default to 0.
   length defaults to min of remaining space.
   Returns dest array."
  ([dest src]
   (acopy! dest 0 src 0 (min (count dest) (count src))))
  ([dest dest-start src src-start len]
   (dotimes [i len]
     (aset! dest (+ dest-start i) (aget src (+ src-start i))))
   dest))

;;-----------------------------------------------------------------------------
;; Low-level access (for building data structures)
;;-----------------------------------------------------------------------------

(defn get-sab
  "Get the underlying SharedArrayBuffer. For internal use."
  [^Int32Array arr]
  (.-sab arr))

(defn get-offset
  "Get the byte offset into the SAB. For internal use."
  [^Int32Array arr]
  (.-offset arr))

(defn get-int32-view
  "Get a raw Int32Array view of the underlying SAB region.
   Useful for bulk operations. Handle with care."
  [^Int32Array arr]
  (js/Int32Array. (.-sab arr) (.-offset arr) (.-length arr)))

(defn get-descriptor-idx
  "Get the block descriptor index for this array. For GC tracking."
  [^Int32Array arr]
  (.-descriptor-idx arr))

;;-----------------------------------------------------------------------------
;; GC / Lifecycle
;;-----------------------------------------------------------------------------

(defn retire!
  "Mark this array's block as retired for GC.
   Call when replacing this array with a new version.
   Returns true if successfully retired, false if already being processed."
  [^Int32Array arr]
  (when-let [desc-idx (.-descriptor-idx arr)]
    (let [eve-env (when atom/*global-atom-instance*
                    (atom/get-env atom/*global-atom-instance*))]
      (when eve-env
        (atom/retire-block! eve-env desc-idx)))))

;;-----------------------------------------------------------------------------
;; SIMD-Accelerated Operations
;;
;; These operations use WASM SIMD for bulk processing (4 elements at a time).
;; They do NOT use Atomics and should only be used when:
;; - The array is not yet shared with other threads
;; - The array is read-only in the current context
;; - You have other synchronization in place
;;-----------------------------------------------------------------------------

(defn afill-simd!
  "Fill array with value using SIMD (4 elements at a time).
   WARNING: Does not use Atomics. Only use before sharing with other threads.
   Returns the array."
  ([^Int32Array arr val]
   (afill-simd! arr val 0 (.-length arr)))
  ([^Int32Array arr val start end]
   (let [offset (.-offset arr)
         byte-start (+ offset (* start 4))
         count (- end start)]
     (when (and (wasm/ready?) (pos? count))
       (wasm/simd-fill-i32! byte-start count val))
     arr)))

(defn acopy-simd!
  "Copy elements from src to dest array using SIMD (4 elements at a time).
   WARNING: Does not use Atomics. Only use before sharing with other threads.
   Returns dest array."
  ([dest src]
   (acopy-simd! dest 0 src 0 (min (count dest) (count src))))
  ([dest dest-start src src-start len]
   (when (and (wasm/ready?) (pos? len))
     (let [dest-byte-offset (+ (.-offset dest) (* dest-start 4))
           src-byte-offset (+ (.-offset src) (* src-start 4))]
       (wasm/simd-copy-i32! dest-byte-offset src-byte-offset len)))
   dest))

(defn asum-simd
  "Sum all elements in array using SIMD (4 elements at a time).
   Safe to use on shared arrays (read-only operation)."
  ([^Int32Array arr]
   (asum-simd arr 0 (.-length arr)))
  ([^Int32Array arr start end]
   (let [offset (.-offset arr)
         byte-start (+ offset (* start 4))
         count (- end start)]
     (if (and (wasm/ready?) (pos? count))
       (wasm/simd-sum-i32 byte-start count)
       0))))

(defn amin-simd
  "Find minimum value in array using SIMD (4 elements at a time).
   Safe to use on shared arrays (read-only operation).
   Returns INT32_MAX for empty arrays."
  ([^Int32Array arr]
   (amin-simd arr 0 (.-length arr)))
  ([^Int32Array arr start end]
   (let [offset (.-offset arr)
         byte-start (+ offset (* start 4))
         count (- end start)]
     (if (and (wasm/ready?) (pos? count))
       (wasm/simd-min-i32 byte-start count)
       2147483647))))

(defn amax-simd
  "Find maximum value in array using SIMD (4 elements at a time).
   Safe to use on shared arrays (read-only operation).
   Returns INT32_MIN for empty arrays."
  ([^Int32Array arr]
   (amax-simd arr 0 (.-length arr)))
  ([^Int32Array arr start end]
   (let [offset (.-offset arr)
         byte-start (+ offset (* start 4))
         count (- end start)]
     (if (and (wasm/ready?) (pos? count))
       (wasm/simd-max-i32 byte-start count)
       -2147483648))))

(defn aequal-simd?
  "Compare two arrays for equality using SIMD (4 elements at a time).
   Safe to use on shared arrays (read-only operation)."
  [^Int32Array arr1 ^Int32Array arr2]
  (let [len1 (.-length arr1)
        len2 (.-length arr2)]
    (if (not= len1 len2)
      false
      (if (and (wasm/ready?) (pos? len1))
        (wasm/simd-eq-i32? (.-offset arr1) (.-offset arr2) len1)
        (zero? len1)))))

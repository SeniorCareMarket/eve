;; src/com/jolygon/eve/ab_list.cljs
(ns com.seniorcaremarket.eve.ab-list
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]
   [com.seniorcaremarket.eve.util :as u]))

;; --- Forward Declarations ---
(declare ->AbList AbList empty-ab-list)

(defprotocol IPersistentLogList (-log-list? [this]))

;; --- AbList Deftype ---
(deftype AbList [^js/SharedArrayBuffer buffer
                 ^js/Uint32Array offsets-buffer
                 ^number list-count
                 ^:mutable __hash
                 meta-map]
  IPersistentLogList
  (-log-list? [_this] true)

  ISequential
  Object
  (equiv [this other]
    (println :equiv_caled)
    (u/-equiv-sequential this other))
  (toString [coll] (pr-str (vec coll)))
  IEquiv
  (-equiv [this other]
    (println :-equiv_called)
    (u/-equiv-sequential this other))

  IMeta (-meta [_] meta-map)
  IWithMeta (-with-meta [this new-meta]
              (if (identical? meta-map new-meta)
                this
                (->AbList buffer offsets-buffer list-count __hash new-meta)))

  ICounted
  (-count [_this] list-count)

  IIndexed
  (-nth [this idx] (-nth this idx nil))
  ;; In AbList deftype, -nth method
  (-nth [_this idx not-found]
    (if (or (< idx 0) (>= idx list-count))
      not-found
      (let [offsets (js/Uint32Array. offsets-buffer)
            element-start-offset (aget offsets idx)
            next-element-start-offset (if (< (inc idx) list-count)
                                        (aget offsets (inc idx))
                                        (.-byteLength buffer))
            element-byte-length (- next-element-start-offset element-start-offset)

;; Original view:
            ;; element-bytes-view (js/Uint8Array. buffer element-start-offset element-byte-length)

            ;; MODIFICATION: Create a copy into a new ArrayBuffer
            copied-element-buffer (js/SharedArrayBuffer. (* element-byte-length js/Uint32Array.BYTES_PER_ELEMENT))
            copied-element-view (js/Uint8Array. copied-element-buffer)
            original-segment-view (js/Uint8Array. buffer element-start-offset element-byte-length)]

        (.set copied-element-view original-segment-view 0) ;; Copy the bytes

        ;; (println "AbList/-nth: idx" idx "element_byte_length:" element-byte-length)
        ;; (println "AbList/-nth: Copied element bytes for Fressian deserialization (hex):")
        ;; (u/hex-window copied-element-buffer) ;; Use the new buffer for fress-window

        ;; Pass the copied view to fast-path deserializer
        (let [s-atom-env (when atom/*global-atom-instance*
                           (atom/get-env atom/*global-atom-instance*))]
          (ser/deserialize-element (or s-atom-env {}) copied-element-view)))))

  ISeqable
  (-seq [this]
    (when (> list-count 0)
      ((fn ab-list-seq [idx]
         (lazy-seq
          (when (< idx list-count)
            (cons (-nth this idx) (ab-list-seq (inc idx))))))
       0)))

  IEmptyableCollection
  (-empty [_this] (empty-ab-list meta-map))

  ICollection
  ;; In AbList deftype
  (-conj [_this element]
    (u/log ">>> AbList -conj (PREPENDING): Adding element:" (pr-str element))
    (let [serialized-new-element (ser/serialize-val element)
          new-element-len (if serialized-new-element (.-length serialized-new-element) 0)
          old-buffer-len (.-byteLength buffer)
          new-buffer-len (+ new-element-len old-buffer-len) ; Total size for new element + old buffer
          new-buffer (js/SharedArrayBuffer. (* new-buffer-len js/Uint32Array.BYTES_PER_ELEMENT))
          new-u8-view (js/Uint8Array. new-buffer)
          old-u8-view (js/Uint8Array. buffer)]

    ;; Write new element first
      (when serialized-new-element
        (.set new-u8-view serialized-new-element 0))
    ;; Then write old elements after the new one
      (.set new-u8-view old-u8-view new-element-len)

      (let [new-offsets-buffer (js/SharedArrayBuffer. (* (inc list-count) js/Uint32Array.BYTES_PER_ELEMENT))
            new-offsets-array (js/Uint32Array. new-offsets-buffer)
            offsets (js/Uint32Array. offsets-buffer)
            old-offsets-len (.-length offsets)]
        ;; First offset is 0 (for the new element)
        (aset new-offsets-array 0 0)
        (dotimes [i old-offsets-len]
          (aset new-offsets-array (inc i) (+ (aget offsets i) new-element-len)))

        (u/log "AbList.-conj (PREPENDING): new-buffer content:")
        (u/hex-window new-buffer)
        (u/log "AbList.-conj (PREPENDING): new-offsets-array content:")
        (u/hex-window new-offsets-array)

        (->AbList new-buffer new-offsets-array (inc list-count) nil meta-map))))

  IStack
  (-peek [this]
    (when-not (zero? list-count)
      (-nth this 0)))

  (-pop [this]
    (if (or (zero? list-count) (= 1 list-count)) ; Popping last element or empty results in empty
      (empty-ab-list meta-map)
      (let [old-offsets-view (js/Uint32Array. offsets-buffer)
          ;; Data of the first element to be popped
            first-element-start-offset (aget old-offsets-view 0) ; Always 0 if conj prepends like yours does
            first-element-end-offset (aget old-offsets-view 1) ; Start of the second element
            first-element-len (- first-element-end-offset first-element-start-offset)

          ;; New data buffer will contain all elements *except* the first
            new-data-buffer-len (- (.-byteLength buffer) first-element-len)
            new-data-sab (js/SharedArrayBuffer. new-data-buffer-len)
            new-data-u8-view (js/Uint8Array. new-data-sab)
          ;; Copy data from the second element onwards
            _ (.set new-data-u8-view (js/Uint8Array. buffer first-element-end-offset))

            new-count (dec list-count)
            new-offsets-byte-len (* new-count js/Uint32Array.BYTES_PER_ELEMENT)
            new-offsets-sab (js/SharedArrayBuffer. new-offsets-byte-len)
            new-offsets-view (js/Uint32Array. new-offsets-sab)]

      ;; New offsets are the old offsets (from the second element onwards)
      ;; shifted left by the length of the popped first element's data region.
      ;; No, they are shifted by `first-element-end-offset`.
        (dotimes [i new-count]
          (aset new-offsets-view i (- (aget old-offsets-view (inc i)) first-element-end-offset)))

        (->AbList new-data-sab new-offsets-sab new-count nil meta-map))))

  #_(-pop [this]
          (if (zero? list-count)
            this
            (if (= 1 list-count)
              (empty-ab-list meta-map)
              (let [new-count (dec list-count)
                    offsets (js/Uint32Array. offsets-buffer)
                    new-buffer-len (aget offsets new-count)
                    new-buffer (js/SharedArrayBuffer. (* new-buffer-len js/Uint32Array.BYTES_PER_ELEMENT))
                    new-u8-view (js/Uint8Array. new-buffer)
                    old-u8-view (js/Uint8Array. buffer 0 new-buffer-len)]
                (.set new-u8-view old-u8-view 0)
                (let [new-offsets-array (js/Uint32Array. new-count)]
                  (dotimes [i new-count]
                    (aset new-offsets-array i (aget offsets i)))
                  (->AbList new-buffer new-offsets-array new-count nil meta-map))))))

  IHash
  (-hash [coll]
    (if-not (nil? __hash)
      __hash
      (set! __hash (hash-ordered-coll coll))))

  IPrintWithWriter
  (-pr-writer [coll writer opts]
    (binding [*out* writer]
      #_{:clj-kondo/ignore [:private-call]}
      (pr-sequential-writer writer pr-writer "(" " " ")" opts coll))))

;; --- Empty AbList Instance & Constructor ---
(defonce EMPTY_AB_LIST_INSTANCE (->AbList (js/SharedArrayBuffer. 0) (js/Uint32Array. 0) 0 nil nil))

(defn empty-ab-list
  ([] EMPTY_AB_LIST_INSTANCE)
  ([meta-map] (if (or (nil? meta-map) (empty? meta-map)) EMPTY_AB_LIST_INSTANCE (with-meta EMPTY_AB_LIST_INSTANCE meta-map))))

(defn pl-list? [l]
  (if (satisfies? IPersistentLogList l)
    (-log-list? l)
    false))

(defn conveyable-> [t]
  ;; (println :ab-list-> :t t)
  (if (pl-list? t)
    {:type "pl-list"
     :sab (.-buffer t)
     :offsets-buffer (.-offsets-buffer t)
     :count (.-list-count t)
     :meta (meta t)}
    t))

(defn <-conveyable [m]
  ;; (println :<- :m m)
  (if-not (and (map? m) (= "pl-list" (:type m)))
    m
    (let [;m (js->clj m :keywordize-keys true)
          sab (:sab m)
          offsets (:offsets-buffer m)
          cnt (:count m)
          mta (:meta m)]
      (->AbList sab offsets cnt nil mta))))

;; --- `ab-list` Public Constructor Function ---
(defn ab-list
  "Creates a new persistent list backed by an ArrayBuffer.
   Elements are serialized using raw/object->bytes.
   Example: (ab-list 1 \"hello\" :a-keyword)"
  [& elements]
  (if (empty? elements)
    EMPTY_AB_LIST_INSTANCE
    (let [num-elements (count elements)
          element-byte-arrays (mapv #(ser/serialize-val %) (vec elements))
          total-bytes (reduce + 0 (map #(if % (.-length %) 0) element-byte-arrays))
          final-buffer (js/SharedArrayBuffer. total-bytes)
          final-u8-view (js/Uint8Array. final-buffer)
          offsets-byte-length (* num-elements js/Uint32Array.BYTES_PER_ELEMENT)
          offsets-buffer (js/SharedArrayBuffer. offsets-byte-length)
          final-offsets (js/Uint32Array. offsets-buffer)
          current-offset (volatile! 0)]
      (doseq [[idx element-ba] (map-indexed vector element-byte-arrays)]
        (aset final-offsets idx @current-offset)
        (when element-ba
          (.set final-u8-view element-ba @current-offset)
          (vswap! current-offset + (.-length element-ba))))
      (->AbList final-buffer offsets-buffer num-elements nil nil))))

#_#_(def a (ab-list 1 2 3 4 5))

  (-> a
      conveyable->
      (js->clj :keywordize-keys true)
      <-conveyable)

(comment
  ;; Expected for 1000.0 double: FA <8 bytes for 1000.0> (9 bytes total)
  ;; Expected for int 1000: F8 02 03 E8 (4 bytes total)
  :end)

(comment

  (u/log "\n--- Testing AbList ---")
  ;; Example of using u/hex-window to inspect an AbList's buffer
  (def inspect-list (ab-list 1000 "alpha" :beta {:my :map}))
  (u/log "Inspect list pr-str:" (pr-str inspect-list))
  (u/hex-window (.-buffer inspect-list) :title "AbList 'inspect-list' Internal Buffer")

  (println "\n--- Original Test Suite ---")
  (def l0 (ab-list))
  (u/log "l0:" (pr-str l0))
  (u/log "l0 count:" (count l0))
  (assert (= 0 (count l0)))
  (u/log "l0 seq:" (seq l0))
  (assert (nil? (seq l0)))

  (def l1 (ab-list 10 20 "hello"))
  (u/log "l1:" (pr-str l1))
  (u/log "l1 count:" (count l1))
  (assert (= 3 (count l1)))
  (u/log "l1 nth 0:" (nth l1 0))
  (assert (= 10 (nth l1 0)))
  (u/log "l1 nth 1:" (nth l1 1))
  (assert (= 20 (nth l1 1)))
  (u/log "l1 nth 2:" (nth l1 2))
  (assert (= "hello" (nth l1 2)))
  (u/log "l1 seq as vec:" (vec (seq l1)))
  (assert (= [10 20 "hello"] (vec (seq l1))))

  (def l2 (conj l1 :world))
  (u/log "l2 (conj l1 :world):" (pr-str l2))
  (u/log "l2 count:" (count l2))
  (assert (= 4 (count l2)))
  (u/log "l2 nth 3:" (nth l2 3))
  (assert (= :world (nth l2 0)))

  (println "but when we conj on a regular list:")
  (println "like: (def ll1 '(10 20 \"hello\"))")
  (println "      (conj ll1 :world)")

  (def ll1 '(10 20 "hello"))
  (conj ll1 :world)

  (u/log "l2 seq as vec:" (vec (seq l2)))
  (assert (= [:world 10 20 "hello"] (vec (seq l2))))
  (u/log "l1 unchanged:" (vec (seq l1)))
  (assert (= [10 20 "hello"] (vec (seq l1))))

  l2 ;=> (:world 10 20 "hello")
  (def ll '(:world 10 20 "hello"))
  (pop ll) ;=> (10 20 "hello")

  (def l3 (pop l2))
  (u/log "l3 (pop l2):" (pr-str l3))
  (u/log "l3 count:" (count l3))
  (assert (= 3 (count l3)))
  (u/log "l3 peek:" (peek l3))
  (assert (= 10 (peek l3)))
  (u/log "l3 seq as vec:" (vec (seq l3)))
  (assert (= [10 20 "hello"] (vec (seq l3)))) ;=> ; Assert failed: (= [10 20 "hello"] (vec (seq l3)))

  (def l4 (pop (pop (pop l3))))
  (u/log "l4 (pop pop pop l3):" (pr-str l4))
  (u/log "l4 count:" (count l4))
  (assert (= 0 (count l4)))
  (assert (empty? l4))

  (def l5 (pop l4)) ;; pop empty
  (u/log "l5 (pop l4):" (pr-str l5))
  (assert (empty? l5))

  (u/log "Equality test l0 vs l4:" (= l0 l4))
  (assert (= l0 l4))
  (u/log "Equality test l1 vs l3:" (= l1 l3))
  (assert (= l1 l3))
  (u/log "Equality test l1 vs l2:" (= l1 l2))
  (assert (not= l1 l2))

  (u/log "Equality with cljs.core.List:" (= l1 (list 10 20 "hello")))
  (assert (= l1 (list 10 20 "hello")))
  (u/log "Equality with cljs.core.Vector:" (= l1 [10 20 "hello"]))
  (assert (= l1 [10 20 "hello"]))

  (def l-meta (with-meta l1 {:my :meta}))
  (u/log "l-meta meta:" (meta l-meta))
  (assert (= {:my :meta} (meta l-meta)))
  (u/log "l-meta content:" (vec l-meta))
  (assert (= (vec l1) (vec l-meta)))

  (u/log "l1 pr-str:" (pr-str l1))
  (u/log "l-meta pr-str:" (pr-str l-meta))
  (u/log "l0 pr-str:" (pr-str l0))

  ;; You had a `com.seniorcaremarket.eve.list8/MyListItem` here.
  ;; For AbList tests, we'd need that record def in this namespace or a common data ns
  ;; if we want to test AbList with records *directly*.
  ;; For now, AbList will serialize elements using whatever `raw/object->bytes` does
  ;; for them based on globally registered handlers.

  ;; (def record-for-list (com.seniorcaremarket.eve.some.test.records/->MyTestRecord 123 "test"))
  ;; (def ab-with-record (ab-list record-for-list 99))
  ;; (u/log "ab-with-record:" (pr-str ab-with-record))
  ;; (u/log "ab-with-record peek:" (peek ab-with-record))
  ;; (u/log "ab-with-record first element:" (nth ab-with-record 0))
  ;; (assert (= record-for-list (nth ab-with-record 0)))

  (u/log "--- AbList Tests Complete ---")
  (u/log "Equality test l1 vs l3:" (= l1 l3))
  (u/log "Meta l1:" (meta l1) "Meta l3:" (meta l3))
  (u/log "Hash l1:" (hash l1) "Hash l3:" (hash l3))
  (u/log "l1 content:" (vec l1))
  (u/log "l3 content:" (vec l3))
  (assert (= l1 l3) "Assert failed: l1 should be equal to l3")
  ;; ...
  :done)

;; Fressian handlers removed — serialization now uses ser/ fast-path (Phase 5)

(ns com.seniorcaremarket.eve.in
  (:require
    [com.seniorcaremarket.eve.macro-impl :as i]))

(defmacro in [id & x]
  (let [[conveyer names opts body] (i/globals-locals-and-args &env x)
        yield? (i/yields? x)
        yfn `(fn ~names ~@body)]
    `(com.seniorcaremarket.eve.in/post-msg ~id ~conveyer (clojure.core/str "(function(){return " ~yfn " })()") (assoc ~opts :yield? ~yield?))))

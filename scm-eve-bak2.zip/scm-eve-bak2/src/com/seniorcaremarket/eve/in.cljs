(ns com.seniorcaremarket.eve.in
  (:require-macros [com.seniorcaremarket.eve.in :refer [in]])
  (:require
   [cljs.nodejs :as nodejs]
   [clojure.walk]
   [com.seniorcaremarket.eve.ab-list :as ab]
   [com.seniorcaremarket.eve.conveyance :as conv]))

(def worker-threads (nodejs/require "worker_threads"))
(def Worker (.-Worker worker-threads))

(defn handle-message [msg]
  (case (:type msg)
    "println" (println (:msg msg))
    "error" (js/console.error (:msg msg))
    (println "[MAIN] NO HANDLER FOR:" msg)))

(def worker-ids (atom 999))

(defn next-id []
  (swap! worker-ids inc))

(defn transferable?
  "Tests whether a given value is a typed array or transferable."
  [value]
  (let [value-type (type value)]
    (or (= value-type js/Int8Array)
        (= value-type js/Uint8Array)
        (= value-type js/Uint8ClampedArray)
        (= value-type js/Int16Array)
        (= value-type js/Uint16Array)
        (= value-type js/Int32Array)
        (= value-type js/Uint32Array)
        (= value-type js/Float32Array)
        (= value-type js/Float64Array)
        (= value-type js/BigInt64Array)
        (= value-type js/BigUint64Array)
        (= value-type js/ArrayBuffer)
        (= value-type js/DataView)
        (= value-type js/MessagePort)
        (= value-type js/ReadableStream)
        (= value-type js/WritableStream)
        (= value-type js/TransformStream))))

(defn post-msg [w conveyer sfn opts]
  (let [conveyer* (mapv (comp conv/conveyable-> ab/conveyable->) conveyer)
        transferables (clj->js (filterv transferable? conveyer))]
    (.postMessage w
                  (clj->js {:type "do" :sfn sfn :conveyer (clj->js conveyer*) :opts (clj->js opts)})
                  transferables)))

(defn do-on [w afn]
  (let [sfn (str "(" afn ")();")]
    (post-msg w [] sfn {})))

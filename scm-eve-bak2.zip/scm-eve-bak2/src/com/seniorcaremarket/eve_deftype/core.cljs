(ns com.seniorcaremarket.eve-deftype.core
  (:require-macros [com.seniorcaremarket.eve-deftype.core]))

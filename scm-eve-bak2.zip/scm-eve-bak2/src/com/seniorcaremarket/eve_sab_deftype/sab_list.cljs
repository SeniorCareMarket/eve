(ns com.seniorcaremarket.eve-sab-deftype.sab-list
  "SAB-backed persistent list with fast-path serialization.

   Built on eve-sab-deftype with full feature parity:
   - Supports arbitrary CLJS values (via fast-path serialization)
   - Fast-path for primitives (nil, bool, int32, float64, string, keyword)
   - O(1) cons/first/rest operations

   Architecture:
   - SabList: count + head-offset (list handle)
   - Nodes: next-offset + serialized value"
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser])
  (:require-macros
   [com.seniorcaremarket.eve-sab-deftype.core :refer [eve-sab-deftype]]))

;; Forward declarations
(declare ->SabList SabList empty-sab-list)
(declare ->SabListN SabListN empty-sab-list-n)

;;-----------------------------------------------------------------------------
;; Allocation helpers
;;-----------------------------------------------------------------------------

;; Offset → descriptor-idx tracking for O(1) retirement/freeing.
(defonce ^:private offset->desc (js/Map.))

(defn- alloc-bytes!
  "Allocate n bytes with 4-byte alignment. Returns #js [offset descriptor-idx].
   Tracks offset→descriptor-idx mapping for O(1) retirement/freeing."
  [s-atom-env n]
  (let [size-needed (+ n 4)
        alloc-result (atom/alloc s-atom-env size-needed)]
    (when (:error alloc-result)
      (throw (js/Error. (str "List allocation failed: " (:error alloc-result)))))
    (let [off (:offset alloc-result)
          desc-idx (:descriptor-idx alloc-result)]
      (.set offset->desc off desc-idx)
      #js [off desc-idx])))

(defn- copy-from-sab
  "Copy bytes from WASM memory to a regular ArrayBuffer-backed Uint8Array."
  [^number offset ^number len]
  (let [src (.subarray (wasm/u8-view) offset (+ offset len))
        dst (js/Uint8Array. len)]
    (.set dst src 0)
    dst))

;;-----------------------------------------------------------------------------
;; Node operations
;; Node layout: [next-off:i32][val-len:u32][val-bytes...]
;;-----------------------------------------------------------------------------

(defn- make-list-node!
  "Create a list node with serialized value and next pointer."
  [s-atom-env ^js val-bytes next-off]
  (let [val-len (.-length val-bytes)
        node-size (+ 4 4 val-len)  ;; next + val-len + val
        offset (aget (alloc-bytes! s-atom-env node-size) 0)
        dv (wasm/data-view)
        u8 (wasm/u8-view)]
    (.setInt32 dv offset next-off true)
    (.setUint32 dv (+ offset 4) val-len true)
    (when (pos? val-len)
      (.set u8 val-bytes (+ offset 8)))
    offset))

(defn- read-node-next [^js dv node-off]
  (.getInt32 dv node-off true))

(defn- read-node-value
  "Read the value from a node. Returns [value val-len]."
  [s-atom-env ^js dv node-off]
  (let [val-len (.getUint32 dv (+ node-off 4) true)
        val-bytes (copy-from-sab (+ node-off 8) val-len)
        value (ser/deserialize-element s-atom-env val-bytes)]
    [value val-len]))

;;-----------------------------------------------------------------------------
;; List type - the persistent list handle
;;-----------------------------------------------------------------------------

(declare dispose!)

(eve-sab-deftype SabList
  [^:int32 cnt         ;; element count
   ^:int32 head-off]   ;; offset to first node, -1 for empty

  ISequential

  ICounted
  (-count [_] cnt)

  IStack
  (-peek [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            [value _] (read-node-value s-atom-env dv head-off)]
        value)))

  (-pop [_]
    (cond
      (zero? cnt)
      (throw (js/Error. "Can't pop empty list"))

      (== cnt 1)
      (empty-sab-list)

      :else
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            new-head (read-node-next dv head-off)]
        (->SabList (dec cnt) new-head))))

  ICollection
  (-conj [_ val]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          val-bytes (ser/serialize-element val)
          new-off (make-list-node! s-atom-env val-bytes head-off)]
      (->SabList (inc cnt) new-off)))

  IEmptyableCollection
  (-empty [_]
    (empty-sab-list))

  ISeq
  (-first [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            [value _] (read-node-value s-atom-env dv head-off)]
        value)))

  (-rest [_]
    (if (zero? cnt)
      (empty-sab-list)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            new-head (read-node-next dv head-off)
            new-cnt (dec cnt)]
        (if (== new-head -1)
          (empty-sab-list)
          (->SabList new-cnt new-head)))))

  INext
  (-next [_]
    (when (> cnt 1)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            new-head (read-node-next dv head-off)]
        (when (not= new-head -1)
          (->SabList (dec cnt) new-head)))))

  ISeqable
  (-seq [this]
    (when (pos? cnt)
      this))

  IReduce
  (-reduce [_ f]
    (if (zero? cnt)
      (f)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (loop [node-off head-off
               acc nil
               first? true]
          (if (== node-off -1)
            acc
            (let [[val _] (read-node-value s-atom-env dv node-off)
                  next-off (read-node-next dv node-off)]
              (if first?
                (recur next-off val false)
                (let [acc' (f acc val)]
                  (if (reduced? acc')
                    @acc'
                    (recur next-off acc' false))))))))))

  (-reduce [_ f init]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (loop [node-off head-off
             acc init]
        (if (or (== node-off -1) (reduced? acc))
          (if (reduced? acc) @acc acc)
          (let [[val _] (read-node-value s-atom-env dv node-off)
                next-off (read-node-next dv node-off)]
            (recur next-off (f acc val)))))))

  IEquiv
  (-equiv [this other]
    (cond
      (identical? this other) true
      (not (sequential? other)) false
      :else
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (loop [node-off head-off
               other-seq (seq other)]
          (cond
            (and (== node-off -1) (nil? other-seq)) true
            (or (== node-off -1) (nil? other-seq)) false
            :else
            (let [[val _] (read-node-value s-atom-env dv node-off)]
              (if (= val (first other-seq))
                (recur (read-node-next dv node-off) (next other-seq))
                false)))))))

  IHash
  (-hash [this]
    (hash-ordered-coll this))

  IFn
  (-invoke [this n]
    (nth this n))
  (-invoke [this n not-found]
    (nth this n not-found))

  IIndexed
  (-nth [_ n]
    (if (or (neg? n) (>= n cnt))
      (throw (js/Error. (str "Index out of bounds: " n)))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (loop [node-off head-off
               i 0]
          (if (== i n)
            (let [[val _] (read-node-value s-atom-env dv node-off)]
              val)
            (recur (read-node-next dv node-off) (inc i)))))))

  (-nth [this n not-found]
    (if (or (neg? n) (>= n cnt))
      not-found
      (-nth this n)))

  IPrintWithWriter
  (-pr-writer [_ writer opts]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (-write writer "(")
      (loop [node-off head-off
             i 0]
        (when (and (not= node-off -1) (< i 10))
          (when (pos? i) (-write writer " "))
          (let [[val _] (read-node-value s-atom-env dv node-off)]
            (-write writer (pr-str val))
            (recur (read-node-next dv node-off) (inc i)))))
      (when (> cnt 10)
        (-write writer " ..."))
      (-write writer ")")))

  d/IDirectSerialize
  (-direct-serialize [this]
    (ser/encode-sab-pointer ser/FAST_TAG_SAB_LIST (.-offset__ this)))

  d/ISabStorable
  (-sab-tag [_] :sab-list)
  (-sab-encode [this _s-atom-env]
    (d/-direct-serialize this))
  (-sab-dispose [this _s-atom-env]
    (dispose! this))

  d/ISabRetirable
  (-sab-retire-diff! [this new-value s-atom-env mode]
    (let [old-head head-off
          new-head (when (instance? SabList new-value)
                     (let [dv (wasm/data-view)]
                       (.getInt32 dv (+ (SabList-offset new-value) 8) true)))]
      (if new-head
        ;; Both are SabList — retire replaced chain nodes
        (retire-replaced-chain! s-atom-env old-head new-head mode)
        ;; Different type — dispose entire old chain
        (dispose! this)))))

;;-----------------------------------------------------------------------------
;; Disposal - explicit cleanup for reclaiming SAB memory
;;-----------------------------------------------------------------------------

(defn- find-desc-idx
  "Look up descriptor-idx for a given offset. O(1) from tracking map,
   falls back to linear scan for nodes not in the map."
  [s-atom-env node-off]
  (if (.has offset->desc node-off)
    (.get offset->desc node-off)
    (when-let [desc (u/find-descriptor-for-data-offset s-atom-env node-off)]
      (:descriptor-idx desc))))

(defn- free-block!
  "Free a single allocation block by its SAB offset.
   Uses offset→desc map for O(1) descriptor lookup."
  [s-atom-env offset]
  (when (> offset -1)
    (when-let [desc-idx (find-desc-idx s-atom-env offset)]
      (.delete offset->desc offset)
      (atom/free s-atom-env desc-idx))))

(defn- free-list-chain!
  "Free all nodes in a SabList linked list chain."
  [s-atom-env head-off]
  (let [dv (wasm/data-view)]
    (loop [node-off head-off]
      (when (not= node-off -1)
        (let [next-off (read-node-next dv node-off)]
          (free-block! s-atom-env node-off)
          (recur next-off))))))

(defn- free-chunk-chain!
  "Free all chunks and their value blocks in a SabListN chain."
  [s-atom-env head-off head-idx chunk-size]
  (let [dv (wasm/data-view)]
    (loop [chunk-off head-off
           idx head-idx]
      (when (not= chunk-off -1)
        (let [chunk-cnt (chunk-get-count dv chunk-off)
              next-chunk (chunk-get-next dv chunk-off)]
          ;; Free value blocks in this chunk
          (loop [i idx]
            (when (< i chunk-size)
              (let [val-off (chunk-get-offset dv chunk-off chunk-size i)]
                (when (> val-off -1)
                  (free-block! s-atom-env val-off)))
              (recur (inc i))))
          ;; Free the chunk itself
          (free-block! s-atom-env chunk-off)
          ;; Continue to next chunk (always starts at idx 0)
          (recur next-chunk 0))))))

(defn dispose!
  "Dispose a SabList or SabListN, freeing all nodes/chunks.
   Call this when the list is no longer needed to reclaim SAB memory.

   WARNING: After disposal, the list must not be used. Any access will
   result in undefined behavior or errors."
  [sab-list]
  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
        dv (wasm/data-view)
        base-off (.-offset__ sab-list)]
    (cond
      ;; SabList (linked list) — head-off at offset +8
      (instance? SabList sab-list)
      (let [head-off (.getInt32 dv (+ base-off 8) true)]
        (when (not= head-off -1)
          (free-list-chain! s-atom-env head-off)))

      ;; SabListN (chunked list) — head-off+8, head-idx+12, chunk-size+16
      (instance? SabListN sab-list)
      (let [head-off (.getInt32 dv (+ base-off 8) true)
            head-idx (.getInt32 dv (+ base-off 12) true)
            cs (.getInt32 dv (+ base-off 16) true)]
        (when (not= head-off -1)
          (free-chunk-chain! s-atom-env head-off head-idx cs))))))

(defn retire-replaced-chain!
  "After an atom swap that replaced a list, retire old nodes not shared
   by the new list.

   For cons: old-head == new-head.next, so nothing to retire.
   For pop/rest: new-head == old-head.next, so retire old-head only.
   For general changes: walk old chain, retire nodes not in new chain.

   mode: :retire (epoch-based, for multi-worker) or :free (immediate)"
  ([s-atom-env old-head new-head]
   (retire-replaced-chain! s-atom-env old-head new-head :free))
  ([s-atom-env old-head new-head mode]
   (when (and (not= old-head -1) (not= old-head new-head))
     (let [dv (wasm/data-view)]
       ;; Walk old chain, retiring nodes until we hit a shared node
       (loop [node-off old-head]
         (when (and (not= node-off -1) (not= node-off new-head))
           (let [next-off (read-node-next dv node-off)]
             ;; Retire/free this old node
             (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
               (if (= mode :retire)
                 (atom/retire-block! s-atom-env desc-idx)
                 (do (.delete offset->desc node-off)
                     (atom/free s-atom-env desc-idx))))
             (recur next-off))))))))

;;-----------------------------------------------------------------------------
;; Constructors
;;-----------------------------------------------------------------------------

(defn empty-sab-list
  "Create an empty SabList."
  []
  (->SabList 0 -1))

(defn sab-list
  "Create a SabList from a sequence of values.
   Note: Elements are added in reverse order (like Clojure's list)."
  [coll]
  (reduce conj (empty-sab-list) (reverse (vec coll))))

(defn into-sab-list
  "Conj all elements onto a list (faster, but reverses order)."
  [coll]
  (reduce conj (empty-sab-list) coll))

;;-----------------------------------------------------------------------------
;; Chunked List - Configurable Chunk Size with Columnar Layout
;;
;; SabListN groups elements into chunks for better cache locality.
;; Uses columnar layout for SIMD-friendly scanning.
;;
;; COLUMNAR CHUNK LAYOUT (optimized for SIMD):
;;   Header (16 bytes, aligned):
;;     [next-chunk-off:i32]     - offset to next chunk, -1 for end
;;     [chunk-count:u16]        - number of elements in this chunk
;;     [padding:u16]            - alignment padding
;;     [flags:u32]              - reserved for future SIMD hints
;;     [data-region-off:i32]    - offset to data region start
;;
;;   Columnar Arrays (each is SIMD-scannable):
;;     [types: capacity * u8]   - type tags (SIMD: find all ints, all strings, etc.)
;;     [padding to 4-byte align]
;;     [lengths: capacity * u32] - serialized lengths (SIMD: prefix sum for offsets)
;;     [offsets: capacity * i32] - offsets into data region (SIMD: gather)
;;
;;   Data Region:
;;     [data: variable bytes]   - packed serialized elements
;;
;; The columnar layout enables:
;;   1. SIMD type filtering: Find all elements of a specific type
;;   2. SIMD prefix sum: Calculate data offsets from lengths
;;   3. SIMD gather: Load multiple elements at once
;;
;; Note: Elements are stored front-to-back within chunks, newest chunk first.
;;-----------------------------------------------------------------------------

;; Columnar chunk layout constants
(def ^:private ^:const CHUNK_HEADER_SIZE 16)      ;; next + count + pad + flags + data-region-off
(def ^:private ^:const CHUNK_NEXT_OFFSET 0)
(def ^:private ^:const CHUNK_COUNT_OFFSET 4)
(def ^:private ^:const CHUNK_FLAGS_OFFSET 8)
(def ^:private ^:const CHUNK_DATA_REGION_OFFSET 12)

(defn- types-array-offset
  "Offset to types array within chunk."
  [chunk-off]
  (+ chunk-off CHUNK_HEADER_SIZE))

(defn- types-array-size
  "Size of types array (padded to 4-byte alignment)."
  [capacity]
  (let [raw-size capacity
        remainder (mod raw-size 4)]
    (if (zero? remainder)
      raw-size
      (+ raw-size (- 4 remainder)))))

(defn- lengths-array-offset
  "Offset to lengths array within chunk."
  [chunk-off capacity]
  (+ (types-array-offset chunk-off) (types-array-size capacity)))

(defn- offsets-array-offset
  "Offset to offsets array within chunk."
  [chunk-off capacity]
  (+ (lengths-array-offset chunk-off capacity) (* capacity 4)))

(defn- alloc-columnar-chunk!
  "Allocate a columnar chunk with capacity.
   Layout: header | types[capacity] | pad | lengths[capacity] | offsets[capacity]"
  [s-atom-env capacity]
  (let [types-size (types-array-size capacity)
        lengths-size (* capacity 4)
        offsets-size (* capacity 4)
        total-size (+ CHUNK_HEADER_SIZE types-size lengths-size offsets-size)
        offset (aget (alloc-bytes! s-atom-env total-size) 0)
        dv (wasm/data-view)]
    ;; Initialize header
    (.setInt32 dv (+ offset CHUNK_NEXT_OFFSET) -1 true)       ;; next = -1
    (.setUint16 dv (+ offset CHUNK_COUNT_OFFSET) 0 true)      ;; count = 0
    (.setUint16 dv (+ offset (+ CHUNK_COUNT_OFFSET 2)) 0 true) ;; padding
    (.setUint32 dv (+ offset CHUNK_FLAGS_OFFSET) 0 true)      ;; flags = 0
    (.setInt32 dv (+ offset CHUNK_DATA_REGION_OFFSET) -1 true) ;; data-region = -1
    ;; Initialize arrays
    (let [types-off (types-array-offset offset)
          lengths-off (lengths-array-offset offset capacity)
          offsets-off (offsets-array-offset offset capacity)]
      ;; Zero out types
      (dotimes [i (types-array-size capacity)]
        (.setUint8 dv (+ types-off i) 0))
      ;; Zero out lengths
      (dotimes [i capacity]
        (.setUint32 dv (+ lengths-off (* i 4)) 0 true))
      ;; Initialize offsets to -1
      (dotimes [i capacity]
        (.setInt32 dv (+ offsets-off (* i 4)) -1 true)))
    offset))

(defn- chunk-get-next [^js dv chunk-off]
  (.getInt32 dv (+ chunk-off CHUNK_NEXT_OFFSET) true))

(defn- chunk-get-count [^js dv chunk-off]
  (.getUint16 dv (+ chunk-off CHUNK_COUNT_OFFSET) true))

(defn- chunk-set-next! [^js dv chunk-off next-off]
  (.setInt32 dv (+ chunk-off CHUNK_NEXT_OFFSET) next-off true))

(defn- chunk-set-count! [^js dv chunk-off cnt]
  (.setUint16 dv (+ chunk-off CHUNK_COUNT_OFFSET) cnt true))

(defn- chunk-get-type [^js dv chunk-off capacity idx]
  (.getUint8 dv (+ (types-array-offset chunk-off) idx)))

(defn- chunk-set-type! [^js dv chunk-off capacity idx type-tag]
  (.setUint8 dv (+ (types-array-offset chunk-off) idx) type-tag))

(defn- chunk-get-length [^js dv chunk-off capacity idx]
  (.getUint32 dv (+ (lengths-array-offset chunk-off capacity) (* idx 4)) true))

(defn- chunk-set-length! [^js dv chunk-off capacity idx len]
  (.setUint32 dv (+ (lengths-array-offset chunk-off capacity) (* idx 4)) len true))

(defn- chunk-get-offset [^js dv chunk-off capacity idx]
  (.getInt32 dv (+ (offsets-array-offset chunk-off capacity) (* idx 4)) true))

(defn- chunk-set-offset! [^js dv chunk-off capacity idx data-off]
  (.setInt32 dv (+ (offsets-array-offset chunk-off capacity) (* idx 4)) data-off true))

;; Type tags for fast SIMD filtering
(def ^:private ^:const TYPE_NIL 0)
(def ^:private ^:const TYPE_BOOL 1)
(def ^:private ^:const TYPE_INT32 2)
(def ^:private ^:const TYPE_FLOAT64 3)
(def ^:private ^:const TYPE_STRING 4)
(def ^:private ^:const TYPE_KEYWORD 5)
(def ^:private ^:const TYPE_OTHER 255)

(defn- get-type-tag
  "Get type tag for a serialized value."
  [^js val-bytes]
  (cond
    (or (nil? val-bytes) (zero? (.-length val-bytes)))
    TYPE_NIL

    (and (>= (.-length val-bytes) 3)
         (== (aget val-bytes 0) d/DIRECT_MAGIC_0)
         (== (aget val-bytes 1) d/DIRECT_MAGIC_1))
    (let [tag (aget val-bytes 2)]
      (case tag
        (1 2) TYPE_BOOL
        3     TYPE_INT32
        4     TYPE_FLOAT64
        (5 6) TYPE_STRING
        (7 8) TYPE_KEYWORD
        TYPE_OTHER))

    :else TYPE_OTHER))

(defn- make-value-block!
  "Allocate and write a serialized value. Returns offset."
  [s-atom-env ^js val-bytes]
  (let [val-len (.-length val-bytes)
        offset (aget (alloc-bytes! s-atom-env (+ 4 val-len)) 0)
        dv (wasm/data-view)
        u8 (wasm/u8-view)]
    (.setUint32 dv offset val-len true)
    (when (pos? val-len)
      (.set u8 val-bytes (+ offset 4)))
    offset))

(defn- read-value-block
  "Read value from a value block offset."
  [s-atom-env ^js dv val-off]
  (let [val-len (.getUint32 dv val-off true)
        val-bytes (copy-from-sab (+ val-off 4) val-len)]
    (ser/deserialize-element s-atom-env val-bytes)))

(defn- clone-columnar-chunk!
  "Clone a columnar chunk, copying all arrays."
  [s-atom-env ^js dv src-off capacity]
  (let [new-off (alloc-columnar-chunk! s-atom-env capacity)
        cnt (chunk-get-count dv src-off)]
    ;; Copy next pointer (critical for linked list)
    (chunk-set-next! dv new-off (chunk-get-next dv src-off))
    ;; Copy count
    (chunk-set-count! dv new-off cnt)
    ;; Copy columnar data for each element
    (dotimes [i capacity]
      (chunk-set-type! dv new-off capacity i (chunk-get-type dv src-off capacity i))
      (chunk-set-length! dv new-off capacity i (chunk-get-length dv src-off capacity i))
      (chunk-set-offset! dv new-off capacity i (chunk-get-offset dv src-off capacity i)))
    new-off))

(eve-sab-deftype SabListN
  [^:int32 cnt        ;; total element count
   ^:int32 head-off   ;; offset to first chunk, -1 for empty
   ^:int32 head-idx   ;; index of first element within head chunk
   ^:int32 chunk-size] ;; elements per chunk (capacity)

  ISequential

  ICounted
  (-count [_] cnt)

  IStack
  (-peek [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            val-off (chunk-get-offset dv head-off chunk-size head-idx)]
        (read-value-block s-atom-env dv val-off))))

  (-pop [_]
    (cond
      (zero? cnt)
      (throw (js/Error. "Can't pop empty list"))

      (== cnt 1)
      (empty-sab-list-n chunk-size)

      :else
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            chunk-cnt (chunk-get-count dv head-off)
            ;; Elements in this chunk from head-idx to end
            elems-in-chunk (- chunk-cnt head-idx)]
        (if (> elems-in-chunk 1)
          ;; More elements in this chunk
          (->SabListN (dec cnt) head-off (inc head-idx) chunk-size)
          ;; Move to next chunk
          (let [next-chunk (chunk-get-next dv head-off)]
            (->SabListN (dec cnt) next-chunk 0 chunk-size))))))

  ICollection
  (-conj [_ val]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          val-bytes (ser/serialize-element val)
          type-tag (get-type-tag val-bytes)
          val-off (make-value-block! s-atom-env val-bytes)]
      (if (or (== head-off -1) (zero? head-idx))
        ;; Need new chunk (empty list or current chunk's front is full)
        (let [new-chunk (alloc-columnar-chunk! s-atom-env chunk-size)
              new-idx (dec chunk-size)]
          (chunk-set-type! dv new-chunk chunk-size new-idx type-tag)
          (chunk-set-length! dv new-chunk chunk-size new-idx (.-length val-bytes))
          (chunk-set-offset! dv new-chunk chunk-size new-idx val-off)
          (chunk-set-count! dv new-chunk 1)
          (chunk-set-next! dv new-chunk head-off)
          (->SabListN (inc cnt) new-chunk new-idx chunk-size))
        ;; Room in current chunk - create new chunk with shifted data
        (let [new-chunk (clone-columnar-chunk! s-atom-env dv head-off chunk-size)
              new-idx (dec head-idx)]
          (chunk-set-type! dv new-chunk chunk-size new-idx type-tag)
          (chunk-set-length! dv new-chunk chunk-size new-idx (.-length val-bytes))
          (chunk-set-offset! dv new-chunk chunk-size new-idx val-off)
          (chunk-set-count! dv new-chunk (inc (chunk-get-count dv head-off)))
          (->SabListN (inc cnt) new-chunk new-idx chunk-size)))))

  IEmptyableCollection
  (-empty [_]
    (empty-sab-list-n chunk-size))

  ISeq
  (-first [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            val-off (chunk-get-offset dv head-off chunk-size head-idx)]
        (read-value-block s-atom-env dv val-off))))

  (-rest [_]
    (if (zero? cnt)
      (empty-sab-list-n chunk-size)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            chunk-cnt (chunk-get-count dv head-off)
            elems-in-chunk (- chunk-cnt head-idx)]
        (if (> elems-in-chunk 1)
          (->SabListN (dec cnt) head-off (inc head-idx) chunk-size)
          (let [next-chunk (chunk-get-next dv head-off)]
            (if (== next-chunk -1)
              (empty-sab-list-n chunk-size)
              (->SabListN (dec cnt) next-chunk 0 chunk-size)))))))

  INext
  (-next [_]
    (when (> cnt 1)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            chunk-cnt (chunk-get-count dv head-off)
            elems-in-chunk (- chunk-cnt head-idx)]
        (if (> elems-in-chunk 1)
          (->SabListN (dec cnt) head-off (inc head-idx) chunk-size)
          (let [next-chunk (chunk-get-next dv head-off)]
            (when (not= next-chunk -1)
              (->SabListN (dec cnt) next-chunk 0 chunk-size)))))))

  ISeqable
  (-seq [this]
    (when (pos? cnt)
      this))

  IReduce
  (-reduce [_ f]
    (if (zero? cnt)
      (f)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (loop [chunk-off head-off
               idx head-idx
               acc nil
               first? true
               remaining cnt]
          (if (zero? remaining)
            acc
            (let [val-off (chunk-get-offset dv chunk-off chunk-size idx)
                  val (read-value-block s-atom-env dv val-off)
                  chunk-cnt (chunk-get-count dv chunk-off)
                  elems-left (- chunk-size idx)]
              (if first?
                (if (> elems-left 1)
                  (recur chunk-off (inc idx) val false (dec remaining))
                  (recur (chunk-get-next dv chunk-off) 0 val false (dec remaining)))
                (let [acc' (f acc val)]
                  (if (reduced? acc')
                    @acc'
                    (if (> elems-left 1)
                      (recur chunk-off (inc idx) acc' false (dec remaining))
                      (recur (chunk-get-next dv chunk-off) 0 acc' false (dec remaining))))))))))))

  (-reduce [_ f init]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (loop [chunk-off head-off
             idx head-idx
             acc init
             remaining cnt]
        (if (or (zero? remaining) (reduced? acc))
          (if (reduced? acc) @acc acc)
          (let [val-off (chunk-get-offset dv chunk-off chunk-size idx)
                val (read-value-block s-atom-env dv val-off)
                chunk-cnt (chunk-get-count dv chunk-off)
                elems-left (- chunk-size idx)
                acc' (f acc val)]
            (if (> elems-left 1)
              (recur chunk-off (inc idx) acc' (dec remaining))
              (recur (chunk-get-next dv chunk-off) 0 acc' (dec remaining))))))))

  IEquiv
  (-equiv [this other]
    (cond
      (identical? this other) true
      (not (sequential? other)) false
      :else
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (loop [chunk-off head-off
               idx head-idx
               other-seq (seq other)
               remaining cnt]
          (cond
            (and (zero? remaining) (nil? other-seq)) true
            (or (zero? remaining) (nil? other-seq)) false
            :else
            (let [val-off (chunk-get-offset dv chunk-off chunk-size idx)
                  val (read-value-block s-atom-env dv val-off)
                  chunk-cnt (chunk-get-count dv chunk-off)
                  elems-left (- chunk-size idx)]
              (if (= val (first other-seq))
                (if (> elems-left 1)
                  (recur chunk-off (inc idx) (next other-seq) (dec remaining))
                  (recur (chunk-get-next dv chunk-off) 0 (next other-seq) (dec remaining)))
                false)))))))

  IHash
  (-hash [this]
    (hash-ordered-coll this))

  IFn
  (-invoke [this n]
    (nth this n))
  (-invoke [this n not-found]
    (nth this n not-found))

  IIndexed
  (-nth [_ n]
    (if (or (neg? n) (>= n cnt))
      (throw (js/Error. (str "Index out of bounds: " n)))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        ;; Navigate through chunks to find element at index n
        (loop [chunk-off head-off
               chunk-idx head-idx
               remaining-in-chunk (- (chunk-get-count dv head-off) head-idx)
               target n]
          (if (< target remaining-in-chunk)
            ;; Element is in this chunk
            (let [val-off (chunk-get-offset dv chunk-off chunk-size (+ chunk-idx target))]
              (read-value-block s-atom-env dv val-off))
            ;; Element is in a later chunk
            (let [next-chunk (chunk-get-next dv chunk-off)]
              (recur next-chunk 0 (chunk-get-count dv next-chunk) (- target remaining-in-chunk))))))))

  (-nth [this n not-found]
    (if (or (neg? n) (>= n cnt))
      not-found
      (-nth this n)))

  IPrintWithWriter
  (-pr-writer [_ writer opts]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (-write writer (str "(#sab/list-" chunk-size " "))
      (loop [chunk-off head-off
             idx head-idx
             i 0
             remaining cnt]
        (when (and (pos? remaining) (< i 10))
          (when (pos? i) (-write writer " "))
          (let [val-off (chunk-get-offset dv chunk-off chunk-size idx)
                val (read-value-block s-atom-env dv val-off)
                chunk-cnt (chunk-get-count dv chunk-off)
                elems-left (- chunk-size idx)]
            (-write writer (pr-str val))
            (if (> elems-left 1)
              (recur chunk-off (inc idx) (inc i) (dec remaining))
              (recur (chunk-get-next dv chunk-off) 0 (inc i) (dec remaining))))))
      (when (> cnt 10)
        (-write writer " ..."))
      (-write writer ")"))))

;;-----------------------------------------------------------------------------
;; Chunked List Constructors
;;-----------------------------------------------------------------------------

(defn empty-sab-list-n
  "Create an empty chunked SabListN with specified chunk size.
   Valid sizes: 32, 64, 128, 256, 512, 1024"
  [chunk-size]
  (->SabListN 0 -1 0 chunk-size))

(defn sab-list-n
  "Create a SabListN from a sequence with specified chunk size.
   Valid sizes: 32, 64, 128, 256, 512, 1024"
  [chunk-size coll]
  (reduce conj (empty-sab-list-n chunk-size) (reverse coll)))

(defn into-sab-list-n
  "Conj all elements onto a chunked list (faster, but reverses order)."
  [chunk-size coll]
  (reduce conj (empty-sab-list-n chunk-size) coll))

;;-----------------------------------------------------------------------------
;; SAB Pointer Registration
;;-----------------------------------------------------------------------------

(ser/register-sab-type-constructor!
  ser/FAST_TAG_SAB_LIST
  (fn [sab offset] (SabList. sab offset)))

(ser/register-cljs-to-sab-builder!
  list?
  (fn [l] (sab-list l)))

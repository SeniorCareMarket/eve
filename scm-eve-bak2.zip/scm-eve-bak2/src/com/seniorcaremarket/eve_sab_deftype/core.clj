(ns com.seniorcaremarket.eve-sab-deftype.core
  "eve-sab-deftype: SAB-backed types with fast-path serialization.

   This is the structural layer that provides:
   - Memory management (allocation from global atom)
   - Concurrency management (reader tracking, orphaning)
   - Typed field access with full Atomics API

   Used to build lock-free persistent data structures like sab-vec, sab-map.

   Field types:
     ^:int8, ^:uint8, ^:int16, ^:uint16     - small integers
     ^:int32, ^:uint32                       - 32-bit integers (Atomics-capable)
     ^:float32, ^:float64                    - floating point
     ^:SomeType                              - reference to another eve-sab-deftype (offset)

   Mutability:
     (default)          - immutable after construction
     ^:mutable          - mutable via set! (single worker)
     ^:volatile-mutable - atomic via set!/cas! (multi-worker safe)")

;;-----------------------------------------------------------------------------
;; Type Registry (compile-time)
;;-----------------------------------------------------------------------------

(defonce ^:private type-registry (atom {}))
(defonce ^:private next-type-id (atom 1))

(defn- register-type! [type-name type-info]
  (swap! type-registry assoc type-name type-info))

(defn- lookup-type [type-name]
  (get @type-registry type-name))

(defn- next-type-id! []
  (let [id @next-type-id]
    (swap! next-type-id inc)
    id))

;;-----------------------------------------------------------------------------
;; Field Parsing
;;-----------------------------------------------------------------------------

(def ^:private primitive-types
  #{:int8 :uint8 :int16 :uint16 :int32 :uint32 :float32 :float64})

(def ^:private type-sizes
  {:int8 1, :uint8 1, :int16 2, :uint16 2,
   :int32 4, :uint32 4, :float32 4, :float64 8,
   :ref 4}) ;; references are int32 offsets

(def ^:private type-alignments
  {:int8 1, :uint8 1, :int16 2, :uint16 2,
   :int32 4, :uint32 4, :float32 4, :float64 8,
   :ref 4})

(defn- parse-field
  "Parse a field symbol with metadata into a field spec."
  [field-sym]
  (let [m (meta field-sym)
        field-name (name field-sym)
        ;; Check for primitive type hints
        type-hint (first (filter primitive-types (keys m)))
        ;; Check for eve-type reference (capitalized keyword like :TreeNode)
        eve-type-hint (first (filter #(and (keyword? %)
                                           (Character/isUpperCase (first (name %))))
                                     (keys m)))
        ;; Determine mutability
        mutability (cond
                     (:volatile-mutable m) :volatile-mutable
                     (:mutable m) :mutable
                     :else :immutable)]
    {:name field-name
     :type-hint (or type-hint eve-type-hint :int32) ;; default to int32
     :type-class (cond
                   type-hint :primitive
                   eve-type-hint :eve-type
                   :else :primitive) ;; default to primitive
     :mutability mutability}))

(defn- align-offset [offset alignment]
  (let [rem (mod offset alignment)]
    (if (zero? rem) offset (+ offset (- alignment rem)))))

(defn- compute-layout
  "Compute field offsets. Returns {:fields [...] :total-size n}."
  [parsed-fields]
  ;; First byte reserved for type-id
  (loop [fields parsed-fields
         offset 1 ;; Start after type-id byte
         result []]
    (if (empty? fields)
      {:fields result
       :total-size (align-offset offset 4)} ;; Final 4-byte alignment
      (let [f (first fields)
            type-class (:type-class f)
            size (if (= :eve-type type-class)
                   4 ;; eve-type refs are int32 offsets
                   (type-sizes (:type-hint f) 4))
            alignment (if (= :eve-type type-class)
                        4
                        (type-alignments (:type-hint f) 4))
            aligned (align-offset offset alignment)]
        (recur (rest fields)
               (+ aligned size)
               (conj result (assoc f :offset aligned :size size)))))))

;;-----------------------------------------------------------------------------
;; Code Generation Helpers
;;-----------------------------------------------------------------------------

(defn- read-fn-for-type
  "Return the read expression for a field type."
  [{:keys [type-hint type-class mutability]} sab-expr offset-expr field-offset]
  (let [volatile? (= :volatile-mutable mutability)
        abs-offset (list '+ offset-expr field-offset)]
    (case type-class
      :primitive
      (case type-hint
        :int8    (list '.getInt8 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset)
        :uint8   (list '.getUint8 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset)
        :int16   (list '.getInt16 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true)
        :uint16  (list '.getUint16 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true)
        :int32   (if volatile?
                   (list 'js/Atomics.load
                         (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
                         (list 'unsigned-bit-shift-right abs-offset 2))
                   (list '.getInt32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true))
        :uint32  (if volatile?
                   (list 'js/Atomics.load
                         (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
                         (list 'unsigned-bit-shift-right abs-offset 2))
                   (list '.getUint32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true))
        :float32 (list '.getFloat32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true)
        :float64 (list '.getFloat64 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true))
      :eve-type
      ;; Eve-type reads: load offset, -1 means nil
      (if volatile?
        (list 'js/Atomics.load
              (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
              (list 'unsigned-bit-shift-right abs-offset 2))
        (list '.getInt32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true))
      ;; Default to int32
      (if volatile?
        (list 'js/Atomics.load
              (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
              (list 'unsigned-bit-shift-right abs-offset 2))
        (list '.getInt32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset true)))))

(defn- write-fn-for-type
  "Return the write expression for a field type."
  [{:keys [type-hint type-class mutability]} sab-expr offset-expr field-offset val-expr]
  (let [volatile? (= :volatile-mutable mutability)
        abs-offset (list '+ offset-expr field-offset)]
    (case type-class
      :primitive
      (case type-hint
        :int8    (list '.setInt8 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr)
        :uint8   (list '.setUint8 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr)
        :int16   (list '.setInt16 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true)
        :uint16  (list '.setUint16 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true)
        :int32   (if volatile?
                   (list 'js/Atomics.store
                         (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
                         (list 'unsigned-bit-shift-right abs-offset 2)
                         val-expr)
                   (list '.setInt32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true))
        :uint32  (if volatile?
                   (list 'js/Atomics.store
                         (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
                         (list 'unsigned-bit-shift-right abs-offset 2)
                         val-expr)
                   (list '.setUint32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true))
        :float32 (list '.setFloat32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true)
        :float64 (list '.setFloat64 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true))
      :eve-type
      (if volatile?
        (list 'js/Atomics.store
              (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
              (list 'unsigned-bit-shift-right abs-offset 2)
              val-expr)
        (list '.setInt32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true))
      ;; Default to int32
      (if volatile?
        (list 'js/Atomics.store
              (list 'com.seniorcaremarket.eve.wasm-mem/i32-view)
              (list 'unsigned-bit-shift-right abs-offset 2)
              val-expr)
        (list '.setInt32 (list 'com.seniorcaremarket.eve.wasm-mem/data-view) abs-offset val-expr true)))))

(defn- field-bindings
  "Generate let-bindings for reading all fields."
  [fields sab-expr offset-expr]
  (vec (mapcat (fn [f]
                 [(symbol (:name f))
                  (read-fn-for-type f sab-expr offset-expr (:offset f))])
               fields)))

(defn- rewrite-set!-forms
  "Rewrite (set! field val) to SAB write operations."
  [form field-map sab-expr offset-expr]
  (cond
    ;; set! on a field
    (and (seq? form)
         (= 'set! (first form))
         (symbol? (second form))
         (contains? field-map (name (second form))))
    (let [field-spec (get field-map (name (second form)))
          val-expr (rewrite-set!-forms (nth form 2) field-map sab-expr offset-expr)]
      (when (= :immutable (:mutability field-spec))
        (throw (ex-info (str "Cannot set! immutable field: " (:name field-spec)) {})))
      (write-fn-for-type field-spec sab-expr offset-expr (:offset field-spec) val-expr))

    ;; cas! on a field
    (and (seq? form)
         (= 'cas! (first form))
         (symbol? (second form))
         (contains? field-map (name (second form))))
    (let [field-spec (get field-map (name (second form)))
          expected-expr (rewrite-set!-forms (nth form 2) field-map sab-expr offset-expr)
          new-expr (rewrite-set!-forms (nth form 3) field-map sab-expr offset-expr)
          abs-offset (list '+ offset-expr (:offset field-spec))]
      (when (not= :volatile-mutable (:mutability field-spec))
        (throw (ex-info "cas! requires ^:volatile-mutable field" {:field (:name field-spec)})))
      (list '==
            expected-expr
            (list 'js/Atomics.compareExchange
                  (list 'js/Int32Array. sab-expr)
                  (list 'unsigned-bit-shift-right abs-offset 2)
                  expected-expr new-expr)))

    ;; Recurse
    (seq? form)
    (with-meta (apply list (map #(rewrite-set!-forms % field-map sab-expr offset-expr) form))
               (meta form))
    (vector? form)
    (with-meta (mapv #(rewrite-set!-forms % field-map sab-expr offset-expr) form)
               (meta form))
    (map? form)
    (with-meta (into {} (map (fn [[k v]]
                               [(rewrite-set!-forms k field-map sab-expr offset-expr)
                                (rewrite-set!-forms v field-map sab-expr offset-expr)])
                             form))
               (meta form))
    :else form))

(defn- transform-method-body
  "Transform method body with field bindings and set!/cas! rewriting."
  [body fields field-map sab-expr offset-expr]
  (let [bindings (field-bindings fields sab-expr offset-expr)
        rewritten (map #(rewrite-set!-forms % field-map sab-expr offset-expr) body)]
    (if (empty? bindings)
      rewritten
      ;; Wrap body in let with field bindings
      (list (apply list 'let bindings (vec rewritten))))))

(defn- parse-protocol-impls [body]
  (loop [remaining body
         current-proto nil
         result []]
    (if (empty? remaining)
      (if current-proto (conj result current-proto) result)
      (let [form (first remaining)]
        (if (and (symbol? form) (not (list? form)))
          (recur (rest remaining)
                 {:protocol form :methods []}
                 (if current-proto (conj result current-proto) result))
          (if (and (seq? form) current-proto)
            (recur (rest remaining)
                   (update current-proto :methods conj
                           {:name (first form)
                            :args (second form)
                            :body (rest (rest form))})
                   result)
            (recur (rest remaining) current-proto result)))))))

(defn- user-provides-protocol? [parsed-protos proto-sym]
  (some #(= proto-sym (:protocol %)) parsed-protos))

;;-----------------------------------------------------------------------------
;; eve-sab-deftype macro
;;-----------------------------------------------------------------------------

(defmacro eve-sab-deftype
  "Define a SAB-backed type with fast-path serialization.

   Fields support type hints for optimized storage:
     ^:int32, ^:uint32, ^:float32, ^:float64 — primitives
     ^:MyType — reference to another eve-sab-deftype (stored as offset)

   Mutability:
     (default) — immutable after construction
     ^:mutable — mutable via set!
     ^:volatile-mutable — atomic via set!/cas!

   The generated type:
     - Gets SAB from global atom automatically (no env threading)
     - Provides field access via protocol methods you define
     - Supports reader tracking for GC coordination

   Example:
     (eve-sab-deftype TreeNode [^:volatile-mutable ^:int32 key
                                ^:volatile-mutable ^:TreeNode left
                                ^:volatile-mutable ^:TreeNode right]
       ITreeNode
       (-get-key [this] key)
       (-set-key! [this v] (set! key v))
       (-cas-left! [this old new] (cas! left old new)))"
  [type-name fields & body]
  (let [;; Parse fields
        parsed-fields (mapv parse-field fields)
        ;; Compute layout
        {:keys [fields total-size]} (compute-layout parsed-fields)
        ;; Assign type-id
        type-id (next-type-id!)
        type-key (str (ns-name *ns*) "/" (name type-name))

        ;; Register
        _ (register-type! (name type-name)
                          {:type-id type-id
                           :total-size total-size
                           :fields fields
                           :type-key type-key})

        ;; Build helpers
        field-map (into {} (map (fn [f] [(:name f) f]) fields))
        parsed-protos (parse-protocol-impls body)

        ;; Internal field names
        sab-sym 'sab__
        off-sym 'offset__

        ;; Transform methods
        transformed-protos
        (mapcat (fn [{:keys [protocol methods]}]
                  (cons protocol
                        (map (fn [{:keys [name args body]}]
                               (let [this-sym (first args)
                                     tbody (transform-method-body
                                            body fields field-map
                                            (list '.-sab__ this-sym)
                                            (list '.-offset__ this-sym))]
                                 (list name args (cons 'do tbody))))
                             methods)))
                parsed-protos)

        ;; Boilerplate protocols
        boilerplate
        (concat
         ;; IHash
         (when-not (user-provides-protocol? parsed-protos 'IHash)
           ['IHash (list '-hash ['_] (list 'hash off-sym))])
         ;; IEquiv
         (when-not (user-provides-protocol? parsed-protos 'IEquiv)
           ['IEquiv
            (list '-equiv ['_ 'other]
                  (list 'and
                        (list 'instance? type-name 'other)
                        (list 'identical? sab-sym (list '.-sab__ 'other))
                        (list '== off-sym (list '.-offset__ 'other))))])
         ;; IPrintWithWriter
         (when-not (user-provides-protocol? parsed-protos 'IPrintWithWriter)
           ['IPrintWithWriter
            (list '-pr-writer ['this 'writer 'opts]
                  (list 'let (field-bindings fields sab-sym off-sym)
                        (list '-write 'writer (str "#sab/" (name type-name) " "))
                        (list '-write 'writer (str "{:offset " off-sym "}"))))]))

        ;; Constructor
        ctor-name (symbol (str "->" (name type-name)))
        ctor-args (mapv (fn [f] (symbol (:name f))) fields)
        ;; Gensyms for constructor body
        sab-ctor-sym (gensym "sab_")
        off-ctor-sym (gensym "offset_")
        ;; Generate field write expressions with the constructor gensyms
        field-writes (map (fn [f]
                            (write-fn-for-type
                             (assoc f :mutability (if (= :volatile-mutable (:mutability f))
                                                    :volatile-mutable :mutable))
                             sab-ctor-sym off-ctor-sym (:offset f) (symbol (:name f))))
                          fields)]
    `(do
       ;; The deftype
       (~'deftype ~type-name [~sab-sym ~off-sym]
         ~@boilerplate
         ~@transformed-protos)

       ;; Constructor - allocates from global atom
       (~'defn ~ctor-name [~@ctor-args]
         (let [eve-env# (if com.seniorcaremarket.eve.atom/*global-atom-instance*
                          (com.seniorcaremarket.eve.atom/get-env com.seniorcaremarket.eve.atom/*global-atom-instance*)
                          (throw (js/Error. "No global atom instance")))
               ~sab-ctor-sym (:sab eve-env#)
               ;; Allocate region (request extra bytes to ensure 4-byte alignment)
               alloc-result# (com.seniorcaremarket.eve.atom/alloc eve-env# (+ ~total-size 4))
               _# (when (:error alloc-result#)
                    (throw (js/Error. (str "Allocation failed: " (:error alloc-result#)))))
               raw-offset# (:offset alloc-result#)
               ;; Align to 4-byte boundary
               ~off-ctor-sym (let [rem# (mod raw-offset# 4)]
                               (if (zero? rem#) raw-offset# (+ raw-offset# (- 4 rem#))))
               dv# (js/DataView. ~sab-ctor-sym)
               ;; Zero-fill the allocated region
               u8# (js/Uint8Array. ~sab-ctor-sym)]
           (dotimes [i# ~total-size]
             (aset u8# (+ ~off-ctor-sym i#) 0))
           ;; Write type-id byte
           (.setUint8 dv# ~off-ctor-sym ~type-id)
           ;; Write initial field values
           ~@field-writes
           ;; Return instance
           (~(symbol (str (name type-name) ".")) ~sab-ctor-sym ~off-ctor-sym)))

       ;; Offset accessor for composing types
       (~'defn ~(symbol (str (name type-name) "-offset")) [inst#]
         (.-offset__ inst#))

       ;; SAB accessor
       (~'defn ~(symbol (str (name type-name) "-sab")) [inst#]
         (.-sab__ inst#))

       ;; Type-id constant
       (~'def ~(symbol (str (name type-name) "-type-id")) ~type-id)

       ;; Nil sentinel constant
       (~'def ~(symbol (str (name type-name) "-nil")) -1)

       ~type-name)))

(defmacro eve-sab-extend-type
  "Extend protocols to an existing eve-sab-deftype."
  [type-name & body]
  (let [type-reg (lookup-type (name type-name))
        _ (when-not type-reg
            (throw (ex-info (str "Unknown type: " type-name) {:type type-name})))
        fields (:fields type-reg)
        field-map (into {} (map (fn [f] [(:name f) f]) fields))
        parsed-protos (parse-protocol-impls body)
        transformed-protos
        (mapcat (fn [{:keys [protocol methods]}]
                  (cons protocol
                        (map (fn [{:keys [name args body]}]
                               (let [this-sym (first args)
                                     tbody (transform-method-body
                                            body fields field-map
                                            (list '.-sab__ this-sym)
                                            (list '.-offset__ this-sym))]
                                 (list name args (cons 'do tbody))))
                             methods)))
                parsed-protos)]
    `(~'extend-type ~type-name ~@transformed-protos)))

(ns com.seniorcaremarket.eve-sab-deftype.sab-vec
  "SAB-backed persistent vector with fast-path serialization.

   Built on eve-sab-deftype with full feature parity:
   - Supports arbitrary CLJS values (via fast-path serialization)
   - Fast-path for primitives (nil, bool, int32, float64, string, keyword)
   - HAMT-style trie with 32-way branching for O(log32 N) access

   Architecture:
   - SabVecRoot: root handle with count, shift, root-offset, tail info
   - Internal nodes: 32-element int32 arrays (child offsets, -1 = nil)
   - Leaf nodes: 32-element int32 arrays (offsets to value blocks)
   - Value blocks: length-prefixed serialized values
   - Tail: separate array for fast append"
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser])
  (:require-macros
   [com.seniorcaremarket.eve-sab-deftype.core :refer [eve-sab-deftype]]))

;; Forward declarations
(declare ->SabVecRoot SabVecRoot empty-sab-vec)
(declare ->SabVecN SabVecN empty-sab-vec-n)

;;-----------------------------------------------------------------------------
;; Configurable Chunk Size
;;
;; NODE_SIZE determines how many elements per node/chunk.
;; Valid values: 32, 64, 128, 256, 512, 1024
;; Each size requires a corresponding SHIFT_STEP = log2(NODE_SIZE)
;;-----------------------------------------------------------------------------

;; Default chunk size - can be overridden at construction time
(def ^:dynamic *chunk-size* 32)

(defn- size->shift
  "Convert node size to shift step (log2)."
  [size]
  (case size
    32   5
    64   6
    128  7
    256  8
    512  9
    1024 10
    ;; Default for unsupported sizes - compute log2
    (loop [s size, shift 0]
      (if (<= s 1)
        shift
        (recur (unsigned-bit-shift-right s 1) (inc shift))))))

(defn- size->mask
  "Convert node size to bit mask (size - 1)."
  [size]
  (dec size))

;; Legacy constants for backward compatibility
(def ^:const NODE_SIZE 32)
(def ^:const SHIFT_STEP 5)
(def ^:const MASK 0x1f)

;;-----------------------------------------------------------------------------
;; Allocation helpers
;;-----------------------------------------------------------------------------

;; Offset → descriptor-idx tracking for O(1) retirement/freeing.
(defonce ^:private offset->desc (js/Map.))

(defn- alloc-bytes!
  "Allocate n bytes with 4-byte alignment. Returns #js [offset descriptor-idx].
   Tracks offset→descriptor-idx mapping for O(1) retirement/freeing."
  [s-atom-env n]
  (let [size-needed (+ n 4)
        alloc-result (atom/alloc s-atom-env size-needed)]
    (when (:error alloc-result)
      (throw (js/Error. (str "Vec allocation failed: " (:error alloc-result)))))
    (let [off (:offset alloc-result)
          desc-idx (:descriptor-idx alloc-result)]
      (.set offset->desc off desc-idx)
      #js [off desc-idx])))

(defn- alloc-node!
  "Allocate a node-size element int32 array initialized to -1 (nil sentinel).
   Returns the SAB offset."
  ([s-atom-env] (alloc-node! s-atom-env NODE_SIZE))
  ([s-atom-env node-size]
   (let [;; node-size int32s = node-size*4 bytes
         offset (aget (alloc-bytes! s-atom-env (* node-size 4)) 0)
         dv (wasm/data-view)]
     ;; Initialize all slots to -1 (nil sentinel)
     (dotimes [i node-size]
       (.setInt32 dv (+ offset (* i 4)) -1 true))
     offset)))

(defn- copy-from-sab
  "Copy bytes from WASM memory to a regular ArrayBuffer-backed Uint8Array."
  [^number offset ^number len]
  (let [src (.subarray (wasm/u8-view) offset (+ offset len))
        dst (js/Uint8Array. len)]
    (.set dst src 0)
    dst))

;;-----------------------------------------------------------------------------
;; Value block operations
;; Value block layout: [len:u32][bytes...]
;;-----------------------------------------------------------------------------

(defn- make-value-block!
  "Allocate and write a serialized value. Returns offset."
  [s-atom-env ^js val-bytes]
  (let [val-len (.-length val-bytes)
        offset (aget (alloc-bytes! s-atom-env (+ 4 val-len)) 0)
        dv (wasm/data-view)
        u8 (wasm/u8-view)]
    (.setUint32 dv offset val-len true)
    (when (pos? val-len)
      (.set u8 val-bytes (+ offset 4)))
    offset))

(defn- read-value-block
  "Read value from a value block offset. Returns deserialized value.
   Uses zero-copy deserialization — reads directly from DataView, no byte copies."
  [s-atom-env ^js dv val-off]
  (let [val-len (.getUint32 dv val-off true)]
    (ser/deserialize-from-dv s-atom-env dv (+ val-off 4) val-len)))

;;-----------------------------------------------------------------------------
;; Node operations
;;-----------------------------------------------------------------------------

(defn- node-get
  "Get the i-th slot from a node at the given offset."
  [^js dv offset i]
  (.getInt32 dv (+ offset (* i 4)) true))

(defn- node-set!
  "Set the i-th slot in a node. Returns the offset."
  [^js dv offset i val]
  (.setInt32 dv (+ offset (* i 4)) val true)
  offset)

(defn- clone-node!
  "Allocate a new node and copy contents from source."
  ([s-atom-env ^js dv src-offset] (clone-node! s-atom-env dv src-offset NODE_SIZE))
  ([s-atom-env ^js dv src-offset node-size]
   (let [new-offset (alloc-node! s-atom-env node-size)]
     (dotimes [i node-size]
       (let [v (.getInt32 dv (+ src-offset (* i 4)) true)]
         (.setInt32 dv (+ new-offset (* i 4)) v true)))
     new-offset)))

;;-----------------------------------------------------------------------------
;; Disposal helpers - recursive freeing for vector trees
;;-----------------------------------------------------------------------------

(defn- find-desc-idx
  "Look up descriptor-idx for a given offset. O(1) from tracking map,
   falls back to linear scan for nodes not in the map."
  [s-atom-env node-off]
  (if (.has offset->desc node-off)
    (.get offset->desc node-off)
    (when-let [desc (u/find-descriptor-for-data-offset s-atom-env node-off)]
      (:descriptor-idx desc))))

(defn- free-block!
  "Free a single allocation block by its SAB offset.
   Uses offset→desc map for O(1) descriptor lookup."
  [s-atom-env offset]
  (when (> offset -1)
    (when-let [desc-idx (find-desc-idx s-atom-env offset)]
      (.delete offset->desc offset)
      (atom/free s-atom-env desc-idx))))

(defn- free-leaf-node!
  "Free a leaf node and all its value blocks."
  [s-atom-env ^js dv node-off node-size]
  (when (> node-off -1)
    ;; Free each value block pointed to by this leaf
    (dotimes [i node-size]
      (let [val-off (node-get dv node-off i)]
        (when (> val-off -1)
          (free-block! s-atom-env val-off))))
    ;; Free the leaf node itself
    (free-block! s-atom-env node-off)))

(defn- free-trie-node!
  "Recursively free a trie node and all its descendants."
  [s-atom-env ^js dv node-off shift node-size shift-step]
  (when (> node-off -1)
    (if (zero? shift)
      ;; Leaf level — free value blocks
      (free-leaf-node! s-atom-env dv node-off node-size)
      ;; Internal node — recurse into children
      (do
        (dotimes [i node-size]
          (let [child-off (node-get dv node-off i)]
            (when (> child-off -1)
              (free-trie-node! s-atom-env dv child-off (- shift shift-step) node-size shift-step))))
        ;; Free this internal node
        (free-block! s-atom-env node-off)))))

;;-----------------------------------------------------------------------------
;; Internal implementation helpers (configurable chunk size)
;;-----------------------------------------------------------------------------

(defn- tail-offset-calc
  "Calculate the index where the tail starts."
  ([cnt] (tail-offset-calc cnt NODE_SIZE SHIFT_STEP))
  ([cnt node-size shift-step]
   (if (< cnt node-size)
     0
     (bit-shift-left (unsigned-bit-shift-right (dec cnt) shift-step) shift-step))))

(defn- nth-impl
  "Get element at index. Takes s-atom-env and field values."
  ([s-atom-env dv cnt shift root tail n]
   (nth-impl s-atom-env dv cnt shift root tail n NODE_SIZE SHIFT_STEP MASK))
  ([s-atom-env dv cnt shift root tail n node-size shift-step mask]
   (let [toff (tail-offset-calc cnt node-size shift-step)]
     (if (>= n toff)
       ;; Element is in tail
       (let [val-off (node-get dv tail (- n toff))]
         (read-value-block s-atom-env dv val-off))
       ;; Element is in trie
       (let [val-off (loop [node-off root
                            sh shift]
                       (let [idx (bit-and (unsigned-bit-shift-right n sh) mask)]
                         (if (zero? sh)
                           (node-get dv node-off idx)
                           (recur (node-get dv node-off idx) (- sh shift-step)))))]
         (read-value-block s-atom-env dv val-off))))))

(defn- new-path
  "Create a new path from root to leaf at given shift level."
  ([s-atom-env ^js dv shift leaf-offset]
   (new-path s-atom-env dv shift leaf-offset NODE_SIZE SHIFT_STEP))
  ([s-atom-env ^js dv shift leaf-offset node-size shift-step]
   (if (zero? shift)
     leaf-offset
     (let [node-off (alloc-node! s-atom-env node-size)]
       (node-set! dv node-off 0 (new-path s-atom-env dv (- shift shift-step) leaf-offset node-size shift-step))
       node-off))))

(defn- push-tail
  "Push a full tail into the trie, returning new root offset."
  ([s-atom-env ^js dv shift parent-off tail-off cnt]
   (push-tail s-atom-env dv shift parent-off tail-off cnt NODE_SIZE SHIFT_STEP MASK))
  ([s-atom-env ^js dv shift parent-off tail-off cnt node-size shift-step mask]
   (let [idx (bit-and (unsigned-bit-shift-right (dec cnt) shift) mask)
         new-parent-off (if (== parent-off -1)
                          (alloc-node! s-atom-env node-size)
                          (clone-node! s-atom-env dv parent-off node-size))]
     (if (== shift shift-step)
       ;; At the bottom level, insert tail directly
       (do
         (node-set! dv new-parent-off idx tail-off)
         new-parent-off)
       ;; Recurse into child
       (let [child-off (node-get dv new-parent-off idx)
             new-child-off (if (== child-off -1)
                             (new-path s-atom-env dv (- shift shift-step) tail-off node-size shift-step)
                             (push-tail s-atom-env dv (- shift shift-step) child-off tail-off cnt node-size shift-step mask))]
         (node-set! dv new-parent-off idx new-child-off)
         new-parent-off)))))

(defn- do-assoc
  "Recursively update trie at index n with value offset."
  ([s-atom-env ^js dv shift node-off n val-off]
   (do-assoc s-atom-env dv shift node-off n val-off NODE_SIZE SHIFT_STEP MASK))
  ([s-atom-env ^js dv shift node-off n val-off node-size shift-step mask]
   (let [new-node-off (clone-node! s-atom-env dv node-off node-size)
         idx (bit-and (unsigned-bit-shift-right n shift) mask)]
     (if (zero? shift)
       (do
         (node-set! dv new-node-off idx val-off)
         new-node-off)
       (let [child-off (node-get dv node-off idx)
             new-child-off (do-assoc s-atom-env dv (- shift shift-step) child-off n val-off node-size shift-step mask)]
         (node-set! dv new-node-off idx new-child-off)
         new-node-off)))))

(defn- pop-tail
  "Remove the rightmost leaf from the trie."
  ([s-atom-env ^js dv shift node-off cnt]
   (pop-tail s-atom-env dv shift node-off cnt NODE_SIZE SHIFT_STEP MASK))
  ([s-atom-env ^js dv shift node-off cnt node-size shift-step mask]
   (let [idx (bit-and (unsigned-bit-shift-right (dec cnt) shift) mask)]
     (cond
       (> shift shift-step)
       (let [child-off (node-get dv node-off idx)
             new-child (pop-tail s-atom-env dv (- shift shift-step) child-off cnt node-size shift-step mask)]
         (if (and (== new-child -1) (zero? idx))
           -1
           (let [new-node-off (clone-node! s-atom-env dv node-off node-size)]
             (node-set! dv new-node-off idx new-child)
             new-node-off)))

       (zero? idx)
       -1

       :else
       (let [new-node-off (clone-node! s-atom-env dv node-off node-size)]
         (node-set! dv new-node-off idx -1)
         new-node-off)))))

;;-----------------------------------------------------------------------------
;; WASM batch reduce
;;-----------------------------------------------------------------------------

(defn- vec-reduce-batch
  "Reduce over vec elements using WASM batch collection.
   Returns the reduced value, or ::no-wasm if WASM path unavailable."
  [s-atom-env dv cnt shift root tail tail-len f init start-idx]
  (let [scratch-start (:scratch-region-start s-atom-env)
        max-entries wasm/MAX_COLLECT_ENTRIES
        n (when scratch-start
            (wasm/vec-collect-values root tail cnt shift tail-len scratch-start max-entries))]
    (if (and n (<= n max-entries))
      ;; WASM path: copy output to JS buffer, then iterate
      (let [i32-src (wasm/i32-view)
            base (unsigned-bit-shift-right scratch-start 2)
            len (* n 2)
            buf (js/Int32Array. len)]
        (.set buf (.subarray i32-src base (+ base len)))
        (loop [i start-idx acc init]
          (if (or (>= i n) (reduced? acc))
            (if (reduced? acc) @acc acc)
            (let [slot (* i 2)
                  val-off (aget buf slot)
                  val-len (aget buf (+ slot 1))
                  v (ser/deserialize-from-dv s-atom-env dv val-off val-len)]
              (recur (inc i) (f acc v))))))
      ::no-wasm)))

;;-----------------------------------------------------------------------------
;; SabVecRoot - the persistent vector handle
;;-----------------------------------------------------------------------------

(declare dispose!)

(eve-sab-deftype SabVecRoot
  [^:int32 cnt        ;; total element count
   ^:int32 shift      ;; current trie depth (* SHIFT_STEP)
   ^:int32 root       ;; offset to root node, -1 for nil
   ^:int32 tail       ;; offset to tail array
   ^:int32 tail-len]  ;; number of elements in tail

  ;; Marker protocol for sequential collections
  ISequential

  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [_ k]
    (if (and (integer? k) (>= k 0) (< k cnt))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (nth-impl s-atom-env dv cnt shift root tail k))
      nil))
  (-lookup [_ k not-found]
    (if (and (integer? k) (>= k 0) (< k cnt))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (nth-impl s-atom-env dv cnt shift root tail k))
      not-found))

  IIndexed
  (-nth [_ n]
    (if (or (neg? n) (>= n cnt))
      (throw (js/Error. (str "Index out of bounds: " n)))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (nth-impl s-atom-env dv cnt shift root tail n))))
  (-nth [this n not-found]
    (if (or (neg? n) (>= n cnt))
      not-found
      (-nth this n)))

  ICollection
  (-conj [_ val]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          val-bytes (ser/serialize-element val)
          val-off (make-value-block! s-atom-env val-bytes)]
      (if (< tail-len NODE_SIZE)
        ;; Room in tail
        (let [new-tail (clone-node! s-atom-env dv tail)]
          (node-set! dv new-tail tail-len val-off)
          (->SabVecRoot (inc cnt) shift root new-tail (inc tail-len)))
        ;; Tail is full, push into trie
        (let [old-tail tail
              new-tail (alloc-node! s-atom-env)
              _ (node-set! dv new-tail 0 val-off)]
          (if (>= (bit-shift-left 1 shift) (unsigned-bit-shift-right cnt SHIFT_STEP))
            ;; Room in trie
            (let [new-root (push-tail s-atom-env dv shift root old-tail cnt)]
              (->SabVecRoot (inc cnt) shift new-root new-tail 1))
            ;; Trie needs to grow
            (let [new-root-off (alloc-node! s-atom-env)
                  _ (node-set! dv new-root-off 0 root)
                  new-shift (+ shift SHIFT_STEP)
                  _ (node-set! dv new-root-off 1 (new-path s-atom-env dv shift old-tail))]
              (->SabVecRoot (inc cnt) new-shift new-root-off new-tail 1)))))))

  IEmptyableCollection
  (-empty [_]
    (empty-sab-vec))

  IStack
  (-peek [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (nth-impl s-atom-env dv cnt shift root tail (dec cnt)))))

  (-pop [_]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (cond
        (zero? cnt)
        (throw (js/Error. "Can't pop empty vector"))

        (== cnt 1)
        (empty-sab-vec)

        :else
        (if (> tail-len 1)
          ;; Just shrink tail
          (let [new-tail (clone-node! s-atom-env dv tail)]
            (node-set! dv new-tail (dec tail-len) -1)
            (->SabVecRoot (dec cnt) shift root new-tail (dec tail-len)))
          ;; Need to get new tail from trie
          (let [new-cnt (dec cnt)
                new-toff (tail-offset-calc new-cnt)
                ;; Find the leaf that will become the new tail
                new-tail-off (loop [node-off root
                                    sh shift]
                               (let [idx (bit-and (unsigned-bit-shift-right (dec new-cnt) sh) MASK)]
                                 (if (zero? sh)
                                   node-off
                                   (recur (node-get dv node-off idx) (- sh SHIFT_STEP)))))
                new-root (pop-tail s-atom-env dv shift root cnt)]
            (cond
              ;; Root became nil
              (== new-root -1)
              (->SabVecRoot new-cnt SHIFT_STEP -1 new-tail-off NODE_SIZE)

              ;; Root has only one child and we can collapse
              (and (> shift SHIFT_STEP)
                   (== (node-get dv new-root 1) -1))
              (->SabVecRoot new-cnt (- shift SHIFT_STEP)
                            (node-get dv new-root 0) new-tail-off NODE_SIZE)

              :else
              (->SabVecRoot new-cnt shift new-root new-tail-off NODE_SIZE)))))))

  IVector
  (-assoc-n [this n val]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (cond
        (== n cnt)
        (-conj this val)

        (or (neg? n) (> n cnt))
        (throw (js/Error. (str "Index " n " out of bounds [0," cnt "]")))

        :else
        (let [val-bytes (ser/serialize-element val)
              val-off (make-value-block! s-atom-env val-bytes)
              toff (tail-offset-calc cnt)]
          (if (>= n toff)
            ;; Update in tail
            (let [new-tail (clone-node! s-atom-env dv tail)]
              (node-set! dv new-tail (- n toff) val-off)
              (->SabVecRoot cnt shift root new-tail tail-len))
            ;; Update in trie
            (let [new-root (do-assoc s-atom-env dv shift root n val-off)]
              (->SabVecRoot cnt shift new-root tail tail-len)))))))

  IAssociative
  (-assoc [this k v]
    (if (integer? k)
      (-assoc-n this k v)
      (throw (js/Error. "Vector's key for assoc must be a number."))))
  (-contains-key? [_ k]
    (and (integer? k) (>= k 0) (< k cnt)))

  IFn
  (-invoke [this k]
    (-lookup this k nil))
  (-invoke [this k not-found]
    (-lookup this k not-found))

  ISeqable
  (-seq [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        ((fn iter [i]
           (lazy-seq
            (when (< i cnt)
              (cons (nth-impl s-atom-env dv cnt shift root tail i) (iter (inc i))))))
         0))))

  IReduce
  (-reduce [_ f]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (case cnt
        0 (f)
        1 (nth-impl s-atom-env dv cnt shift root tail 0)
        (let [first-val (nth-impl s-atom-env dv cnt shift root tail 0)
              result (vec-reduce-batch s-atom-env dv cnt shift root tail tail-len f first-val 1)]
          (if (keyword-identical? result ::no-wasm)
            ;; JS fallback
            (loop [i 1 acc first-val]
              (if (>= i cnt)
                acc
                (let [acc' (f acc (nth-impl s-atom-env dv cnt shift root tail i))]
                  (if (reduced? acc') @acc' (recur (inc i) acc')))))
            result)))))
  (-reduce [_ f init]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          result (vec-reduce-batch s-atom-env dv cnt shift root tail tail-len f init 0)]
      (if (keyword-identical? result ::no-wasm)
        ;; JS fallback
        (loop [i 0 acc init]
          (if (or (>= i cnt) (reduced? acc))
            (if (reduced? acc) @acc acc)
            (recur (inc i) (f acc (nth-impl s-atom-env dv cnt shift root tail i)))))
        result)))

  IEquiv
  (-equiv [_ other]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (cond
        (not (sequential? other)) false
        (not= cnt (count other)) false
        :else
        (loop [i 0]
          (if (>= i cnt)
            true
            (if (= (nth-impl s-atom-env dv cnt shift root tail i) (nth other i))
              (recur (inc i))
              false))))))

  IHash
  (-hash [this]
    (hash-ordered-coll this))

  IPrintWithWriter
  (-pr-writer [_ writer opts]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)]
      (-write writer "#sab/vec [")
      (dotimes [i (min cnt 10)]
        (when (pos? i) (-write writer " "))
        (-write writer (pr-str (nth-impl s-atom-env dv cnt shift root tail i))))
      (when (> cnt 10)
        (-write writer " ..."))
      (-write writer "]")))

  d/IDirectSerialize
  (-direct-serialize [this]
    (ser/encode-sab-pointer ser/FAST_TAG_SAB_VEC (.-offset__ this)))

  d/ISabStorable
  (-sab-tag [_] :sab-vec)
  (-sab-encode [this _s-atom-env]
    (d/-direct-serialize this))
  (-sab-dispose [this _s-atom-env]
    (dispose! this))

  d/ISabRetirable
  (-sab-retire-diff! [this new-value s-atom-env mode]
    (let [old-root root
          old-shift shift]
      (if (instance? SabVecRoot new-value)
        ;; Both are SabVecRoot — diff trie paths
        (let [dv (wasm/data-view)
              new-root (.getInt32 dv (+ (SabVecRoot-offset new-value) 12) true)]
          (retire-replaced-trie-path! s-atom-env old-root new-root old-shift -1 mode))
        ;; Different type — dispose entire old trie
        (dispose! this)))))

;;-----------------------------------------------------------------------------
;; Disposal - explicit cleanup for reclaiming SAB memory
;;-----------------------------------------------------------------------------

(defn dispose!
  "Dispose a SabVecRoot or SabVecN, freeing its entire trie tree and tail.
   Call this when the vector is no longer needed to reclaim SAB memory.

   WARNING: After disposal, the vector must not be used. Any access will
   result in undefined behavior or errors."
  [sab-vec]
  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
        dv (wasm/data-view)
        base-off (.-offset__ sab-vec)
        root-off (.getInt32 dv (+ base-off 12) true)
        tail-off (.getInt32 dv (+ base-off 16) true)
        shift-val (.getInt32 dv (+ base-off 8) true)
        ;; Detect SabVecN vs SabVecRoot — SabVecN has node-size at offset 24
        ns (if (instance? SabVecN sab-vec)
             (.getInt32 dv (+ base-off 24) true)
             NODE_SIZE)
        ss (size->shift ns)]
    ;; Free the trie
    (when (> root-off -1)
      (free-trie-node! s-atom-env dv root-off shift-val ns ss))
    ;; Free the tail (leaf node with value blocks)
    (when (> tail-off -1)
      (free-leaf-node! s-atom-env dv tail-off ns))))

(defn retire-replaced-trie-path!
  "After an atom swap that replaced old-root with new-root, retire the old
   path nodes that are no longer referenced by the new trie.

   Walks both tries following the index bits for the modified index. At each
   level where old-node != new-node, the old node is retired via retire-block!
   (epoch-based) or freed immediately.

   Only retires trie internal/leaf nodes — shared subtrees and value blocks
   are untouched.

   mode: :retire (epoch-based, for multi-worker) or :free (immediate)
   idx: the index that was modified (for assoc) or -1 for structural changes"
  ([s-atom-env old-root new-root shift-val idx]
   (retire-replaced-trie-path! s-atom-env old-root new-root shift-val idx :free))
  ([s-atom-env old-root new-root shift-val idx mode]
   (retire-replaced-trie-path! s-atom-env old-root new-root shift-val idx mode NODE_SIZE SHIFT_STEP MASK))
  ([s-atom-env old-root new-root shift-val idx mode node-size shift-step mask]
   (when (and (not= old-root -1) (not= old-root new-root))
     (let [dv (wasm/data-view)]
       (loop [old-off old-root
              new-off new-root
              sh shift-val]
         (when (and (not= old-off -1) (not= old-off new-off))
           ;; Retire/free this old trie node
           (when-let [desc-idx (find-desc-idx s-atom-env old-off)]
             (if (= mode :retire)
               (atom/retire-block! s-atom-env desc-idx)
               (do (.delete offset->desc old-off)
                   (atom/free s-atom-env desc-idx))))
           ;; Continue down the trie path
           (when (and (pos? sh) (>= idx 0))
             (let [child-idx (bit-and (unsigned-bit-shift-right idx sh) mask)
                   old-child (node-get dv old-off child-idx)
                   new-child (node-get dv new-off child-idx)]
               (recur old-child new-child (- sh shift-step))))))))))

;;-----------------------------------------------------------------------------
;; Constructors
;;-----------------------------------------------------------------------------

(defn empty-sab-vec
  "Create an empty SabVec."
  []
  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
        tail-off (alloc-node! s-atom-env)]
    (->SabVecRoot 0 SHIFT_STEP -1 tail-off 0)))

(defn sab-vec
  "Create a SabVec from a sequence of values."
  [coll]
  (reduce conj (empty-sab-vec) coll))

;;-----------------------------------------------------------------------------
;; Configurable Chunk Size Vector
;;
;; SabVecN stores node-size in the root for variable chunk sizes.
;; This enables benchmarking different chunk sizes: 32, 64, 128, 256, 512, 1024
;;-----------------------------------------------------------------------------

(eve-sab-deftype SabVecN
  [^:int32 cnt        ;; total element count
   ^:int32 shift      ;; current trie depth (* shift-step)
   ^:int32 root       ;; offset to root node, -1 for nil
   ^:int32 tail       ;; offset to tail array
   ^:int32 tail-len   ;; number of elements in tail
   ^:int32 node-size] ;; configurable chunk size (32, 64, 128, 256, 512, 1024)

  ISequential

  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [_ k]
    (if (and (integer? k) (>= k 0) (< k cnt))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            shift-step (size->shift node-size)
            mask (size->mask node-size)]
        (nth-impl s-atom-env dv cnt shift root tail k node-size shift-step mask))
      nil))
  (-lookup [_ k not-found]
    (if (and (integer? k) (>= k 0) (< k cnt))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            shift-step (size->shift node-size)
            mask (size->mask node-size)]
        (nth-impl s-atom-env dv cnt shift root tail k node-size shift-step mask))
      not-found))

  IIndexed
  (-nth [_ n]
    (if (or (neg? n) (>= n cnt))
      (throw (js/Error. (str "Index out of bounds: " n)))
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            shift-step (size->shift node-size)
            mask (size->mask node-size)]
        (nth-impl s-atom-env dv cnt shift root tail n node-size shift-step mask))))
  (-nth [this n not-found]
    (if (or (neg? n) (>= n cnt))
      not-found
      (-nth this n)))

  ICollection
  (-conj [_ val]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)
          val-bytes (ser/serialize-element val)
          val-off (make-value-block! s-atom-env val-bytes)]
      (if (< tail-len node-size)
        ;; Room in tail
        (let [new-tail (clone-node! s-atom-env dv tail node-size)]
          (node-set! dv new-tail tail-len val-off)
          (->SabVecN (inc cnt) shift root new-tail (inc tail-len) node-size))
        ;; Tail is full, push into trie
        (let [old-tail tail
              new-tail (alloc-node! s-atom-env node-size)
              _ (node-set! dv new-tail 0 val-off)]
          (if (>= (bit-shift-left 1 shift) (unsigned-bit-shift-right cnt shift-step))
            ;; Room in trie
            (let [new-root (push-tail s-atom-env dv shift root old-tail cnt node-size shift-step mask)]
              (->SabVecN (inc cnt) shift new-root new-tail 1 node-size))
            ;; Trie needs to grow
            (let [new-root-off (alloc-node! s-atom-env node-size)
                  _ (node-set! dv new-root-off 0 root)
                  new-shift (+ shift shift-step)
                  _ (node-set! dv new-root-off 1 (new-path s-atom-env dv shift old-tail node-size shift-step))]
              (->SabVecN (inc cnt) new-shift new-root-off new-tail 1 node-size)))))))

  IEmptyableCollection
  (-empty [_]
    (empty-sab-vec-n node-size))

  IStack
  (-peek [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            shift-step (size->shift node-size)
            mask (size->mask node-size)]
        (nth-impl s-atom-env dv cnt shift root tail (dec cnt) node-size shift-step mask))))

  (-pop [_]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)]
      (cond
        (zero? cnt)
        (throw (js/Error. "Can't pop empty vector"))

        (== cnt 1)
        (empty-sab-vec-n node-size)

        :else
        (if (> tail-len 1)
          ;; Just shrink tail
          (let [new-tail (clone-node! s-atom-env dv tail node-size)]
            (node-set! dv new-tail (dec tail-len) -1)
            (->SabVecN (dec cnt) shift root new-tail (dec tail-len) node-size))
          ;; Need to get new tail from trie
          (let [new-cnt (dec cnt)
                ;; Find the leaf that will become the new tail
                new-tail-off (loop [node-off root
                                    sh shift]
                               (let [idx (bit-and (unsigned-bit-shift-right (dec new-cnt) sh) mask)]
                                 (if (zero? sh)
                                   node-off
                                   (recur (node-get dv node-off idx) (- sh shift-step)))))
                new-root (pop-tail s-atom-env dv shift root cnt node-size shift-step mask)]
            (cond
              ;; Root became nil
              (== new-root -1)
              (->SabVecN new-cnt shift-step -1 new-tail-off node-size node-size)

              ;; Root has only one child and we can collapse
              (and (> shift shift-step)
                   (== (node-get dv new-root 1) -1))
              (->SabVecN new-cnt (- shift shift-step)
                         (node-get dv new-root 0) new-tail-off node-size node-size)

              :else
              (->SabVecN new-cnt shift new-root new-tail-off node-size node-size)))))))

  IVector
  (-assoc-n [this n val]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)]
      (cond
        (== n cnt)
        (-conj this val)

        (or (neg? n) (> n cnt))
        (throw (js/Error. (str "Index " n " out of bounds [0," cnt "]")))

        :else
        (let [val-bytes (ser/serialize-element val)
              val-off (make-value-block! s-atom-env val-bytes)
              toff (tail-offset-calc cnt node-size shift-step)]
          (if (>= n toff)
            ;; Update in tail
            (let [new-tail (clone-node! s-atom-env dv tail node-size)]
              (node-set! dv new-tail (- n toff) val-off)
              (->SabVecN cnt shift root new-tail tail-len node-size))
            ;; Update in trie
            (let [new-root (do-assoc s-atom-env dv shift root n val-off node-size shift-step mask)]
              (->SabVecN cnt shift new-root tail tail-len node-size)))))))

  IAssociative
  (-assoc [this k v]
    (if (integer? k)
      (-assoc-n this k v)
      (throw (js/Error. "Vector's key for assoc must be a number."))))
  (-contains-key? [_ k]
    (and (integer? k) (>= k 0) (< k cnt)))

  IFn
  (-invoke [this k]
    (-lookup this k nil))
  (-invoke [this k not-found]
    (-lookup this k not-found))

  ISeqable
  (-seq [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            shift-step (size->shift node-size)
            mask (size->mask node-size)]
        ((fn iter [i]
           (lazy-seq
            (when (< i cnt)
              (cons (nth-impl s-atom-env dv cnt shift root tail i node-size shift-step mask) (iter (inc i))))))
         0))))

  IReduce
  (-reduce [_ f]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)]
      (case cnt
        0 (f)
        1 (nth-impl s-atom-env dv cnt shift root tail 0 node-size shift-step mask)
        (loop [i 1 acc (nth-impl s-atom-env dv cnt shift root tail 0 node-size shift-step mask)]
          (if (>= i cnt)
            acc
            (let [acc' (f acc (nth-impl s-atom-env dv cnt shift root tail i node-size shift-step mask))]
              (if (reduced? acc')
                @acc'
                (recur (inc i) acc'))))))))
  (-reduce [_ f init]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)]
      (loop [i 0 acc init]
        (if (or (>= i cnt) (reduced? acc))
          (if (reduced? acc) @acc acc)
          (recur (inc i) (f acc (nth-impl s-atom-env dv cnt shift root tail i node-size shift-step mask)))))))

  IEquiv
  (-equiv [_ other]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)]
      (cond
        (not (sequential? other)) false
        (not= cnt (count other)) false
        :else
        (loop [i 0]
          (if (>= i cnt)
            true
            (if (= (nth-impl s-atom-env dv cnt shift root tail i node-size shift-step mask) (nth other i))
              (recur (inc i))
              false))))))

  IHash
  (-hash [this]
    (hash-ordered-coll this))

  IPrintWithWriter
  (-pr-writer [_ writer opts]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          shift-step (size->shift node-size)
          mask (size->mask node-size)]
      (-write writer (str "#sab/vec-" node-size " ["))
      (dotimes [i (min cnt 10)]
        (when (pos? i) (-write writer " "))
        (-write writer (pr-str (nth-impl s-atom-env dv cnt shift root tail i node-size shift-step mask))))
      (when (> cnt 10)
        (-write writer " ..."))
      (-write writer "]"))))

;;-----------------------------------------------------------------------------
;; Configurable constructors
;;-----------------------------------------------------------------------------

(defn empty-sab-vec-n
  "Create an empty SabVecN with specified chunk size.
   Valid sizes: 32, 64, 128, 256, 512, 1024"
  [node-size]
  (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
        shift-step (size->shift node-size)
        tail-off (alloc-node! s-atom-env node-size)]
    (->SabVecN 0 shift-step -1 tail-off 0 node-size)))

(defn sab-vec-n
  "Create a SabVecN from a sequence of values with specified chunk size.
   Valid sizes: 32, 64, 128, 256, 512, 1024"
  [node-size coll]
  (reduce conj (empty-sab-vec-n node-size) coll))

;;-----------------------------------------------------------------------------
;; SAB Pointer Registration
;;-----------------------------------------------------------------------------

(ser/register-sab-type-constructor!
  ser/FAST_TAG_SAB_VEC
  (fn [sab offset] (SabVecRoot. sab offset)))

(ser/register-cljs-to-sab-builder!
  vector?
  (fn [v] (sab-vec v)))

(ns com.seniorcaremarket.eve-sab-deftype.sab-set
  "SAB-backed persistent set with fast-path serialization.

   Built on eve-sab-deftype with full feature parity:
   - Supports arbitrary CLJS values (via fast-path serialization)
   - Fast-path for primitives (nil, bool, int32, float64, string, keyword)
   - Arena-based allocation for efficient transients
   - Two-bitmap HAMT with inline values for performance

   Architecture:
   - SabSetRoot: root handle with count and root-offset
   - Bitmap nodes: two bitmaps (data_bitmap + node_bitmap) with inline values
   - Collision nodes: list of serialized values with same hash

   Node layout (two-bitmap HAMT):
   [type:u8][pad:u8][data_bitmap:u32][node_bitmap:u32][children...][values...]
   - data_bitmap: marks slots with inline values
   - node_bitmap: marks slots with child node pointers
   - children: 4 bytes each (popcount of node_bitmap entries)
   - values: [len:u32][bytes...] for each inline value"
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser]
   [com.seniorcaremarket.eve-sab-deftype.simd :as simd])
  (:require-macros
   [com.seniorcaremarket.eve-sab-deftype.core :refer [eve-sab-deftype]]))

;; Forward declarations
(declare ->SabSetRoot ->TransientSabSet SabSetRoot TransientSabSet)
(declare empty-sab-set)

;;-----------------------------------------------------------------------------
;; Constants
;;-----------------------------------------------------------------------------

(def ^:const SHIFT_STEP 5)
(def ^:const MASK 0x1f)      ;; 31

;; Node types encoded in first byte
(def ^:const NODE_TYPE_BITMAP 1)    ;; Two-bitmap node (inline values + child pointers)
(def ^:const NODE_TYPE_COLLISION 2) ;; Hash collision node

;; Node header: [type:u8][flags:u8][pad:u16][data_bitmap:u32][node_bitmap:u32] = 12
(def ^:const NODE_HEADER_SIZE 12)

;;-----------------------------------------------------------------------------
;; Allocation helpers - Pool with size-class normalization + batch pre-alloc
;; Mirrors sab_map pool infrastructure for consistent allocation behavior.
;;-----------------------------------------------------------------------------

(def ^:private ^:const POOL_SIZE_CLASSES #js [64 128 256 512])
(def ^:private ^:const MAX_POOL_SIZE 200)
(def ^:private ^:const BATCH_ALLOC_SIZE 32)

(defn- size-class-for
  "Find the appropriate size class for a given allocation size."
  [n]
  (cond (<= n 64) 64 (<= n 128) 128 (<= n 256) 256 (<= n 512) 512 :else nil))

;; Direct pool arrays — eliminates js/Map lookup per pool access.
;; Each entry is #js [offset desc-idx].
(def ^:private pool-64 #js [])
(def ^:private pool-128 #js [])
(def ^:private pool-256 #js [])
(def ^:private pool-512 #js [])

;; Offset → descriptor-idx tracking for O(1) retirement/freeing.
(defonce ^:private offset->desc (js/Map.))

(defn reset-pools!
  "Reset global node pool and offset→desc map.
   Must be called when switching to a new atom environment (new SAB)."
  []
  (set! pool-64 #js [])
  (set! pool-128 #js [])
  (set! pool-256 #js [])
  (set! pool-512 #js [])
  (.clear offset->desc))

(defn- pool-get!
  "Try to get a node from the pool. Returns #js [offset desc-idx] or nil."
  [size-class]
  (let [stack (case size-class
                64 pool-64  128 pool-128
                256 pool-256  512 pool-512
                nil)]
    (when (and stack (pos? (.-length stack)))
      (.pop stack))))

(defn- pool-put!
  "Add a node to the pool. Returns true if added, false if pool is full."
  [size-class entry]
  (let [stack (case size-class
                64 pool-64  128 pool-128
                256 pool-256  512 pool-512
                nil)]
    (when stack
      (if (< (.-length stack) MAX_POOL_SIZE)
        (do (.push stack entry) true)
        false))))

(defn- alloc-bytes!
  "Allocate n bytes, rounded up to nearest size class.
   Returns the SAB offset (integer).
   On pool miss, uses batch-alloc to pre-fill the pool in a single descriptor scan.
   Tracks offset→descriptor-idx mapping for O(1) retirement/freeing."
  [s-atom-env n]
  (let [size-class (cond (<= n 64) 64 (<= n 128) 128 (<= n 256) 256 (<= n 512) 512 :else nil)]
    (if size-class
      (if-let [pooled (pool-get! size-class)]
        ;; No zeroing needed — nodes are fully written before CAS publication
        (let [off (aget pooled 0)
              desc-idx (aget pooled 1)]
          (.set offset->desc off desc-idx)
          off)
        ;; Pool miss — batch-alloc returns #js [] of #js [offset descriptor-idx] pairs
        (let [results (atom/batch-alloc s-atom-env size-class BATCH_ALLOC_SIZE)
              ;; If batch-alloc fails, sweep retired blocks and retry once
              results (if (pos? (.-length results))
                        results
                        (do (atom/sweep-retired-blocks! s-atom-env)
                            (atom/batch-alloc s-atom-env size-class BATCH_ALLOC_SIZE)))
              len (.-length results)]
          (when (== len 0)
            (throw (js/Error. (str "Set allocation failed: out of memory for " size-class " bytes"))))
          ;; batch-alloc returns #js [offset descriptor-idx] pairs — pass through directly
          ;; Note: offset→desc is NOT set here — only set when block is consumed from pool
          (loop [i 1]
            (when (< i len)
              (pool-put! size-class (aget results i))
              (recur (inc i))))
          ;; Return the first block offset (no zeroing — fully written before publish)
          (let [first-result (aget results 0)
                off (aget first-result 0)
                desc-idx (aget first-result 1)]
            (.set offset->desc off desc-idx)
            off)))
    (let [r (atom/alloc s-atom-env n)]
      (if (:error r)
        (throw (js/Error. (str "Set allocation failed: " (:error r))))
        (let [off (:offset r)
              desc-idx (:descriptor-idx r)]
          (.set offset->desc off desc-idx)
          off))))))

;; Forward declare for recursive freeing
(declare free-hamt-node!)

(defn- maybe-pool-or-free!
  "Try to add a freed node to the pool. If pool is full, actually free it."
  [s-atom-env node-off desc-idx size]
  (let [size-class (size-class-for size)]
    (if (and size-class
             (pool-put! size-class #js [node-off desc-idx]))
      true
      (do (.delete offset->desc node-off)
          (atom/free s-atom-env desc-idx)))))

(defn- find-desc-idx
  "Look up descriptor-idx for a given offset. O(1) from tracking map,
   falls back to linear scan for nodes not in the map."
  [s-atom-env node-off]
  (if (.has offset->desc node-off)
    (.get offset->desc node-off)
    (when-let [desc (u/find-descriptor-for-data-offset s-atom-env node-off)]
      (:descriptor-idx desc))))

(defn- find-desc-capacity
  "Look up block capacity for a given offset.
   Uses offset→desc map for O(1) descriptor lookup, then reads capacity field."
  [s-atom-env node-off]
  (if-let [desc-idx (find-desc-idx s-atom-env node-off)]
    (u/read-block-descriptor-field (:index-view s-atom-env) desc-idx d/OFFSET_BD_BLOCK_CAPACITY)
    0))

(defn- free-hamt-node!
  "Recursively free a HAMT node and all its children.
   Nodes are added to the pool for reuse if possible.
   Uses offset→desc tracking map for O(1) descriptor lookup."
  [s-atom-env dv node-off]
  (when (> node-off -1)
    (let [node-type (.getUint8 dv node-off)]
      (case node-type
        ;; Bitmap node - free children first, then this node
        1 (let [node-bm (.getUint32 dv (+ node-off 6) true)
                child-count (popcount32 node-bm)]
            ;; Recursively free all child nodes
            (dotimes [i child-count]
              (let [child-off (.getInt32 dv (+ node-off NODE_HEADER_SIZE (* i 4)) true)]
                (free-hamt-node! s-atom-env dv child-off)))
            ;; Try to pool this node
            (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
              (let [size (find-desc-capacity s-atom-env node-off)]
                (maybe-pool-or-free! s-atom-env node-off desc-idx size))))

        ;; Collision node - no children, just pool/free this node
        2 (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
            (let [size (find-desc-capacity s-atom-env node-off)]
              (maybe-pool-or-free! s-atom-env node-off desc-idx size)))

        ;; Unknown node type - just free
        (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
          (.delete offset->desc node-off)
          (atom/free s-atom-env desc-idx))))))

(defn- copy-from-sab
  "Copy bytes from SharedArrayBuffer to a regular ArrayBuffer-backed Uint8Array."
  [^number offset ^number len]
  (let [src (.subarray (wasm/u8-view) offset (+ offset len))
        dst-buf (js/ArrayBuffer. len)
        dst (js/Uint8Array. dst-buf)]
    (.set dst src 0)
    dst))

;;-----------------------------------------------------------------------------
;; Low-level two-bitmap HAMT operations
;;
;; Node layout for bitmap nodes:
;; [type:u8][pad:u8][data_bitmap:u32][node_bitmap:u32][children...][values...]
;; - data_bitmap: which slots have inline values (popcount = # of inline values)
;; - node_bitmap: which slots have child node pointers (popcount = # of children)
;; - children: 4 bytes each, i32 offsets
;; - values: [len:u32][bytes...] for each inline value
;;
;; Collision node layout:
;; [type:u8][count:u8][hash:u32][unused:u32]
;; then count entries: [val_len:u32][val_bytes...]
;;-----------------------------------------------------------------------------

;; Use SIMD-accelerated popcount when available
(def ^:private popcount32 simd/popcount32)

(defn- read-node-type [^js dv offset]
  (.getUint8 dv offset))

(defn- read-data-bitmap [^js dv offset]
  (.getUint32 dv (+ offset 4) true))

(defn- read-node-bitmap [^js dv offset]
  (.getUint32 dv (+ offset 8) true))

(defn- read-child-offset [^js dv base child-idx]
  (.getInt32 dv (+ base NODE_HEADER_SIZE (* child-idx 4)) true))

(defn- val-data-start
  "Calculate where value data starts for a node with given node_bitmap."
  [offset node-bm]
  (+ offset NODE_HEADER_SIZE (* 4 (popcount32 node-bm))))

(defn- has-data? [data-bm bit-pos]
  (not (zero? (bit-and data-bm (bit-shift-left 1 bit-pos)))))

(defn- has-node? [node-bm bit-pos]
  (not (zero? (bit-and node-bm (bit-shift-left 1 bit-pos)))))

(defn- get-data-idx [data-bm bit-pos]
  (popcount32 (bit-and data-bm (dec (bit-shift-left 1 bit-pos)))))

(defn- get-child-idx [node-bm bit-pos]
  (popcount32 (bit-and node-bm (dec (bit-shift-left 1 bit-pos)))))

;;-----------------------------------------------------------------------------
;; Value reading/writing helpers
;;-----------------------------------------------------------------------------

(defn- skip-val-at
  "Skip over a value entry at pos. Returns next pos."
  [^js dv pos]
  (let [len (.getUint32 dv pos true)]
    (+ pos 4 len)))

(defn- read-val-at
  "Read a value from the given byte offset. Returns [value next-offset].
   Uses zero-copy deserialization — reads directly from DataView, no byte copies."
  [s-atom-env ^js dv val-offset]
  (let [val-len (.getUint32 dv val-offset true)
        val-start (+ val-offset 4)
        val-val (ser/deserialize-from-dv s-atom-env dv val-start val-len)
        next-off (+ val-start val-len)]
    [val-val next-off]))

(defn- write-val!
  "Write a value at pos. Returns next pos after written data."
  [s-atom-env ^js dv pos ^js val-bytes]
  (let [val-len (.-length val-bytes)]
    (.setUint32 dv pos val-len true)
    (when (pos? val-len)
      (.set (wasm/u8-view) val-bytes (+ pos 4)))
    (+ pos 4 val-len)))

(defn- get-val-at-idx
  "Read value at data index within a bitmap node."
  [s-atom-env ^js dv node-off data-bm node-bm idx]
  (let [val-start (val-data-start node-off node-bm)]
    (loop [i 0 pos val-start]
      (if (== i idx)
        (let [[v _] (read-val-at s-atom-env dv pos)]
          v)
        (recur (inc i) (skip-val-at dv pos))))))

;;-----------------------------------------------------------------------------
;; Raw byte copying helpers for value data (no vector creation)
;;-----------------------------------------------------------------------------

(defn- calc-node-val-total-size
  "Calculate total bytes used by all values in a bitmap node."
  [^js dv node-off data-bm node-bm]
  (let [val-start (val-data-start node-off node-bm)
        val-count (popcount32 data-bm)]
    (loop [i 0 pos val-start]
      (if (>= i val-count)
        (- pos val-start)
        (recur (inc i) (skip-val-at dv pos))))))

(defn- copy-val-data-all!
  "Copy all value data from src node to dst position."
  [s-atom-env ^js dv src-off src-data-bm src-node-bm dst-pos]
  (let [val-start (val-data-start src-off src-node-bm)
        total-size (calc-node-val-total-size dv src-off src-data-bm src-node-bm)]
    (when (pos? total-size)
      (wasm/memcpy! dst-pos val-start total-size))))

;;-----------------------------------------------------------------------------
;; Optimized node creation with raw byte copying
;;-----------------------------------------------------------------------------

(defn- make-bitmap-node-with-raw-val!
  "Create bitmap node, copying value data directly from source node via raw bytes.
   If update-child-idx >= 0, replaces that child with new-child-off."
  ([s-atom-env data-bm node-bm src-offset src-data-bm src-node-bm]
   (make-bitmap-node-with-raw-val! s-atom-env data-bm node-bm src-offset src-data-bm src-node-bm -1 -1))
  ([s-atom-env data-bm node-bm src-offset src-data-bm src-node-bm update-child-idx new-child-off]
   (let [dv (wasm/data-view)
         child-count (popcount32 node-bm)
         existing-val-size (calc-node-val-total-size dv src-offset src-data-bm src-node-bm)
         node-size (+ NODE_HEADER_SIZE (* 4 child-count) existing-val-size)
         offset (alloc-bytes! s-atom-env node-size)]
     ;; Write header
     (.setUint8 dv offset NODE_TYPE_BITMAP)
     (.setUint8 dv (+ offset 1) 0)
     (.setUint16 dv (+ offset 2) 0 true)
     (.setUint32 dv (+ offset 4) data-bm true)
     (.setUint32 dv (+ offset 8) node-bm true)
     ;; Write child offsets directly (no vector creation)
     (dotimes [i child-count]
       (let [child-off (if (== i update-child-idx)
                         new-child-off
                         (read-child-offset dv src-offset i))]
         (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4)) child-off true)))
     ;; Raw copy value data
     (copy-val-data-all! s-atom-env dv src-offset src-data-bm src-node-bm
                         (val-data-start offset node-bm))
     offset)))

(defn- make-bitmap-node-with-added-val!
  "Create bitmap node adding a new inline value at insert-idx.
   Copies existing values from source and inserts new value."
  [s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm insert-idx ^js vb]
  (let [dv (wasm/data-view)
        src-child-count (popcount32 src-node-bm)
        dst-child-count (popcount32 new-node-bm)
        data-count (popcount32 src-data-bm)
        src-val-size (calc-node-val-total-size dv src-offset src-data-bm src-node-bm)
        new-val-size (+ 4 (.-length vb))
        node-size (+ NODE_HEADER_SIZE (* 4 dst-child-count) src-val-size new-val-size)
        offset (alloc-bytes! s-atom-env node-size)]
    ;; Write header
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) 0 true)
    (.setUint32 dv (+ offset 4) new-data-bm true)
    (.setUint32 dv (+ offset 8) new-node-bm true)
    ;; Copy children (same as source)
    (dotimes [i src-child-count]
      (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4))
                 (read-child-offset dv src-offset i) true))
    ;; Copy values with insertion
    (let [src-val-start (val-data-start src-offset src-node-bm)
          dst-val-start (val-data-start offset new-node-bm)]
      (loop [src-i 0 src-pos src-val-start dst-pos dst-val-start inserted? false]
        (cond
          (and (== src-i insert-idx) (not inserted?))
          ;; Insert new value here
          (let [next-dst (write-val! s-atom-env dv dst-pos vb)]
            (recur src-i src-pos next-dst true))
          (>= src-i data-count)
          ;; Done with source, insert at end if not yet inserted
          (when-not inserted?
            (write-val! s-atom-env dv dst-pos vb))
          :else
          ;; Copy existing value
          (let [next-src (skip-val-at dv src-pos)
                val-len (- next-src src-pos)]
            (wasm/memcpy! dst-pos src-pos val-len)
            (recur (inc src-i) next-src (+ dst-pos val-len) inserted?)))))
    offset))

(defn- make-bitmap-node-removing-val!
  "Create bitmap node with value at remove-idx removed, optionally inserting a new child."
  ([s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm remove-idx]
   (make-bitmap-node-removing-val! s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm remove-idx -1 -1))
  ([s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm remove-idx insert-child-idx new-child-off]
   (let [dv (wasm/data-view)
         src-child-count (popcount32 src-node-bm)
         dst-child-count (popcount32 new-node-bm)
         data-count (popcount32 src-data-bm)
         ;; Calculate size - one fewer value, possibly one more child
         src-val-size (calc-node-val-total-size dv src-offset src-data-bm src-node-bm)
         ;; Find size of removed value
         removed-val-size (let [val-start (val-data-start src-offset src-node-bm)]
                            (loop [i 0 pos val-start]
                              (if (== i remove-idx)
                                (- (skip-val-at dv pos) pos)
                                (recur (inc i) (skip-val-at dv pos)))))
         new-val-size (- src-val-size removed-val-size)
         node-size (+ NODE_HEADER_SIZE (* 4 dst-child-count) new-val-size)
         offset (alloc-bytes! s-atom-env node-size)]
     ;; Write header
     (.setUint8 dv offset NODE_TYPE_BITMAP)
     (.setUint8 dv (+ offset 1) 0)
     (.setUint16 dv (+ offset 2) 0 true)
     (.setUint32 dv (+ offset 4) new-data-bm true)
     (.setUint32 dv (+ offset 8) new-node-bm true)
     ;; Copy children with optional insertion
     (if (>= insert-child-idx 0)
       ;; Insert new child
       (loop [src-i 0 dst-i 0]
         (cond
           (>= dst-i dst-child-count) nil  ;; done
           (== dst-i insert-child-idx)
           (do (.setInt32 dv (+ offset NODE_HEADER_SIZE (* dst-i 4)) new-child-off true)
               (recur src-i (inc dst-i)))
           :else
           (do (.setInt32 dv (+ offset NODE_HEADER_SIZE (* dst-i 4))
                          (read-child-offset dv src-offset src-i) true)
               (recur (inc src-i) (inc dst-i)))))
       ;; Copy children unchanged
       (dotimes [i src-child-count]
         (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4))
                    (read-child-offset dv src-offset i) true)))
     ;; Copy values, skipping removed one
     (let [src-val-start (val-data-start src-offset src-node-bm)
           dst-val-start (val-data-start offset new-node-bm)]
       (loop [i 0 src-pos src-val-start dst-pos dst-val-start]
         (when (< i data-count)
           (let [next-src (skip-val-at dv src-pos)
                 val-len (- next-src src-pos)]
             (if (== i remove-idx)
               ;; Skip this value
               (recur (inc i) next-src dst-pos)
               ;; Copy this value
               (do (wasm/memcpy! dst-pos src-pos val-len)
                   (recur (inc i) next-src (+ dst-pos val-len))))))))
     offset)))

(defn- make-bitmap-node-removing-child!
  "Create bitmap node with a child removed (for disj)."
  [s-atom-env data-bm new-node-bm src-offset src-data-bm src-node-bm remove-child-idx]
  (let [dv (wasm/data-view)
        src-child-count (popcount32 src-node-bm)
        dst-child-count (popcount32 new-node-bm)
        val-size (calc-node-val-total-size dv src-offset src-data-bm src-node-bm)
        node-size (+ NODE_HEADER_SIZE (* 4 dst-child-count) val-size)
        offset (alloc-bytes! s-atom-env node-size)]
    ;; Write header
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) 0 true)
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) new-node-bm true)
    ;; Copy children, skipping removed one
    (loop [src-i 0 dst-i 0]
      (when (< src-i src-child-count)
        (if (== src-i remove-child-idx)
          (recur (inc src-i) dst-i)
          (do (.setInt32 dv (+ offset NODE_HEADER_SIZE (* dst-i 4))
                         (read-child-offset dv src-offset src-i) true)
              (recur (inc src-i) (inc dst-i))))))
    ;; Raw copy all value data
    (copy-val-data-all! s-atom-env dv src-offset src-data-bm src-node-bm
                        (val-data-start offset new-node-bm))
    offset))

(defn- make-single-val-bitmap-node!
  "Create a bitmap node with single inline value."
  [s-atom-env bit-pos ^js vb]
  (let [dv (wasm/data-view)
        data-bm (bit-shift-left 1 bit-pos)
        val-len (.-length vb)
        node-size (+ NODE_HEADER_SIZE 4 val-len)  ;; header + val len + val bytes
        offset (alloc-bytes! s-atom-env node-size)]
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) 0 true)
    (.setUint32 dv (+ offset 4) data-bm true)  ;; data_bitmap
    (.setUint32 dv (+ offset 8) 0 true)        ;; node_bitmap = 0
    ;; Write value (no children)
    (.setUint32 dv (+ offset NODE_HEADER_SIZE) val-len true)
    (when (pos? val-len)
      (.set (wasm/u8-view) vb (+ offset NODE_HEADER_SIZE 4)))
    offset))

(defn- make-two-val-bitmap-node!
  "Create a bitmap node with two inline values at different bit positions."
  [s-atom-env bit-pos1 ^js vb1 bit-pos2 ^js vb2]
  (let [dv (wasm/data-view)
        ;; Order by bit position
        [first-bpos first-vb second-bpos second-vb]
        (if (< bit-pos1 bit-pos2)
          [bit-pos1 vb1 bit-pos2 vb2]
          [bit-pos2 vb2 bit-pos1 vb1])
        data-bm (bit-or (bit-shift-left 1 first-bpos) (bit-shift-left 1 second-bpos))
        val1-len (.-length first-vb)
        val2-len (.-length second-vb)
        node-size (+ NODE_HEADER_SIZE 4 val1-len 4 val2-len)
        offset (alloc-bytes! s-atom-env node-size)]
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) 0 true)
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) 0 true)  ;; node_bitmap = 0
    ;; Write first value
    (let [pos1 (+ offset NODE_HEADER_SIZE)]
      (.setUint32 dv pos1 val1-len true)
      (when (pos? val1-len)
        (.set (wasm/u8-view) first-vb (+ pos1 4)))
      ;; Write second value
      (let [pos2 (+ pos1 4 val1-len)]
        (.setUint32 dv pos2 val2-len true)
        (when (pos? val2-len)
          (.set (wasm/u8-view) second-vb (+ pos2 4)))))
    offset))

(defn- make-collision-node!
  "Create a collision node for values with same hash."
  [s-atom-env hash-val val-bytes-seq]
  (let [cnt (count val-bytes-seq)
        ;; Calculate total size
        entries-size (reduce (fn [acc vb] (+ acc 4 (.-length vb))) 0 val-bytes-seq)
        node-size (+ NODE_HEADER_SIZE entries-size)
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)
        u8 (wasm/u8-view)]
    (.setUint8 dv offset NODE_TYPE_COLLISION)
    (.setUint8 dv (+ offset 1) cnt)
    (.setUint32 dv (+ offset 2) hash-val true)
    (.setUint32 dv (+ offset 8) 0 true)  ;; unused
    ;; Write entries
    (loop [vs (seq val-bytes-seq) pos (+ offset NODE_HEADER_SIZE)]
      (when vs
        (let [vb (first vs)
              vlen (.-length vb)]
          (.setUint32 dv pos vlen true)
          (when (pos? vlen) (.set u8 vb (+ pos 4)))
          (recur (next vs) (+ pos 4 vlen)))))
    offset))

;;-----------------------------------------------------------------------------
;; HAMT lookup
;;-----------------------------------------------------------------------------

(defn- hamt-find
  "Look up value in HAMT. Returns found?."
  [s-atom-env ^js dv root-off v vh shift]
  (if (== root-off -1)
    false
    (let [node-type (read-node-type dv root-off)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv root-off)
                node-bm (read-node-bitmap dv root-off)
                bit-pos (bit-and (unsigned-bit-shift-right vh shift) MASK)]
            (cond
              ;; Check inline value first
              (has-data? data-bm bit-pos)
              (let [idx (get-data-idx data-bm bit-pos)
                    found-v (get-val-at-idx s-atom-env dv root-off data-bm node-bm idx)]
                (= v found-v))

              ;; Check child node
              (has-node? node-bm bit-pos)
              (let [idx (get-child-idx node-bm bit-pos)
                    child-off (read-child-offset dv root-off idx)]
                (recur s-atom-env dv child-off v vh (+ shift SHIFT_STEP)))

              ;; Not found
              :else false))

        ;; Collision node
        2 (let [cnt (.getUint8 dv (+ root-off 1))]
            (loop [i 0 pos (+ root-off NODE_HEADER_SIZE)]
              (if (>= i cnt)
                false
                (let [[entry-v next-pos] (read-val-at s-atom-env dv pos)]
                  (if (= v entry-v)
                    true
                    (recur (inc i) next-pos))))))

        ;; Unknown
        false))))

;;-----------------------------------------------------------------------------
;; HAMT conj (persistent)
;;-----------------------------------------------------------------------------

;; Module-level mutable flags to eliminate CLJS vector allocation per hamt-conj/disj call.
(def ^:private ^:mutable hamt-conj-added? false)
(def ^:private ^:mutable hamt-disj-removed? false)

(defn- hamt-conj
  "Add value to HAMT. Returns new-root-off (integer).
   Sets hamt-conj-added? to true if new value, false otherwise."
  [s-atom-env root-off v vh vb shift]
  (if (== root-off -1)
    ;; Empty → create single-value bitmap node
    (let [bit-pos (bit-and (unsigned-bit-shift-right vh shift) MASK)]
      (set! hamt-conj-added? true)
      (make-single-val-bitmap-node! s-atom-env bit-pos vb))
    (let [dv (wasm/data-view)
          node-type (read-node-type dv root-off)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv root-off)
                node-bm (read-node-bitmap dv root-off)
                bit-pos (bit-and (unsigned-bit-shift-right vh shift) MASK)]
            (cond
              ;; Slot has inline value
              (has-data? data-bm bit-pos)
              (let [idx (get-data-idx data-bm bit-pos)
                    existing-v (get-val-at-idx s-atom-env dv root-off data-bm node-bm idx)]
                (if (= v existing-v)
                  ;; Already in set
                  (do (set! hamt-conj-added? false) root-off)
                  ;; Need to split: remove inline, add child node
                  (let [existing-vb (ser/serialize-val existing-v)
                        existing-vh (hash existing-v)]
                    (if (== existing-vh vh)
                      ;; Hash collision → create collision node as child
                      (let [collision-off (make-collision-node! s-atom-env vh [existing-vb vb])
                            new-data-bm (bit-xor data-bm (bit-shift-left 1 bit-pos))
                            new-node-bm (bit-or node-bm (bit-shift-left 1 bit-pos))
                            child-idx (get-child-idx new-node-bm bit-pos)]
                        (set! hamt-conj-added? true)
                        (make-bitmap-node-removing-val! s-atom-env new-data-bm new-node-bm
                                                         root-off data-bm node-bm idx
                                                         child-idx collision-off))
                      ;; Different hashes → recurse to split
                      (let [new-child-off (let [bp1 (bit-and (unsigned-bit-shift-right existing-vh (+ shift SHIFT_STEP)) MASK)
                                                bp2 (bit-and (unsigned-bit-shift-right vh (+ shift SHIFT_STEP)) MASK)]
                                            (if (== bp1 bp2)
                                              ;; Same position at next level, need deeper split
                                              (let [sub (hamt-conj s-atom-env
                                                                   (make-single-val-bitmap-node! s-atom-env bp1 existing-vb)
                                                                   v vh vb (+ shift SHIFT_STEP SHIFT_STEP))]
                                                sub)
                                              ;; Different positions → two-value node
                                              (make-two-val-bitmap-node! s-atom-env bp1 existing-vb bp2 vb)))
                            new-data-bm (bit-xor data-bm (bit-shift-left 1 bit-pos))
                            new-node-bm (bit-or node-bm (bit-shift-left 1 bit-pos))
                            child-idx (get-child-idx new-node-bm bit-pos)]
                        (set! hamt-conj-added? true)
                        (make-bitmap-node-removing-val! s-atom-env new-data-bm new-node-bm
                                                         root-off data-bm node-bm idx
                                                         child-idx new-child-off))))))

              ;; Slot has child node
              (has-node? node-bm bit-pos)
              (let [child-idx (get-child-idx node-bm bit-pos)
                    child-off (read-child-offset dv root-off child-idx)
                    new-child-off (hamt-conj s-atom-env child-off v vh vb (+ shift SHIFT_STEP))]
                ;; hamt-conj-added? set by recursive call
                (if-not hamt-conj-added?
                  root-off
                  ;; Child was modified
                  (make-bitmap-node-with-raw-val! s-atom-env data-bm node-bm
                                                   root-off data-bm node-bm
                                                   child-idx new-child-off)))

              ;; Empty slot → add inline value
              :else
              (let [new-data-bm (bit-or data-bm (bit-shift-left 1 bit-pos))
                    insert-idx (get-data-idx new-data-bm bit-pos)]
                (set! hamt-conj-added? true)
                (make-bitmap-node-with-added-val! s-atom-env new-data-bm node-bm
                                                   root-off data-bm node-bm
                                                   insert-idx vb))))

        ;; Collision node
        2 (let [node-hash (.getUint32 dv (+ root-off 2) true)
                cnt (.getUint8 dv (+ root-off 1))]
            (if (== vh node-hash)
              ;; Same hash → check if already present or add
              (loop [i 0 pos (+ root-off NODE_HEADER_SIZE) val-bytes-list []]
                (if (>= i cnt)
                  ;; Value not found → add new entry
                  (let [all-vals (conj val-bytes-list vb)]
                    (set! hamt-conj-added? true)
                    (make-collision-node! s-atom-env vh all-vals))
                  (let [val-len (.getUint32 dv pos true)
                        val-bytes (copy-from-sab (+ pos 4) val-len)
                        entry-v (ser/deserialize-element s-atom-env val-bytes)
                        next-pos (+ pos 4 val-len)]
                    (if (= v entry-v)
                      ;; Already in set
                      (do (set! hamt-conj-added? false) root-off)
                      ;; Continue searching
                      (recur (inc i) next-pos (conj val-bytes-list val-bytes))))))
              ;; Different hash → split into internal node
              (let [bit-pos1 (bit-and (unsigned-bit-shift-right node-hash shift) MASK)
                    bit-pos2 (bit-and (unsigned-bit-shift-right vh shift) MASK)]
                (if (== bit-pos1 bit-pos2)
                  ;; Same bit position → recurse
                  (let [sub-node (hamt-conj s-atom-env root-off v vh vb (+ shift SHIFT_STEP))
                        ;; hamt-conj-added? set by recursive call
                        node-bm (bit-shift-left 1 bit-pos1)
                        offset (alloc-bytes! s-atom-env (+ NODE_HEADER_SIZE 4))
                        dv2 (wasm/data-view)]
                    (.setUint8 dv2 offset NODE_TYPE_BITMAP)
                    (.setUint8 dv2 (+ offset 1) 0)
                    (.setUint16 dv2 (+ offset 2) 0 true)       ;; pad
                    (.setUint32 dv2 (+ offset 4) 0 true)       ;; data_bitmap = 0
                    (.setUint32 dv2 (+ offset 8) node-bm true) ;; node_bitmap
                    (.setInt32 dv2 (+ offset NODE_HEADER_SIZE) sub-node true)
                    offset)
                  ;; Different positions → collision + new value
                  (let [new-val-off (make-single-val-bitmap-node! s-atom-env bit-pos2 vb)
                        node-bm (bit-or (bit-shift-left 1 bit-pos1) (bit-shift-left 1 bit-pos2))
                        offset (alloc-bytes! s-atom-env (+ NODE_HEADER_SIZE 8))
                        dv2 (wasm/data-view)]
                    (.setUint8 dv2 offset NODE_TYPE_BITMAP)
                    (.setUint8 dv2 (+ offset 1) 0)
                    (.setUint16 dv2 (+ offset 2) 0 true)       ;; pad
                    (.setUint32 dv2 (+ offset 4) 0 true)       ;; data_bitmap = 0
                    (.setUint32 dv2 (+ offset 8) node-bm true) ;; node_bitmap
                    ;; Order children by bit position
                    (if (< bit-pos1 bit-pos2)
                      (do (.setInt32 dv2 (+ offset NODE_HEADER_SIZE) root-off true)
                          (.setInt32 dv2 (+ offset NODE_HEADER_SIZE 4) new-val-off true))
                      (do (.setInt32 dv2 (+ offset NODE_HEADER_SIZE) new-val-off true)
                          (.setInt32 dv2 (+ offset NODE_HEADER_SIZE 4) root-off true)))
                    (set! hamt-conj-added? true)
                    offset)))))

        ;; Unknown
        (do (set! hamt-conj-added? false) root-off)))))

;;-----------------------------------------------------------------------------
;; HAMT disj (persistent)
;;-----------------------------------------------------------------------------

(defn- hamt-disj
  "Remove value from HAMT. Returns new-root-off (integer).
   Sets hamt-disj-removed? to true if value was removed, false otherwise."
  [s-atom-env root-off v vh shift]
  (if (== root-off -1)
    (do (set! hamt-disj-removed? false) -1)
    (let [dv (wasm/data-view)
          node-type (read-node-type dv root-off)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv root-off)
                node-bm (read-node-bitmap dv root-off)
                bit-pos (bit-and (unsigned-bit-shift-right vh shift) MASK)]
            (cond
              ;; Check inline value
              (has-data? data-bm bit-pos)
              (let [idx (get-data-idx data-bm bit-pos)
                    found-v (get-val-at-idx s-atom-env dv root-off data-bm node-bm idx)]
                (if-not (= v found-v)
                  (do (set! hamt-disj-removed? false) root-off)
                  ;; Remove this inline value
                  (let [new-data-bm (bit-xor data-bm (bit-shift-left 1 bit-pos))
                        total-entries (+ (popcount32 new-data-bm) (popcount32 node-bm))]
                    (set! hamt-disj-removed? true)
                    (if (zero? total-entries)
                      ;; Node becomes empty
                      -1
                      ;; Remove value from node
                      (make-bitmap-node-removing-val! s-atom-env new-data-bm node-bm
                                                       root-off data-bm node-bm idx)))))

              ;; Check child node
              (has-node? node-bm bit-pos)
              (let [child-idx (get-child-idx node-bm bit-pos)
                    child-off (read-child-offset dv root-off child-idx)
                    new-child (hamt-disj s-atom-env child-off v vh (+ shift SHIFT_STEP))]
                ;; hamt-disj-removed? set by recursive call
                (if-not hamt-disj-removed?
                  root-off
                  (if (== new-child -1)
                    ;; Child was removed entirely
                    (let [new-node-bm (bit-xor node-bm (bit-shift-left 1 bit-pos))
                          total-entries (+ (popcount32 data-bm) (popcount32 new-node-bm))]
                      (if (zero? total-entries)
                        -1
                        (make-bitmap-node-removing-child! s-atom-env data-bm new-node-bm
                                                           root-off data-bm node-bm child-idx)))
                    ;; Child was modified
                    (make-bitmap-node-with-raw-val! s-atom-env data-bm node-bm
                                                     root-off data-bm node-bm
                                                     child-idx new-child))))

              ;; Not found
              :else (do (set! hamt-disj-removed? false) root-off)))

        ;; Collision node
        2 (let [cnt (.getUint8 dv (+ root-off 1))
                node-hash (.getUint32 dv (+ root-off 2) true)]
            (loop [i 0 pos (+ root-off NODE_HEADER_SIZE) val-bytes-list []]
              (if (>= i cnt)
                ;; Value not found
                (do (set! hamt-disj-removed? false) root-off)
                (let [val-len (.getUint32 dv pos true)
                      val-bytes (copy-from-sab (+ pos 4) val-len)
                      entry-v (ser/deserialize-element s-atom-env val-bytes)
                      next-pos (+ pos 4 val-len)]
                  (if (= v entry-v)
                    ;; Found - remove it
                    (let [rest-vals (loop [j (inc i) p next-pos acc []]
                                      (if (>= j cnt)
                                        acc
                                        (let [vl (.getUint32 dv p true)
                                              vbytes (copy-from-sab (+ p 4) vl)]
                                          (recur (inc j) (+ p 4 vl) (conj acc vbytes)))))
                          all-remaining (into val-bytes-list rest-vals)]
                      (set! hamt-disj-removed? true)
                      (cond
                        (empty? all-remaining) -1
                        (== 1 (count all-remaining))
                        ;; Convert to single-value bitmap node
                        (let [vb (first all-remaining)
                              bp (bit-and (unsigned-bit-shift-right node-hash shift) MASK)]
                          (make-single-val-bitmap-node! s-atom-env bp vb))
                        :else
                        (make-collision-node! s-atom-env node-hash all-remaining)))
                    ;; Continue searching
                    (recur (inc i) next-pos (conj val-bytes-list val-bytes)))))))

        ;; Unknown
        (do (set! hamt-disj-removed? false) root-off)))))

;;-----------------------------------------------------------------------------
;; Streaming reduce (direct tree walk, no materialization)
;;-----------------------------------------------------------------------------

(defn- hamt-val-reduce
  "Walk HAMT tree directly, calling (f acc v) at each value.
   Supports reduced? for early termination."
  [s-atom-env ^js dv offset f init]
  (if (== offset -1)
    init
    (let [node-type (read-node-type dv offset)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv offset)
                node-bm (read-node-bitmap dv offset)
                data-count (popcount32 data-bm)
                val-start (val-data-start offset node-bm)
                ;; Reduce over inline values
                acc-after-data
                (loop [i 0 pos val-start acc init]
                  (if (or (>= i data-count) (reduced? acc))
                    acc
                    (let [[v next-pos] (read-val-at s-atom-env dv pos)]
                      (recur (inc i) next-pos (f acc v)))))
                child-count (popcount32 node-bm)]
            (if (reduced? acc-after-data)
              acc-after-data
              ;; Reduce over children
              (loop [i 0 acc acc-after-data]
                (if (or (>= i child-count) (reduced? acc))
                  acc
                  (let [child-off (read-child-offset dv offset i)]
                    (recur (inc i) (hamt-val-reduce s-atom-env dv child-off f acc)))))))

        ;; Collision node
        2 (let [cnt (.getUint8 dv (+ offset 1))]
            (loop [i 0 pos (+ offset NODE_HEADER_SIZE) acc init]
              (if (or (>= i cnt) (reduced? acc))
                acc
                (let [[v next-pos] (read-val-at s-atom-env dv pos)]
                  (recur (inc i) next-pos (f acc v))))))

        init))))

;;-----------------------------------------------------------------------------
;; HAMT seq
;;-----------------------------------------------------------------------------

(defn- hamt-seq
  "Return lazy seq of values from HAMT."
  [s-atom-env root-off]
  (when (not= root-off -1)
    (let [dv (wasm/data-view)]
      ((fn walk [off]
         (lazy-seq
          (when (not= off -1)
            (let [node-type (read-node-type dv off)]
              (case node-type
                ;; Bitmap node
                1 (let [data-bm (read-data-bitmap dv off)
                        node-bm (read-node-bitmap dv off)
                        data-count (popcount32 data-bm)
                        child-count (popcount32 node-bm)
                        ;; Inline values first
                        inline-vals (when (pos? data-count)
                                      (loop [i 0 pos (val-data-start off node-bm) result []]
                                        (if (>= i data-count)
                                          result
                                          (let [[v next-pos] (read-val-at s-atom-env dv pos)]
                                            (recur (inc i) next-pos (conj result v))))))
                        ;; Then children
                        child-vals (when (pos? child-count)
                                     (mapcat (fn [i]
                                               (walk (read-child-offset dv off i)))
                                             (range child-count)))]
                    (concat inline-vals child-vals))

                ;; Collision node
                2 (let [cnt (.getUint8 dv (+ off 1))]
                    (loop [i 0 pos (+ off NODE_HEADER_SIZE) result []]
                      (if (>= i cnt)
                        result
                        (let [[v next-pos] (read-val-at s-atom-env dv pos)]
                          (recur (inc i) next-pos (conj result v))))))

                ;; Unknown
                nil)))))
       root-off))))

;;-----------------------------------------------------------------------------
;; SabSetRoot - persistent set handle
;;-----------------------------------------------------------------------------

(eve-sab-deftype SabSetRoot
  [^:int32 cnt        ;; number of values
   ^:int32 root-off]  ;; offset to root node, -1 for empty

  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [this v] (-lookup this v nil))
  (-lookup [_ v not-found]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          vh (hash v)]
      (if (hamt-find s-atom-env dv root-off v vh 0)
        v
        not-found)))

  ICollection
  (-conj [this v]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          vb (ser/serialize-key v)
          vh (hash v)
          new-root (hamt-conj s-atom-env root-off v vh vb 0)]
      (if hamt-conj-added?
        (let [new-set (->SabSetRoot (inc cnt) new-root)
              parent-khs (.-_modified_khs this)
              parent-len (if parent-khs (.-length parent-khs) 0)]
          (when (<= parent-len 8)
            (let [khs (if (and parent-khs (pos? parent-len)) (.slice parent-khs 0) #js [])]
              (.push khs vh)
              (set! (.-_modified_khs new-set) khs)))
          new-set)
        this)))

  IEmptyableCollection
  (-empty [_] (empty-sab-set))

  ISet
  (-disjoin [this v]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          vh (hash v)
          new-root (hamt-disj s-atom-env root-off v vh 0)]
      (if hamt-disj-removed?
        (if (== new-root -1)
          (empty-sab-set)
          (let [new-set (->SabSetRoot (dec cnt) new-root)
                parent-khs (.-_modified_khs this)
                parent-len (if parent-khs (.-length parent-khs) 0)]
            (when (<= parent-len 8)
              (let [khs (if (and parent-khs (pos? parent-len)) (.slice parent-khs 0) #js [])]
                (.push khs vh)
                (set! (.-_modified_khs new-set) khs)))
            new-set))
        this)))

  ISeqable
  (-seq [_]
    (when (pos? cnt)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)]
        (hamt-seq s-atom-env root-off))))

  IEquiv
  (-equiv [this other]
    (and (set? other)
         (== cnt (count other))
         (every? (fn [v]
                   (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
                         dv (wasm/data-view)]
                     (hamt-find s-atom-env dv root-off v (hash v) 0)))
                 other)))

  IFn
  (-invoke [this v] (-lookup this v nil))
  (-invoke [this v not-found] (-lookup this v not-found))

  IHash
  (-hash [this]
    (hash-unordered-coll (seq this)))

  IReduce
  (-reduce [this f]
    (if (zero? cnt)
      (f)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)
            ;; Get first value and reduce from there
            first-val (first (seq this))
            result (hamt-val-reduce s-atom-env dv root-off
                                    (fn [acc v]
                                      (if (identical? v first-val)
                                        acc  ;; Skip first value
                                        (f acc v)))
                                    first-val)]
        (if (reduced? result) @result result))))
  (-reduce [this f init]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)
          dv (wasm/data-view)
          result (hamt-val-reduce s-atom-env dv root-off f init)]
      (if (reduced? result) @result result)))

  IPrintWithWriter
  (-pr-writer [this writer opts]
    (let [values (take 10 (seq this))]
      (-write writer "#{")
      (doseq [[i v] (map-indexed vector values)]
        (when (pos? i) (-write writer " "))
        (-write writer (pr-str v)))
      (when (> cnt 10)
        (-write writer " ..."))
      (-write writer "}")))

  IEditableCollection
  (-as-transient [this]
    (let [s-atom-env (atom/get-env atom/*global-atom-instance*)]
      (->TransientSabSet s-atom-env root-off this root-off cnt (js/Object.))))

  d/IDirectSerialize
  (-direct-serialize [this]
    (ser/encode-sab-pointer ser/FAST_TAG_SAB_SET (.-offset__ this)))

  d/ISabStorable
  (-sab-tag [_] :sab-set)
  (-sab-encode [this _s-atom-env]
    (d/-direct-serialize this))
  (-sab-dispose [this _s-atom-env]
    (when (> root-off -1)
      (let [env (atom/get-env atom/*global-atom-instance*)
            dv (wasm/data-view)]
        (free-hamt-node! env dv root-off))))

  d/ISabRetirable
  (-sab-retire-diff! [this new-value s-atom-env mode]
    (let [old-root root-off]
      (if (instance? SabSetRoot new-value)
        (let [dv (wasm/data-view)
              new-root-off (.getInt32 dv (+ (SabSetRoot-offset new-value) 8) true)
              modified-khs (.-_modified_khs new-value)]
          (if (and modified-khs (pos? (.-length modified-khs)) (<= (.-length modified-khs) 8))
            ;; Fast path: retire via hash-directed path walk for each modified key
            (dotimes [i (.-length modified-khs)]
              (retire-replaced-path! s-atom-env old-root new-root-off (aget modified-khs i) mode))
            ;; Fallback: full tree diff for bulk operations
            (retire-tree-diff! s-atom-env old-root new-root-off mode)))
        (when (> old-root -1)
          (let [dv (wasm/data-view)]
            (free-hamt-node! s-atom-env dv old-root)))))))

;;-----------------------------------------------------------------------------
;; TransientSabSet - mutable set for batch operations
;;-----------------------------------------------------------------------------

(deftype TransientSabSet [s-atom-env
                           initial-root-off
                           original-persistent
                           ^:mutable root-offset
                           ^:mutable cnt
                           ^:mutable edit]
  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [this v] (-lookup this v nil))
  (-lookup [_ v not-found]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [dv (wasm/data-view)
          vh (hash v)]
      (if (hamt-find s-atom-env dv root-offset v vh 0)
        v
        not-found)))

  ITransientCollection
  (-conj! [this v]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [vb (ser/serialize-key v)
          vh (hash v)
          new-root (hamt-conj s-atom-env root-offset v vh vb 0)]
      (set! root-offset new-root)
      (when hamt-conj-added? (set! cnt (inc cnt)))
      this))
  (-persistent! [_]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (set! edit nil)
    (if (== root-offset initial-root-off)
      ;; No-op transient round-trip: return original persistent set
      original-persistent
      (->SabSetRoot cnt root-offset)))

  ITransientSet
  (-disjoin! [this v]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [vh (hash v)
          new-root (hamt-disj s-atom-env root-offset v vh 0)]
      (set! root-offset new-root)
      (when hamt-disj-removed? (set! cnt (dec cnt)))
      this)))

;;-----------------------------------------------------------------------------
;; Disposal - explicit cleanup for reclaiming SAB memory
;;-----------------------------------------------------------------------------

(defn dispose!
  "Dispose a SabSetRoot, freeing its entire HAMT tree.
   Call this when the set is no longer needed to reclaim SAB memory.

   WARNING: After disposal, the set must not be used. Any access will
   result in undefined behavior or errors."
  [sab-set]
  (let [dv (wasm/data-view)
        root-off (.getInt32 dv (+ (SabSetRoot-offset sab-set) 8) true)]
    (when (> root-off -1)
      (let [s-atom-env (atom/get-env atom/*global-atom-instance*)]
        (free-hamt-node! s-atom-env dv root-off)))))

(defn retire-replaced-path!
  "After an atom swap that replaced old-root with new-root, retire the old
   path nodes that are no longer referenced by the new tree.

   Walks both trees following the hash bits for value hash vh. At each level
   where old-node != new-node, the old node is retired via retire-block!
   (epoch-based) or freed via maybe-pool-or-free! (immediate).

   Only retires individual path nodes — shared subtrees are untouched.

   mode: :retire (epoch-based, for multi-worker) or :free (immediate pool/free)
   vh: the hash of the value that was modified"
  ([s-atom-env old-root new-root vh]
   (retire-replaced-path! s-atom-env old-root new-root vh :free))
  ([s-atom-env old-root new-root vh mode]
   (when (and (not= old-root -1) (not= old-root new-root))
     (let [dv (wasm/data-view)]
       (loop [old-off old-root
              new-off new-root
              sh 0]
         (when (and (not= old-off -1) (not= old-off new-off))
           ;; Retire/free this old node
           (when-let [desc-idx (find-desc-idx s-atom-env old-off)]
             (if (= mode :retire)
               (atom/retire-block! s-atom-env desc-idx)
               (let [size (find-desc-capacity s-atom-env old-off)]
                 (maybe-pool-or-free! s-atom-env old-off desc-idx size))))
           ;; Continue down the hash path via node_bitmap children
           (let [old-type (read-node-type dv old-off)
                 new-type (read-node-type dv new-off)]
             (when (and (== old-type NODE_TYPE_BITMAP) (== new-type NODE_TYPE_BITMAP))
               (let [bit-pos (bit-and (unsigned-bit-shift-right vh sh) MASK)
                     old-node-bm (read-node-bitmap dv old-off)
                     new-node-bm (read-node-bitmap dv new-off)]
                 (when (and (has-node? old-node-bm bit-pos)
                            (has-node? new-node-bm bit-pos))
                   (let [old-child-idx (get-child-idx old-node-bm bit-pos)
                         new-child-idx (get-child-idx new-node-bm bit-pos)
                         old-child (read-child-offset dv old-off old-child-idx)
                         new-child (read-child-offset dv new-off new-child-idx)]
                     (recur old-child new-child (+ sh SHIFT_STEP)))))))))))))

(defn retire-tree-diff!
  "Full tree diff: walk old and new HAMT trees in parallel, retiring all
   old nodes that differ from the new tree.

   At each node pair:
   - If old-off == new-off → shared subtree, skip entirely
   - If old-off != new-off → retire old node, recurse into children

   This handles multi-element operations where retire-replaced-path!
   (single-hash) is insufficient.

   Cost: O(changed nodes). Shared subtrees are skipped via integer compare.

   mode: :retire (epoch-based, for multi-worker) or :free (immediate pool/free)"
  ([s-atom-env old-root new-root]
   (retire-tree-diff! s-atom-env old-root new-root :free))
  ([s-atom-env old-root new-root mode]
   (when (and (not= old-root -1) (not= old-root new-root))
     (let [dv (wasm/data-view)]
       (letfn [(walk [old-off new-off]
                 (when (and (not= old-off -1) (not= old-off new-off))
                   ;; Retire this old node
                   (when-let [desc-idx (find-desc-idx s-atom-env old-off)]
                     (if (= mode :retire)
                       (atom/retire-block! s-atom-env desc-idx)
                       (let [size (find-desc-capacity s-atom-env old-off)]
                         (maybe-pool-or-free! s-atom-env old-off desc-idx size))))
                   ;; Recurse into children if both are bitmap nodes
                   (let [old-type (read-node-type dv old-off)]
                     (when (== old-type NODE_TYPE_BITMAP)
                       (let [old-node-bm (read-node-bitmap dv old-off)
                             new-type (when (not= new-off -1) (read-node-type dv new-off))
                             new-node-bm (when (and new-type (== new-type NODE_TYPE_BITMAP))
                                           (read-node-bitmap dv new-off))]
                         ;; Walk only set bits in old-node-bm (bit-walking)
                         (loop [remaining old-node-bm
                                old-idx 0]
                           (when (not (zero? remaining))
                             (let [bit (bit-and remaining (- remaining))  ;; lowest set bit
                                   old-child (read-child-offset dv old-off old-idx)
                                   new-child (when (and new-node-bm (not (zero? (bit-and new-node-bm bit))))
                                               (let [new-idx (popcount32 (bit-and new-node-bm (dec bit)))]
                                                 (read-child-offset dv new-off new-idx)))]
                               (walk old-child (or new-child -1))
                               (recur (bit-and remaining (dec remaining)) (inc old-idx))))))))))]
         (walk old-root new-root))))))

;;-----------------------------------------------------------------------------
;; Constructors
;;-----------------------------------------------------------------------------

(defn empty-sab-set
  "Return an empty SAB-backed set."
  []
  (->SabSetRoot 0 -1))

(defn sab-set
  "Create a SAB-backed set from values."
  [& vs]
  (reduce conj (empty-sab-set) vs))

(defn into-sab-set
  "Create a SAB-backed set from a collection."
  [coll]
  (reduce conj (empty-sab-set) coll))

;;-----------------------------------------------------------------------------
;; SAB Pointer Registration
;;-----------------------------------------------------------------------------

(ser/register-sab-type-constructor!
  ser/FAST_TAG_SAB_SET
  (fn [sab offset] (SabSetRoot. sab offset)))

(ser/register-cljs-to-sab-builder!
  set?
  (fn [s] (into-sab-set s)))

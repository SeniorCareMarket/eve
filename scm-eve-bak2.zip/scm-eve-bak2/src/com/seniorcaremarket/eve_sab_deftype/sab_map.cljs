(ns com.seniorcaremarket.eve-sab-deftype.sab-map
  "SAB-backed persistent map with fast-path serialization.

   Built on eve-sab-deftype with full feature parity:
   - Supports arbitrary CLJS keys and values (via fast-path serialization)
   - Fast-path for primitives (nil, bool, int32, float64, string, keyword)
   - Arena-based allocation for efficient transients
   - Two-bitmap HAMT-style trie with 32-way branching
     - data_bitmap: tracks inline KV entries
     - node_bitmap: tracks child node pointers

   Architecture:
   - SabMapRoot: root handle with count and root-offset
   - Bitmap nodes: data_bitmap + node_bitmap + children + inline KV entries
   - Collision nodes: list of KV pairs with same hash"
  (:require
   [com.seniorcaremarket.eve.atom :as atom]
   [com.seniorcaremarket.eve.data :as d]
   [com.seniorcaremarket.eve.util :as u]
   [com.seniorcaremarket.eve.wasm-mem :as wasm]
   [com.seniorcaremarket.eve-sab-deftype.serialize :as ser])
  ;; All EVE atoms use WASM memory. The wasm-mem module provides SIMD-accelerated
  ;; primitives including full HAMT lookup in WASM.
  (:require-macros
   [com.seniorcaremarket.eve-sab-deftype.core :refer [eve-sab-deftype]]))

;; Forward declarations
(declare ->SabMapRoot ->TransientSabMap SabMapRoot TransientSabMap)
(declare empty-sab-map)

;;-----------------------------------------------------------------------------
;; Constants
;;-----------------------------------------------------------------------------

(def ^:const SHIFT_STEP 5)
(def ^:const MASK 0x1f)      ;; 31

;; Node types encoded in first byte
(def ^:const NODE_TYPE_BITMAP 1)     ;; Two-bitmap node with inline KV + children
(def ^:const NODE_TYPE_COLLISION 3)

;; Node header: type:u8 + flags:u8 + pad:u16 + data_bitmap:u32 + node_bitmap:u32 = 12
(def ^:const NODE_HEADER_SIZE 12)

;; Collision node header: type:u8 + count:u8 + pad:u16 + hash:i32
(def ^:const COLLISION_HEADER_SIZE 8)

;;-----------------------------------------------------------------------------
;; Cached Deserialization
;;-----------------------------------------------------------------------------
;; Maps in hot paths often access the same keys repeatedly. Caching avoids
;; repeated SAB reads and deserialization.

(def ^:const ^:private CACHE_MAX_SIZE 256)  ;; Max entries before LRU eviction

(defn- ensure-cache!
  "Lazily initialize cache on a SabMapRoot instance.
   Returns the cache (a js/Map)."
  [sab-map]
  (or (.-_cache sab-map)
      (let [c (js/Map.)]
        (set! (.-_cache sab-map) c)
        c)))

(defn- cache-get
  "Get value from cache. Returns [found? value]."
  [sab-map k]
  (when-let [cache (.-_cache sab-map)]
    (when (.has cache k)
      [true (.get cache k)])))

(defn- cache-put!
  "Store value in cache with LRU eviction."
  [sab-map k v]
  (let [cache (ensure-cache! sab-map)]
    ;; Simple LRU: delete oldest entries when over limit
    (when (>= (.-size cache) CACHE_MAX_SIZE)
      (let [keys-iter (.keys cache)
            ;; Delete ~25% of entries for amortized cost
            to-delete (/ CACHE_MAX_SIZE 4)]
        (dotimes [_ to-delete]
          (let [oldest (.next keys-iter)]
            (when-not (.-done oldest)
              (.delete cache (.-value oldest)))))))
    (.set cache k v)))

;;-----------------------------------------------------------------------------
;; Element Serialization - delegates to shared serialize module
;; Keyword caching + reusable scratch buffers for zero-allocation primitives
;;-----------------------------------------------------------------------------

;; Cached atom env — avoids dynamic var deref + get-env field chain per operation.
;; Invalidated by reset-pools! (called on SAB environment change).
(def ^:private ^:mutable cached-s-atom-env nil)

(defn- fast-get-env
  "Get atom env with caching. Avoids dynamic var deref on hot paths."
  []
  (or cached-s-atom-env
      (let [env (atom/get-env atom/*global-atom-instance*)]
        (set! cached-s-atom-env env)
        env)))

;;-----------------------------------------------------------------------------
;; Allocation helpers - Direct allocation with descriptor tracking
;;
;; Strategy: all allocations are rounded UP to the nearest size class.
;; This means every block in a pool class is guaranteed to be exactly that size,
;; maximizing pool hit rates and eliminating fragmentation within classes.
;; The slight memory waste (up to 50% for worst-case power-of-2 classes) is
;; more than offset by the allocation speedup from pool reuse.
;;-----------------------------------------------------------------------------

;; Node pool for reusing freed nodes (reduces allocation overhead)
;;
;; Size classes chosen so typical HAMT nodes land in 64 or 128:
;;   - Leaf node (1 KV, keyword+int32): ~32 bytes → class 64
;;   - Branch node (1 child + 1 KV): ~36 bytes → class 64
;;   - 2-entry node: ~54 bytes → class 64
;;   - 3-entry or branchy node: ~76-100 bytes → class 128
;;   - Root with many entries: ~128-256 bytes → class 128 or 256
(def ^:private ^:const POOL_SIZE_CLASSES #js [64 128 256 512])
(def ^:private ^:const MAX_POOL_SIZE 512)  ;; Per size class
(def ^:private ^:const BATCH_ALLOC_SIZE 64) ;; On pool miss, batch-alloc this many blocks

(defn- size-class-for
  "Find the appropriate size class for a given allocation size."
  [n]
  (cond (<= n 64) 64 (<= n 128) 128 (<= n 256) 256 (<= n 512) 512 :else nil))

;; Direct pool arrays — eliminates js/Map lookup per pool access.
;; Each entry is #js [offset desc-idx].
(def ^:private pool-64 #js [])
(def ^:private pool-128 #js [])
(def ^:private pool-256 #js [])
(def ^:private pool-512 #js [])

;; Offset → descriptor-idx tracking for O(1) retirement/freeing.
;; Updated on every alloc, cleared on free/dispose.
(defonce ^:private offset->desc (js/Map.))

(defn reset-pools!
  "Reset global node pool, offset→desc map, and atom root pool.
   Must be called when switching to a new atom environment (new SAB)."
  []
  (set! pool-64 #js [])
  (set! pool-128 #js [])
  (set! pool-256 #js [])
  (set! pool-512 #js [])
  (.clear offset->desc)
  (set! cached-s-atom-env nil)
  (set! cached-build-src nil)
  (set! cached-build-root nil)
  (atom/reset-root-pool!))

(defn- pool-get!
  "Try to get a node from the pool. Returns #js [offset desc-idx] or nil."
  [size-class]
  (let [stack (case size-class
                64 pool-64  128 pool-128
                256 pool-256  512 pool-512
                nil)]
    (when (and stack (pos? (.-length stack)))
      (.pop stack))))

(defn- pool-put!
  "Add a node to the pool. Returns true if added, false if pool is full."
  [size-class entry]
  (let [stack (case size-class
                64 pool-64  128 pool-128
                256 pool-256  512 pool-512
                nil)]
    (when stack
      (if (< (.-length stack) MAX_POOL_SIZE)
        (do (.push stack entry) true)
        false))))

(defn- alloc-bytes!
  "Allocate n bytes, rounded up to nearest size class.
   Returns the SAB offset (integer).
   On pool miss, uses batch-alloc to pre-fill the pool in a single descriptor scan.
   Tracks offset→descriptor-idx mapping for O(1) retirement/freeing."
  [s-atom-env n]
  ;; Inline size-class selection — avoids function call + loop
  (let [size-class (cond (<= n 64) 64 (<= n 128) 128 (<= n 256) 256 (<= n 512) 512 :else nil)]
    (if size-class
      ;; Try to get from pool first
      (if-let [pooled (pool-get! size-class)]
        ;; Pool hit: offset→desc was already set during batch-alloc
        (aget pooled 0)
        ;; Pool miss — batch-alloc multiple blocks in one scan
        (let [results (atom/batch-alloc s-atom-env size-class BATCH_ALLOC_SIZE)
              results (if (pos? (.-length results))
                        results
                        (do (atom/sweep-retired-blocks! s-atom-env)
                            (atom/batch-alloc s-atom-env size-class BATCH_ALLOC_SIZE)))
              len (.-length results)]
          (when (== len 0)
            (throw (js/Error. (str "Map allocation failed: out of memory for " size-class " bytes"))))
          ;; Put extra blocks into pool; set offset→desc for ALL blocks now
          ;; (avoids js/Map.set on every pool-get!)
          (loop [i 0]
            (when (< i len)
              (let [entry (aget results i)]
                (.set offset->desc (aget entry 0) (aget entry 1))
                (when (> i 0) (pool-put! size-class entry)))
              (recur (inc i))))
          ;; Return the first block offset
          (aget (aget results 0) 0)))
      ;; Size too large for pooling, allocate directly
      (let [r (atom/alloc s-atom-env n)]
        (if (:error r)
          (throw (js/Error. (str "Map allocation failed: " (:error r))))
          (let [off (:offset r)
                desc-idx (:descriptor-idx r)]
            (.set offset->desc off desc-idx)
            off))))))

;; Forward declare for recursive freeing
(declare free-hamt-node!)

(defn- maybe-pool-or-free!
  "Try to add a freed node to the pool. If pool is full, actually free it.
   size is the block's actual capacity (should already be a size class).
   Cleans up offset→desc tracking on actual free."
  [s-atom-env node-off desc-idx size]
  (let [size-class (size-class-for size)]
    (if (and size-class
             (pool-put! size-class #js [node-off desc-idx]))
      ;; Added to pool - mark as reusable but don't actually free
      true
      ;; Pool full or size too large - actually free
      (do (.delete offset->desc node-off)
          (atom/free s-atom-env desc-idx)))))

(defn- find-desc-idx
  "Look up descriptor-idx for a given offset. O(1) from tracking map,
   falls back to linear scan for nodes not in the map (e.g., from other workers)."
  [s-atom-env node-off]
  (if (.has offset->desc node-off)
    (.get offset->desc node-off)
    (when-let [desc (u/find-descriptor-for-data-offset s-atom-env node-off)]
      (:descriptor-idx desc))))

(defn- find-desc-capacity
  "Look up block capacity for a given offset.
   Uses offset→desc map for O(1) descriptor lookup, then reads capacity field."
  [s-atom-env node-off]
  (if-let [desc-idx (find-desc-idx s-atom-env node-off)]
    (u/read-block-descriptor-field (:index-view s-atom-env) desc-idx d/OFFSET_BD_BLOCK_CAPACITY)
    0))

(defn- free-hamt-node!
  "Recursively free a HAMT node and all its children.
   Nodes are added to the pool for reuse if possible.
   Uses offset→desc tracking map for O(1) descriptor lookup."
  [s-atom-env dv node-off]
  (when (> node-off -1)
    (let [dv-len (.-byteLength dv)]
      (when (>= node-off dv-len)
        (throw (js/Error. (str "free-hamt-node!: node-off " node-off
                               " >= DataView byteLength " dv-len
                               " (sab-size=" (get-in s-atom-env [:config :sab-total-size-bytes])
                               ", offset->desc has? " (.has offset->desc node-off) ")"))))
      (let [node-type (.getUint8 dv node-off)
            iv (:index-view s-atom-env)]
        (case node-type
          ;; Bitmap node - free children first, then this node
          1 (let [node-bm (.getUint32 dv (+ node-off 8) true)
                  child-count (let [n (- node-bm (bit-and (unsigned-bit-shift-right node-bm 1) 0x55555555))
                                    n (+ (bit-and n 0x33333333) (bit-and (unsigned-bit-shift-right n 2) 0x33333333))
                                    n (bit-and (+ n (unsigned-bit-shift-right n 4)) 0x0f0f0f0f)
                                    n (+ n (unsigned-bit-shift-right n 8))
                                    n (+ n (unsigned-bit-shift-right n 16))]
                                (bit-and n 0x3f))]
              (when (> child-count 32)
                (throw (js/Error. (str "free-hamt-node!: impossible child-count " child-count
                                       " at node-off " node-off " node-bm 0x" (.toString node-bm 16)))))
              ;; Recursively free all child nodes
              (dotimes [i child-count]
                (let [child-off (.getInt32 dv (+ node-off NODE_HEADER_SIZE (* i 4)) true)]
                  (when (and (> child-off -1) (>= child-off dv-len))
                    (throw (js/Error. (str "free-hamt-node!: child[" i "] offset " child-off
                                           " >= DataView byteLength " dv-len
                                           " (parent node-off=" node-off
                                           ", child-count=" child-count
                                           ", node-bm=0x" (.toString node-bm 16) ")"))))
                  (free-hamt-node! s-atom-env dv child-off)))
              ;; Try to pool this node — read capacity directly (avoids redundant find-desc-idx)
              (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
                (let [size (u/read-block-descriptor-field iv desc-idx d/OFFSET_BD_BLOCK_CAPACITY)]
                  (maybe-pool-or-free! s-atom-env node-off desc-idx size))))

          ;; Collision node - no children, just pool/free this node
          3 (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
              (let [size (u/read-block-descriptor-field iv desc-idx d/OFFSET_BD_BLOCK_CAPACITY)]
                (maybe-pool-or-free! s-atom-env node-off desc-idx size)))

          ;; Unknown node type - just free (don't pool unknown types)
          (do
            (js/console.warn (str "free-hamt-node!: unknown node-type " node-type
                                  " at offset " node-off
                                  " (in-desc-map? " (.has offset->desc node-off) ")"))
            (when-let [desc-idx (find-desc-idx s-atom-env node-off)]
              (.delete offset->desc node-off)
              (atom/free s-atom-env desc-idx))))))))

(defn- make-sab-map-root
  "Fast SabMapRoot constructor using pooled allocation.
   Bypasses the macro-generated ->SabMapRoot which uses the expensive atom/alloc
   path (descriptor scanning, CAS locking, new DataView/Uint8Array per call).
   Instead uses alloc-bytes! (pool-first, ~O(1) amortized) and cached wasm views."
  [s-atom-env cnt root-off]
  (let [off (alloc-bytes! s-atom-env 12)
        dv (wasm/data-view)]
    (.setUint8 dv off SabMapRoot-type-id)
    (.setInt32 dv (+ off 4) cnt true)
    (.setInt32 dv (+ off 8) root-off true)
    (SabMapRoot. (.-buffer dv) off)))

(defn dispose!
  "Dispose a SabMapRoot, freeing its entire HAMT tree.
   Call this when the map is no longer needed to reclaim SAB memory.

   WARNING: After disposal, the map must not be used. Any access will
   result in undefined behavior or errors."
  [sab-map]
  (let [dv (wasm/data-view)
        root-off (.getInt32 dv (+ (SabMapRoot-offset sab-map) 8) true)]
    (when (> root-off -1)
      (let [s-atom-env (fast-get-env)]
        (free-hamt-node! s-atom-env dv root-off)))))

(defn retire-replaced-path!
  "After an atom swap that replaced old-root with new-root, retire the old
   path nodes that are no longer referenced by the new tree.

   Walks both trees following the hash bits for key kh. At each level where
   old-node != new-node, the old node is retired via retire-block! (epoch-based)
   or freed via maybe-pool-or-free! (immediate, for single-worker use).

   Only retires individual path nodes — shared subtrees are untouched.

   mode: :retire (epoch-based, for multi-worker) or :free (immediate pool/free)
   kh: the hash of the key that was modified"
  ([s-atom-env old-root new-root kh]
   (retire-replaced-path! s-atom-env old-root new-root kh :free))
  ([s-atom-env old-root new-root kh mode]
   (when (and (not= old-root -1) (not= old-root new-root))
     (let [dv (wasm/data-view)
           iv (:index-view s-atom-env)]
       (loop [old-off old-root
              new-off new-root
              sh 0]
         (when (and (not= old-off -1) (not= old-off new-off))
           ;; Retire/free this old node
           (when-let [desc-idx (find-desc-idx s-atom-env old-off)]
             (if (= mode :retire)
               (atom/retire-block! s-atom-env desc-idx)
               (let [size (u/read-block-descriptor-field iv desc-idx d/OFFSET_BD_BLOCK_CAPACITY)]
                 (maybe-pool-or-free! s-atom-env old-off desc-idx size))))
           ;; Continue down the hash path
           (let [old-type (.getUint8 dv old-off)
                 new-type (.getUint8 dv new-off)]
             (when (and (== old-type NODE_TYPE_BITMAP) (== new-type NODE_TYPE_BITMAP))
               (let [bit (bitpos kh sh)
                     old-node-bm (.getUint32 dv (+ old-off 8) true)
                     new-node-bm (.getUint32 dv (+ new-off 8) true)]
                 (when (and (not (zero? (bit-and old-node-bm bit)))
                            (not (zero? (bit-and new-node-bm bit))))
                   (let [old-child-idx (get-index old-node-bm bit)
                         new-child-idx (get-index new-node-bm bit)
                         old-child (.getInt32 dv (+ old-off NODE_HEADER_SIZE (* old-child-idx 4)) true)
                         new-child (.getInt32 dv (+ new-off NODE_HEADER_SIZE (* new-child-idx 4)) true)]
                     (recur old-child new-child (+ sh SHIFT_STEP)))))))))))))

(defn retire-tree-diff!
  "Full tree diff: walk old and new HAMT trees in parallel, retiring all
   old nodes that differ from the new tree.

   At each node pair:
   - If old-off == new-off → shared subtree, skip entirely
   - If old-off != new-off → retire old node, recurse into children

   This handles multi-key operations (merge, select-keys, etc.) where
   retire-replaced-path! (single-hash) is insufficient.

   Cost: O(changed nodes). Shared subtrees are skipped via integer compare.

   mode: :retire (epoch-based, for multi-worker) or :free (immediate pool/free)"
  ([s-atom-env old-root new-root]
   (retire-tree-diff! s-atom-env old-root new-root :free))
  ([s-atom-env old-root new-root mode]
   (when (and (not= old-root -1) (not= old-root new-root))
     (let [dv (wasm/data-view)
           dv-len (.-byteLength dv)
           iv (:index-view s-atom-env)]
       (when (>= old-root dv-len)
         (throw (js/Error. (str "retire-tree-diff!: old-root " old-root " >= dv.byteLength " dv-len))))
       (letfn [(walk [old-off new-off]
                 (when (and (not= old-off -1) (not= old-off new-off))
                   (when (>= old-off dv-len)
                     (throw (js/Error. (str "retire-tree-diff! walk: old-off " old-off
                                            " >= dv.byteLength " dv-len
                                            " (old-root=" old-root ", new-root=" new-root ")"))))
                   ;; Retire this old node
                   (when-let [desc-idx (find-desc-idx s-atom-env old-off)]
                     (if (= mode :retire)
                       (atom/retire-block! s-atom-env desc-idx)
                       (let [size (u/read-block-descriptor-field iv desc-idx d/OFFSET_BD_BLOCK_CAPACITY)]
                         (maybe-pool-or-free! s-atom-env old-off desc-idx size))))
                   ;; Recurse into children if both are bitmap nodes
                   (let [old-type (.getUint8 dv old-off)]
                     (when (== old-type NODE_TYPE_BITMAP)
                       (let [old-node-bm (.getUint32 dv (+ old-off 8) true)
                             new-type (when (not= new-off -1) (.getUint8 dv new-off))
                             new-node-bm (when (and new-type (== new-type NODE_TYPE_BITMAP))
                                           (.getUint32 dv (+ new-off 8) true))]
                         ;; Walk only set bits in old-node-bm (bit-walking)
                         (loop [remaining old-node-bm
                                old-idx 0]
                           (when (not (zero? remaining))
                             (let [bit (bit-and remaining (- remaining))  ;; lowest set bit
                                   old-child (.getInt32 dv (+ old-off NODE_HEADER_SIZE (* old-idx 4)) true)
                                   new-child (when (and new-node-bm (not (zero? (bit-and new-node-bm bit))))
                                               (let [new-idx (popcount32 (bit-and new-node-bm (dec bit)))]
                                                 (.getInt32 dv (+ new-off NODE_HEADER_SIZE (* new-idx 4)) true)))]
                               (walk old-child (or new-child -1))
                               (recur (bit-and remaining (dec remaining)) (inc old-idx))))))))))]
         (walk old-root new-root))))))

(defn- copy-from-sab
  "Copy bytes from WASM memory to a regular ArrayBuffer-backed Uint8Array."
  [^number offset ^number len]
  (let [src (.subarray (wasm/u8-view) offset (+ offset len))
        dst (js/Uint8Array. len)]
    (.set dst src 0)
    dst))

;; Byte comparison for JS-side operations (used until full WASM lookup is integrated)
;; Note: wasm/bytes-equal? takes memory offsets, not Uint8Arrays
;; For full WASM integration, use wasm/hamt-find which does everything in WASM
(defn- bytes-equal?
  "Compare two Uint8Arrays byte-by-byte."
  [^js a ^js b]
  (let [len (.-length a)]
    (if (not= len (.-length b))
      false
      (loop [i 0]
        (if (>= i len)
          true
          (if (== (aget a i) (aget b i))
            (recur (inc i))
            false))))))

(defn- key-bytes-match?
  "Compare serialized key bytes at SAB offset against provided key bytes.
   Avoids copying when lengths differ. Accepts pre-fetched dv to avoid
   redundant (wasm/data-view) calls from hot paths."
  [^js dv key-offset ^js kb]
  (let [stored-len (.getUint32 dv key-offset true)
        kb-len (.-length kb)]
    (if (not= stored-len kb-len)
      false
      ;; Same length - compare byte by byte from SAB directly
      (let [u8 (wasm/u8-view)
            base (+ key-offset 4)]
        (loop [i 0]
          (if (>= i stored-len)
            true
            (if (== (aget u8 (+ base i)) (aget kb i))
              (recur (inc i))
              false)))))))

(defn- read-element
  "Read a single serialized element from SAB at offset.
   Element format: [len:u32][bytes...] where bytes are serialized via serialize-element."
  [s-atom-env ^js dv offset]
  (let [len (.getUint32 dv offset true)
        elem-bytes (copy-from-sab (+ offset 4) len)]
    (ser/deserialize-element s-atom-env elem-bytes)))

(defn- read-element-bytes
  "Read raw element bytes from SAB (including length prefix).
   Returns Uint8Array with [len:u32][data...]."
  [^js dv offset]
  (let [len (.getUint32 dv offset true)
        total (+ 4 len)]
    (copy-from-sab offset total)))

(defn- write-element-bytes!
  "Write serialized element bytes to SAB at offset.
   Element format: [len:u32][bytes...]."
  [s-atom-env offset ^js elem-bytes]
  (let [dv (wasm/data-view)
        len (.-length elem-bytes)]
    (.setUint32 dv offset len true)
    (when (pos? len)
      (.set (wasm/u8-view) elem-bytes (+ offset 4)))))

;;-----------------------------------------------------------------------------
;; Low-level node read/write
;;
;; Two-Bitmap Node Layout:
;; [type:u8][flags:u8][pad:u16][data_bitmap:u32][node_bitmap:u32]  12 bytes header
;; [child0:i32]...[childC:i32]      (C = popcount(node_bitmap))
;; [hash0:i32]...[hashM:i32]        (M = popcount(data_bitmap)) — per-entry CLJS hashes
;; [kv0]...[kvM]                    (M = popcount(data_bitmap)) — inline KV entries
;; Each KV: [key_len:u32][key_bytes...][val_len:u32][val_bytes...]
;;
;; Collision Node:
;; [type:u8][count:u8][pad:u16][hash:i32]
;; then count entries: [key_len:u32][key_bytes...][val_len:u32][val_bytes...]
;;-----------------------------------------------------------------------------

;; Pure JS popcount32 — avoids WASM boundary crossing overhead.
;; While WASM i32.popcnt is a single instruction, the JS→WASM call overhead (~20-50ns)
;; dominates the ~2ns computation. V8 JITs the bitwise ops below to ~7 instructions.
;; Called 5+ times per hamt-assoc, so the boundary crossing savings add up.
(defn- popcount32 [n]
  (let [n (- (bit-and n 0xFFFFFFFF) (bit-and (unsigned-bit-shift-right n 1) 0x55555555))
        n (+ (bit-and n 0x33333333) (bit-and (unsigned-bit-shift-right n 2) 0x33333333))
        n (bit-and (+ n (unsigned-bit-shift-right n 4)) 0x0f0f0f0f)]
    (unsigned-bit-shift-right (js* "(~{} * 0x01010101)" n) 24)))

(defn- read-node-type [^js dv offset]
  (.getUint8 dv offset))

(defn- read-data-bitmap [^js dv offset]
  (.getUint32 dv (+ offset 4) true))

(defn- read-node-bitmap [^js dv offset]
  (.getUint32 dv (+ offset 8) true))

(defn- read-child-offset [^js dv base child-idx]
  (.getInt32 dv (+ base NODE_HEADER_SIZE (* child-idx 4)) true))

(defn- hashes-start
  "Offset where the per-entry hash array starts within a bitmap node.
   Hash array is after children, before KV data."
  [base node-bitmap]
  (+ base NODE_HEADER_SIZE (* 4 (popcount32 node-bitmap))))

(defn- kv-data-start
  "Offset where KV data starts within a bitmap node.
   KV data is after children + hash array."
  [base data-bitmap node-bitmap]
  (+ base NODE_HEADER_SIZE (* 4 (popcount32 node-bitmap)) (* 4 (popcount32 data-bitmap))))

(defn- mask-hash [kh shift]
  (bit-and (unsigned-bit-shift-right kh shift) MASK))

(defn- bitpos [kh shift]
  (bit-shift-left 1 (mask-hash kh shift)))

(defn- has-bit? [bitmap bit]
  (not (zero? (bit-and bitmap bit))))

(defn- get-index [bitmap bit]
  "Count bits below this position."
  (popcount32 (bit-and bitmap (dec bit))))

;;-----------------------------------------------------------------------------
;; KV read/write helpers
;;-----------------------------------------------------------------------------

(defn- read-kv-at
  "Read a KV pair from the given byte offset. Returns [key-val val-val next-offset].
   KV layout: [key_len:u32][key_bytes...][val_len:u32][val_bytes...]
   Uses zero-copy deserialization — reads directly from DataView, no byte copies."
  [s-atom-env ^js dv kv-offset]
  (let [key-len (.getUint32 dv kv-offset true)
        key-start (+ kv-offset 4)
        key-val (ser/deserialize-from-dv s-atom-env dv key-start key-len)
        val-offset (+ key-start key-len)
        val-len (.getUint32 dv val-offset true)
        val-start (+ val-offset 4)
        val-val (ser/deserialize-from-dv s-atom-env dv val-start val-len)
        next-off (+ val-start val-len)]
    [key-val val-val next-off]))

(defn- skip-kv-at
  "Skip a KV pair, returning the offset after it.
   KV layout: [key_len:u32][key_bytes...][val_len:u32][val_bytes...]"
  [^js dv kv-offset]
  (let [key-len (.getUint32 dv kv-offset true)
        val-offset (+ kv-offset 4 key-len)
        val-len (.getUint32 dv val-offset true)]
    (+ val-offset 4 val-len)))

(defn- calc-kv-size [^js key-bytes ^js val-bytes]
  (+ 4 (.-length key-bytes) 4 (.-length val-bytes)))

(defn- write-kv!
  "Write a KV pair at offset. Returns offset after written data.
   KV layout: [key_len:u32][key_bytes...][val_len:u32][val_bytes...]
   Hash is stored separately in the node's hash array."
  [s-atom-env ^js dv offset ^js key-bytes ^js val-bytes]
  (let [u8 (wasm/u8-view)]
    (.setUint32 dv offset (.-length key-bytes) true)
    (when (pos? (.-length key-bytes))
      (.set u8 key-bytes (+ offset 4)))
    (let [val-off (+ offset 4 (.-length key-bytes))]
      (.setUint32 dv val-off (.-length val-bytes) true)
      (when (pos? (.-length val-bytes))
        (.set u8 val-bytes (+ val-off 4)))
      (+ val-off 4 (.-length val-bytes)))))

;;-----------------------------------------------------------------------------
;; Raw byte copying (no deserialization)
;;-----------------------------------------------------------------------------

(defn- copy-kv-data-all!
  "Copy all KV entries from src node to dst offset. Returns offset after last KV."
  [s-atom-env ^js dv src-offset src-data-bm src-node-bm dst-offset]
  (let [data-count (popcount32 src-data-bm)
        src-kv-start (kv-data-start src-offset src-data-bm src-node-bm)]
    (loop [i 0 src-pos src-kv-start dst-pos dst-offset]
      (if (>= i data-count)
        dst-pos
        (let [next-src (skip-kv-at dv src-pos)
              kv-len (- next-src src-pos)]
          (wasm/memcpy! dst-pos src-pos kv-len)
          (recur (inc i) next-src (+ dst-pos kv-len)))))))

(defn- copy-kv-data-except!
  "Copy all KV entries from src node to dst, skipping entry at skip-idx."
  [s-atom-env ^js dv src-offset src-data-bm src-node-bm dst-offset skip-idx]
  (let [data-count (popcount32 src-data-bm)
        src-kv-start (kv-data-start src-offset src-data-bm src-node-bm)]
    (loop [i 0 src-pos src-kv-start dst-pos dst-offset]
      (if (>= i data-count)
        dst-pos
        (let [next-src (skip-kv-at dv src-pos)
              kv-len (- next-src src-pos)]
          (if (== i skip-idx)
            (recur (inc i) next-src dst-pos)
            (do
              (wasm/memcpy! dst-pos src-pos kv-len)
              (recur (inc i) next-src (+ dst-pos kv-len)))))))))

(defn- calc-node-kv-total-size
  "Calculate total size of all KV pairs in a bitmap node's data section."
  [^js dv offset data-bm node-bm]
  (let [data-count (popcount32 data-bm)
        kv-start (kv-data-start offset data-bm node-bm)]
    (loop [i 0 pos kv-start]
      (if (>= i data-count)
        (- pos kv-start)
        (recur (inc i) (skip-kv-at dv pos))))))

(defn- read-node-kv-total-size
  "Fast read of cached kv-total-size from node header bytes 2-3.
   Falls back to calc-node-kv-total-size for nodes built before this optimization."
  [^js dv offset data-bm node-bm]
  (let [cached (.getUint16 dv (+ offset 2) true)]
    (if (pos? cached)
      cached
      (calc-node-kv-total-size dv offset data-bm node-bm))))

;;-----------------------------------------------------------------------------
;; Node construction helpers
;;-----------------------------------------------------------------------------

(defn- make-bitmap-node!
  "Create a two-bitmap node with given bitmaps, children, and KV entries.
   entries is seq of [kh kb vb] triples."
  [s-atom-env data-bm node-bm children entries]
  (let [child-count (count children)
        entry-count (count entries)
        kv-size (reduce (fn [acc [_kh kb vb]] (+ acc (calc-kv-size kb vb))) 0 entries)
        node-size (+ NODE_HEADER_SIZE (* 4 child-count) (* 4 entry-count) kv-size)
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)]
    ;; Write header
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)  ;; flags
    (.setUint16 dv (+ offset 2) kv-size true) ;; cached kv-total-size
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) node-bm true)
    ;; Write child offsets
    (dotimes [i child-count]
      (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4)) (nth children i) true))
    ;; Write hash array
    (let [h-start (hashes-start offset node-bm)]
      (loop [es (seq entries) i 0]
        (when es
          (let [[kh _kb _vb] (first es)]
            (.setInt32 dv (+ h-start (* i 4)) kh true)
            (recur (next es) (inc i))))))
    ;; Write KV entries (without hash — hash is in hash array)
    (let [kv-start (kv-data-start offset data-bm node-bm)]
      (loop [es (seq entries) pos kv-start]
        (when es
          (let [[_kh kb vb] (first es)
                next-pos (write-kv! s-atom-env dv pos kb vb)]
            (recur (next es) next-pos)))))
    offset))

(defn- make-single-entry-node!
  "Create bitmap node with exactly 1 data entry and 0 children.
   Avoids CLJS vector/seq allocation overhead of make-bitmap-node!."
  [s-atom-env data-bm kh kb vb]
  (let [kv-size (calc-kv-size kb vb)
        node-size (+ NODE_HEADER_SIZE 4 kv-size)  ;; 12 + 4 (hash) + kv
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)]
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) kv-size true)
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) 0 true)  ;; node-bm = 0
    ;; Hash array (1 entry, right after header since no children)
    (.setInt32 dv (+ offset NODE_HEADER_SIZE) kh true)
    ;; KV data
    (write-kv! s-atom-env dv (+ offset NODE_HEADER_SIZE 4) kb vb)
    offset))

(defn- make-two-entry-node!
  "Create bitmap node with exactly 2 data entries and 0 children.
   Entries are ordered by their index in data-bm."
  [s-atom-env data-bm kh1 kb1 vb1 kh2 kb2 vb2]
  (let [kv-size (+ (calc-kv-size kb1 vb1) (calc-kv-size kb2 vb2))
        node-size (+ NODE_HEADER_SIZE 8 kv-size)  ;; 12 + 8 (2 hashes) + kv
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)]
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) kv-size true)
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) 0 true)  ;; node-bm = 0
    ;; Hash array (2 entries)
    (.setInt32 dv (+ offset NODE_HEADER_SIZE) kh1 true)
    (.setInt32 dv (+ offset NODE_HEADER_SIZE 4) kh2 true)
    ;; KV data
    (let [next-pos (write-kv! s-atom-env dv (+ offset NODE_HEADER_SIZE 8) kb1 vb1)]
      (write-kv! s-atom-env dv next-pos kb2 vb2))
    offset))

(defn- make-single-child-node!
  "Create bitmap node with 0 data entries and 1 child."
  [s-atom-env node-bm child-off]
  (let [node-size (+ NODE_HEADER_SIZE 4)  ;; 12 + 4 (child offset)
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)]
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) 0 true)  ;; kv-size = 0
    (.setUint32 dv (+ offset 4) 0 true)  ;; data-bm = 0
    (.setUint32 dv (+ offset 8) node-bm true)
    (.setInt32 dv (+ offset NODE_HEADER_SIZE) child-off true)
    offset))

(defn- make-child-and-entry-node!
  "Create bitmap node with 1 data entry and 1 child."
  [s-atom-env data-bm node-bm child-off kh kb vb]
  (let [kv-size (calc-kv-size kb vb)
        node-size (+ NODE_HEADER_SIZE 4 4 kv-size)  ;; 12 + 4 (child) + 4 (hash) + kv
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)]
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) kv-size true)
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) node-bm true)
    ;; Child offset
    (.setInt32 dv (+ offset NODE_HEADER_SIZE) child-off true)
    ;; Hash array (1 entry, after child)
    (.setInt32 dv (+ offset NODE_HEADER_SIZE 4) kh true)
    ;; KV data
    (write-kv! s-atom-env dv (+ offset NODE_HEADER_SIZE 8) kb vb)
    offset))

(defn- make-bitmap-node-with-raw-kv!
  "Create bitmap node, copying KV data directly from source node via raw bytes.
   Much faster than collecting entries into vectors.
   If update-child-idx >= 0, replaces that child with new-child-off."
  ([s-atom-env data-bm node-bm src-offset src-data-bm src-node-bm]
   (make-bitmap-node-with-raw-kv! s-atom-env data-bm node-bm src-offset src-data-bm src-node-bm -1 -1))
  ([s-atom-env data-bm node-bm src-offset src-data-bm src-node-bm update-child-idx new-child-off]
   (let [dv (wasm/data-view)
         child-count (popcount32 node-bm)
         data-count (popcount32 data-bm)
         existing-kv-size (read-node-kv-total-size dv src-offset src-data-bm src-node-bm)
         node-size (+ NODE_HEADER_SIZE (* 4 child-count) (* 4 data-count) existing-kv-size)
         offset (alloc-bytes! s-atom-env node-size)]
     ;; Fast path: bulk-copy entire source node via copyWithin, then patch one child.
     ;; Avoids JS→WASM boundary crossing overhead of build_node_replace_child.
     (.copyWithin (wasm/u8-view) offset src-offset (+ src-offset node-size))
     (when (>= update-child-idx 0)
       (.setInt32 dv (+ offset NODE_HEADER_SIZE (* update-child-idx 4)) new-child-off true))
     offset)))

;;-----------------------------------------------------------------------------
;; Cached scratch region offset
;; Eliminates repeated (:scratch-region-start s-atom-env) keyword lookup,
;; (or d/*worker-id* 0) dynamic var deref, and scratch-offset arithmetic.
;; Safe because JS is single-threaded; invalidated when s-atom-env changes.
;;-----------------------------------------------------------------------------

(def ^:private ^:mutable cached-scratch-env nil)
(def ^:private ^:mutable cached-scratch-off -1)
(def ^:private ^:mutable cached-scratch-start -1)

(defn- get-scratch-off
  "Get scratch offset for current worker, cached per s-atom-env identity."
  [s-atom-env]
  (if (identical? cached-scratch-env s-atom-env)
    cached-scratch-off
    (let [scratch-start (:scratch-region-start s-atom-env)
          worker-id (or d/*worker-id* 0)
          off (wasm/scratch-offset worker-id scratch-start)]
      (set! cached-scratch-env s-atom-env)
      (set! cached-scratch-off off)
      (set! cached-scratch-start scratch-start)
      off)))

(defn- get-scratch-start
  "Get scratch region start, cached per s-atom-env identity."
  [s-atom-env]
  (if (identical? cached-scratch-env s-atom-env)
    cached-scratch-start
    (do (get-scratch-off s-atom-env)
        cached-scratch-start)))

(defn- make-bitmap-node-with-added-kv!
  "Create bitmap node with one KV entry added at insert-idx.
   Uses raw byte copy for existing entries and children."
  [s-atom-env new-data-bm node-bm src-offset src-data-bm src-node-bm insert-idx kh kb vb]
  (let [dv (wasm/data-view)
        child-count (popcount32 node-bm)
        new-data-count (popcount32 new-data-bm)
        existing-kv-size (read-node-kv-total-size dv src-offset src-data-bm src-node-bm)
        new-kv-size (calc-kv-size kb vb)
        total-kv-size (+ existing-kv-size new-kv-size)
        node-size (+ NODE_HEADER_SIZE (* 4 child-count) (* 4 new-data-count) total-kv-size)
        offset (alloc-bytes! s-atom-env node-size)]
    ;; Try WASM path: copy kb/vb to scratch, then build in one WASM call
    (if (wasm/ready?)
      (let [scratch-off (get-scratch-off s-atom-env)
            kb-len (.-length kb)
            vb-len (.-length vb)
            u8 (wasm/u8-view)]
        (.set u8 kb scratch-off)
        (.set u8 vb (+ scratch-off kb-len))
        (wasm/build-node-add-kv! offset src-offset src-data-bm src-node-bm new-data-bm
                                  insert-idx kh scratch-off kb-len
                                  (+ scratch-off kb-len) vb-len))
      ;; JS fallback
      (do
        (.setUint8 dv offset NODE_TYPE_BITMAP)
        (.setUint8 dv (+ offset 1) 0)
        (.setUint16 dv (+ offset 2) total-kv-size true) ;; cached kv-total-size
        (.setUint32 dv (+ offset 4) new-data-bm true)
        (.setUint32 dv (+ offset 8) node-bm true)
        (dotimes [i child-count]
          (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4))
                     (read-child-offset dv src-offset i) true))
        ;; Write hash array with insertion
        (let [src-h (hashes-start src-offset src-node-bm)
              dst-h (hashes-start offset node-bm)
              src-data-count (popcount32 src-data-bm)]
          (loop [src-i 0 dst-i 0 inserted? false]
            (cond
              (and (== dst-i insert-idx) (not inserted?))
              (do (.setInt32 dv (+ dst-h (* dst-i 4)) kh true)
                  (recur src-i (inc dst-i) true))
              (>= src-i src-data-count)
              (when-not inserted?
                (.setInt32 dv (+ dst-h (* dst-i 4)) kh true))
              :else
              (do (.setInt32 dv (+ dst-h (* dst-i 4))
                             (.getInt32 dv (+ src-h (* src-i 4)) true) true)
                  (recur (inc src-i) (inc dst-i) inserted?)))))
        ;; Copy KV entries with insertion
        (let [dst-kv-start (kv-data-start offset new-data-bm node-bm)
              src-kv-start (kv-data-start src-offset src-data-bm src-node-bm)
              data-count (popcount32 src-data-bm)]
          (loop [src-i 0 src-pos src-kv-start dst-pos dst-kv-start inserted? false]
            (cond
              (and (== src-i insert-idx) (not inserted?))
              (let [next-dst (write-kv! s-atom-env dv dst-pos kb vb)]
                (recur src-i src-pos next-dst true))
              (>= src-i data-count)
              (when-not inserted?
                (write-kv! s-atom-env dv dst-pos kb vb))
              :else
              (let [next-src (skip-kv-at dv src-pos)
                    kv-len (- next-src src-pos)]
                (wasm/memcpy! dst-pos src-pos kv-len)
                (recur (inc src-i) next-src (+ dst-pos kv-len) inserted?)))))))
    offset))

(defn- make-bitmap-node-with-replaced-kv!
  "Create bitmap node with KV entry at replace-idx replaced.
   Uses raw byte copy for other entries and children.
   known-kv-pos: if provided, skip the kv-data-start + skip-kv-at scan (caller already found it)."
  ([s-atom-env data-bm node-bm src-offset src-node-bm replace-idx kh kb vb]
   (make-bitmap-node-with-replaced-kv! s-atom-env data-bm node-bm src-offset src-node-bm replace-idx kh kb vb -1))
  ([s-atom-env data-bm node-bm src-offset src-node-bm replace-idx kh kb vb known-kv-pos]
   (let [dv (wasm/data-view)
         child-count (popcount32 node-bm)
         data-count (popcount32 data-bm)
         existing-kv-size (read-node-kv-total-size dv src-offset data-bm src-node-bm)
         ;; Use caller-provided position if available, otherwise scan
         old-pos (if (>= known-kv-pos 0)
                   known-kv-pos
                   (let [src-kv-start (kv-data-start src-offset data-bm src-node-bm)]
                     (loop [i 0 p src-kv-start]
                       (if (== i replace-idx) p (recur (inc i) (skip-kv-at dv p))))))
         old-next (skip-kv-at dv old-pos)
         old-kv-size (- old-next old-pos)
         new-kv-size (calc-kv-size kb vb)
         size-diff (- new-kv-size old-kv-size)
         node-size (+ NODE_HEADER_SIZE (* 4 child-count) (* 4 data-count) existing-kv-size size-diff)
         offset (alloc-bytes! s-atom-env node-size)]
    (if (zero? size-diff)
      ;; Same-size value replacement: bulk copy entire node, then patch only value bytes.
      ;; Key is guaranteed same (caller checked key-bytes-match?), hash unchanged.
      ;; Avoids WASM boundary crossing and element-by-element copy loops.
      (let [u8 (wasm/u8-view)]
        (.copyWithin u8 offset src-offset (+ src-offset node-size))
        ;; Patch value within the copied KV entry
        (let [val-off (+ offset (- old-pos src-offset) 4 (.-length kb))]
          (.setUint32 dv val-off (.-length vb) true)
          (when (pos? (.-length vb))
            (.set u8 vb (+ val-off 4)))))
      ;; Different-size replacement: use WASM or JS fallback
      (if (wasm/ready?)
        (let [scratch-off (get-scratch-off s-atom-env)
              kb-len (.-length kb)
              vb-len (.-length vb)
              u8 (wasm/u8-view)]
          (.set u8 kb scratch-off)
          (.set u8 vb (+ scratch-off kb-len))
          (wasm/build-node-replace-kv! offset src-offset data-bm node-bm replace-idx kh
                                        scratch-off kb-len (+ scratch-off kb-len) vb-len))
        ;; JS fallback
        (do
          (.setUint8 dv offset NODE_TYPE_BITMAP)
          (.setUint8 dv (+ offset 1) 0)
          (.setUint16 dv (+ offset 2) (+ existing-kv-size size-diff) true)
          (.setUint32 dv (+ offset 4) data-bm true)
          (.setUint32 dv (+ offset 8) node-bm true)
          (dotimes [i child-count]
            (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4))
                       (read-child-offset dv src-offset i) true))
          (let [src-h (hashes-start src-offset src-node-bm)
                dst-h (hashes-start offset node-bm)]
            (dotimes [i data-count]
              (.setInt32 dv (+ dst-h (* i 4))
                         (if (== i replace-idx) kh (.getInt32 dv (+ src-h (* i 4)) true))
                         true)))
          (let [dst-kv-start (kv-data-start offset data-bm node-bm)]
            (loop [i 0 src-pos src-kv-start dst-pos dst-kv-start]
              (when (< i data-count)
                (if (== i replace-idx)
                  (let [next-dst (write-kv! s-atom-env dv dst-pos kb vb)
                        next-src (skip-kv-at dv src-pos)]
                    (recur (inc i) next-src next-dst))
                  (let [next-src (skip-kv-at dv src-pos)
                        kv-len (- next-src src-pos)]
                    (wasm/memcpy! dst-pos src-pos kv-len)
                    (recur (inc i) next-src (+ dst-pos kv-len))))))))))
    offset)))

(defn- make-bitmap-node-removing-kv!
  "Create bitmap node with KV entry at remove-idx removed, optionally inserting a new child.
   Uses raw byte copy for other entries and children."
  ([s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm remove-idx]
   (make-bitmap-node-removing-kv! s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm remove-idx -1 -1))
  ([s-atom-env new-data-bm new-node-bm src-offset src-data-bm src-node-bm remove-idx insert-child-idx new-child-off]
   (let [dv (wasm/data-view)
         old-child-count (popcount32 src-node-bm)
         new-child-count (popcount32 new-node-bm)
         new-data-count (popcount32 new-data-bm)
         existing-kv-size (read-node-kv-total-size dv src-offset src-data-bm src-node-bm)
         ;; Find size of removed entry
         src-kv-start (kv-data-start src-offset src-data-bm src-node-bm)
         remove-pos (loop [i 0 p src-kv-start]
                      (if (== i remove-idx) p (recur (inc i) (skip-kv-at dv p))))
         remove-next (skip-kv-at dv remove-pos)
         removed-size (- remove-next remove-pos)
         final-kv-size (- existing-kv-size removed-size)
         node-size (+ NODE_HEADER_SIZE (* 4 new-child-count) (* 4 new-data-count) final-kv-size)
         offset (alloc-bytes! s-atom-env node-size)]
     (when-not (wasm/build-node-remove-kv-add-child! offset src-offset src-data-bm src-node-bm
                                                      new-data-bm new-node-bm
                                                      remove-idx insert-child-idx new-child-off)
       ;; JS fallback
       (.setUint8 dv offset NODE_TYPE_BITMAP)
       (.setUint8 dv (+ offset 1) 0)
       (.setUint16 dv (+ offset 2) final-kv-size true) ;; cached kv-total-size
       (.setUint32 dv (+ offset 4) new-data-bm true)
       (.setUint32 dv (+ offset 8) new-node-bm true)
       (if (>= insert-child-idx 0)
         (loop [src-i 0 dst-i 0]
           (when (< dst-i new-child-count)
             (if (== dst-i insert-child-idx)
               (do
                 (.setInt32 dv (+ offset NODE_HEADER_SIZE (* dst-i 4)) new-child-off true)
                 (recur src-i (inc dst-i)))
               (do
                 (.setInt32 dv (+ offset NODE_HEADER_SIZE (* dst-i 4))
                            (read-child-offset dv src-offset src-i) true)
                 (recur (inc src-i) (inc dst-i))))))
         (dotimes [i old-child-count]
           (.setInt32 dv (+ offset NODE_HEADER_SIZE (* i 4))
                      (read-child-offset dv src-offset i) true)))
       ;; Copy hash array, skipping removed entry
       (let [src-h (hashes-start src-offset src-node-bm)
             dst-h (hashes-start offset new-node-bm)
             src-data-count (popcount32 src-data-bm)]
         (loop [src-i 0 dst-i 0]
           (when (< src-i src-data-count)
             (if (== src-i remove-idx)
               (recur (inc src-i) dst-i)
               (do (.setInt32 dv (+ dst-h (* dst-i 4))
                              (.getInt32 dv (+ src-h (* src-i 4)) true) true)
                   (recur (inc src-i) (inc dst-i)))))))
       (copy-kv-data-except! s-atom-env dv src-offset src-data-bm src-node-bm
                             (kv-data-start offset new-data-bm new-node-bm) remove-idx))
     offset)))

(defn- make-collision-node!
  "Create a collision node for entries with same hash.
   entries is seq of [kh kb vb] triples."
  [s-atom-env hash-val entries]
  (let [cnt (count entries)
        entries-size (reduce (fn [acc [_kh kb vb]] (+ acc (calc-kv-size kb vb))) 0 entries)
        node-size (+ COLLISION_HEADER_SIZE entries-size)
        offset (alloc-bytes! s-atom-env node-size)
        dv (wasm/data-view)]
    (.setUint8 dv offset NODE_TYPE_COLLISION)
    (.setUint8 dv (+ offset 1) cnt)
    (.setUint16 dv (+ offset 2) 0 true)  ;; pad
    (.setInt32 dv (+ offset 4) hash-val true)
    ;; Write entries (hash is in collision header, not per-entry)
    (loop [es (seq entries) pos (+ offset COLLISION_HEADER_SIZE)]
      (when es
        (let [[_kh kb vb] (first es)
              next-pos (write-kv! s-atom-env dv pos kb vb)]
          (recur (next es) next-pos))))
    offset))

;;-----------------------------------------------------------------------------
;; HAMT lookup
;;-----------------------------------------------------------------------------

(defn- hamt-find-fast
  "Look up key in HAMT using binary key comparison.
   kb is the serialized key bytes.
   Sets find-result-found? and find-result-val (avoids vector allocation)."
  [s-atom-env ^js dv root-off kb kh shift]
  (if (== root-off -1)
    (do (set! find-result-found? false) (set! find-result-val nil) nil)
    (let [node-type (read-node-type dv root-off)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv root-off)
                node-bm (read-node-bitmap dv root-off)
                bit (bitpos kh shift)]
            (cond
              ;; Check node_bitmap first (child nodes)
              (has-bit? node-bm bit)
              (let [idx (get-index node-bm bit)
                    child-off (read-child-offset dv root-off idx)]
                (recur s-atom-env dv child-off kb kh (+ shift SHIFT_STEP)))

              ;; Check data_bitmap (inline KV)
              (has-bit? data-bm bit)
              (let [data-idx (get-index data-bm bit)
                    ;; Hash pre-filter: compare stored CLJS hash with target.
                    ;; If different, skip the expensive skip_kv walk + key comparison.
                    stored-hash (.getInt32 dv (+ (hashes-start root-off node-bm) (* data-idx 4)) true)]
                (if (not= stored-hash kh)
                  (do (set! find-result-found? false) (set! find-result-val nil) nil)
                  (let [kv-start (kv-data-start root-off data-bm node-bm)
                        ;; Skip to the target entry (inline skip-kv-at to avoid fn call overhead)
                        pos (loop [i 0 p kv-start]
                              (if (== i data-idx) p
                                (let [kl (.getUint32 dv p true) vo (+ p 4 kl) vl (.getUint32 dv vo true)]
                                  (recur (inc i) (+ vo 4 vl)))))
                        key-len (.getUint32 dv pos true)]
                    (if (key-bytes-match? dv pos kb)
                      ;; Key matches - deserialize value directly from DV (no copy)
                      (let [val-off (+ pos 4 key-len)
                            val-len (.getUint32 dv val-off true)
                            entry-v (ser/deserialize-from-dv s-atom-env dv (+ val-off 4) val-len)]
                        (set! find-result-found? true)
                        (set! find-result-val entry-v)
                        nil)
                      (do (set! find-result-found? false) (set! find-result-val nil) nil)))))

              :else (do (set! find-result-found? false) (set! find-result-val nil) nil)))

        ;; Collision node - must check all entries
        3 (let [coll-hash (.getInt32 dv (+ root-off 4) true)]
            ;; Hash pre-filter: all entries share the same CLJS hash.
            ;; If collision hash != target hash, none can match.
            (if (not= coll-hash kh)
              (do (set! find-result-found? false) (set! find-result-val nil) nil)
              (let [cnt (.getUint8 dv (+ root-off 1))]
                (loop [i 0 pos (+ root-off COLLISION_HEADER_SIZE)]
                  (if (>= i cnt)
                    (do (set! find-result-found? false) (set! find-result-val nil) nil)
                    ;; pos points to [key_len:u32][key_bytes...][val_len:u32][val_bytes...]
                    (let [key-len (.getUint32 dv pos true)]
                      (if (key-bytes-match? dv pos kb)
                        ;; Key matches - deserialize value directly from DV (no copy)
                        (let [val-off (+ pos 4 key-len)
                              val-len (.getUint32 dv val-off true)
                              entry-v (ser/deserialize-from-dv s-atom-env dv (+ val-off 4) val-len)]
                          (set! find-result-found? true)
                          (set! find-result-val entry-v)
                          nil)
                        ;; Skip this entry
                        (let [val-off (+ pos 4 key-len)
                              val-len (.getUint32 dv val-off true)
                              next-pos (+ val-off 4 val-len)]
                          (recur (inc i) next-pos)))))))))

        ;; Unknown
        (do (set! find-result-found? false) (set! find-result-val nil) nil)))))

(defn- hamt-find-wasm
  "Look up key in HAMT using WASM acceleration.
   Sets find-result-found? and find-result-val.
   Returns truthy if WASM handled the search, nil if not ready."
  [s-atom-env ^js dv root-off kb kh]
  (when (wasm/ready?)
    ;; Copy key to scratch area for WASM access
    (let [scratch-off (get-scratch-off s-atom-env)]
      ;; Copy key bytes to scratch
      (.set (wasm/u8-view) kb scratch-off)
      (let [key-len (.-length kb)
            key-hash (wasm/fnv1a-hash scratch-off key-len)
            val-off (wasm/hamt-find root-off scratch-off key-len key-hash kh 0)]
        (if (>= val-off 0)
          ;; WASM found it - read and deserialize value from val-off
          (let [val-len (.getUint32 dv val-off true)
                entry-v (ser/deserialize-from-dv s-atom-env dv (+ val-off 4) val-len)]
            (set! find-result-found? true)
            (set! find-result-val entry-v)
            true)
          (do (set! find-result-found? false)
              (set! find-result-val nil)
              true))))))

(defn- hamt-find
  "Look up key in HAMT. Sets find-result-found? and find-result-val.
   Uses WASM when available, falls back to JS."
  [s-atom-env ^js dv root-off k kh shift]
  ;; Serialize key once
  (let [kb (ser/serialize-key k)]
    ;; Try WASM first (only at shift 0, since WASM handles full traversal)
    (when-not (and (zero? shift) (hamt-find-wasm s-atom-env dv root-off kb kh))
      ;; Fall back to JS implementation
      (hamt-find-fast s-atom-env dv root-off kb kh shift))
    nil))

;;-----------------------------------------------------------------------------
;; HAMT assoc (persistent)
;;-----------------------------------------------------------------------------

(defn- collect-raw-kv-entries
  "Collect [[kh kb vb] ...] from a bitmap node's data section."
  [s-atom-env ^js dv offset data-bm node-bm]
  (let [data-count (popcount32 data-bm)
        h-start (hashes-start offset node-bm)
        kv-start (kv-data-start offset data-bm node-bm)]
    (loop [i 0 pos kv-start acc []]
      (if (>= i data-count)
        acc
        (let [kh (.getInt32 dv (+ h-start (* i 4)) true)
              klen (.getUint32 dv pos true)
              kb (copy-from-sab (+ pos 4) klen)
              val-off (+ pos 4 klen)
              vlen (.getUint32 dv val-off true)
              vb (copy-from-sab (+ val-off 4) vlen)]
          (recur (inc i) (+ val-off 4 vlen)
                 (conj acc [kh kb vb])))))))

;; Module-level mutable flags to eliminate CLJS vector/map allocation per hamt operation.
;; Safe because JS is single-threaded and recursive calls naturally propagate the flag.
(def ^:private ^:mutable hamt-result-added? false)
(def ^:private ^:mutable hamt-result-removed? false)

;; Module-level find result — eliminates [found? val] vector allocation per lookup.
;; Set by hamt-find-fast/hamt-find-wasm, read by callers.
(def ^:private ^:mutable find-result-found? false)
(def ^:private ^:mutable find-result-val nil)

;; When true, hamt-assoc recycles replaced nodes back to the pool for immediate reuse.
;; Only safe for bulk builds (build-hamt-from-cljs) where old versions are not retained.
;; UNSAFE for persistent assoc (old SabMapRoot still references old nodes).
(def ^:private ^:mutable recycle-replaced-nodes? false)

(defn- recycle-node!
  "Pool a replaced node for reuse. Only called when recycle-replaced-nodes? is true.
   The node's data has already been copied to a new node, so its memory is reusable."
  [s-atom-env node-off]
  (when-let [desc-idx (.get offset->desc node-off)]
    (let [cap (u/read-block-descriptor-field (:index-view s-atom-env) desc-idx d/OFFSET_BD_BLOCK_CAPACITY)]
      (maybe-pool-or-free! s-atom-env node-off desc-idx cap))))

(defn- hamt-assoc
  "Assoc key/value into HAMT. Returns new-root-off (integer).
   Sets hamt-result-added? to true if new key, false otherwise.
   Uses stored CLJS hash per KV entry to avoid key deserialization."
  [s-atom-env root-off kh kb vb shift]
  (if (== root-off -1)
    ;; Empty → create single-entry bitmap node
    (let [bit (bitpos kh shift)]
      (set! hamt-result-added? true)
      (make-single-entry-node! s-atom-env bit kh kb vb))

    (let [dv (wasm/data-view)
          node-type (read-node-type dv root-off)
          result
          (case node-type
            ;; Bitmap node
            1 (let [data-bm (read-data-bitmap dv root-off)
                    node-bm (read-node-bitmap dv root-off)
                    bit (bitpos kh shift)]
                (cond
                  ;; Position has child node - descend
                  (has-bit? node-bm bit)
                  (let [child-idx (get-index node-bm bit)
                        child-off (read-child-offset dv root-off child-idx)
                        new-child-off (hamt-assoc s-atom-env child-off kh kb vb (+ shift SHIFT_STEP))]
                    ;; hamt-result-added? is set by recursive call
                    (if (== new-child-off child-off)
                      ;; Child unchanged (same-value assoc) - skip parent rebuild
                      root-off
                      ;; Rebuild node with updated child
                      (make-bitmap-node-with-raw-kv! s-atom-env data-bm node-bm
                                                      root-off data-bm node-bm
                                                      child-idx new-child-off)))

                  ;; Position has inline data
                  (has-bit? data-bm bit)
                  (let [data-idx (get-index data-bm bit)
                        kv-start (kv-data-start root-off data-bm node-bm)
                        ;; pos points to [key_len:u32][key_bytes...]... (inline skip-kv-at)
                        pos (loop [i 0 p kv-start]
                              (if (== i data-idx) p
                                (let [kl (.getUint32 dv p true) vo (+ p 4 kl) vl (.getUint32 dv vo true)]
                                  (recur (inc i) (+ vo 4 vl)))))
                        ;; Read stored hash from hash array + compare key bytes directly
                        existing-kh (.getInt32 dv (+ (hashes-start root-off node-bm) (* data-idx 4)) true)
                        existing-kb-len (.getUint32 dv pos true)]
                    (if (key-bytes-match? dv pos kb)
                      ;; Key bytes match → same key — check if value bytes are unchanged
                      (let [val-off (+ pos 4 existing-kb-len)]
                        (if (key-bytes-match? dv val-off vb)
                          ;; Value unchanged - return original root (no allocation)
                          (do (set! hamt-result-added? false) root-off)
                          ;; Value changed - replace entry (pass pos to avoid duplicate scan)
                          (do (set! hamt-result-added? false)
                              (make-bitmap-node-with-replaced-kv! s-atom-env data-bm node-bm
                                                                  root-off node-bm data-idx kh kb vb pos))))
                      ;; Different key at same bit position - use stored hash for push down
                      (let [existing-kb (copy-from-sab (+ pos 4) existing-kb-len)
                            existing-vb-off (+ pos 4 existing-kb-len)
                            existing-vb-len (.getUint32 dv existing-vb-off true)
                            existing-vb (copy-from-sab (+ existing-vb-off 4) existing-vb-len)]
                        (if (== existing-kh kh)
                          ;; Hash collision - create collision node, remove from data_bitmap
                          (let [collision-node (make-collision-node! s-atom-env kh [[existing-kh existing-kb existing-vb] [kh kb vb]])
                                new-data-bm (bit-xor data-bm bit)
                                new-node-bm (bit-or node-bm bit)
                                new-child-idx (get-index new-node-bm bit)]
                            (set! hamt-result-added? true)
                            (make-bitmap-node-removing-kv! s-atom-env new-data-bm new-node-bm
                                                            root-off data-bm node-bm data-idx
                                                            new-child-idx collision-node))
                          ;; Different hash - create child node for both, move to node_bitmap
                          (let [sub-shift (+ shift SHIFT_STEP)
                                existing-bit (bitpos existing-kh sub-shift)
                                new-bit (bitpos kh sub-shift)]
                            (if (== existing-bit new-bit)
                              ;; Same bit at next level - recurse to create deeper structure
                              (let [sub-node (hamt-assoc s-atom-env -1 existing-kh existing-kb existing-vb sub-shift)
                                    final-sub (hamt-assoc s-atom-env sub-node kh kb vb sub-shift)
                                    new-data-bm (bit-xor data-bm bit)
                                    new-node-bm (bit-or node-bm bit)
                                    new-child-idx (get-index new-node-bm bit)]
                                (set! hamt-result-added? true)
                                (make-bitmap-node-removing-kv! s-atom-env new-data-bm new-node-bm
                                                                root-off data-bm node-bm data-idx
                                                                new-child-idx final-sub))
                              ;; Different bits - create two-entry sub-node
                              (let [sub-data-bm (bit-or existing-bit new-bit)
                                    sub-node (if (< existing-bit new-bit)
                                               (make-two-entry-node! s-atom-env sub-data-bm
                                                                      existing-kh existing-kb existing-vb kh kb vb)
                                               (make-two-entry-node! s-atom-env sub-data-bm
                                                                      kh kb vb existing-kh existing-kb existing-vb))
                                    new-data-bm (bit-xor data-bm bit)
                                    new-node-bm (bit-or node-bm bit)
                                    new-child-idx (get-index new-node-bm bit)]
                                (set! hamt-result-added? true)
                                (make-bitmap-node-removing-kv! s-atom-env new-data-bm new-node-bm
                                                                root-off data-bm node-bm data-idx
                                                                new-child-idx sub-node))))))))

                  ;; Position is empty - add to data_bitmap using raw byte copy
                  :else
                  (let [data-idx (get-index data-bm bit)
                        new-data-bm (bit-or data-bm bit)]
                    (set! hamt-result-added? true)
                    (make-bitmap-node-with-added-kv! s-atom-env new-data-bm node-bm
                                                      root-off data-bm node-bm data-idx kh kb vb))))

            ;; Collision node
            3 (let [node-hash (.getInt32 dv (+ root-off 4) true)
                    cnt (.getUint8 dv (+ root-off 1))]
                (if (== kh node-hash)
                  ;; Same hash - add/replace in collision (compare key bytes directly)
                  (loop [i 0 pos (+ root-off COLLISION_HEADER_SIZE) entries []]
                    (if (>= i cnt)
                      ;; Key not found - add new entry
                      (do (set! hamt-result-added? true)
                          (make-collision-node! s-atom-env kh (conj entries [kh kb vb])))
                      ;; pos points to [key_len:u32][key_bytes...]...
                      (let [klen (.getUint32 dv pos true)
                            entry-kb (copy-from-sab (+ pos 4) klen)
                            val-off (+ pos 4 klen)
                            vlen (.getUint32 dv val-off true)
                            entry-vb (copy-from-sab (+ val-off 4) vlen)
                            next-pos (+ val-off 4 vlen)]
                        (if (key-bytes-match? dv pos kb)
                          ;; Key matches - check if value is unchanged
                          (if (bytes-equal? entry-vb vb)
                            ;; Value unchanged - return original root
                            (do (set! hamt-result-added? false) root-off)
                            ;; Replace existing
                            (let [remaining (loop [j (inc i) p next-pos acc []]
                                              (if (>= j cnt)
                                                acc
                                                (let [kl (.getUint32 dv p true)
                                                      kb2 (copy-from-sab (+ p 4) kl)
                                                      vo (+ p 4 kl)
                                                      vl (.getUint32 dv vo true)
                                                      vb2 (copy-from-sab (+ vo 4) vl)]
                                                  (recur (inc j) (+ vo 4 vl) (conj acc [node-hash kb2 vb2])))))]
                              (set! hamt-result-added? false)
                              (make-collision-node! s-atom-env kh (into (conj entries [kh kb vb]) remaining))))
                          ;; Continue
                          (recur (inc i) next-pos (conj entries [node-hash entry-kb entry-vb]))))))
                  ;; Different hash - split into bitmap node
                  (let [bit1 (bitpos node-hash shift)
                        bit2 (bitpos kh shift)]
                    (if (== bit1 bit2)
                      ;; Same bit position - recurse
                      (let [new-child (hamt-assoc s-atom-env root-off kh kb vb (+ shift SHIFT_STEP))]
                        ;; hamt-result-added? set by recursive call
                        (make-single-child-node! s-atom-env bit1 new-child))
                      ;; Different bit positions
                      (let [data-bm bit2
                            node-bm bit1]
                        (set! hamt-result-added? true)
                        (make-child-and-entry-node! s-atom-env data-bm node-bm root-off kh kb vb))))))

            ;; Unknown
            (do (set! hamt-result-added? false) root-off))]
      ;; Recycle replaced node back to pool for immediate reuse during bulk builds.
      ;; Only active when recycle-replaced-nodes? is true (set by build-hamt-from-cljs).
      ;; Safe because: (1) new node data was copied from old before this point,
      ;; (2) old versions are not retained in bulk build mode.
      (when (and recycle-replaced-nodes? (not= result root-off))
        (recycle-node! s-atom-env root-off))
      result)))

;;-----------------------------------------------------------------------------
;; HAMT dissoc (persistent)
;;-----------------------------------------------------------------------------

(defn- make-bitmap-node-removing-child!
  "Create bitmap node with a child removed (for dissoc).
   Uses raw byte copy for all data."
  [s-atom-env data-bm new-node-bm src-offset src-data-bm src-node-bm remove-child-idx]
  (let [dv (wasm/data-view)
        old-child-count (popcount32 src-node-bm)
        new-child-count (popcount32 new-node-bm)
        data-count (popcount32 data-bm)
        existing-kv-size (read-node-kv-total-size dv src-offset src-data-bm src-node-bm)
        node-size (+ NODE_HEADER_SIZE (* 4 new-child-count) (* 4 data-count) existing-kv-size)
        offset (alloc-bytes! s-atom-env node-size)]
    ;; Write header
    (.setUint8 dv offset NODE_TYPE_BITMAP)
    (.setUint8 dv (+ offset 1) 0)
    (.setUint16 dv (+ offset 2) existing-kv-size true) ;; cached kv-total-size
    (.setUint32 dv (+ offset 4) data-bm true)
    (.setUint32 dv (+ offset 8) new-node-bm true)
    ;; Copy child offsets, skipping removed one
    (loop [src-i 0 dst-i 0]
      (when (< dst-i new-child-count)
        (if (== src-i remove-child-idx)
          (recur (inc src-i) dst-i)
          (do
            (.setInt32 dv (+ offset NODE_HEADER_SIZE (* dst-i 4))
                       (read-child-offset dv src-offset src-i) true)
            (recur (inc src-i) (inc dst-i))))))
    ;; Copy hash array (data entries unchanged — only removing a child)
    (let [src-h (hashes-start src-offset src-node-bm)
          dst-h (hashes-start offset new-node-bm)]
      (wasm/memcpy! dst-h src-h (* 4 data-count)))
    ;; Copy KV data
    (copy-kv-data-all! s-atom-env dv src-offset src-data-bm src-node-bm
                       (kv-data-start offset data-bm new-node-bm))
    offset))

(defn- hamt-dissoc
  "Dissoc key from HAMT. Returns new-root-off (integer).
   Sets hamt-result-removed? to true if key was removed, false otherwise.
   Uses stored CLJS hash per KV entry to avoid key deserialization."
  [s-atom-env root-off kh kb shift]
  (if (== root-off -1)
    (do (set! hamt-result-removed? false) -1)
    (let [dv (wasm/data-view)
          node-type (read-node-type dv root-off)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv root-off)
                node-bm (read-node-bitmap dv root-off)
                bit (bitpos kh shift)]
            (cond
              ;; Position has child node
              (has-bit? node-bm bit)
              (let [child-idx (get-index node-bm bit)
                    child-off (read-child-offset dv root-off child-idx)
                    new-child (hamt-dissoc s-atom-env child-off kh kb (+ shift SHIFT_STEP))]
                ;; hamt-result-removed? set by recursive call
                (if-not hamt-result-removed?
                  root-off
                  (let [child-count (popcount32 node-bm)
                        data-count (popcount32 data-bm)]
                    (if (== new-child -1)
                      ;; Child was removed entirely - remove from node_bitmap
                      (if (and (== child-count 1) (zero? data-count))
                        ;; Node becomes empty
                        -1
                        ;; Remove child from node
                        (let [new-node-bm (bit-xor node-bm bit)]
                          (make-bitmap-node-removing-child! s-atom-env data-bm new-node-bm
                                                            root-off data-bm node-bm child-idx)))
                      ;; Child was modified
                      (make-bitmap-node-with-raw-kv! s-atom-env data-bm node-bm
                                                      root-off data-bm node-bm
                                                      child-idx new-child)))))

              ;; Position has inline data
              (has-bit? data-bm bit)
              (let [data-idx (get-index data-bm bit)
                    kv-start (kv-data-start root-off data-bm node-bm)
                    pos (loop [i 0 p kv-start]
                          (if (== i data-idx) p
                            (let [kl (.getUint32 dv p true) vo (+ p 4 kl) vl (.getUint32 dv vo true)]
                              (recur (inc i) (+ vo 4 vl)))))]
                (if (key-bytes-match? dv pos kb)
                  ;; Found - remove it using raw byte copy
                  (let [child-count (popcount32 node-bm)
                        data-count (popcount32 data-bm)]
                    (set! hamt-result-removed? true)
                    (if (and (== data-count 1) (zero? child-count))
                      ;; Node becomes empty
                      -1
                      ;; Remove entry from data
                      (let [new-data-bm (bit-xor data-bm bit)]
                        (make-bitmap-node-removing-kv! s-atom-env new-data-bm node-bm
                                                        root-off data-bm node-bm data-idx))))
                  ;; Key not found
                  (do (set! hamt-result-removed? false) root-off)))

              :else (do (set! hamt-result-removed? false) root-off)))

        ;; Collision node
        3 (let [cnt (.getUint8 dv (+ root-off 1))
                node-hash (.getInt32 dv (+ root-off 4) true)]
            (loop [i 0 pos (+ root-off COLLISION_HEADER_SIZE) entries []]
              (if (>= i cnt)
                ;; Key not found
                (do (set! hamt-result-removed? false) root-off)
                (let [klen (.getUint32 dv pos true)
                      entry-kb (copy-from-sab (+ pos 4) klen)
                      val-off (+ pos 4 klen)
                      vlen (.getUint32 dv val-off true)
                      entry-vb (copy-from-sab (+ val-off 4) vlen)
                      next-pos (+ val-off 4 vlen)]
                  (if (key-bytes-match? dv pos kb)
                    ;; Found - remove it
                    (let [remaining (loop [j (inc i) p next-pos acc []]
                                      (if (>= j cnt)
                                        acc
                                        (let [kl (.getUint32 dv p true)
                                              ekb (copy-from-sab (+ p 4) kl)
                                              vo (+ p 4 kl)
                                              vl (.getUint32 dv vo true)
                                              evb (copy-from-sab (+ vo 4) vl)]
                                          (recur (inc j) (+ vo 4 vl) (conj acc [node-hash ekb evb])))))
                          all-remaining (into entries remaining)]
                      (set! hamt-result-removed? true)
                      (cond
                        (empty? all-remaining) -1
                        (== 1 (count all-remaining))
                        ;; Convert to bitmap node with single entry
                        (let [[ekh ekb evb] (first all-remaining)
                              bit (bitpos node-hash shift)]
                          (make-single-entry-node! s-atom-env bit ekh ekb evb))
                        :else
                        (make-collision-node! s-atom-env node-hash all-remaining)))
                    ;; Continue
                    (recur (inc i) next-pos (conj entries [node-hash entry-kb entry-vb])))))))

        ;; Unknown
        (do (set! hamt-result-removed? false) root-off)))))

;;-----------------------------------------------------------------------------
;; HAMT seq (lazy)
;;-----------------------------------------------------------------------------

(defn- hamt-seq
  "Return lazy seq of MapEntry pairs from HAMT."
  [s-atom-env root-off]
  (when (not= root-off -1)
    (let [dv (wasm/data-view)]
      ((fn walk [off]
         (lazy-seq
          (when (not= off -1)
            (let [node-type (read-node-type dv off)]
              (case node-type
                ;; Bitmap node
                1 (let [data-bm (read-data-bitmap dv off)
                        node-bm (read-node-bitmap dv off)
                        data-count (popcount32 data-bm)
                        child-count (popcount32 node-bm)
                        kv-start (kv-data-start off data-bm node-bm)
                        ;; Materialize inline entries
                        inline-entries (loop [i 0 pos kv-start acc []]
                                         (if (>= i data-count)
                                           acc
                                           (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                                             (recur (inc i) next-pos (conj acc (MapEntry. k v nil))))))
                        ;; Lazy child traversal
                        child-seqs (fn step [ci]
                                     (lazy-seq
                                       (when (< ci child-count)
                                         (let [child-off (read-child-offset dv off ci)]
                                           (concat (walk child-off)
                                                   (step (inc ci)))))))]
                    (concat inline-entries (child-seqs 0)))

                ;; Collision node
                3 (let [cnt (.getUint8 dv (+ off 1))]
                    (loop [i 0 pos (+ off COLLISION_HEADER_SIZE) result []]
                      (if (>= i cnt)
                        result
                        (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                          (recur (inc i) next-pos (conj result (MapEntry. k v nil)))))))

                ;; Unknown
                nil)))))
       root-off))))

;;-----------------------------------------------------------------------------
;; Streaming reduce (direct tree walk, no materialization)
;;-----------------------------------------------------------------------------

(defn- hamt-kv-reduce-js
  "Walk HAMT tree in pure JS, calling (f acc k v) at each entry.
   Supports reduced? for early termination."
  [s-atom-env ^js dv offset f init]
  (if (== offset -1)
    init
    (let [node-type (read-node-type dv offset)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv offset)
                node-bm (read-node-bitmap dv offset)
                data-count (popcount32 data-bm)
                kv-start (kv-data-start offset data-bm node-bm)
                ;; Reduce over inline KV entries
                acc-after-data
                (loop [i 0 pos kv-start acc init]
                  (if (or (>= i data-count) (reduced? acc))
                    acc
                    (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                      (recur (inc i) next-pos (f acc k v)))))
                child-count (popcount32 node-bm)]
            (if (reduced? acc-after-data)
              acc-after-data
              ;; Reduce over children
              (loop [i 0 acc acc-after-data]
                (if (or (>= i child-count) (reduced? acc))
                  acc
                  (let [child-off (read-child-offset dv offset i)]
                    (recur (inc i) (hamt-kv-reduce-js s-atom-env dv child-off f acc)))))))

        ;; Collision node
        3 (let [cnt (.getUint8 dv (+ offset 1))]
            (loop [i 0 pos (+ offset COLLISION_HEADER_SIZE) acc init]
              (if (or (>= i cnt) (reduced? acc))
                acc
                (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                  (recur (inc i) next-pos (f acc k v))))))

        init))))

(defn- hamt-kv-reduce
  "Walk HAMT tree calling (f acc k v) at each entry.
   Uses WASM batch collection when available, falls back to JS tree walk."
  [s-atom-env ^js dv offset f init]
  (if (== offset -1)
    init
    (let [scratch-start (get-scratch-start s-atom-env)
          max-entries wasm/MAX_COLLECT_ENTRIES
          n (when (>= scratch-start 0)
              (wasm/hamt-collect-kv offset scratch-start max-entries))]
      (if (and n (< n max-entries))
        ;; WASM path: copy collected offsets to JS buffer, then iterate.
        ;; Must copy because f may call get/assoc which uses WASM scratch.
        (let [i32-src (wasm/i32-view)
              base (unsigned-bit-shift-right scratch-start 2)
              len (* n 4)
              buf (js/Int32Array. len)]
          (.set buf (.subarray i32-src base (+ base len)))
          (loop [i 0 acc init]
            (if (or (>= i n) (reduced? acc))
              acc
              (let [slot (* i 4)
                    key-off (aget buf slot)
                    key-len (aget buf (+ slot 1))
                    val-off (aget buf (+ slot 2))
                    val-len (aget buf (+ slot 3))
                    k (ser/deserialize-from-dv s-atom-env dv key-off key-len)
                    v (ser/deserialize-from-dv s-atom-env dv val-off val-len)]
                (recur (inc i) (f acc k v))))))
        ;; Fallback: JS tree walk
        (hamt-kv-reduce-js s-atom-env dv offset f init)))))

;;-----------------------------------------------------------------------------
;; Parallel reduce helpers
;;-----------------------------------------------------------------------------

(def ^:const MIN_PARALLEL_ENTRIES 1000)

(defn- get-top-level-subtrees
  "Get the top-level child offsets and any inline KV data from the root node.
   Returns {:children [offset ...] :inline-kvs [[k v] ...]}."
  [s-atom-env ^js dv root-offset]
  (if (== root-offset -1)
    {:children [] :inline-kvs []}
    (let [node-type (read-node-type dv root-offset)]
      (case node-type
        ;; Bitmap node
        1 (let [data-bm (read-data-bitmap dv root-offset)
                node-bm (read-node-bitmap dv root-offset)
                child-count (popcount32 node-bm)
                children (vec (for [i (range child-count)]
                                (read-child-offset dv root-offset i)))
                ;; Collect inline KV entries at root level
                data-count (popcount32 data-bm)
                inline-kvs (if (zero? data-count)
                             []
                             (let [kv-start (kv-data-start root-offset data-bm node-bm)]
                               (loop [i 0 pos kv-start acc []]
                                 (if (>= i data-count)
                                   acc
                                   (let [[k v next-pos] (read-kv-at s-atom-env dv pos)]
                                     (recur (inc i) next-pos (conj acc [k v])))))))]
            {:children children :inline-kvs inline-kvs})
        ;; Other node types
        {:children [] :inline-kvs []}))))

(defn- partition-offsets
  "Partition a vector of offsets into n roughly equal groups."
  [offsets n]
  (let [total (count offsets)
        per-group (max 1 (quot total n))]
    (loop [remaining offsets groups []]
      (if (empty? remaining)
        groups
        (let [take-n (if (< (count groups) (dec n))
                       per-group
                       (count remaining))]
          (recur (subvec remaining take-n)
                 (conj groups (subvec remaining 0 take-n))))))))

;;-----------------------------------------------------------------------------
;; SabMapRoot - persistent map handle
;;-----------------------------------------------------------------------------

(eve-sab-deftype SabMapRoot
  [^:int32 cnt        ;; number of key-value pairs
   ^:int32 root-off]  ;; offset to root node, -1 for empty

  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [this k] (-lookup this k nil))
  (-lookup [this k not-found]
    ;; Check cache first (avoids SAB read + deserialization)
    (if-let [[_ cached-v] (cache-get this k)]
      cached-v
      ;; Cache miss - read from SAB
      (let [s-atom-env (fast-get-env)
            dv (wasm/data-view)
            kh (hash k)]
        (hamt-find s-atom-env dv root-off k kh 0)
        (if find-result-found?
          (let [v find-result-val]
            (set! find-result-val nil)
            (cache-put! this k v) v)
          not-found))))

  IAssociative
  (-contains-key? [this k]
    ;; Check cache first
    (if (cache-get this k)
      true
      (let [s-atom-env (fast-get-env)
            dv (wasm/data-view)
            kh (hash k)]
        (hamt-find s-atom-env dv root-off k kh 0)
        (when find-result-found?
          (let [v find-result-val]
            (set! find-result-val nil)
            (cache-put! this k v)))
        find-result-found?)))
  (-assoc [this k v]
    (let [s-atom-env (fast-get-env)
          kb (ser/serialize-key k)
          vb (ser/serialize-val v)
          kh (hash k)
          new-root (hamt-assoc s-atom-env root-off kh kb vb 0)]
      (if (== new-root root-off)
        this  ;; Same-value assoc: return identical instance (enables identical? fast-path in swap)
        (let [new-cnt (if hamt-result-added? (inc cnt) cnt)
              new-map (make-sab-map-root s-atom-env new-cnt new-root)
              ;; Accumulate modified key hashes for fast path retirement (cap at 8)
              parent-khs (.-_modified_khs this)
              parent-len (if parent-khs (.-length parent-khs) 0)]
          (when (<= parent-len 8)
            (set! (.-_modified_khs new-map)
                  (if (or (nil? parent-khs) (zero? parent-len))
                    #js [kh]
                    (let [khs (.slice parent-khs 0)] (.push khs kh) khs))))
          new-map))))

  IMap
  (-dissoc [this k]
    (let [s-atom-env (fast-get-env)
          kh (hash k)
          kb (ser/serialize-key k)
          new-root (hamt-dissoc s-atom-env root-off kh kb 0)]
      (if-not hamt-result-removed?
        this  ;; Key not found - return same instance
        (if (== new-root -1)
          (empty-sab-map)
          (let [new-map (make-sab-map-root s-atom-env (dec cnt) new-root)
                parent-khs (.-_modified_khs this)
                parent-len (if parent-khs (.-length parent-khs) 0)]
            (when (<= parent-len 8)
              (set! (.-_modified_khs new-map)
                    (if (or (nil? parent-khs) (zero? parent-len))
                      #js [kh]
                      (let [khs (.slice parent-khs 0)] (.push khs kh) khs))))
            new-map)))))

  ICollection
  (-conj [this entry]
    (if (vector? entry)
      (-assoc this (nth entry 0) (nth entry 1))
      (if (satisfies? IMapEntry entry)
        (-assoc this (key entry) (val entry))
        (reduce -conj this entry))))

  IEmptyableCollection
  (-empty [_] (empty-sab-map))

  ISeqable
  (-seq [_]
    (when (pos? cnt)
      (let [s-atom-env (fast-get-env)]
        (hamt-seq s-atom-env root-off))))

  IReduce
  (-reduce [this f]
    (if (zero? cnt)
      (f)
      (let [s-atom-env (fast-get-env)
            dv (wasm/data-view)
            result (hamt-kv-reduce s-atom-env dv root-off
                                   (fn [acc k v]
                                     (if (nil? acc)
                                       (MapEntry. k v nil)
                                       (f acc (MapEntry. k v nil))))
                                   nil)]
        (if (reduced? result) @result result))))

  (-reduce [_ f init]
    (let [s-atom-env (fast-get-env)
          dv (wasm/data-view)
          result (hamt-kv-reduce s-atom-env dv root-off
                                 (fn [acc k v] (f acc (MapEntry. k v nil)))
                                 init)]
      (if (reduced? result) @result result)))

  IKVReduce
  (-kv-reduce [_ f init]
    (let [s-atom-env (fast-get-env)
          dv (wasm/data-view)
          result (hamt-kv-reduce s-atom-env dv root-off f init)]
      (if (reduced? result) @result result)))

  IEquiv
  (-equiv [this other]
    (and (map? other)
         (== cnt (count other))
         (every? (fn [[k v]]
                   (let [s-atom-env (fast-get-env)
                         dv (wasm/data-view)]
                     (hamt-find s-atom-env dv root-off k (hash k) 0)
                     (and find-result-found? (= v find-result-val))))
                 other)))

  IHash
  (-hash [this]
    (hash-unordered-coll this))

  IFn
  (-invoke [this k] (-lookup this k nil))
  (-invoke [this k not-found] (-lookup this k not-found))

  IEditableCollection
  (-as-transient [this]
    (let [s-atom-env (fast-get-env)]
      ;; Note: Flat hashtable code is available but currently HAMT is faster
      ;; due to conversion overhead. Always use HAMT for now.
      (->TransientSabMap s-atom-env root-off this root-off cnt (js/Object.) false)))

  IPrintWithWriter
  (-pr-writer [this writer opts]
    (-write writer "{")
    (let [s (seq this)]
      (when s
        (loop [[[k v] & more] s first? true]
          (when-not first? (-write writer ", "))
          (-write writer (pr-str k))
          (-write writer " ")
          (-write writer (pr-str v))
          (when more (recur more false)))))
    (-write writer "}"))

  d/IDirectSerialize
  (-direct-serialize [this]
    (ser/encode-sab-pointer ser/FAST_TAG_SAB_MAP (.-offset__ this)))

  d/ISabStorable
  (-sab-tag [_] :sab-map)
  (-sab-encode [this _s-atom-env]
    (d/-direct-serialize this))
  (-sab-dispose [this _s-atom-env]
    (when (> root-off -1)
      (let [env (fast-get-env)
            dv (wasm/data-view)]
        (free-hamt-node! env dv root-off))))

  d/ISabRetirable
  (-sab-retire-diff! [this new-value s-atom-env mode]
    (let [old-root root-off]
      (if (instance? SabMapRoot new-value)
        ;; Both are SabMapRoot — try fast path retirement via tracked hashes
        (let [dv (wasm/data-view)
              new-root-off (.getInt32 dv (+ (SabMapRoot-offset new-value) 8) true)
              modified-khs (.-_modified_khs new-value)]
          (if (and modified-khs (pos? (.-length modified-khs)) (<= (.-length modified-khs) 8))
            ;; Fast path: retire via hash-directed path walk for each modified key
            (dotimes [i (.-length modified-khs)]
              (retire-replaced-path! s-atom-env old-root new-root-off (aget modified-khs i) mode))
            ;; Fallback: full tree diff for bulk operations or unknown changes
            (retire-tree-diff! s-atom-env old-root new-root-off mode)))
        ;; New value is not a SabMapRoot — dispose entire old tree
        (when (> old-root -1)
          (let [dv (wasm/data-view)]
            (when (>= old-root (.-byteLength dv))
              (throw (js/Error. (str "_sab_retire_diff_BANG_ (full dispose): old-root " old-root
                                     " >= dv.byteLength " (.-byteLength dv)
                                     ", new-value type=" (type new-value)))))
            (free-hamt-node! s-atom-env dv old-root)))))))

;;-----------------------------------------------------------------------------
;; Flat Hashtable for Transients
;;-----------------------------------------------------------------------------
;; When building maps via transients (e.g., `into`, `reduce conj`), a flat
;; hashtable avoids HAMT node allocations until persistent!
;;
;; Layout:
;;   Header: [type:u8 = 10][capacity:u16][count:u16][next-free:u16]
;;   Buckets: capacity * [hash:u32][key-off:i32][val-off:i32][next:u16]
;;
;; Each bucket is 14 bytes. Open addressing with linear probing + overflow chain.

(def ^:const ^:private HT_TYPE 10)
(def ^:const ^:private HT_HEADER_SIZE 7)  ;; type(1) + capacity(2) + count(2) + next-free(2)
(def ^:const ^:private HT_BUCKET_SIZE 14) ;; hash(4) + key-off(4) + val-off(4) + next(2)
(def ^:const ^:private HT_EMPTY_BUCKET -1)
(def ^:const ^:private HT_LOAD_FACTOR 0.75)
(def ^:const ^:private HT_INITIAL_CAPACITY 32)
(def ^:const ^:private HT_MIN_TRANSIENT_SIZE 8) ;; Min entries before using HT

(defn- ht-bucket-offset
  "Get byte offset of bucket at index."
  [ht-off idx]
  (+ ht-off HT_HEADER_SIZE (* idx HT_BUCKET_SIZE)))

(defn- create-flat-ht!
  "Create a flat hashtable in SAB. Returns header offset."
  [s-atom-env capacity]
  (let [total-size (+ HT_HEADER_SIZE (* capacity HT_BUCKET_SIZE))
        alloc-result (atom/alloc s-atom-env (+ total-size 4))
        _ (when (:error alloc-result)
            (throw (js/Error. (str "HT allocation failed: " (:error alloc-result)))))
        raw-off (:offset alloc-result)
        ht-off (let [rem (mod raw-off 4)]
                 (if (zero? rem) raw-off (+ raw-off (- 4 rem))))
        dv (wasm/data-view)]
    ;; Write header
    (.setUint8 dv ht-off HT_TYPE)
    (.setUint16 dv (+ ht-off 1) capacity true)
    (.setUint16 dv (+ ht-off 3) 0 true)         ;; count = 0
    (.setUint16 dv (+ ht-off 5) capacity true)  ;; next-free = capacity (no overflow yet)
    ;; Initialize all buckets as empty
    (dotimes [i capacity]
      (let [bucket-off (ht-bucket-offset ht-off i)]
        (.setInt32 dv (+ bucket-off 4) HT_EMPTY_BUCKET true)))  ;; key-off = -1 means empty
    ht-off))

(defn- ht-read-header
  "Read hashtable header. Returns [capacity count next-free]."
  [dv ht-off]
  (let [capacity (.getUint16 dv (+ ht-off 1) true)
        cnt (.getUint16 dv (+ ht-off 3) true)
        next-free (.getUint16 dv (+ ht-off 5) true)]
    [capacity cnt next-free]))

(defn- ht-write-count!
  "Update count in hashtable header."
  [dv ht-off new-cnt]
  (.setUint16 dv (+ ht-off 3) new-cnt true))

(defn- ht-find
  "Find key in flat hashtable. Returns [found? value bucket-idx]."
  [s-atom-env dv ht-off k kh]
  (let [[capacity _ _] (ht-read-header dv ht-off)
        start-idx (mod (unsigned-bit-shift-right kh 0) capacity)]
    ;; Linear probe
    (loop [idx start-idx
           probes 0]
      (if (>= probes capacity)
        [false nil -1]  ;; Full table scan, not found
        (let [bucket-off (ht-bucket-offset ht-off idx)
              key-off (.getInt32 dv (+ bucket-off 4) true)]
          (if (== key-off HT_EMPTY_BUCKET)
            [false nil idx]  ;; Empty slot, not found (return slot for insert)
            (let [stored-hash (.getUint32 dv bucket-off true)]
              (if (== stored-hash kh)
                ;; Hash match, compare keys
                (let [entry-k (read-element s-atom-env dv key-off)]
                  (if (= k entry-k)
                    ;; Found!
                    (let [val-off (.getInt32 dv (+ bucket-off 8) true)
                          entry-v (read-element s-atom-env dv val-off)]
                      [true entry-v idx])
                    ;; Hash collision, continue probing
                    (recur (mod (inc idx) capacity) (inc probes))))
                ;; Different hash, continue probing
                (recur (mod (inc idx) capacity) (inc probes))))))))))

(defn- ht-assoc!
  "Insert or update key in flat hashtable. Returns [ht-off added?].
   May reallocate if load factor exceeded."
  [s-atom-env ht-off k kh kb vb]
  (let [dv (wasm/data-view)
        [capacity cnt _] (ht-read-header dv ht-off)
        ;; Check load factor - resize if needed
        [ht-off capacity] (if (>= (/ (inc cnt) capacity) HT_LOAD_FACTOR)
                            (let [new-cap (* capacity 2)
                                  new-ht (create-flat-ht! s-atom-env new-cap)]
                              ;; Copy all entries to new table
                              (dotimes [i capacity]
                                (let [bucket-off (ht-bucket-offset ht-off i)
                                      key-off (.getInt32 dv (+ bucket-off 4) true)]
                                  (when (not= key-off HT_EMPTY_BUCKET)
                                    (let [h (.getUint32 dv bucket-off true)
                                          val-off (.getInt32 dv (+ bucket-off 8) true)
                                          new-idx (mod (unsigned-bit-shift-right h 0) new-cap)
                                          ;; Find empty slot via linear probe
                                          new-bucket (loop [idx new-idx]
                                                       (let [b (ht-bucket-offset new-ht idx)]
                                                         (if (== (.getInt32 dv (+ b 4) true) HT_EMPTY_BUCKET)
                                                           b
                                                           (recur (mod (inc idx) new-cap)))))]
                                      (.setUint32 dv new-bucket h true)
                                      (.setInt32 dv (+ new-bucket 4) key-off true)
                                      (.setInt32 dv (+ new-bucket 8) val-off true)))))
                              ;; Update count in new table
                              (ht-write-count! dv new-ht cnt)
                              [new-ht new-cap])
                            [ht-off capacity])]
    ;; Now insert/update
    (let [[found? _ slot-idx] (ht-find s-atom-env dv ht-off k kh)]
      (if found?
        ;; Update existing - write new value
        (let [bucket-off (ht-bucket-offset ht-off slot-idx)
              val-alloc (atom/alloc s-atom-env (+ (alength vb) 4))
              _ (when (:error val-alloc)
                  (throw (js/Error. (str "HT value alloc failed: " (:error val-alloc)))))
              val-off (:offset val-alloc)]
          (write-element-bytes! s-atom-env val-off vb)
          (.setInt32 dv (+ bucket-off 8) val-off true)
          [ht-off false])
        ;; Insert new
        (let [;; Allocate key
              key-alloc (atom/alloc s-atom-env (+ (alength kb) 4))
              _ (when (:error key-alloc)
                  (throw (js/Error. (str "HT key alloc failed: " (:error key-alloc)))))
              key-off (:offset key-alloc)
              ;; Allocate value
              val-alloc (atom/alloc s-atom-env (+ (alength vb) 4))
              _ (when (:error val-alloc)
                  (throw (js/Error. (str "HT value alloc failed: " (:error val-alloc)))))
              val-off (:offset val-alloc)]
          (write-element-bytes! s-atom-env key-off kb)
          (write-element-bytes! s-atom-env val-off vb)
          ;; Find slot and write bucket
          (let [idx (if (>= slot-idx 0)
                      slot-idx  ;; Reuse slot from find
                      (mod (unsigned-bit-shift-right kh 0) capacity))
                bucket-off (loop [i idx]
                             (let [b (ht-bucket-offset ht-off i)]
                               (if (== (.getInt32 dv (+ b 4) true) HT_EMPTY_BUCKET)
                                 b
                                 (recur (mod (inc i) capacity)))))]
            (.setUint32 dv bucket-off kh true)
            (.setInt32 dv (+ bucket-off 4) key-off true)
            (.setInt32 dv (+ bucket-off 8) val-off true)
            (ht-write-count! dv ht-off (inc cnt))
            [ht-off true]))))))

(defn- ht-dissoc!
  "Remove key from flat hashtable. Returns [ht-off removed?]."
  [s-atom-env ht-off k kh]
  (let [dv (wasm/data-view)
        [found? _ slot-idx] (ht-find s-atom-env dv ht-off k kh)]
    (if found?
      (let [bucket-off (ht-bucket-offset ht-off slot-idx)
            [_ cnt _] (ht-read-header dv ht-off)]
        ;; Mark as deleted by setting key-off to empty
        (.setInt32 dv (+ bucket-off 4) HT_EMPTY_BUCKET true)
        (ht-write-count! dv ht-off (dec cnt))
        [ht-off true])
      [ht-off false])))

(defn- ht-to-hamt
  "Convert flat hashtable to HAMT root. Used on persistent!."
  [s-atom-env ht-off]
  (let [dv (wasm/data-view)
        [capacity cnt _] (ht-read-header dv ht-off)]
    (if (zero? cnt)
      -1  ;; Empty map
      ;; Build HAMT by iterating all non-empty buckets
      (loop [i 0
             root-off -1]
        (if (>= i capacity)
          root-off
          (let [bucket-off (ht-bucket-offset ht-off i)
                key-off (.getInt32 dv (+ bucket-off 4) true)]
            (if (== key-off HT_EMPTY_BUCKET)
              (recur (inc i) root-off)
              (let [kh (.getUint32 dv bucket-off true)
                    val-off (.getInt32 dv (+ bucket-off 8) true)
                    kb (read-element-bytes dv key-off)
                    vb (read-element-bytes dv val-off)
                    new-root (hamt-assoc s-atom-env root-off kh kb vb 0)]
                (recur (inc i) new-root)))))))))

;;-----------------------------------------------------------------------------
;; TransientSabMap - mutable map for batch operations
;;-----------------------------------------------------------------------------

(deftype TransientSabMap [s-atom-env
                          initial-root-off
                          original-persistent
                          ^:mutable root-offset
                          ^:mutable cnt
                          ^:mutable edit
                          ^:mutable use-ht?]
  ICounted
  (-count [_] cnt)

  ILookup
  (-lookup [this k] (-lookup this k nil))
  (-lookup [_ k not-found]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [dv (wasm/data-view)
          kh (hash k)]
      (if use-ht?
        ;; Use flat hashtable lookup
        (let [[found? v _] (ht-find s-atom-env dv root-offset k kh)]
          (if found? v not-found))
        ;; Use HAMT lookup
        (do (hamt-find s-atom-env dv root-offset k kh 0)
            (if find-result-found?
              (let [v find-result-val] (set! find-result-val nil) v)
              not-found)))))

  ITransientCollection
  (-conj! [this entry]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (if (vector? entry)
      (-assoc! this (nth entry 0) (nth entry 1))
      (if (satisfies? IMapEntry entry)
        (-assoc! this (key entry) (val entry))
        (reduce -conj! this entry))))
  (-persistent! [this]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (set! edit nil)
    (if (and (not use-ht?) (== root-offset initial-root-off))
      ;; No-op transient round-trip: return original persistent map
      original-persistent
      (if use-ht?
        ;; Convert flat hashtable to HAMT
        (let [hamt-root (ht-to-hamt s-atom-env root-offset)]
          (make-sab-map-root s-atom-env cnt hamt-root))
        ;; Already HAMT
        (make-sab-map-root s-atom-env cnt root-offset))))

  ITransientAssociative
  (-assoc! [this k v]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [kb (ser/serialize-key k)
          vb (ser/serialize-val v)
          kh (hash k)]
      (if use-ht?
        ;; Use flat hashtable
        (let [[new-ht added?] (ht-assoc! s-atom-env root-offset k kh kb vb)]
          (set! root-offset new-ht)
          (when added? (set! cnt (inc cnt)))
          this)
        ;; Use HAMT
        (let [new-root (hamt-assoc s-atom-env root-offset kh kb vb 0)]
          (set! root-offset new-root)
          (when hamt-result-added? (set! cnt (inc cnt)))
          this))))

  ITransientMap
  (-dissoc! [this k]
    (when-not edit (throw (js/Error. "Transient used after persistent!")))
    (let [kh (hash k)]
      (if use-ht?
        ;; Use flat hashtable
        (let [[new-ht removed?] (ht-dissoc! s-atom-env root-offset k kh)]
          (set! root-offset new-ht)
          (when removed? (set! cnt (dec cnt)))
          this)
        ;; Use HAMT
        (let [kb (ser/serialize-key k)
              new-root (hamt-dissoc s-atom-env root-offset kh kb 0)]
          (set! root-offset new-root)
          (when hamt-result-removed? (set! cnt (dec cnt)))
          this)))))

;;-----------------------------------------------------------------------------
;; Constructors
;;-----------------------------------------------------------------------------

(defn empty-sab-map
  "Return an empty SAB-backed map."
  []
  (make-sab-map-root (fast-get-env) 0 -1))

(defn sab-map
  "Create a new SAB-backed map from key-value pairs."
  [& kvs]
  (let [pairs (partition 2 kvs)]
    (reduce (fn [m [k v]] (assoc m k v))
            (empty-sab-map)
            pairs)))

(defn into-sab-map
  "Create a SAB-backed map from a collection of [key value] entries."
  [entries]
  (reduce (fn [m [k v]] (assoc m k v))
          (empty-sab-map)
          entries))

(def ^:const ^:private SABMAPROOT_ROOT_OFF_OFFSET 8)

(defn sab-map-sum-values
  "Fast WASM-accelerated sum of all numeric values in a SabMap.
   Returns the sum as a number, or nil if any value is non-numeric or WASM unavailable.
   Callers should fall back to reduce-kv when nil."
  [sab-map]
  (when (pos? (count sab-map))
    (let [dv (wasm/data-view)
          root-off (.getInt32 dv (+ (SabMapRoot-offset sab-map) SABMAPROOT_ROOT_OFF_OFFSET) true)
          s-atom-env (fast-get-env)
          scratch-start (get-scratch-start s-atom-env)]
      (when (>= scratch-start 0)
        (wasm/hamt-reduce-sum root-off scratch-start)))))

;;-----------------------------------------------------------------------------
;; Parallel Reduce
;;-----------------------------------------------------------------------------

(defn sab-preduce
  "Parallel reduce over a SabMapRoot. Splits the HAMT tree at the top level
   and reduces each subtree independently, then merges results.

   Only effective when map has >= 1000 entries. Falls back to sequential
   reduce otherwise.

   init-fn:  (fn [] init-val) - called per partition
   rfn:      (fn [acc k v] acc') - per-entry reduction
   merge-fn: (fn [acc1 acc2] merged) - combines partition results"
  [sab-map init-fn rfn merge-fn]
  (let [dv (wasm/data-view)
        base-off (SabMapRoot-offset sab-map)
        cnt (.getInt32 dv (+ base-off 4) true)
        root-off (.getInt32 dv (+ base-off 8) true)]
    (if (< cnt MIN_PARALLEL_ENTRIES)
      ;; Sequential fallback for small maps
      (let [s-atom-env (fast-get-env)
            dv (wasm/data-view)
            result (hamt-kv-reduce s-atom-env dv root-off rfn (init-fn))]
        (if (reduced? result) @result result))
      ;; Parallel path: split tree at top level
      (let [s-atom-env (fast-get-env)
            dv (wasm/data-view)
            {:keys [children inline-kvs]} (get-top-level-subtrees s-atom-env dv root-off)
            num-partitions (min (count children) 4)]
        (if (<= (count children) 1)
          ;; Too few children to parallelize
          (let [result (hamt-kv-reduce s-atom-env dv root-off rfn (init-fn))]
            (if (reduced? result) @result result))
          ;; Reduce each partition independently, then merge
          (let [partitions (partition-offsets children num-partitions)
                ;; Reduce inline KVs first
                inline-acc (reduce (fn [acc [k v]] (rfn acc k v))
                                   (init-fn)
                                   inline-kvs)
                ;; Reduce each partition of subtrees
                partition-results
                (mapv (fn [offsets]
                        (let [init (init-fn)]
                          (reduce (fn [acc child-off]
                                    (let [r (hamt-kv-reduce s-atom-env dv child-off rfn acc)]
                                      (if (reduced? r) @r r)))
                                  init
                                  offsets)))
                      partitions)]
            ;; Merge all results
            (reduce merge-fn inline-acc partition-results)))))))

;;-----------------------------------------------------------------------------
;; SAB Pointer Registration
;; Enables serialize.cljs to encode/decode SabMapRoot as SAB pointers
;; and auto-convert CLJS maps to SabMapRoot during serialization.
;;-----------------------------------------------------------------------------

;; Register constructor for deserializing SAB pointer tags
(ser/register-sab-type-constructor!
  ser/FAST_TAG_SAB_MAP
  (fn [sab offset] (SabMapRoot. sab offset)))

;; Helper: build HAMT from CLJS map, return SabMapRoot.
;; Shared between builder (returns SabMapRoot) and encoder (returns bytes).
;; Identity cache: if called with the same CLJS map (identical?), returns
;; the previously built SabMapRoot. This dramatically speeds up repeated
;; atom reset! with the same value.
(def ^:private ^:mutable cached-build-src nil)
(def ^:private ^:mutable cached-build-root nil)

(defn- build-hamt-from-cljs
  "Build HAMT from CLJS map entries. Returns SabMapRoot.
   Caches result for identical? CLJS maps."
  [m]
  (if (identical? m cached-build-src)
    cached-build-root
    (let [s-atom-env (fast-get-env)
          state #js [-1 0]]  ;; [root-off cnt]
      (set! recycle-replaced-nodes? true)
      (reduce-kv
        (fn [_ k v]
          (let [kb (ser/serialize-key k)
                vb (ser/serialize-val v)
                kh (hash k)
                new-root (hamt-assoc s-atom-env (aget state 0) kh kb vb 0)]
            (aset state 0 new-root)
            (when hamt-result-added? (aset state 1 (inc (aget state 1))))
            nil))
        nil
        m)
      (set! recycle-replaced-nodes? false)
      (let [root (make-sab-map-root s-atom-env (aget state 1) (aget state 0))]
        (set! cached-build-src m)
        (set! cached-build-root root)
        root))))

;; Register CLJS map → SabMap auto-conversion (used by try-build-sab for non-map contexts)
(ser/register-cljs-to-sab-builder!
  map?
  (fn [m] (build-hamt-from-cljs m)))

;; Direct map encoder: builds HAMT, creates root metadata in SAB, and returns
;; pointer bytes directly — skips protocol dispatch chain in serialize-key/serialize-val.
(ser/set-direct-map-encoder!
  (fn [m]
    (let [root (build-hamt-from-cljs m)]
      (ser/encode-sab-pointer ser/FAST_TAG_SAB_MAP (.-offset__ root)))))

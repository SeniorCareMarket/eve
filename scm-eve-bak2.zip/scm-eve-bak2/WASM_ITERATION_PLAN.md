# WASM Iteration Acceleration Plan

> Close the 10-100x gap in SAB iteration by moving per-entry work into WASM
> and eliminating unnecessary memory allocations.

## Current Bottleneck: Per-Entry Cost in `read-kv-at`

Every entry visited during `reduce-kv` runs this path (sab_map.cljs:539-553):

```
read-kv-at(s-atom-env, dv, kv-offset):
  1. dv.getUint32(kv-offset)                   JS read key-len
  2. copy-from-sab(key-start, key-len)          ALLOC Uint8Array + memcpy
  3. deserialize-element(s-atom-env, key-bytes)  JS tag dispatch + TextDecoder + object ctor
  4. dv.getUint32(val-offset)                   JS read val-len
  5. copy-from-sab(val-start, val-len)          ALLOC Uint8Array + memcpy
  6. deserialize-element(s-atom-env, val-bytes)  JS tag dispatch + DataView ctor + decode
```

Per entry: **4 allocations**, **2 memcpys**, **2 full deserializations**.
For 1000 entries: 4000 garbage arrays, 2000 TextDecoder calls.
Zero WASM involvement.

Meanwhile, single `get` uses WASM `hamt_find` for the entire tree walk + key
comparison and is only **2-3x** slower than stock CLJS. The disparity is that
iteration doesn't use WASM at all.

---

## Phase 1: Zero-Copy Deserialization in read-kv-at

**Goal**: Eliminate `copy-from-sab` + intermediate Uint8Array for all fast-path types.

**Observation**: `deserialize-from-dv` (serialize.cljs:588) already reads SAB pointer
types directly from the DataView. But it falls back to copy + `deserialize-element`
for everything else. And `read-kv-at` doesn't use it at all.

### Changes

**A. Extend `deserialize-from-dv` to handle ALL fast-path types inline**
(serialize.cljs:588-625)

Currently only handles SAB pointer tags (0x10-0x13) and RECORD (0x1A) without copy.
Add inline handling for:

| Tag | Current | After |
|-----|---------|-------|
| FALSE (0x01) | copy → deser | `false` (no read needed) |
| TRUE (0x02) | copy → deser | `true` (no read needed) |
| INT32 (0x03) | copy → new DV → getInt32 | `dv.getInt32(off+3, true)` |
| INT64 (0x0F) | copy → new DV → getBigInt64 | `dv.getBigInt64(off+3, true)` |
| FLOAT64 (0x04) | copy → new DV → getFloat64 | `dv.getFloat64(off+3, true)` |
| STRING_SHORT (0x05) | copy → subarray → decode | `u8.subarray(off+4, off+4+len)` → decode |
| STRING_LONG (0x06) | copy → subarray → decode | `u8.subarray(off+7, off+7+len)` → decode |
| KEYWORD_SHORT (0x07) | copy → subarray → decode → keyword | `u8.subarray` → decode → keyword |
| KEYWORD_LONG (0x08) | copy → subarray → decode → keyword | same, long variant |
| KEYWORD_NS_SHORT (0x09) | copy → 2x subarray → decode → keyword | 2x subarray → decode → keyword |
| KEYWORD_NS_LONG (0x0A) | copy → 2x subarray → decode → keyword | same, long variant |
| DATE (0x0E) | copy → new DV → getFloat64 → Date | `dv.getFloat64(off+3)` → Date |
| SYMBOL_SHORT (0x0C) | copy → subarray → decode → symbol | `u8.subarray` → decode → symbol |
| SYMBOL_NS_SHORT (0x0D) | copy → 2x subarray → decode → symbol | same pattern |
| UUID (0x0B) | copy → hex loop → uuid | read bytes from `u8` directly |
| SAB_MAP-SAB_LIST (0x10-0x13) | already zero-copy | no change |

For numeric types (INT32, FLOAT64, BOOL), this eliminates ALL allocations —
just a single DataView read from the SAB.

For string/keyword types, this eliminates the `copy-from-sab` Uint8Array
allocation but still needs `TextDecoder.decode()` on a subarray view (which
does NOT allocate — `.subarray()` returns a view).

**B. Replace `read-kv-at` to use the extended `deserialize-from-dv`**
(sab_map.cljs:539-553)

```clojure
;; BEFORE:
(defn- read-kv-at [s-atom-env ^js dv kv-offset]
  (let [key-len (.getUint32 dv kv-offset true)
        key-start (+ kv-offset 4)
        key-bytes (copy-from-sab key-start key-len)          ;; ALLOC
        key-val (ser/deserialize-element s-atom-env key-bytes) ;; deser from copy
        val-offset (+ key-start key-len)
        val-len (.getUint32 dv val-offset true)
        val-start (+ val-offset 4)
        val-bytes (copy-from-sab val-start val-len)          ;; ALLOC
        val-val (ser/deserialize-element s-atom-env val-bytes) ;; deser from copy
        next-off (+ val-start val-len)]
    [key-val val-val next-off]))

;; AFTER:
(defn- read-kv-at [s-atom-env ^js dv kv-offset]
  (let [key-len (.getUint32 dv kv-offset true)
        key-start (+ kv-offset 4)
        key-val (ser/deserialize-from-dv s-atom-env dv key-start key-len)
        val-offset (+ key-start key-len)
        val-len (.getUint32 dv val-offset true)
        val-start (+ val-offset 4)
        val-val (ser/deserialize-from-dv s-atom-env dv val-start val-len)
        next-off (+ val-start val-len)]
    [key-val val-val next-off]))
```

**C. Apply same fix to `read-val-at` in sab_set.cljs** (line 271-279)
and `read-value-block` in sab_vec.cljs (line 122-127).

**D. Apply same fix to `hamt-find-wasm` value deserialization** (sab_map.cljs:997)

### Expected Impact

- **Numeric values (int32, float64, bool)**: ~3-5x faster per entry (eliminate
  2 allocations + memcpy + DataView construction)
- **Keyword keys**: ~1.5-2x faster per entry (eliminate 1 allocation + memcpy)
- **String values**: ~1.3-1.5x faster per entry (eliminate 1 allocation)
- **Overall reduce-kv**: ~2-3x improvement (from 50-100x → ~20-40x vs stock)

### Testing
- All 66 existing tests must pass (they exercise reduce-kv, seq, get, assoc)
- Run real-world benchmark before/after

---

## Phase 2: Keyword Deserialization Cache by SAB Offset

**Goal**: Avoid repeated TextDecoder + `keyword()` for the same key bytes.

**Observation**: Keywords are the dominant key type. During `reduce-kv`, the same
keyword keys are deserialized every call. `serialize.cljs` has a `keyword-cache`
for *serialization* (keyword → bytes) but nothing for *deserialization*
(bytes → keyword).

### Changes

**A. Add `deser-keyword-cache` in serialize.cljs**

```clojure
(def ^:private deser-keyword-cache (js/Map.))
(def ^:const ^:private DESER_KEYWORD_CACHE_MAX 4096)

(defn- lookup-keyword-cache
  "Cache keyword deserialization by (offset << 8 | len).
   Offset within a given SAB is stable for immutable data."
  [offset len]
  (.get deser-keyword-cache (+ (bit-shift-left offset 8) len)))

(defn- store-keyword-cache [offset len kw]
  (when (>= (.-size deser-keyword-cache) DESER_KEYWORD_CACHE_MAX)
    (.clear deser-keyword-cache))
  (.set deser-keyword-cache (+ (bit-shift-left offset 8) len) kw)
  kw)
```

**B. Wire into `deserialize-from-dv` keyword branches**

Before calling `TextDecoder.decode` + `keyword()`, check
`lookup-keyword-cache(data-offset, data-len)`. On hit, return directly.
On miss, decode and `store-keyword-cache`.

**C. Cache invalidation**

Keywords in SAB are immutable — once written, the bytes at a given offset
never change (structural sharing copies, doesn't mutate). The cache only
needs clearing when the SAB itself is replaced (which resets the atom env).

Add a `clear-deser-caches!` call in `fresh-env` / atom init.

### Expected Impact

- **First reduce-kv**: Same speed as Phase 1 (cache cold)
- **Subsequent reduce-kv on same map**: ~2x faster for keyword-heavy data
  (skip TextDecoder + keyword construction entirely)
- **Typical render cycle** (deref → multiple gets): Keywords cached from
  first access, subsequent lookups near-free

### Testing
- Existing tests cover repeated map access patterns
- Add benchmark that measures first vs second reduce-kv on same map

---

## Phase 3: WASM Batch KV Offset Collection (`hamt_collect_kv`)

**Goal**: Replace JS tree walk in `hamt-kv-reduce` with a single WASM call
that enumerates all KV entry offsets.

**Observation**: `hamt-kv-reduce` walks the tree in JS — reading node types,
computing bitmaps, recursing on children. This is the same tree walk that
`hamt_find` does in WASM (and does efficiently). But `hamt-kv-reduce`
replicates it in JS.

### New WASM Function

```wat
(func $hamt_collect_kv (export "hamt_collect_kv")
  (param $root i32)         ;; Root node offset
  (param $out_buf i32)      ;; Output buffer offset (in SAB scratch region)
  (param $max_entries i32)  ;; Maximum entries to collect
  (result i32)              ;; Number of entries written

  ;; For each KV entry in tree order, write to out_buf:
  ;;   [key_off:i32][key_len:i32][val_off:i32][val_len:i32]  (16 bytes per entry)
  ;;
  ;; Walk order: data entries first (left-to-right), then children (left-to-right),
  ;; matching the existing hamt-kv-reduce traversal order.
  ;;
  ;; Implementation: iterative with explicit stack (avoid WASM call stack limits)
  ;; Stack stored at end of out_buf region: [offset, child_idx, state] triples
```

The WASM function walks the entire tree, reads key_len/val_len at each KV
position, and writes the 4-tuple to the output buffer. No deserialization —
just offset arithmetic.

### JS Side Changes

**Replace `hamt-kv-reduce`** with:

```clojure
(defn- hamt-kv-reduce [s-atom-env ^js dv root-off f init]
  (if (== root-off -1)
    init
    (if-let [entry-count (hamt-collect-kv-wasm root-off)]
      ;; WASM path: iterate collected offsets
      (let [scratch (wasm/scratch-offset ...)
            out (js/Int32Array. (.-buffer (wasm/u8-view)) scratch (* entry-count 4))]
        (loop [i 0 acc init]
          (if (or (>= i entry-count) (reduced? acc))
            acc
            (let [base (* i 4)
                  key-off (aget out base)
                  key-len (aget out (+ base 1))
                  val-off (aget out (+ base 2))
                  val-len (aget out (+ base 3))
                  k (ser/deserialize-from-dv s-atom-env dv key-off key-len)
                  v (ser/deserialize-from-dv s-atom-env dv val-off val-len)]
              (recur (inc i) (f acc k v))))))
      ;; Fallback: JS tree walk (WASM not ready)
      (hamt-kv-reduce-js s-atom-env dv root-off f init))))
```

**Add equivalent for sab_set**: `hamt_collect_val` that writes `[val_off:i32][val_len:i32]`
(8 bytes per entry).

### WASM Implementation Details

- **Stack-based iteration** (not recursive): WASM functions have limited call
  stack depth. Use an explicit stack in the scratch region (after the output
  buffer). Each stack frame: `[node_off:i32, child_idx:i32]` = 8 bytes.
  Max depth: 7 levels (32-bit hash / 5 bits per level) = 56 bytes of stack.

- **Output buffer sizing**: Max entries × 16 bytes. For n=5000: 80KB.
  Scratch region per worker is typically 256KB+, so this fits.

- **Node traversal**: Read type byte → dispatch:
  - Type 1 (bitmap): Read data_bm, node_bm. For each data entry,
    compute kv_pos via `$kv_start` + `$skip_kv` loop. Write (key_off,
    key_len, val_off, val_len). Push children to stack.
  - Type 3 (collision): Read count. Walk entries linearly.

### Expected Impact

- Eliminates ~20% of per-entry overhead (JS tree walk, popcount calls,
  read_node_type, kv_data_start computation)
- Single WASM call for entire tree vs N JS function calls
- Enables further optimizations (batch prefetch, SIMD scan of tags)
- **reduce-kv**: ~1.5-2x on top of Phase 1+2

### Testing
- Verify traversal order matches JS `hamt-kv-reduce` exactly (data before children)
- Test with collision nodes, empty maps, single-entry maps, n=1000
- Run full test suite

---

## Phase 4: WASM Fast-Path Tag Dispatch (`deser_tag_info`)

**Goal**: Move the per-entry type tag dispatch from JS into WASM.

**Observation**: `deserialize-from-dv` / `deserialize-element` checks the 3-byte
magic prefix and dispatches on the tag byte via a `cond` chain (13+ branches).
This is pure arithmetic that WASM handles more efficiently via `br_table`.

### New WASM Function

```wat
(func $deser_tag_info (export "deser_tag_info")
  (param $offset i32)  ;; Data offset in SAB
  (param $len i32)      ;; Data length
  (result i64)          ;; Packed: (tag:i8 << 56) | (payload_offset:i32 << 24) | (payload_len:i24)
                        ;; Or for numeric: (tag:i8 << 56) | (raw_value:i32)

  ;; If len == 0: return (0, 0, 0)  → nil
  ;; If magic prefix doesn't match: return (-1, offset, len)  → fallback to JS
  ;; Read tag byte at offset+2
  ;; Switch on tag:
  ;;   FALSE/TRUE: return (tag, 0, 0)
  ;;   INT32: return (tag, i32.load(offset+3), 0)
  ;;   FLOAT64: return (tag, offset+3, 8)  → JS reads float64
  ;;   STRING_SHORT: len = u8.load(offset+3), return (tag, offset+4, len)
  ;;   STRING_LONG: len = i32.load(offset+3), return (tag, offset+7, len)
  ;;   KEYWORD_SHORT: len = u8.load(offset+3), return (tag, offset+4, len)
  ;;   ... etc for all fast-path tags
  ;;   SAB_MAP..SAB_LIST: return (tag, i32.load(offset+3), 0)
```

Returns a packed i64 that tells JS:
- What type this is (tag)
- Where the payload bytes are (offset + length)
- For int32/bool: the actual value (no further reads needed)

### JS Side

```clojure
(defn deserialize-from-dv [s-atom-env ^js dv data-offset data-len]
  (if (zero? data-len) nil
    (let [info (wasm/deser-tag-info data-offset data-len)
          tag (unsigned-bit-shift-right info 56)]
      (case tag
        0x01 false
        0x02 true
        0x03 (bit-and info 0xFFFFFFFF)  ;; int32 value directly
        0x04 (.getFloat64 dv (bit-and (unsigned-bit-shift-right info 24) 0xFFFFFFFF) true)
        0x05 (keyword (.decode fast-decoder
               (.subarray (wasm/u8-view) payload-off (+ payload-off payload-len))))
        ;; ... etc
        -1 (deserialize-element-fallback ...)))))
```

### Expected Impact

- **int32 values**: ~30% faster (WASM tag dispatch vs JS cond chain + getUint8 calls)
- **Other types**: ~10-15% faster (avoids 3 JS getUint8 calls for magic check)
- Combined with Phase 1: int32 deser = 1 WASM call + 1 bit mask = ~50ns

### Testing
- Same as Phases 1-3 (all existing tests)
- Verify packed i64 encoding/decoding for all tag types

---

## Phase 5: WASM Numeric Aggregation (`hamt_reduce_sum_numeric`)

**Goal**: For the specific `(reduce-kv (fn [acc _ v] (+ acc v)) 0 map)` pattern
where values are int32/float64, do the entire reduce inside WASM.

### New WASM Function

```wat
(func $hamt_reduce_sum_numeric (export "hamt_reduce_sum_numeric")
  (param $root i32)
  (result f64)

  ;; Walk tree (same as hamt_collect_kv structure)
  ;; For each KV entry:
  ;;   Read value tag at val_off: skip 4 bytes (len), read magic+tag
  ;;   If INT32: acc += i32.load(val_off + 4 + 3)
  ;;   If FLOAT64: acc += f64.load(val_off + 4 + 3)
  ;;   Else: return NaN (signal JS to fall back)
  ;; Return accumulated sum as f64
```

### JS Side

```clojure
(defn reduce-kv-sum-numeric
  "Optimized numeric sum via WASM. Falls back to JS if non-numeric values."
  [root-off]
  (when (wasm/ready?)
    (let [result (wasm/hamt-reduce-sum-numeric root-off)]
      (when-not (js/isNaN result)
        result))))
```

Wire into `IKVReduce` as an optimization: detect `(fn [acc _ v] (+ acc v))`
pattern via a protocol or explicit fast-path API:

```clojure
(defn sab-map-sum-values
  "Fast numeric sum of all values. Returns nil if non-numeric values present."
  [sab-map]
  (reduce-kv-sum-numeric (.-root-off sab-map)))
```

### Expected Impact

- **Numeric reduce-kv**: Near parity with stock CLJS (~2-5x vs current 50-100x)
- **Mixed-type maps**: Falls back to JS path (no regression)
- Narrow applicability, but covers the most common aggregation pattern

### Testing
- Test with all-int32 map, all-float64, mixed numeric, mixed types (fallback)
- Verify sum accuracy matches JS path exactly

---

## Phase 6: Vec Reduce Acceleration

**Goal**: Accelerate vector `reduce` which currently calls `nth-impl` per element.

**Observation**: Vec reduce (sab_vec.cljs:480-500) loops `i` from 0 to cnt,
calling `nth-impl` for each index. `nth-impl` navigates the trie from root
each time. This is O(n * log32(n)) instead of O(n).

### New WASM Function

```wat
(func $vec_collect_values (export "vec_collect_values")
  (param $root i32)       ;; Root node offset
  (param $tail i32)       ;; Tail node offset
  (param $cnt i32)        ;; Element count
  (param $shift i32)      ;; Trie shift
  (param $out_buf i32)    ;; Output buffer
  (param $max i32)        ;; Max entries
  (result i32)            ;; Count written

  ;; Walk trie leaf-first (in-order), write [val_off:i32][val_len:i32] per element
  ;; Trie walk: descend to leftmost leaf, iterate slots, then next leaf
  ;; Tail: iterate tail slots
```

### JS Side

Replace the loop-over-nth pattern with:
```clojure
;; Collect all value offsets in one WASM call
(let [entry-count (wasm/vec-collect-values root tail cnt shift scratch max)
      out (js/Int32Array. ...)]
  (loop [i 0 acc init]
    (if (>= i entry-count) acc
      (let [val-off (aget out (* i 2))
            val-len (aget out (+ (* i 2) 1))
            v (ser/deserialize-from-dv s-atom-env dv val-off val-len)]
        (recur (inc i) (f acc v))))))
```

### Expected Impact

- Eliminates trie navigation overhead per element: O(n) instead of O(n * log32(n))
- **Vec reduce n=1000**: ~2-3x improvement (from 34x → ~12-15x vs stock)
- **Vec reduce n=5000**: ~3-5x improvement (deeper trie, more savings)

### Testing
- Verify element order matches sequential nth calls
- Test with various vec sizes (n < 32, n = 32, n = 33, n = 1024, n = 5000)

---

## Projected Combined Impact

| Phase | Target | Estimated reduce-kv Ratio vs Stock |
|-------|--------|------------------------------------|
| Current (no WASM) | — | 50-100x slower |
| Phase 1 (zero-copy deser) | All iteration | **20-40x** |
| Phase 1+2 (+ keyword cache) | Repeated iteration | **12-25x** |
| Phase 1+2+3 (+ WASM batch collect) | All iteration | **8-15x** |
| Phase 1+2+3+4 (+ WASM tag dispatch) | All iteration | **6-12x** |
| Phase 5 (numeric reduce) | Numeric aggregation only | **2-5x** |
| Phase 6 (vec collect) | Vec reduce | **10-15x** |

**Minimum viable improvement (Phase 1 alone)**: 2-3x faster iteration.
Pure JS change, no WASM, low risk.

**Full plan (Phases 1-4)**: 5-8x faster iteration.
~200 lines WASM, ~100 lines JS. Medium effort.

**Specialized (Phase 5)**: Near-parity for numeric workloads.
Narrow but high-value.

---

## Implementation Order & Dependencies

```
Phase 1 ──► Phase 2 ──► Phase 3 ──► Phase 4
  (JS)        (JS)       (WASM)      (WASM)
   │                       │
   │                       └──► Phase 6 (WASM, vec)
   │
   └──────────────────────────► Phase 5 (WASM, standalone)
```

- Phase 1 is prerequisite for everything (establishes the `deserialize-from-dv` path)
- Phase 2 is independent of WASM phases, pure JS cache
- Phase 3 requires Phase 1 (batch collect feeds into `deserialize-from-dv`)
- Phase 4 enhances Phase 1's `deserialize-from-dv` with WASM dispatch
- Phase 5 is standalone (doesn't need Phases 2-4)
- Phase 6 depends on Phase 1 pattern but otherwise independent

---

## WASM Binary Budget

Current: 5,646 bytes (37 exports, ≤8KB budget)

| Phase | New Exports | Estimated Size |
|-------|------------|----------------|
| Phase 3: hamt_collect_kv | 1 (+1 for set variant) | ~400 bytes |
| Phase 4: deser_tag_info | 1 | ~200 bytes |
| Phase 5: hamt_reduce_sum_numeric | 1 | ~300 bytes |
| Phase 6: vec_collect_values | 1 | ~300 bytes |
| **Total** | **+5** | **~1,200 bytes** |
| **Projected total** | **42 exports** | **~6,846 bytes** |

Well within 8KB budget.

---

## Testing Strategy

Each phase:
1. Run full test suite: `shadow-compile sab-unit-test && node out/sab-unit-test.js`
   (66 tests, 1257 assertions)
2. Run real-world benchmark: `shadow-compile real-world-benchmark && node out/real-world-benchmark.js`
3. Run stock comparison: `shadow-compile stock-comparison && node out/stock-comparison.js`
4. Verify WASM binary size: `wc -c` on compiled .wasm
5. Compare before/after for the specific operation being optimized

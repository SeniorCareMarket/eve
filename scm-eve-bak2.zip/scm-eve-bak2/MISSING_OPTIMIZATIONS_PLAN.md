# Missing Optimizations Implementation Plan

## Overview

This document outlines the implementation plan for re-implementing optimizations that were present in the old `sabp-*` implementations but are missing from the new `sab-*` structures after the epoch-based GC migration.

**Target structures:**
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_map.cljs`
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_set.cljs`
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_vec.cljs`
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/sab_list.cljs`

---

## Existing Optimizations Status (VERIFIED WORKING)

| Phase | Optimization | Status | Location |
|-------|-------------|--------|----------|
| 1 | Two-Bitmap HAMT | WORKING | `sab_map.cljs:574-596`, `sab_set.cljs:569-618` |
| 2 | Streaming Reduce | WORKING | `sab_map.cljs:955-993` (hamt-kv-reduce with reduced?) |
| 3 | Lazy Sequences | WORKING | `sab_map.cljs:907-949` (lazy-seq for child traversal) |
| 4 | Skip Functions | WORKING | `sab_map.cljs:277-301`, `sab_set.cljs:262-297` |
| 5 | Raw Byte Copying | WORKING | `sab_map.cljs:306-336`, `sab_set.cljs:313-349` |
| 6 | Parallel Reduce | WORKING | `sab_map.cljs:1253-1298` (sab-preduce) |
| 7 | Chunked Storage | WORKING | `sab_vec.cljs:644-918` (SabVecN), `sab_list.cljs:419-879` (SabListN) |

---

## Recently Implemented

### Proactive Writer Cleanup with Retry (DONE)

**Location:** `src/com/seniorcaremarket/eve/atom.cljs`

**Before:**
- Writers try to free old blocks once
- If readers are active, immediately mark as ORPHANED and move on
- Results in memory fragmentation and orphaned blocks

**After:**
- Writers bounce 4 times with exponential backoff (2ms, 4ms, 8ms, 16ms)
- Uses `Atomics.wait` for CPU-friendly waiting
- Only marks as ORPHANED after all bounces fail
- More proactive about cleanup and reader cooperation

**Implementation:**
```clojure
(def ^:const FREE_RETRY_BOUNCES 4)
(def ^:const FREE_RETRY_BASE_DELAY_MS 2)

(defn free [s-atom-env desc-idx-to-free]
  (loop [bounce 0]
    (let [outcome (free-once s-atom-env desc-idx-to-free)]
      (cond
        (:success outcome) outcome
        (and (#{:active-readers :orphaned-still-has-readers} (:error outcome))
             (< bounce FREE_RETRY_BOUNCES))
        (do (spin-wait-ms (* FREE_RETRY_BASE_DELAY_MS (bit-shift-left 1 bounce)) index-view)
            (recur (inc bounce)))
        ;; ... mark as ORPHANED only after all bounces
        ))))
```

---

### Block Coalescing (DONE)

**Location:** `src/com/seniorcaremarket/eve/atom.cljs`

**Problem:**
- When blocks were freed, they were NOT coalesced with adjacent free blocks
- Memory fragmented over time leading to allocation failures
- Out-of-memory errors even when total free space was sufficient

**Solution:**
- Added `find-physically-adjacent-left-free-neighbor` to find FREE blocks ending at our start
- Added `find-physically-adjacent-right-free-neighbor` to find FREE blocks starting at our end
- Added `coalesce-adjacent-free-blocks!` to merge adjacent free blocks after freeing
- Integrated coalescing into `free-once` for both ALLOCATED and ORPHANED block cleanup
- Integrated coalescing into `end-read!` orphaned block cleanup

**Implementation:**
```clojure
(defn- find-physically-adjacent-left-free-neighbor [s-atom-env current-desc-idx]
  "Find a FREE block whose end (data_offset + capacity) equals current block's data_offset."
  ...)

(defn- find-physically-adjacent-right-free-neighbor [s-atom-env current-desc-idx current-block-end-offset]
  "Find a FREE block whose data_offset equals current block's end."
  ...)

(defn- coalesce-adjacent-free-blocks! [s-atom-env desc-idx worker-id]
  "After freeing a block, merge with adjacent free blocks to prevent fragmentation."
  ;; Left coalesce: expand left neighbor to include us
  ;; Right coalesce: expand us to include right neighbors
  ...)
```

**Benefits:**
- Prevents memory fragmentation
- Larger contiguous free blocks can satisfy bigger allocations
- Reduces out-of-memory errors in long-running applications

---

## Missing Optimizations — STATUS UPDATE

> **All previously "missing" optimizations have been implemented:**
> - Cached Deserialization: DONE (SabMapRoot `_cache`, `cache-get`/`cache-put!`, CACHE_MAX_SIZE=256)
> - SIMD: DONE (simd.cljs, simd_wasm.cljs, simd_hamt.cljs)
> - Flat Hashtable: DONE but disabled (full impl in sab_map.cljs, `use-ht? = false`)
> - Columnar K/V: DONE (SabListN columnar layout in sab_list.cljs)
> - Fressian Removal + Memory Management: Both COMPLETE (see respective plan docs)
>
> **Remaining optimizations not covered here:**
> - ArrayMap for small maps (≤8 entries)
> - WASM hamt_assoc
> - Immutable block flags + copy-on-write (Opt 7.1/7.2)
> - No-op transient round-trip detection (Opt 7.3c)

### 1. Cached Deserialization (Phase 8) — COMPLETE

**Status: DONE** — SabMapRoot has `_cache` field (js/Map), `cache-get`/`cache-put!` with CACHE_MAX_SIZE=256. LRU eviction when cache exceeds max size. Structural ops (assoc, dissoc) return new instance with fresh cache.

**Current State:**
- ~~Every field access deserializes from SAB~~
- ~~Repeated access to same field incurs full deserialization cost~~

**Impact:**
- ~2-5x slowdown for repeated field access patterns
- Significant impact on iteration and reduce operations

**Implementation:**

#### 1.1 Add Cache Field to Types

```clojure
;; In sab_map.cljs, modify SabMapRoot deftype
(eve-sab-deftype SabMapRoot
  [^:int32 cnt
   ^:int32 root-off]
  ;; Add cache as a mutable JS Map (not serialized)
  ;; Note: Cache is per-instance, no sharing concerns

;; Add after deftype:
(defn- with-cache [sab-map]
  "Ensure map has a cache atom attached."
  (when-not (.-_cache sab-map)
    (set! (.-_cache sab-map) (js/Map.)))
  sab-map)
```

#### 1.2 Cached Entry Pattern

```clojure
(defn- cached-get [sab-map k]
  "Get value from cache or SAB."
  (let [cache (.-_cache sab-map)]
    (if (and cache (.has cache k))
      (.get cache k)
      (let [[found? v] (hamt-find s-atom-env dv root-off k (hash k) 0)]
        (when (and found? cache)
          (.set cache k v))
        (when found? v)))))
```

#### 1.3 Cache Invalidation Strategy

- **Structural ops (assoc, dissoc):** Return new instance with fresh cache
- **Transient ops:** Disable caching (mutable, cache would be stale)
- **Max cache size:** Optional LRU eviction for memory control

#### 1.4 Implementation Steps

1. Add `^:mutable _cache` field to SabMapRoot, SabSetRoot
2. Modify `ILookup/-lookup` to check cache first
3. Modify `IAssociative/-assoc` to return fresh instance
4. Add `with-caching` wrapper function for explicit opt-in
5. Benchmark cache hit rates and memory overhead

---

### 2. SIMD Optimizations (Phase 9) — COMPLETE

**Status: DONE** — Full SIMD module implemented: `simd.cljs` (ClojureScript wrapper with feature detection), `simd_wasm.cljs` (WASM integration), `simd_hamt.cljs` (HAMT-specific SIMD ops). WASM functions in `wasm_mem.wat` include popcount, memcmp, hamt_find, descriptor scanning.

**Current State:**
- ~~Columnar layout in SabListN is SIMD-ready but unused~~
- ~~All operations use scalar JS operations~~
- ~~popcount32 uses JS bit manipulation~~

**Impact:**
- ~2-8x potential speedup for vectorizable operations
- Significant gains for bulk operations, key comparison, memory copy

**Implementation:**

#### 2.1 Create WASM Module

**File: `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/simd.wat`**

```wat
(module
  ;; Memory imported from JS (SharedArrayBuffer)
  (import "env" "memory" (memory 1 256 shared))

  ;; popcount32 - count set bits
  (func $popcount32 (export "popcount32") (param $x i32) (result i32)
    local.get $x
    i32.popcnt)

  ;; simd_memcmp - compare memory regions (16-byte aligned)
  (func $simd_memcmp (export "simd_memcmp")
        (param $ptr1 i32) (param $ptr2 i32) (param $len i32) (result i32)
    (local $i i32)
    (local $v1 v128)
    (local $v2 v128)
    (local.set $i (i32.const 0))
    (block $exit
      (loop $loop
        (br_if $exit (i32.ge_u (local.get $i) (local.get $len)))
        (local.set $v1 (v128.load (i32.add (local.get $ptr1) (local.get $i))))
        (local.set $v2 (v128.load (i32.add (local.get $ptr2) (local.get $i))))
        (br_if $exit
          (i32.eqz (i8x16.all_true (i8x16.eq (local.get $v1) (local.get $v2)))))
        (local.set $i (i32.add (local.get $i) (i32.const 16)))
        (br $loop)
      )
    )
    (i32.lt_u (local.get $i) (local.get $len)))

  ;; simd_memmove - vectorized memory copy (16-byte aligned)
  (func $simd_memmove (export "simd_memmove")
        (param $dst i32) (param $src i32) (param $len i32)
    (local $i i32)
    (local.set $i (i32.const 0))
    (block $exit
      (loop $loop
        (br_if $exit (i32.ge_u (local.get $i) (local.get $len)))
        (v128.store
          (i32.add (local.get $dst) (local.get $i))
          (v128.load (i32.add (local.get $src) (local.get $i))))
        (local.set $i (i32.add (local.get $i) (i32.const 16)))
        (br $loop)
      )
    ))

  ;; simd_find_type - find first element of given type in columnar types array
  (func $simd_find_type (export "simd_find_type")
        (param $types_ptr i32) (param $count i32) (param $type i32) (result i32)
    (local $i i32)
    (local $v v128)
    (local $mask v128)
    (local $type_splat v128)
    (local.set $type_splat (i8x16.splat (local.get $type)))
    (local.set $i (i32.const 0))
    (block $exit
      (loop $loop
        (br_if $exit (i32.ge_u (local.get $i) (local.get $count)))
        (local.set $v (v128.load (i32.add (local.get $types_ptr) (local.get $i))))
        (local.set $mask (i8x16.eq (local.get $v) (local.get $type_splat)))
        (if (i8x16.any_true (local.get $mask))
          (then
            ;; Found - return first matching index
            (return (i32.add (local.get $i)
                            (i32.ctz (i8x16.bitmask (local.get $mask)))))))
        (local.set $i (i32.add (local.get $i) (i32.const 16)))
        (br $loop)
      )
    )
    (i32.const -1))  ;; Not found
)
```

#### 2.2 Create ClojureScript Wrapper

**File: `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/simd.cljs`**

```clojure
(ns com.seniorcaremarket.eve-sab-deftype.simd
  "SIMD utilities via WebAssembly for SAB operations.")

;; WASM module bytes (compiled from simd.wat)
(def ^:private wasm-bytes
  (js/Uint8Array. [0x00 0x61 0x73 0x6d ...]))  ;; Generated

;; Feature detection
(def ^:private simd-available?
  (try
    (js/WebAssembly.validate
      (js/Uint8Array.
        [0x00 0x61 0x73 0x6d 0x01 0x00 0x00 0x00
         0x01 0x05 0x01 0x60 0x00 0x01 0x7b  ;; v128 type
         0x03 0x02 0x01 0x00
         0x0a 0x06 0x01 0x04 0x00 0xfd 0x0c 0x0b]))
    (catch :default _ false)))

;; Lazy WASM instance
(def ^:private simd-instance (atom nil))

(defn- get-simd-instance [sab]
  (or @simd-instance
      (when simd-available?
        (let [memory (js/WebAssembly.Memory.
                       #js {:initial 1 :maximum 256 :shared true})
              module (js/WebAssembly.Module. wasm-bytes)
              instance (js/WebAssembly.Instance.
                         module
                         #js {:env #js {:memory memory}})]
          (reset! simd-instance instance)
          instance))))

;; Public API with fallbacks

(defn popcount32 [n]
  (if-let [inst (get-simd-instance nil)]
    ((.exports inst).popcount32 n)
    ;; JS fallback
    (let [n (- n (bit-and (unsigned-bit-shift-right n 1) 0x55555555))
          n (+ (bit-and n 0x33333333)
               (bit-and (unsigned-bit-shift-right n 2) 0x33333333))
          n (bit-and (+ n (unsigned-bit-shift-right n 4)) 0x0f0f0f0f)
          n (+ n (unsigned-bit-shift-right n 8))
          n (+ n (unsigned-bit-shift-right n 16))]
      (bit-and n 0x3f))))

(defn simd-memcmp [sab offset1 offset2 len]
  "Compare len bytes at two SAB offsets. Returns true if equal."
  (if-let [inst (get-simd-instance sab)]
    (zero? ((.exports inst).simd_memcmp offset1 offset2 len))
    ;; JS fallback
    (let [u8 (js/Uint8Array. sab)]
      (loop [i 0]
        (if (>= i len)
          true
          (if (== (aget u8 (+ offset1 i)) (aget u8 (+ offset2 i)))
            (recur (inc i))
            false))))))

(defn simd-memmove [sab src-off dst-off len]
  "Copy len bytes within SAB using SIMD if available."
  (if-let [inst (get-simd-instance sab)]
    ((.exports inst).simd_memmove dst-off src-off len)
    ;; JS fallback
    (.copyWithin (js/Uint8Array. sab) dst-off src-off (+ src-off len))))

(defn simd-find-type [sab types-ptr count type-tag]
  "Find first element of given type in columnar types array."
  (if-let [inst (get-simd-instance sab)]
    ((.exports inst).simd_find_type types-ptr count type-tag)
    ;; JS fallback
    (let [u8 (js/Uint8Array. sab)]
      (loop [i 0]
        (if (>= i count)
          -1
          (if (== (aget u8 (+ types-ptr i)) type-tag)
            i
            (recur (inc i))))))))
```

#### 2.3 Integration Points

1. Replace `popcount32` in `sab_map.cljs` and `sab_set.cljs`
2. Use `simd-memcmp` for key comparison in collision nodes
3. Use `simd-memmove` in `copy-kv-data-all!` and `copy-kv-data-except!`
4. Use `simd-find-type` for type filtering in SabListN iteration

---

### 3. Flat Hashtable for Transients — COMPLETE (disabled)

**Status: DONE but disabled** — Full implementation exists in sab_map.cljs (~lines 1531+). Includes `create-flat-ht!`, `ht-find`, `ht-assoc!`, `ht-dissoc!`, `ht-to-hamt`. Currently disabled via `use-ht? = false`. Can be enabled when benchmarks justify it.

**Current State:**
- ~~Transients use same HAMT structure as persistent maps~~
- ~~Each assoc! creates new nodes (expensive for bulk ops)~~

**Impact:**
- ~2x speedup for bulk transient operations
- Significant gains for `into` and `reduce`-based construction

**Implementation:**

#### 3.1 Add Flag

In `scm-eve/src/com/seniorcaremarket/eve/data.cljs`:
```clojure
(def ^:dynamic *use-flat-hashtable* false)
```

#### 3.2 Flat Hashtable Layout

```
Hashtable Header:
[type:u8 = 10][capacity:u32][count:u32][load_factor:f32]

Buckets (capacity entries):
[hash:u32][key_offset:i32][val_offset:i32][next:i32]
  - next: -1 for end of chain, else bucket index

Overflow:
Chained entries stored in same format after initial capacity
```

#### 3.3 Functions to Add

**In `sab_map.cljs`:**

```clojure
(def ^:const HT_TYPE 10)
(def ^:const HT_HEADER_SIZE 13)  ;; type + capacity + count + load_factor
(def ^:const HT_BUCKET_SIZE 16)  ;; hash + key_off + val_off + next
(def ^:const HT_LOAD_FACTOR 0.75)

(defn- create-flat-ht!
  "Create a flat hashtable in SAB. Returns header offset."
  [s-atom-env initial-capacity]
  ...)

(defn- ht-find
  "Find key in flat hashtable. Returns [found? value]."
  [s-atom-env dv ht-off k kh]
  ...)

(defn- ht-assoc!
  "Insert or update key in flat hashtable. Returns [ht-off added?].
   May reallocate if load factor exceeded."
  [s-atom-env ht-off k kh kb vb]
  ...)

(defn- ht-dissoc!
  "Remove key from flat hashtable. Returns [ht-off removed?]."
  [s-atom-env ht-off k kh]
  ...)

(defn- ht-to-hamt
  "Convert flat hashtable to HAMT root. Used on persistent!."
  [s-atom-env ht-off]
  ...)
```

#### 3.4 Modify TransientSabMap

```clojure
(deftype TransientSabMap [s-atom-env
                          ^:mutable storage-off  ;; HAMT root or HT offset
                          ^:mutable storage-type ;; :hamt or :ht
                          ^:mutable cnt
                          ^:mutable edit]
  ITransientAssociative
  (-assoc! [this k v]
    (if edit
      (if (and d/*use-flat-hashtable* (= storage-type :hamt))
        ;; Convert to HT on first assoc! if flag enabled
        (let [ht-off (hamt-to-ht s-atom-env storage-off)]
          (set! storage-off ht-off)
          (set! storage-type :ht)
          (-assoc! this k v))
        ;; Use appropriate storage
        (if (= storage-type :ht)
          (let [[new-off added?] (ht-assoc! s-atom-env storage-off k (hash k) ...)]
            (set! storage-off new-off)
            (when added? (set! cnt (inc cnt)))
            this)
          ;; HAMT path
          ...))
      (throw (js/Error. "Transient used after persistent!"))))

  ITransientCollection
  (-persistent! [this]
    (set! edit nil)
    (if (= storage-type :ht)
      ;; Convert HT back to HAMT
      (->SabMapRoot cnt (ht-to-hamt s-atom-env storage-off))
      (->SabMapRoot cnt storage-off))))
```

---

### 4. Columnar K/V Separation — COMPLETE

**Status: DONE** — Columnar layout implemented in SabListN (sab_list.cljs). Type tags stored in contiguous arrays for SIMD-friendly scanning.

**Current State:**
- ~~KV pairs stored contiguously: [klen][key][vlen][val]~~
- ~~Must skip keys to read values~~

**Impact:**
- ~20-30% speedup for value-only iteration
- Better cache utilization for homogeneous key types

**Implementation:**

#### 4.1 New Node Type

```clojure
(def ^:const NODE_TYPE_COLUMNAR 6)

;; Columnar Node Layout:
;; [type:u8 = 6][pad:u8][data_bm:u32][node_bm:u32]
;; [children: popcount(node_bm) * i32]
;; [key_region_off:i32]      - offset to key region
;; [val_region_off:i32]      - offset to val region
;; [key_count:u16]
;; [key_total_size:u32]      - for fast skip to val region
;;
;; Key Region: [klen:u32][kbytes]... (contiguous)
;; Val Region: [vlen:u32][vbytes]... (contiguous, same order as keys)
```

#### 4.2 Functions to Add

```clojure
(defn- make-columnar-node!
  "Create a columnar bitmap node with separated K/V regions."
  [s-atom-env data-bm node-bm children kv-pairs]
  ...)

(defn- read-columnar-key-at
  "Read key at index from columnar node's key region."
  [s-atom-env dv offset data-bm node-bm idx]
  ...)

(defn- read-columnar-val-at
  "Read value at index from columnar node's val region."
  [s-atom-env dv offset data-bm node-bm idx key-total-size]
  ...)
```

#### 4.3 Conditional Usage

Enable for nodes with:
- >= 8 inline entries (amortizes overhead)
- Homogeneous key types (better SIMD potential)

```clojure
(defn- should-use-columnar? [data-count key-types]
  (and (>= data-count 8)
       (= 1 (count (distinct key-types)))))
```

---

## Implementation Order — ALL COMPLETE

All tiers have been implemented:

### Tier 1: Quick Wins — DONE
1. **Cached Deserialization** — DONE
2. **Flat Hashtable** — DONE (disabled via flag)

### Tier 2: Infrastructure — DONE
3. **SIMD Module** — DONE (simd.cljs, simd_wasm.cljs, simd_hamt.cljs, wasm_mem.wat)
4. **Integrate SIMD popcount** — DONE

### Tier 3: Advanced — DONE
5. **SIMD memcmp/memmove** — DONE (in wasm_mem.wat)
6. **Columnar K/V Separation** — DONE (SabListN)
7. **SIMD type filtering** — DONE (simd_hamt.cljs)

---

## Testing Strategy

### Unit Tests
- Verify correctness after each optimization
- Regression tests for all protocols (ISeq, IReduce, IKVReduce, etc.)

### Performance Benchmarks

Run after each phase:
```bash
# Single-threaded performance
npx shadow-cljs compile comprehensive-perf && node out/comprehensive-perf.js

# Multi-threaded contention
npx shadow-cljs compile heterogeneous-contention-test && node out/worker.js
```

### Expected Improvements

| Optimization | Target Improvement |
|-------------|-------------------|
| Cached Deserialization | 2-5x for repeated access |
| SIMD popcount | 2x for HAMT navigation |
| SIMD memcmp | 3x for key comparison |
| SIMD memmove | 2x for raw byte copying |
| Flat Hashtable | 2x for bulk transient ops |
| Columnar K/V | 20-30% for value iteration |

---

## Files to Create/Modify

### New Files
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/simd.cljs` - SIMD utilities
- `scm-eve/src/com/seniorcaremarket/eve_sab_deftype/simd.wat` - WASM source
- `scm-eve/test/com/seniorcaremarket/eve_sab_deftype/simd_test.cljs` - SIMD tests

### Modified Files
- `sab_map.cljs` - Cached deser, SIMD, flat HT, columnar
- `sab_set.cljs` - Cached deser, SIMD, columnar
- `sab_vec.cljs` - Cached deser (optional)
- `sab_list.cljs` - SIMD type filtering
- `scm-eve/src/com/seniorcaremarket/eve/data.cljs` - Add `*use-flat-hashtable*` flag

---

## Success Metrics

| Metric | Current | Target |
|--------|---------|--------|
| Map build (n=500) | ~2.5k ops/s | ~5k ops/s |
| Map lookup (n=500) | ~50k ops/s | ~100k ops/s |
| Map reduce-kv | ~50k ops/s | ~100k ops/s |
| Set contains | ~700k ops/s | ~1.4M ops/s |
| Transient bulk assoc | ~5k ops/s | ~10k ops/s |

---

## Notes

- **SIMD availability:** Check `simd-available?` before using WASM
- **Memory alignment:** SIMD loads require 16-byte alignment
- **Cache invalidation:** Structural ops must return fresh instances
- **Flag system:** Use dynamic vars for opt-in features
- **Backward compatibility:** All changes should be additive

---

## Known Issues (RESOLVED)

### Recursive HAMT Tree Freeing — RESOLVED

**Original Problem:**
When persistent operations (assoc, dissoc) create new HAMT nodes, the old nodes are NOT freed, causing memory exhaustion.

**Resolution (Single-Root-in-Atom Model):**

This is now addressed by the **single-root-in-atom memory management model** (see `MEMORY_MANAGEMENT_PLAN.md`). Key insight: with persistent data structures rooted in a single atom, reachability is determined entirely by the root pointer. After a CAS swap, old unreachable nodes are logically dead.

**What was implemented:**
1. **`dispose!`** for all 4 data structures (commit 823148b) — recursive tree/chain freeing
2. **`offset→desc`** tracking (commit 6729706) — O(1) descriptor lookup via JS Map
3. **`retire-replaced-path!`** (commit 6729706) — walks old/new HAMT trees after swap, retires only the replaced path nodes (O(log n)), skips shared subtrees

**What the new model removes:**
- No data zeroing needed (allocator already doesn't zero)
- No reference counting needed (single root = single owner)
- No complex "deep dispose" needed (tree-diff retire replaces it)

**Remaining work:** ALL DONE
- ~~Wire `retire-replaced-path!` into atom swap~~ — DONE (ISabRetirable in atom swap)
- ~~Add retire for sab_set, sab_vec, sab_list~~ — DONE (all data structures)
- ~~Demand-driven sweep integration~~ — DONE (in alloc/batch-alloc fallback)
- See `MEMORY_MANAGEMENT_PLAN.md` (STATUS: COMPLETE)

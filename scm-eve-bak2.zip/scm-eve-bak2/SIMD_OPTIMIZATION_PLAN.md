# SIMD Optimization Plan — EVE SAB Data Structures

## Status: IN PROGRESS

## Overview

This plan accelerates EVE's allocation, GC sweep, and HAMT operations using
WASM SIMD (v128) instructions. Four phases, each with a benchmark checkpoint.

Current state: SIMD primitives exist in `wasm_mem.wat` (8 v128 functions) but
are **not wired** into allocation, sweep, or HAMT hot paths. The descriptor
table's 28-byte AoS stride and 10-byte node header prevent efficient v128 loads.

---

## Layout Changes Summary

| Change | Bytes | Phase | Rationale |
|---|---|---|---|
| SoA status[N] + capacity[N] mirrors | +2 KB | 1 | Contiguous i32 arrays for v128 scan |
| Pad node header 10 → 12 bytes | +2 B/node | 3 | Aligned child access, flags byte |
| Extract hash array from KV entries | 0 net | 3 | Contiguous hashes for i32x4.eq pre-filter |

---

## Phase 1: SoA Descriptor Mirrors + SIMD Alloc Scan

### Goal
Replace scalar `find_free_descriptor` (1 descriptor/iteration, 28-byte AoS stride)
with v128-accelerated scan over contiguous status/capacity arrays (4 descriptors/cycle).

### 1A. Memory layout — add SoA mirror arrays

**Current layout:**
```
[SAB Header: 24 B]
[Worker Registry: 256 × 24 B = 6144 B]
[Descriptor Table: max_blocks × 28 B]
[Scratch Region: 64 × 4096 B]
[Data Region: remainder]
```

**New layout:**
```
[SAB Header: 24 B]
[Worker Registry: 256 × 24 B = 6144 B]
[Descriptor Table: max_blocks × 28 B]
[Status Mirror: max_blocks × 4 B]          ← NEW
[Capacity Mirror: max_blocks × 4 B]        ← NEW
[Scratch Region: 64 × 4096 B]
[Data Region: remainder]
```

**Files to change:**
- `data.cljs`: Add constants:
  ```clojure
  (defonce ^:const OFFSET_STATUS_MIRROR_START
    (+ OFFSET_BLOCK_DESCRIPTORS_ARRAY_START
       (* MAX_BLOCK_DESCRIPTORS SIZE_OF_BLOCK_DESCRIPTOR)))
  (defonce ^:const OFFSET_CAPACITY_MIRROR_START
    (+ OFFSET_STATUS_MIRROR_START
       (* MAX_BLOCK_DESCRIPTORS SIZE_OF_INT32)))
  ```
  Note: MAX_BLOCK_DESCRIPTORS is dynamic (per-atom). Mirror offsets must be
  computed at atom creation time and stored in the env, not as global constants.
  Add `:status-mirror-start` and `:capacity-mirror-start` to s-atom-env.

- `atom.cljs` `private-atom`: Compute mirror offsets based on actual max-blocks:
  ```
  status-mirror-start  = desc-table-start + max-blocks × 28
  capacity-mirror-start = status-mirror-start + max-blocks × 4
  scratch-region-start  = capacity-mirror-start + max-blocks × 4
  ```
  Adjust data-region-start accordingly. Store in env map.

- `atom.cljs` `init-descriptors!`: Initialize status mirror to STATUS_ZEROED_UNUSED (-1),
  capacity mirror: desc 0 gets data-region-size, rest get 0.

### 1B. Keep mirrors in sync

Every descriptor status/capacity mutation must also write the mirror. Identify all
mutation sites:

| Site | File | Status Change | Capacity Change |
|---|---|---|---|
| `try-claim-descriptor!` | atom.cljs | → ALLOCATED | → requested-size |
| `clear-descriptor-fields!` | atom.cljs | → ZEROED_UNUSED | → 0 |
| Remainder split (in try-claim) | atom.cljs | → FREE | → remainder-size |
| `try-free-retired!` | atom.cljs | → FREE | (unchanged) |
| `retire-block!` | atom.cljs | → RETIRED | (unchanged) |
| `free-descriptor!` (if exists) | atom.cljs/util.cljs | → FREE | (unchanged) |

Each site: add 1-2 `i32.store` calls to mirror arrays after the main descriptor write.
Helper function:
```clojure
(defn- update-mirrors! [s-atom-env desc-idx status capacity]
  (let [index-view (:index-view s-atom-env)
        sm (:status-mirror-start s-atom-env)
        cm (:capacity-mirror-start s-atom-env)
        sm-idx (/ (+ sm (* desc-idx 4)) 4)
        cm-idx (/ (+ cm (* desc-idx 4)) 4)]
    (aset index-view sm-idx status)
    (when capacity (aset index-view cm-idx capacity))))
```

### 1C. WASM SIMD scan functions

Add to `wasm_mem.wat`:

```wat
(func $find_free_descriptor_simd (export "find_free_descriptor_simd")
  (param $status_arr i32)     ;; byte offset of status mirror
  (param $capacity_arr i32)   ;; byte offset of capacity mirror
  (param $count i32)          ;; number of descriptors
  (param $min_capacity i32)   ;; minimum capacity
  (param $start_idx i32)      ;; starting index
  (result i32)                ;; found index or -1

  ;; Process 4 descriptors per iteration:
  ;; 1. v128.load status_arr[i..i+3]
  ;; 2. free_mask = i32x4.eq(statuses, splat(0))      ;; STATUS_FREE
  ;; 3. unused_mask = i32x4.eq(statuses, splat(-1))    ;; STATUS_ZEROED_UNUSED
  ;; 4. combined = v128.or(free_mask, unused_mask)
  ;; 5. If v128.any_true(combined):
  ;;    a. v128.load capacity_arr[i..i+3]
  ;;    b. cap_ok = i32x4.ge_s(capacities, splat(min_capacity))
  ;;    c. final = v128.and(combined, cap_ok)
  ;;    d. If any_true(final): extract first matching lane index
  ;; 6. Scalar tail for remainder (count % 4)
)

(func $find_free_descriptors_batch_simd (export "find_free_descriptors_batch_simd")
  ;; Same but collects up to N matching indices into output buffer
  (param $status_arr i32)
  (param $capacity_arr i32)
  (param $count i32)
  (param $min_capacity i32)
  (param $start_idx i32)
  (param $max_results i32)
  (param $out_ptr i32)
  (result i32)               ;; count found
)
```

### 1D. Wire into alloc path

- `wasm_mem.cljs`: Add CLJS wrappers:
  ```clojure
  (defn find-free-descriptor-simd [status-arr capacity-arr count min-cap start]
    (.find_free_descriptor_simd (.-exports @wasm-module) ...))
  ```
- `atom.cljs` `batch-alloc-wasm`: Pass mirror offsets from env, call SIMD variant.
  Fallback chain: SIMD scan → scalar WASM scan → JS scan.

### 1E. Tests
- All existing 66 tests must pass (no structural changes to data)
- Add test: allocate many blocks, verify mirrors stay in sync
- Add test: free + re-allocate, verify mirror consistency

### Benchmark Checkpoint 1
```
Measure BEFORE and AFTER:
  - build n=10, n=100       (SabMap — heavy alloc)
  - build n=10, n=100       (SabSet — heavy alloc)
  - assoc n=10, n=100       (single alloc per op)
  - swap! (assoc :x random) (alloc + retire)
  - reset! (20-key map)     (batch alloc)
  - [NEW] batch-alloc microbenchmark: time to alloc 100 blocks on empty atom
```

---

## Phase 2: SIMD Sweep + Retire Acceleration

### Goal
SIMD-accelerate `sweep-retired-blocks!` (scan for STATUS_RETIRED) and
`retire-tree-diff!` (compare child arrays between old/new HAMT nodes).

### 2A. SIMD retired-block scan

Add to `wasm_mem.wat`:
```wat
(func $find_retired_descriptors_simd (export "find_retired_descriptors_simd")
  (param $status_arr i32)   ;; status mirror
  (param $count i32)        ;; descriptor count
  (param $out_ptr i32)      ;; output buffer for indices
  (param $max_results i32)
  (result i32)              ;; count found

  ;; v128.load 4 statuses, i32x4.eq(splat(5)), collect matching indices
)
```

- `atom.cljs` `sweep-retired-blocks!`: Use SIMD scan to get retired indices first,
  then call `try-free-retired!` only on those. Skip non-retired entirely.
  Current: O(N) visiting every descriptor. After: O(N/4) SIMD scan + O(R) retire ops.

### 2B. SIMD child-array diff in retire-tree-diff!

`sab_map.cljs` `retire-tree-diff!` (lines 332-383): When comparing old/new nodes
with children, compare child pointer arrays using `wasm/simd-eq-i32?` (already built).

```clojure
;; Current: one-at-a-time child comparison
(dotimes [i child-count]
  (let [old-child (read-child-offset dv old-off i)
        new-child (read-child-offset dv new-off i)]
    (when (not= old-child new-child) ...)))

;; SIMD: compare 4 children per v128
;; Use simd-eq-i32? on child array regions, extract diff bitmask
```

For nodes with ≤4 children (most common), one v128 comparison suffices.
For larger nodes (up to 32 children), loop in groups of 4.

### 2C. SIMD child-array diff in retire-replaced-path!

Same optimization for `retire-replaced-path!` (lines 290-330) — single-key
path walk. Less impactful (only compares one child per level) but still a
free improvement since the SIMD infrastructure exists.

### Benchmark Checkpoint 2
```
Measure BEFORE (Phase 1 done) and AFTER:
  - sweep-retired-blocks! on atom with 200 retired blocks
  - swap! (assoc :x random) × 200 iterations (exercises retire-diff)
  - swap! (update :counter inc) × 200 iterations
  - [NEW] retire-tree-diff! microbenchmark: diff two 10-key maps differing by 1 key
```

---

## Phase 3: Node Layout Changes + SIMD HAMT Lookup

### Goal
Pad node header to 12 bytes, extract hashes into contiguous array per node,
enable i32x4 hash pre-filtering in `hamt_find`.

### 3A. Pad bitmap node header: 10 → 12 bytes

**New header layout:**
```
Offset  Size  Field
0       1     type          u8   (NODE_TYPE_BITMAP=1, COLLISION=3)
1       1     flags         u8   (bit 0: has-hash-array)
2       2     padding       u16  (zero)
4       4     data_bitmap   u32 LE
8       4     node_bitmap   u32 LE
--- 12 bytes total ---
```

Note: `flags` field replaces former `pad` byte. Enables gradual migration
(nodes with flags=0 use old format, flags & 1 = hash-array format).

**Files to change:**
- `sab_map.cljs`: `NODE_HEADER_SIZE = 12`, update `kv-data-start`, all node reads
- `sab_set.cljs`: Same header change
- `wasm_mem.wat`: Update ALL hard-coded `10` constants:
  - `$kv_start`: offset + 12 + popcount(node_bm) × 4
  - `$hamt_find`: child access at offset + 12 + idx × 4
  - All 5 builder functions: header writes, child offsets
  - `$skip_kv`, `$calc_kv_total_size`: affected via kv_start
- `wasm_mem.cljs`: Update any JS-side constants referencing header size

### 3B. Extract hashes into contiguous array

**New bitmap node layout:**
```
[type:u8][flags:u8][pad:u16][data_bm:u32][node_bm:u32]  12 bytes header
[children: i32 × C]                                       4*C bytes
[hashes: i32 × M]                                         4*M bytes (NEW)
[kv_data: entries...]                                      variable
```
Where C = popcount(node_bm), M = popcount(data_bm).

**KV entry format changes:**
```
Old: [cljs_hash:4][key_len:4][key:?][val_len:4][val:?]  = 12 + key + val
New: [key_len:4][key:?][val_len:4][val:?]                = 8 + key + val
```

**Net size change per node: zero.** 4×M bytes move from entries to hash array.

**Formulas:**
```
children_start  = offset + 12
hashes_start    = offset + 12 + C × 4
kv_data_start   = offset + 12 + C × 4 + M × 4
```

**Files to change:**
- `sab_map.cljs`:
  - `kv-data-start`: add `+ (* 4 (popcount32 data-bm))` for hash array
  - `hashes-start` (new fn): `offset + 12 + (* 4 (popcount32 node-bm))`
  - `write-kv!`: Remove hash field write (now written to hash array)
  - `read-kv-hash`: Read from hash_array[idx] instead of kv_entry+0
  - `skip-kv-at`: Update: entry is now `8 + key_len + val_len` (was 12)
  - `hamt-assoc`, `hamt-dissoc`: Write hashes to hash array during node build
  - All 4 `make-bitmap-node-*` functions: Build hash array, adjust KV offsets
- `sab_set.cljs`: Needs same header change but sets have independent value layout
  (no hash per entry). Sets do NOT get a hash array — their KV format is different.
  Only change: NODE_HEADER_SIZE 10→12.
- `wasm_mem.wat`:
  - `$skip_kv`: Now skips `4 + key_len + 4 + val_len` (was `4 + 4 + key_len + 4 + val_len`)
  - `$hamt_find`: Read hash from hash_array[idx] instead of kv_entry+0
  - `$kv_start`: Becomes `$kv_data_start` = offset + 12 + C×4 + M×4
  - All builder functions: Copy/write hash arrays
  - New helper: `$hashes_start` = offset + 12 + popcount(node_bm) × 4

### 3C. SIMD hamt_find with hash pre-filter

New/updated WAT function:
```wat
(func $hamt_find_simd
  ;; At each HAMT level, when checking data entries:
  ;; 1. Load up to 4 hashes: v128.load(hashes_start + i*16)
  ;; 2. i32x4.eq(splat(target_hash)) → match_mask
  ;; 3. If any match: byte-compare key at kv_data for that index
  ;; 4. Skip all non-matching entries (no skip_kv traversal needed!)
  ;;
  ;; Key insight: we know the index of the matching hash lane,
  ;; but still need to walk kv_data to find that entry's offset.
  ;; Optimization: store cumulative byte offsets? Or just walk from start.
  ;; For most nodes (1-4 entries), one v128 load + one walk suffices.
)
```

Biggest win: nodes with 2-8 entries. Currently `hamt_find` walks all entries
serially. With SIMD hash pre-filter, we identify the matching entry in one
v128 comparison, then walk to only that entry.

### 3D. Update WASM node builder functions

All 5 builders must handle the new layout:
- `build_node_replace_child`: Copy hash array unchanged (memcpy)
- `build_node_replace_kv`: Replace hash_array[idx], copy rest; copy/replace KV
- `build_node_add_kv`: Insert into hash_array (shift right), insert KV
- `build_node_remove_kv_add_child`: Remove from hash_array, remove KV

### 3E. Tests
- All 66 existing tests must pass
- Verify round-trip: build map → check all keys/values → dissoc → verify
- Large map tests (n=200, n=500) exercise deep HAMT paths
- Collision node tests (hash collisions still use old format)

### Benchmark Checkpoint 3
```
Measure BEFORE (Phase 2 done) and AFTER:
  - get n=10, n=100          (hamt_find — main beneficiary)
  - contains? n=100          (set lookup)
  - assoc n=10, n=100        (find + build)
  - build n=10, n=100        (repeated assoc)
  - reduce-kv n=100          (traverse all entries)
  - swap! (assoc :x random)  (full read-modify-write)
  - @atom -> get-in [:a :b :c]  (nested lookup)
```

---

## Phase 4: SIMD Bulk Memcpy in Node Builders

### Goal
Replace byte-by-byte `$memcpy` in WASM node builders with v128 bulk copy.

### 4A. SIMD memcpy

New WAT function:
```wat
(func $memcpy_simd (param $dst i32) (param $src i32) (param $len i32)
  ;; Main loop: 16 bytes per iteration
  ;;   v128.load(src + i) → v128.store(dst + i)
  ;; Scalar tail: byte-by-byte for len % 16
)
```

Replace `$memcpy` calls in all node builder functions with `$memcpy_simd`.

### 4B. SIMD child array copy

In `build_node_replace_kv` and `build_node_replace_child`, child arrays are
copied element-by-element (4 bytes each). With v128:
- 4 children copied per v128.load/v128.store
- Most nodes have ≤4 children → one SIMD op

### 4C. SIMD hash array copy

Same pattern for hash array copies in Phase 3 builders.

### Benchmark Checkpoint 4 — Final
```
Measure BEFORE (Phase 3 done) and AFTER:
  All previous metrics + large scale:
  - build n=500, n=1000      (stress allocation + node building)
  - assoc n=500              (deep HAMT)
  - dissoc n=100             (node removal + retire)
  - transient build n=100    (batch build)
  - Full benchmark suite comparison:
    Original baseline (pre-Phase 1) vs Final (Phase 4 complete)
```

---

## Benchmark Harness

Add to `perf_benchmark.cljs`:

```clojure
(defn bench-alloc []
  (println "\n=== Allocation ===\n")
  (fresh-atom!)
  ;; Batch alloc 100 blocks of size 64 (pool-miss scenario)
  (let [env (atom/get-env atom/*global-atom-instance*)]
    (print-row "batch-alloc 100×64B"
      (bench #(atom/batch-alloc env 64 100) :iters 20 :warmup 3))))

(defn bench-sweep []
  (println "\n=== GC Sweep ===\n")
  (fresh-atom!)
  ;; Create 200 retired blocks by building + replacing maps
  (dotimes [_ 20]
    (swap! atom/*global-atom-instance* assoc :x (rand-int 1000)))
  (let [env (atom/get-env atom/*global-atom-instance*)]
    (print-row "sweep (after 20 swaps)"
      (bench #(atom/sweep-retired-blocks! env) :iters 50 :warmup 5))))
```

Each phase: run full benchmark, save output to `benchmarks/phase-N.txt`,
include in commit message.

---

## Risk Mitigation

1. **Mirror sync bugs**: Status/capacity mirrors must match descriptor table exactly.
   Add debug-mode assertion that walks entire table verifying mirrors on each alloc.
   Disable in production.

2. **Node format migration**: Phase 3 changes node layout. All nodes in a single
   atom share the same format (no mixed old/new). The flags byte allows detection
   but we won't support mixed formats — one atomic cutover per phase.

3. **WASM binary size**: Each phase adds functions. Track binary size.
   Budget: ≤8 KB total (currently 3,872 bytes, ~4 KB headroom).

4. **Regression detection**: Run full 66-test suite after every sub-step.
   Any failure = stop and fix before continuing.
